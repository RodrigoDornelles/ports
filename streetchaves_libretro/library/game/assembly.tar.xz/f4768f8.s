; entry 4768f8
4768f8: push ebp
4768f9: mov ebp,esp
4768fb: push ebx
4768fc: push esi
4768fd: imul esi,eax,0x16
476900: mov ebx,DWORD PTR ds:0x4b0ef0
476906: movzx ebx,BYTE PTR [ebx+esi*8-0x45]
47690b: cmp edx,ebx
47690d: jne 0x4769be
476913: mov edx,DWORD PTR ds:0x4b0ef0
476919: movsx edx,WORD PTR [edx+esi*8-0x3c]
47691e: cmp ecx,edx
476920: jne 0x4769be
476926: mov edx,DWORD PTR ds:0x4b0ef0
47692c: mov ecx,DWORD PTR [ebp+0x24]
47692f: mov DWORD PTR [edx+esi*8-0x80],ecx
476933: mov edx,DWORD PTR ds:0x4b0ef0
476939: mov ecx,DWORD PTR [ebp+0x20]
47693c: mov DWORD PTR [edx+esi*8-0x7c],ecx
476940: mov edx,DWORD PTR ds:0x4b0ef0
476946: mov ecx,DWORD PTR [ebp+0x1c]
476949: mov DWORD PTR [edx+esi*8-0x78],ecx
47694d: mov edx,DWORD PTR ds:0x4b0ef0
476953: mov ecx,DWORD PTR [ebp+0x18]
476956: mov DWORD PTR [edx+esi*8-0x74],ecx
47695a: mov edx,DWORD PTR ds:0x4b0ef0
476960: cmp BYTE PTR [edx+esi*8-0x43],0x2
476965: jne 0x476985
476967: mov edx,DWORD PTR ds:0x4b0ef0
47696d: mov ecx,DWORD PTR [ebp+0x1c]
476970: neg ecx
476972: mov DWORD PTR [edx+esi*8-0x80],ecx
476976: mov edx,DWORD PTR ds:0x4b0ef0
47697c: mov ecx,DWORD PTR [ebp+0x24]
47697f: neg ecx
476981: mov DWORD PTR [edx+esi*8-0x78],ecx
476985: mov edx,DWORD PTR ds:0x4b0ef0
47698b: mov cl,BYTE PTR [ebp+0x14]
47698e: mov BYTE PTR [edx+esi*8-0x48],cl
476992: cmp DWORD PTR [ebp+0x10],0x0
476996: je 0x4769a5
476998: mov edx,DWORD PTR ds:0x4b0ef0
47699e: mov cl,BYTE PTR [ebp+0x10]
4769a1: mov BYTE PTR [edx+esi*8-0x41],cl
4769a5: mov edx,DWORD PTR ds:0x4b0ef0
4769ab: mov cl,BYTE PTR [ebp+0xc]
4769ae: mov BYTE PTR [edx+esi*8-0x40],cl
4769b2: mov eax,ds:0x4b0ef0
4769b7: mov dl,BYTE PTR [ebp+0x8]
4769ba: mov BYTE PTR [eax+esi*8-0x3f],dl
4769be: pop esi
4769bf: pop ebx
4769c0: pop ebp
4769c1: ret 0x20
.data 4b0ef0 e8444b000c204b0030b8
