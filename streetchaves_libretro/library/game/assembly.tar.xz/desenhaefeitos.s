; entry 48edfc
; exit 403468
48edfc: push ebp
48edfd: mov ebp,esp
48edff: add esp,0xffffffe0
48ee02: push ebx
48ee03: push esi
48ee04: push edi
48ee05: xor edx,edx
48ee07: mov DWORD PTR [ebp-0x20],edx
48ee0a: mov DWORD PTR [ebp-0x1c],edx
48ee0d: mov DWORD PTR [ebp-0x4],eax
48ee10: xor eax,eax
48ee12: push ebp
48ee13: push 0x49055a
48ee18: push DWORD PTR fs:[eax]
48ee1b: mov DWORD PTR fs:[eax],esp
48ee1e: mov DWORD PTR [ebp-0x8],0x1
48ee25: mov ebx,DWORD PTR ds:0x4b1118
48ee2b: add ebx,0x2b
48ee2e: mov al,BYTE PTR [ebx]
48ee30: test al,al
48ee32: je 0x49052f
48ee38: cmp al,0x1
48ee3a: jne 0x48ee5a
48ee3c: cmp BYTE PTR [ebx+0x1],0x0
48ee40: jne 0x48ee46
48ee42: mov BYTE PTR [ebx+0x3],0x1
48ee46: cmp BYTE PTR [ebx+0x1],0x1
48ee4a: jne 0x48ee50
48ee4c: mov BYTE PTR [ebx+0x3],0x2
48ee50: cmp BYTE PTR [ebx+0x1],0x3
48ee54: jne 0x48ee5a
48ee56: mov BYTE PTR [ebx+0x3],0x3
48ee5a: cmp BYTE PTR [ebx],0x2
48ee5d: jne 0x48eeb2
48ee5f: cmp BYTE PTR [ebx+0x1],0x0
48ee63: jne 0x48ee69
48ee65: mov BYTE PTR [ebx+0x3],0x4
48ee69: cmp BYTE PTR [ebx+0x1],0x3
48ee6d: jne 0x48ee73
48ee6f: mov BYTE PTR [ebx+0x3],0x5
48ee73: cmp BYTE PTR [ebx+0x1],0x6
48ee77: jne 0x48ee7d
48ee79: mov BYTE PTR [ebx+0x3],0x6
48ee7d: cmp BYTE PTR [ebx+0x1],0x9
48ee81: jne 0x48ee87
48ee83: mov BYTE PTR [ebx+0x3],0x7
48ee87: cmp BYTE PTR [ebx+0x1],0xc
48ee8b: jne 0x48ee91
48ee8d: mov BYTE PTR [ebx+0x3],0x8
48ee91: mov eax,ds:0x4b1074
48ee96: cmp BYTE PTR [eax],0x0
48ee99: jne 0x48eeb2
48ee9b: mov eax,ds:0x4b0e84
48eea0: cmp BYTE PTR [eax],0x0
48eea3: jne 0x48eeb2
48eea5: fld QWORD PTR [ebx-0x23]
48eea8: fsub DWORD PTR ds:0x490568
48eeae: fstp QWORD PTR [ebx-0x23]
48eeb1: fwait
48eeb2: cmp BYTE PTR [ebx],0x3
48eeb5: jne 0x48eed0
48eeb7: mov BYTE PTR [ebx+0x3],0xa
48eebb: xor eax,eax
48eebd: mov al,BYTE PTR [ebx+0x1]
48eec0: xor edx,edx
48eec2: mov dl,BYTE PTR [ebx+0x2]
48eec5: sub edx,0x14
48eec8: cmp eax,edx
48eeca: jl 0x48eed0
48eecc: mov BYTE PTR [ebx-0x3],0x1
48eed0: cmp BYTE PTR [ebx],0x4
48eed3: jne 0x48eeee
48eed5: mov BYTE PTR [ebx+0x3],0xb
48eed9: xor eax,eax
48eedb: mov al,BYTE PTR [ebx+0x1]
48eede: xor edx,edx
48eee0: mov dl,BYTE PTR [ebx+0x2]
48eee3: sub edx,0x14
48eee6: cmp eax,edx
48eee8: jl 0x48eeee
48eeea: mov BYTE PTR [ebx-0x3],0x1
48eeee: cmp BYTE PTR [ebx],0x5
48eef1: jne 0x48ef08
48eef3: xor eax,eax
48eef5: mov al,BYTE PTR [ebx+0x1]
48eef8: xor edx,edx
48eefa: mov dl,BYTE PTR [ebx+0x2]
48eefd: sub edx,0xa
48ef00: cmp eax,edx
48ef02: jl 0x48ef08
48ef04: mov BYTE PTR [ebx-0x3],0x1
48ef08: cmp BYTE PTR [ebx],0x6
48ef0b: jne 0x48ef11
48ef0d: mov BYTE PTR [ebx+0x3],0xc
48ef11: cmp BYTE PTR [ebx],0x7
48ef14: jne 0x48ef20
48ef16: cmp BYTE PTR [ebx+0x1],0x0
48ef1a: jne 0x48ef20
48ef1c: mov BYTE PTR [ebx+0x3],0xd
48ef20: cmp BYTE PTR [ebx],0x7
48ef23: jne 0x48ef2f
48ef25: cmp BYTE PTR [ebx+0x1],0x1
48ef29: jne 0x48ef2f
48ef2b: mov BYTE PTR [ebx+0x3],0xd
48ef2f: cmp BYTE PTR [ebx],0x7
48ef32: jne 0x48ef3e
48ef34: cmp BYTE PTR [ebx+0x1],0x2
48ef38: jne 0x48ef3e
48ef3a: mov BYTE PTR [ebx+0x3],0xe
48ef3e: cmp BYTE PTR [ebx],0x7
48ef41: jne 0x48ef4d
48ef43: cmp BYTE PTR [ebx+0x1],0x3
48ef47: jne 0x48ef4d
48ef49: mov BYTE PTR [ebx+0x1],0x0
48ef4d: cmp BYTE PTR [ebx],0x8
48ef50: jne 0x48ef5c
48ef52: cmp BYTE PTR [ebx+0x1],0x0
48ef56: jne 0x48ef5c
48ef58: mov BYTE PTR [ebx+0x3],0xf
48ef5c: cmp BYTE PTR [ebx],0x8
48ef5f: jne 0x48ef6b
48ef61: cmp BYTE PTR [ebx+0x1],0x2
48ef65: jne 0x48ef6b
48ef67: mov BYTE PTR [ebx+0x3],0x10
48ef6b: cmp BYTE PTR [ebx],0x8
48ef6e: jne 0x48ef7a
48ef70: cmp BYTE PTR [ebx+0x1],0x5
48ef74: jne 0x48ef7a
48ef76: mov BYTE PTR [ebx+0x3],0x11
48ef7a: cmp BYTE PTR [ebx],0x8
48ef7d: jne 0x48ef89
48ef7f: cmp BYTE PTR [ebx+0x1],0x5
48ef83: jne 0x48ef89
48ef85: mov BYTE PTR [ebx-0x3],0x1
48ef89: cmp BYTE PTR [ebx],0x9
48ef8c: jne 0x48ef98
48ef8e: cmp BYTE PTR [ebx+0x1],0x0
48ef92: jne 0x48ef98
48ef94: mov BYTE PTR [ebx+0x3],0x12
48ef98: cmp BYTE PTR [ebx],0x9
48ef9b: jne 0x48efa7
48ef9d: cmp BYTE PTR [ebx+0x1],0x1
48efa1: jne 0x48efa7
48efa3: mov BYTE PTR [ebx+0x3],0x12
48efa7: cmp BYTE PTR [ebx],0x9
48efaa: jne 0x48efb6
48efac: cmp BYTE PTR [ebx+0x1],0x2
48efb0: jne 0x48efb6
48efb2: mov BYTE PTR [ebx+0x3],0x13
48efb6: cmp BYTE PTR [ebx],0x9
48efb9: jne 0x48efc5
48efbb: cmp BYTE PTR [ebx+0x1],0x3
48efbf: jne 0x48efc5
48efc1: mov BYTE PTR [ebx+0x1],0x0
48efc5: cmp BYTE PTR [ebx],0xa
48efc8: jne 0x48efd4
48efca: cmp BYTE PTR [ebx+0x1],0x0
48efce: jne 0x48efd4
48efd0: mov BYTE PTR [ebx+0x3],0x14
48efd4: cmp BYTE PTR [ebx],0xa
48efd7: jne 0x48efe3
48efd9: cmp BYTE PTR [ebx+0x1],0x2
48efdd: jne 0x48efe3
48efdf: mov BYTE PTR [ebx+0x3],0x15
48efe3: cmp BYTE PTR [ebx],0xa
48efe6: jne 0x48eff2
48efe8: cmp BYTE PTR [ebx+0x1],0x4
48efec: jne 0x48eff2
48efee: mov BYTE PTR [ebx+0x3],0x16
48eff2: cmp BYTE PTR [ebx],0xa
48eff5: jne 0x48f001
48eff7: cmp BYTE PTR [ebx+0x1],0x6
48effb: jne 0x48f001
48effd: mov BYTE PTR [ebx+0x3],0x17
48f001: cmp BYTE PTR [ebx],0xa
48f004: jne 0x48f010
48f006: cmp BYTE PTR [ebx+0x1],0x8
48f00a: jne 0x48f010
48f00c: mov BYTE PTR [ebx+0x3],0x18
48f010: cmp BYTE PTR [ebx],0xa
48f013: jne 0x48f01f
48f015: cmp BYTE PTR [ebx+0x1],0xa
48f019: jne 0x48f01f
48f01b: mov BYTE PTR [ebx+0x3],0x19
48f01f: cmp BYTE PTR [ebx],0xa
48f022: jne 0x48f02e
48f024: cmp BYTE PTR [ebx+0x1],0xc
48f028: jne 0x48f02e
48f02a: mov BYTE PTR [ebx+0x3],0x1a
48f02e: cmp BYTE PTR [ebx],0xb
48f031: jne 0x48f03d
48f033: cmp BYTE PTR [ebx+0x1],0x0
48f037: jne 0x48f03d
48f039: mov BYTE PTR [ebx+0x3],0x1b
48f03d: cmp BYTE PTR [ebx],0xb
48f040: jne 0x48f04c
48f042: cmp BYTE PTR [ebx+0x1],0x3
48f046: jne 0x48f04c
48f048: mov BYTE PTR [ebx+0x3],0x1c
48f04c: cmp BYTE PTR [ebx],0xb
48f04f: jne 0x48f05b
48f051: cmp BYTE PTR [ebx+0x1],0x6
48f055: jne 0x48f05b
48f057: mov BYTE PTR [ebx+0x3],0x1d
48f05b: cmp BYTE PTR [ebx],0xb
48f05e: jne 0x48f06a
48f060: cmp BYTE PTR [ebx+0x1],0x9
48f064: jne 0x48f06a
48f066: mov BYTE PTR [ebx+0x3],0x1e
48f06a: cmp BYTE PTR [ebx],0xb
48f06d: jne 0x48f079
48f06f: cmp BYTE PTR [ebx+0x1],0xc
48f073: jne 0x48f079
48f075: mov BYTE PTR [ebx+0x3],0x1f
48f079: cmp BYTE PTR [ebx],0xc
48f07c: jne 0x48f088
48f07e: cmp BYTE PTR [ebx+0x1],0x0
48f082: jne 0x48f088
48f084: mov BYTE PTR [ebx+0x3],0x20
48f088: cmp BYTE PTR [ebx],0xc
48f08b: jne 0x48f097
48f08d: cmp BYTE PTR [ebx+0x1],0x1
48f091: jne 0x48f097
48f093: mov BYTE PTR [ebx+0x3],0x20
48f097: cmp BYTE PTR [ebx],0xc
48f09a: jne 0x48f0a6
48f09c: cmp BYTE PTR [ebx+0x1],0x2
48f0a0: jne 0x48f0a6
48f0a2: mov BYTE PTR [ebx+0x3],0x21
48f0a6: cmp BYTE PTR [ebx],0xc
48f0a9: jne 0x48f0b5
48f0ab: cmp BYTE PTR [ebx+0x1],0x3
48f0af: jne 0x48f0b5
48f0b1: mov BYTE PTR [ebx+0x1],0x0
48f0b5: cmp BYTE PTR [ebx],0xd
48f0b8: jne 0x48f0c4
48f0ba: cmp BYTE PTR [ebx+0x1],0x0
48f0be: jne 0x48f0c4
48f0c0: mov BYTE PTR [ebx+0x3],0x22
48f0c4: cmp BYTE PTR [ebx],0xd
48f0c7: jne 0x48f0d3
48f0c9: cmp BYTE PTR [ebx+0x1],0x1
48f0cd: jne 0x48f0d3
48f0cf: mov BYTE PTR [ebx+0x3],0x22
48f0d3: cmp BYTE PTR [ebx],0xd
48f0d6: jne 0x48f0e2
48f0d8: cmp BYTE PTR [ebx+0x1],0x2
48f0dc: jne 0x48f0e2
48f0de: mov BYTE PTR [ebx+0x3],0x23
48f0e2: cmp BYTE PTR [ebx],0xd
48f0e5: jne 0x48f0f1
48f0e7: cmp BYTE PTR [ebx+0x1],0x3
48f0eb: jne 0x48f0f1
48f0ed: mov BYTE PTR [ebx+0x1],0x0
48f0f1: cmp BYTE PTR [ebx],0xe
48f0f4: jne 0x48f100
48f0f6: cmp BYTE PTR [ebx+0x1],0x0
48f0fa: jne 0x48f100
48f0fc: mov BYTE PTR [ebx+0x3],0x24
48f100: cmp BYTE PTR [ebx],0xe
48f103: jne 0x48f10f
48f105: cmp BYTE PTR [ebx+0x1],0x2
48f109: jne 0x48f10f
48f10b: mov BYTE PTR [ebx+0x3],0x25
48f10f: cmp BYTE PTR [ebx],0xe
48f112: jne 0x48f11e
48f114: cmp BYTE PTR [ebx+0x1],0x4
48f118: jne 0x48f11e
48f11a: mov BYTE PTR [ebx+0x3],0x26
48f11e: cmp BYTE PTR [ebx],0xf
48f121: jne 0x48f12d
48f123: cmp BYTE PTR [ebx+0x1],0x0
48f127: jne 0x48f12d
48f129: mov BYTE PTR [ebx+0x3],0x27
48f12d: cmp BYTE PTR [ebx],0xf
48f130: jne 0x48f13c
48f132: cmp BYTE PTR [ebx+0x1],0x1
48f136: jne 0x48f13c
48f138: mov BYTE PTR [ebx+0x3],0x27
48f13c: cmp BYTE PTR [ebx],0xf
48f13f: jne 0x48f14b
48f141: cmp BYTE PTR [ebx+0x1],0x2
48f145: jne 0x48f14b
48f147: mov BYTE PTR [ebx+0x3],0x28
48f14b: cmp BYTE PTR [ebx],0xf
48f14e: jne 0x48f15a
48f150: cmp BYTE PTR [ebx+0x1],0x3
48f154: jne 0x48f15a
48f156: mov BYTE PTR [ebx+0x1],0x0
48f15a: cmp BYTE PTR [ebx],0x10
48f15d: jne 0x48f169
48f15f: cmp BYTE PTR [ebx+0x1],0x0
48f163: jne 0x48f169
48f165: mov BYTE PTR [ebx+0x3],0x29
48f169: cmp BYTE PTR [ebx],0x10
48f16c: jne 0x48f178
48f16e: cmp BYTE PTR [ebx+0x1],0x2
48f172: jne 0x48f178
48f174: mov BYTE PTR [ebx+0x3],0x2a
48f178: cmp BYTE PTR [ebx],0x10
48f17b: jne 0x48f187
48f17d: cmp BYTE PTR [ebx+0x1],0x4
48f181: jne 0x48f187
48f183: mov BYTE PTR [ebx+0x3],0x2b
48f187: cmp BYTE PTR [ebx],0x11
48f18a: jne 0x48f196
48f18c: cmp BYTE PTR [ebx+0x1],0x0
48f190: jne 0x48f196
48f192: mov BYTE PTR [ebx+0x3],0x2c
48f196: cmp BYTE PTR [ebx],0x11
48f199: jne 0x48f1a5
48f19b: cmp BYTE PTR [ebx+0x1],0x4
48f19f: jne 0x48f1a5
48f1a1: mov BYTE PTR [ebx+0x3],0x2d
48f1a5: cmp BYTE PTR [ebx],0x11
48f1a8: jne 0x48f1b4
48f1aa: cmp BYTE PTR [ebx+0x1],0x8
48f1ae: jne 0x48f1b4
48f1b0: mov BYTE PTR [ebx+0x3],0x2e
48f1b4: cmp BYTE PTR [ebx],0x12
48f1b7: jne 0x48f1c3
48f1b9: cmp BYTE PTR [ebx+0x1],0x0
48f1bd: jne 0x48f1c3
48f1bf: mov BYTE PTR [ebx+0x3],0x2f
48f1c3: cmp BYTE PTR [ebx],0x12
48f1c6: jne 0x48f1d2
48f1c8: cmp BYTE PTR [ebx+0x1],0x1
48f1cc: jne 0x48f1d2
48f1ce: mov BYTE PTR [ebx+0x3],0x2f
48f1d2: cmp BYTE PTR [ebx],0x12
48f1d5: jne 0x48f1e1
48f1d7: cmp BYTE PTR [ebx+0x1],0x2
48f1db: jne 0x48f1e1
48f1dd: mov BYTE PTR [ebx+0x3],0x30
48f1e1: cmp BYTE PTR [ebx],0x12
48f1e4: jne 0x48f1f0
48f1e6: cmp BYTE PTR [ebx+0x1],0x3
48f1ea: jne 0x48f1f0
48f1ec: mov BYTE PTR [ebx+0x1],0x0
48f1f0: cmp BYTE PTR [ebx],0x13
48f1f3: jne 0x48f1ff
48f1f5: cmp BYTE PTR [ebx+0x1],0x0
48f1f9: jne 0x48f1ff
48f1fb: mov BYTE PTR [ebx+0x3],0x31
48f1ff: cmp BYTE PTR [ebx],0x13
48f202: jne 0x48f20e
48f204: cmp BYTE PTR [ebx+0x1],0x1
48f208: jne 0x48f20e
48f20a: mov BYTE PTR [ebx+0x3],0x31
48f20e: cmp BYTE PTR [ebx],0x13
48f211: jne 0x48f21d
48f213: cmp BYTE PTR [ebx+0x1],0x2
48f217: jne 0x48f21d
48f219: mov BYTE PTR [ebx+0x3],0x32
48f21d: cmp BYTE PTR [ebx],0x13
48f220: jne 0x48f22c
48f222: cmp BYTE PTR [ebx+0x1],0x3
48f226: jne 0x48f22c
48f228: mov BYTE PTR [ebx+0x1],0x0
48f22c: cmp BYTE PTR [ebx],0x14
48f22f: jne 0x48f23b
48f231: cmp BYTE PTR [ebx+0x1],0x0
48f235: jne 0x48f23b
48f237: mov BYTE PTR [ebx+0x3],0x33
48f23b: cmp BYTE PTR [ebx],0x14
48f23e: jne 0x48f24a
48f240: cmp BYTE PTR [ebx+0x1],0x1
48f244: jne 0x48f24a
48f246: mov BYTE PTR [ebx+0x3],0x33
48f24a: cmp BYTE PTR [ebx],0x14
48f24d: jne 0x48f259
48f24f: cmp BYTE PTR [ebx+0x1],0x2
48f253: jne 0x48f259
48f255: mov BYTE PTR [ebx+0x3],0x34
48f259: cmp BYTE PTR [ebx],0x14
48f25c: jne 0x48f268
48f25e: cmp BYTE PTR [ebx+0x1],0x3
48f262: jne 0x48f268
48f264: mov BYTE PTR [ebx+0x1],0x0
48f268: cmp BYTE PTR [ebx],0x17
48f26b: jne 0x48f277
48f26d: cmp BYTE PTR [ebx+0x1],0x0
48f271: jne 0x48f277
48f273: mov BYTE PTR [ebx+0x3],0x39
48f277: cmp BYTE PTR [ebx],0x17
48f27a: jne 0x48f286
48f27c: cmp BYTE PTR [ebx+0x1],0x2
48f280: jne 0x48f286
48f282: mov BYTE PTR [ebx+0x3],0x3a
48f286: cmp BYTE PTR [ebx],0x17
48f289: jne 0x48f295
48f28b: cmp BYTE PTR [ebx+0x1],0x4
48f28f: jne 0x48f295
48f291: mov BYTE PTR [ebx+0x3],0x39
48f295: cmp BYTE PTR [ebx],0x17
48f298: jne 0x48f2a4
48f29a: cmp BYTE PTR [ebx+0x1],0x6
48f29e: jne 0x48f2a4
48f2a0: mov BYTE PTR [ebx+0x3],0x3a
48f2a4: cmp BYTE PTR [ebx],0x17
48f2a7: jne 0x48f2b3
48f2a9: cmp BYTE PTR [ebx+0x1],0x8
48f2ad: jne 0x48f2b3
48f2af: mov BYTE PTR [ebx+0x3],0x39
48f2b3: cmp BYTE PTR [ebx],0x17
48f2b6: jne 0x48f2c2
48f2b8: cmp BYTE PTR [ebx+0x1],0xa
48f2bc: jne 0x48f2c2
48f2be: mov BYTE PTR [ebx+0x3],0x3a
48f2c2: cmp BYTE PTR [ebx],0x17
48f2c5: jne 0x48f2d1
48f2c7: cmp BYTE PTR [ebx+0x1],0xc
48f2cb: jne 0x48f2d1
48f2cd: mov BYTE PTR [ebx+0x3],0x39
48f2d1: cmp BYTE PTR [ebx],0x17
48f2d4: jne 0x48f2e0
48f2d6: cmp BYTE PTR [ebx+0x1],0xe
48f2da: jne 0x48f2e0
48f2dc: mov BYTE PTR [ebx+0x3],0x3a
48f2e0: cmp BYTE PTR [ebx],0x17
48f2e3: jne 0x48f2ef
48f2e5: cmp BYTE PTR [ebx+0x1],0x10
48f2e9: jne 0x48f2ef
48f2eb: mov BYTE PTR [ebx+0x3],0x39
48f2ef: cmp BYTE PTR [ebx],0x17
48f2f2: jne 0x48f2fe
48f2f4: cmp BYTE PTR [ebx+0x1],0x12
48f2f8: jne 0x48f2fe
48f2fa: mov BYTE PTR [ebx+0x3],0x3a
48f2fe: cmp BYTE PTR [ebx],0x17
48f301: jne 0x48f30d
48f303: cmp BYTE PTR [ebx+0x1],0x14
48f307: jne 0x48f30d
48f309: mov BYTE PTR [ebx+0x3],0x39
48f30d: cmp BYTE PTR [ebx],0x17
48f310: jne 0x48f31c
48f312: cmp BYTE PTR [ebx+0x1],0x16
48f316: jne 0x48f31c
48f318: mov BYTE PTR [ebx+0x3],0x4f
48f31c: cmp BYTE PTR [ebx],0x17
48f31f: jne 0x48f32b
48f321: cmp BYTE PTR [ebx+0x1],0x18
48f325: jne 0x48f32b
48f327: mov BYTE PTR [ebx+0x3],0x3c
48f32b: cmp BYTE PTR [ebx],0x18
48f32e: jne 0x48f345
48f330: xor eax,eax
48f332: mov al,BYTE PTR [ebx+0x1]
48f335: xor edx,edx
48f337: mov dl,BYTE PTR [ebx+0x2]
48f33a: sub edx,0xa
48f33d: cmp eax,edx
48f33f: jge 0x48f345
48f341: mov BYTE PTR [ebx+0x3],0x3d
48f345: cmp BYTE PTR [ebx],0x18
48f348: jne 0x48f35f
48f34a: xor eax,eax
48f34c: mov al,BYTE PTR [ebx+0x1]
48f34f: xor edx,edx
48f351: mov dl,BYTE PTR [ebx+0x2]
48f354: sub edx,0xa
48f357: cmp eax,edx
48f359: jl 0x48f35f
48f35b: mov BYTE PTR [ebx+0x3],0x3e
48f35f: cmp BYTE PTR [ebx],0x19
48f362: jne 0x48f36e
48f364: cmp BYTE PTR [ebx+0x1],0xc
48f368: jae 0x48f36e
48f36a: mov BYTE PTR [ebx+0x3],0x3f
48f36e: cmp BYTE PTR [ebx],0x19
48f371: jne 0x48f383
48f373: cmp BYTE PTR [ebx+0x1],0xc
48f377: jb 0x48f383
48f379: cmp BYTE PTR [ebx+0x1],0x18
48f37d: jae 0x48f383
48f37f: mov BYTE PTR [ebx+0x3],0x40
48f383: cmp BYTE PTR [ebx],0x19
48f386: jne 0x48f392
48f388: cmp BYTE PTR [ebx+0x1],0x18
48f38c: jb 0x48f392
48f38e: mov BYTE PTR [ebx+0x3],0x41
48f392: cmp BYTE PTR [ebx],0x1a
48f395: jne 0x48f3a1
48f397: cmp BYTE PTR [ebx+0x1],0x0
48f39b: jne 0x48f3a1
48f39d: mov BYTE PTR [ebx+0x3],0x42
48f3a1: cmp BYTE PTR [ebx],0x1a
48f3a4: jne 0x48f3b0
48f3a6: cmp BYTE PTR [ebx+0x1],0x1
48f3aa: jne 0x48f3b0
48f3ac: mov BYTE PTR [ebx+0x3],0x42
48f3b0: cmp BYTE PTR [ebx],0x1a
48f3b3: jne 0x48f3bf
48f3b5: cmp BYTE PTR [ebx+0x1],0x4
48f3b9: jne 0x48f3bf
48f3bb: mov BYTE PTR [ebx+0x3],0x43
48f3bf: cmp BYTE PTR [ebx],0x1a
48f3c2: jne 0x48f3ce
48f3c4: cmp BYTE PTR [ebx+0x1],0x6
48f3c8: jne 0x48f3ce
48f3ca: mov BYTE PTR [ebx+0x1],0x0
48f3ce: cmp BYTE PTR [ebx],0x1b
48f3d1: jne 0x48f3dd
48f3d3: cmp BYTE PTR [ebx+0x1],0x0
48f3d7: jne 0x48f3dd
48f3d9: mov BYTE PTR [ebx+0x3],0x44
48f3dd: cmp BYTE PTR [ebx],0x1b
48f3e0: jne 0x48f3ec
48f3e2: cmp BYTE PTR [ebx+0x1],0x1
48f3e6: jne 0x48f3ec
48f3e8: mov BYTE PTR [ebx+0x3],0x44
48f3ec: cmp BYTE PTR [ebx],0x1b
48f3ef: jne 0x48f3fb
48f3f1: cmp BYTE PTR [ebx+0x1],0x4
48f3f5: jne 0x48f3fb
48f3f7: mov BYTE PTR [ebx+0x3],0x45
48f3fb: cmp BYTE PTR [ebx],0x1b
48f3fe: jne 0x48f40a
48f400: cmp BYTE PTR [ebx+0x1],0x6
48f404: jne 0x48f40a
48f406: mov BYTE PTR [ebx+0x1],0x0
48f40a: cmp BYTE PTR [ebx],0x1c
48f40d: jne 0x48f419
48f40f: cmp BYTE PTR [ebx+0x1],0x0
48f413: jne 0x48f419
48f415: mov BYTE PTR [ebx+0x3],0x46
48f419: cmp BYTE PTR [ebx],0x1c
48f41c: jne 0x48f428
48f41e: cmp BYTE PTR [ebx+0x1],0x1
48f422: jne 0x48f428
48f424: mov BYTE PTR [ebx+0x3],0x46
48f428: cmp BYTE PTR [ebx],0x1c
48f42b: jne 0x48f437
48f42d: cmp BYTE PTR [ebx+0x1],0x3
48f431: jne 0x48f437
48f433: mov BYTE PTR [ebx+0x3],0x47
48f437: cmp BYTE PTR [ebx],0x1c
48f43a: jne 0x48f446
48f43c: cmp BYTE PTR [ebx+0x1],0x4
48f440: jne 0x48f446
48f442: mov BYTE PTR [ebx+0x1],0x0
48f446: cmp BYTE PTR [ebx],0x1d
48f449: jne 0x48f455
48f44b: cmp BYTE PTR [ebx+0x1],0x0
48f44f: jne 0x48f455
48f451: mov BYTE PTR [ebx+0x3],0x48
48f455: cmp BYTE PTR [ebx],0x1d
48f458: jne 0x48f464
48f45a: cmp BYTE PTR [ebx+0x1],0x2
48f45e: jne 0x48f464
48f460: mov BYTE PTR [ebx+0x3],0x48
48f464: cmp BYTE PTR [ebx],0x1d
48f467: jne 0x48f473
48f469: cmp BYTE PTR [ebx+0x1],0x4
48f46d: jne 0x48f473
48f46f: mov BYTE PTR [ebx+0x3],0x49
48f473: cmp BYTE PTR [ebx],0x1d
48f476: jne 0x48f482
48f478: cmp BYTE PTR [ebx+0x1],0x5
48f47c: jne 0x48f482
48f47e: mov BYTE PTR [ebx+0x3],0x4a
48f482: cmp BYTE PTR [ebx],0x1d
48f485: jne 0x48f491
48f487: cmp BYTE PTR [ebx+0x1],0x6
48f48b: jne 0x48f491
48f48d: mov BYTE PTR [ebx+0x1],0x0
48f491: cmp BYTE PTR [ebx],0x1e
48f494: jne 0x48f4a0
48f496: cmp BYTE PTR [ebx+0x1],0x0
48f49a: jne 0x48f4a0
48f49c: mov BYTE PTR [ebx+0x3],0x4b
48f4a0: cmp BYTE PTR [ebx],0x1e
48f4a3: jne 0x48f4af
48f4a5: cmp BYTE PTR [ebx+0x1],0x1
48f4a9: jne 0x48f4af
48f4ab: mov BYTE PTR [ebx+0x3],0x4b
48f4af: cmp BYTE PTR [ebx],0x1e
48f4b2: jne 0x48f4be
48f4b4: cmp BYTE PTR [ebx+0x1],0x4
48f4b8: jne 0x48f4be
48f4ba: mov BYTE PTR [ebx+0x3],0x4c
48f4be: cmp BYTE PTR [ebx],0x1e
48f4c1: jne 0x48f4cd
48f4c3: cmp BYTE PTR [ebx+0x1],0x5
48f4c7: jne 0x48f4cd
48f4c9: mov BYTE PTR [ebx+0x1],0x0
48f4cd: cmp BYTE PTR [ebx],0x1e
48f4d0: jne 0x48f4e7
48f4d2: xor eax,eax
48f4d4: mov al,BYTE PTR [ebx+0x4]
48f4d7: xor edx,edx
48f4d9: mov dl,BYTE PTR [ebx+0x5]
48f4dc: sub edx,0xa
48f4df: cmp eax,edx
48f4e1: jl 0x48f4e7
48f4e3: mov BYTE PTR [ebx+0x3],0x4d
48f4e7: cmp BYTE PTR [ebx],0x1e
48f4ea: jne 0x48f501
48f4ec: xor eax,eax
48f4ee: mov al,BYTE PTR [ebx+0x4]
48f4f1: xor edx,edx
48f4f3: mov dl,BYTE PTR [ebx+0x5]
48f4f6: sub edx,0x7
48f4f9: cmp eax,edx
48f4fb: jl 0x48f501
48f4fd: mov BYTE PTR [ebx+0x3],0x4e
48f501: cmp BYTE PTR [ebx],0x1e
48f504: jne 0x48f51b
48f506: xor eax,eax
48f508: mov al,BYTE PTR [ebx+0x4]
48f50b: xor edx,edx
48f50d: mov dl,BYTE PTR [ebx+0x5]
48f510: sub edx,0x4
48f513: cmp eax,edx
48f515: jl 0x48f51b
48f517: mov BYTE PTR [ebx+0x3],0x4f
48f51b: cmp BYTE PTR [ebx],0x1f
48f51e: jne 0x48f52a
48f520: cmp BYTE PTR [ebx+0x1],0x2
48f524: jne 0x48f52a
48f526: mov BYTE PTR [ebx+0x3],0x48
48f52a: cmp BYTE PTR [ebx],0x1f
48f52d: jne 0x48f539
48f52f: cmp BYTE PTR [ebx+0x1],0x4
48f533: jne 0x48f539
48f535: mov BYTE PTR [ebx+0x3],0x49
48f539: cmp BYTE PTR [ebx],0x1f
48f53c: jne 0x48f548
48f53e: cmp BYTE PTR [ebx+0x1],0x5
48f542: jne 0x48f548
48f544: mov BYTE PTR [ebx+0x3],0x4a
48f548: cmp BYTE PTR [ebx],0x1f
48f54b: jne 0x48f557
48f54d: cmp BYTE PTR [ebx+0x1],0x6
48f551: jne 0x48f557
48f553: mov BYTE PTR [ebx+0x1],0x0
48f557: cmp BYTE PTR [ebx],0x20
48f55a: jne 0x48f566
48f55c: cmp BYTE PTR [ebx+0x1],0x2
48f560: jae 0x48f566
48f562: mov BYTE PTR [ebx+0x3],0x48
48f566: cmp BYTE PTR [ebx],0x20
48f569: jne 0x48f575
48f56b: cmp BYTE PTR [ebx+0x1],0x2
48f56f: jne 0x48f575
48f571: mov BYTE PTR [ebx+0x3],0x48
48f575: cmp BYTE PTR [ebx],0x20
48f578: jne 0x48f584
48f57a: cmp BYTE PTR [ebx+0x1],0x4
48f57e: jne 0x48f584
48f580: mov BYTE PTR [ebx+0x3],0x49
48f584: cmp BYTE PTR [ebx],0x20
48f587: jne 0x48f593
48f589: cmp BYTE PTR [ebx+0x1],0x5
48f58d: jne 0x48f593
48f58f: mov BYTE PTR [ebx+0x3],0x4a
48f593: cmp BYTE PTR [ebx],0x20
48f596: jne 0x48f5a2
48f598: cmp BYTE PTR [ebx+0x1],0x6
48f59c: jne 0x48f5a2
48f59e: mov BYTE PTR [ebx+0x1],0x0
48f5a2: cmp BYTE PTR [ebx],0x21
48f5a5: jne 0x48f5b1
48f5a7: cmp BYTE PTR [ebx+0x1],0x0
48f5ab: jne 0x48f5b1
48f5ad: mov BYTE PTR [ebx+0x3],0x50
48f5b1: cmp BYTE PTR [ebx],0x21
48f5b4: jne 0x48f5c0
48f5b6: cmp BYTE PTR [ebx+0x1],0x1
48f5ba: jne 0x48f5c0
48f5bc: mov BYTE PTR [ebx+0x3],0x50
48f5c0: cmp BYTE PTR [ebx],0x21
48f5c3: jne 0x48f5cf
48f5c5: cmp BYTE PTR [ebx+0x1],0x2
48f5c9: jne 0x48f5cf
48f5cb: mov BYTE PTR [ebx+0x3],0x51
48f5cf: cmp BYTE PTR [ebx],0x21
48f5d2: jne 0x48f5de
48f5d4: cmp BYTE PTR [ebx+0x1],0x4
48f5d8: jne 0x48f5de
48f5da: mov BYTE PTR [ebx+0x3],0x52
48f5de: cmp BYTE PTR [ebx],0x21
48f5e1: jne 0x48f5ed
48f5e3: cmp BYTE PTR [ebx+0x1],0x5
48f5e7: jne 0x48f5ed
48f5e9: mov BYTE PTR [ebx+0x3],0x53
48f5ed: cmp BYTE PTR [ebx],0x21
48f5f0: jne 0x48f5fc
48f5f2: cmp BYTE PTR [ebx+0x1],0x6
48f5f6: jne 0x48f5fc
48f5f8: mov BYTE PTR [ebx+0x1],0x0
48f5fc: cmp BYTE PTR [ebx],0x22
48f5ff: jne 0x48f60b
48f601: cmp BYTE PTR [ebx+0x1],0x0
48f605: jne 0x48f60b
48f607: mov BYTE PTR [ebx+0x3],0x54
48f60b: cmp BYTE PTR [ebx],0x22
48f60e: jne 0x48f61a
48f610: cmp BYTE PTR [ebx+0x1],0x3
48f614: jne 0x48f61a
48f616: mov BYTE PTR [ebx+0x3],0x55
48f61a: cmp BYTE PTR [ebx],0x22
48f61d: jne 0x48f629
48f61f: cmp BYTE PTR [ebx+0x1],0x6
48f623: jne 0x48f629
48f625: mov BYTE PTR [ebx+0x3],0x56
48f629: cmp BYTE PTR [ebx],0x22
48f62c: jne 0x48f638
48f62e: cmp BYTE PTR [ebx+0x1],0x9
48f632: jne 0x48f638
48f634: mov BYTE PTR [ebx+0x3],0x57
48f638: cmp BYTE PTR [ebx],0x22
48f63b: jne 0x48f647
48f63d: cmp BYTE PTR [ebx+0x1],0xc
48f641: jne 0x48f647
48f643: mov BYTE PTR [ebx+0x3],0x58
48f647: cmp BYTE PTR [ebx],0x22
48f64a: jne 0x48f656
48f64c: cmp BYTE PTR [ebx+0x1],0xf
48f650: jne 0x48f656
48f652: mov BYTE PTR [ebx+0x3],0x59
48f656: cmp BYTE PTR [ebx],0x22
48f659: jne 0x48f665
48f65b: cmp BYTE PTR [ebx+0x1],0x12
48f65f: jne 0x48f665
48f661: mov BYTE PTR [ebx+0x3],0x5a
48f665: cmp BYTE PTR [ebx],0x23
48f668: jne 0x48f674
48f66a: cmp BYTE PTR [ebx+0x1],0x0
48f66e: jne 0x48f674
48f670: mov BYTE PTR [ebx+0x3],0x5b
48f674: cmp BYTE PTR [ebx],0x23
48f677: jne 0x48f683
48f679: cmp BYTE PTR [ebx+0x1],0x2
48f67d: jne 0x48f683
48f67f: mov BYTE PTR [ebx+0x3],0x5c
48f683: cmp BYTE PTR [ebx],0x23
48f686: jne 0x48f692
48f688: cmp BYTE PTR [ebx+0x1],0x4
48f68c: jne 0x48f692
48f68e: mov BYTE PTR [ebx+0x3],0x5d
48f692: cmp BYTE PTR [ebx],0x23
48f695: jne 0x48f6a1
48f697: cmp BYTE PTR [ebx+0x1],0x6
48f69b: jne 0x48f6a1
48f69d: mov BYTE PTR [ebx+0x3],0x5e
48f6a1: cmp BYTE PTR [ebx],0x23
48f6a4: jne 0x48f6b0
48f6a6: cmp BYTE PTR [ebx+0x1],0x8
48f6aa: jne 0x48f6b0
48f6ac: mov BYTE PTR [ebx+0x3],0x5f
48f6b0: cmp BYTE PTR [ebx],0x24
48f6b3: jne 0x48f6bf
48f6b5: cmp BYTE PTR [ebx+0x1],0x0
48f6b9: jne 0x48f6bf
48f6bb: mov BYTE PTR [ebx+0x3],0x60
48f6bf: cmp BYTE PTR [ebx],0x24
48f6c2: jne 0x48f6ce
48f6c4: cmp BYTE PTR [ebx+0x1],0x2
48f6c8: jne 0x48f6ce
48f6ca: mov BYTE PTR [ebx+0x3],0x61
48f6ce: cmp BYTE PTR [ebx],0x24
48f6d1: jne 0x48f6dd
48f6d3: cmp BYTE PTR [ebx+0x1],0x4
48f6d7: jne 0x48f6dd
48f6d9: mov BYTE PTR [ebx+0x3],0x62
48f6dd: cmp BYTE PTR [ebx],0x24
48f6e0: jne 0x48f6ec
48f6e2: cmp BYTE PTR [ebx+0x1],0x6
48f6e6: jne 0x48f6ec
48f6e8: mov BYTE PTR [ebx+0x3],0x63
48f6ec: cmp BYTE PTR [ebx],0x24
48f6ef: jne 0x48f6fb
48f6f1: cmp BYTE PTR [ebx+0x1],0x8
48f6f5: jne 0x48f6fb
48f6f7: mov BYTE PTR [ebx+0x3],0x64
48f6fb: cmp BYTE PTR [ebx],0x8
48f6fe: jne 0x48f71c
48f700: cmp BYTE PTR [ebx+0x1],0x2
48f704: jne 0x48f71c
48f706: push 0x2d
48f708: push 0x0
48f70a: mov ecx,0xffffff6a
48f70f: mov edx,0xffffffd3
48f714: mov eax,DWORD PTR [ebp-0x8]
48f717: call 0x4769c4
48f71c: cmp BYTE PTR [ebx],0x8
48f71f: jne 0x48f73d
48f721: cmp BYTE PTR [ebx+0x1],0x5
48f725: jne 0x48f73d
48f727: push 0x2d
48f729: push 0x0
48f72b: mov ecx,0xffffff24
48f730: mov edx,0xffffffd3
48f735: mov eax,DWORD PTR [ebp-0x8]
48f738: call 0x4769c4
48f73d: cmp BYTE PTR [ebx],0x8
48f740: jne 0x48f754
48f742: mov al,BYTE PTR [ebx+0x1]
48f745: cmp al,0x6
48f747: je 0x48f74d
48f749: cmp al,0xc
48f74b: jne 0x48f754
48f74d: mov BYTE PTR [ebx+0x6],0x1
48f751: inc BYTE PTR [ebx+0x1]
48f754: cmp BYTE PTR [ebx],0x1c
48f757: jne 0x48f76f
48f759: mov al,BYTE PTR [ebx+0x4]
48f75c: cmp al,0x3
48f75e: je 0x48f768
48f760: cmp al,0x6
48f762: je 0x48f768
48f764: cmp al,0x9
48f766: jne 0x48f76f
48f768: mov BYTE PTR [ebx+0x6],0x1
48f76c: inc BYTE PTR [ebx+0x4]
48f76f: cmp BYTE PTR [ebx],0x1f
48f772: jne 0x48f806
48f778: xor eax,eax
48f77a: mov al,BYTE PTR [ebx+0x4]
48f77d: mov DWORD PTR [ebp-0xc],eax
48f780: fild DWORD PTR [ebp-0xc]
48f783: fdiv DWORD PTR ds:0x49056c
48f789: call 0x40286c
48f78e: fmul DWORD PTR ds:0x490570
48f794: call 0x402894
48f799: mov DWORD PTR [ebp-0x14],eax
48f79c: mov DWORD PTR [ebp-0x10],edx
48f79f: fild QWORD PTR [ebp-0x14]
48f7a2: xor eax,eax
48f7a4: mov al,BYTE PTR [ebx-0x7]
48f7a7: imul eax,eax,0x16
48f7aa: mov edx,DWORD PTR ds:0x4b0ef0
48f7b0: fadd QWORD PTR [edx+eax*8-0xb0]
48f7b7: fstp QWORD PTR [ebx-0x2b]
48f7ba: fwait
48f7bb: xor eax,eax
48f7bd: mov al,BYTE PTR [ebx+0x4]
48f7c0: mov DWORD PTR [ebp-0xc],eax
48f7c3: fild DWORD PTR [ebp-0xc]
48f7c6: fdiv DWORD PTR ds:0x49056c
48f7cc: call 0x40286c
48f7d1: fmul DWORD PTR ds:0x490570
48f7d7: call 0x402894
48f7dc: mov DWORD PTR [ebp-0x14],eax
48f7df: mov DWORD PTR [ebp-0x10],edx
48f7e2: fild QWORD PTR [ebp-0x14]
48f7e5: xor eax,eax
48f7e7: mov al,BYTE PTR [ebx-0x7]
48f7ea: imul eax,eax,0x16
48f7ed: mov edx,DWORD PTR ds:0x4b0ef0
48f7f3: fld QWORD PTR [edx+eax*8-0xa8]
48f7fa: fsub DWORD PTR ds:0x490574
48f800: faddp st(1),st
48f802: fstp QWORD PTR [ebx-0x23]
48f805: fwait
48f806: cmp BYTE PTR [ebx],0x20
48f809: jne 0x48f89d
48f80f: xor eax,eax
48f811: mov al,BYTE PTR [ebx+0x4]
48f814: mov DWORD PTR [ebp-0xc],eax
48f817: fild DWORD PTR [ebp-0xc]
48f81a: fdiv DWORD PTR ds:0x49056c
48f820: call 0x40286c
48f825: fmul DWORD PTR ds:0x490570
48f82b: call 0x402894
48f830: mov DWORD PTR [ebp-0x14],eax
48f833: mov DWORD PTR [ebp-0x10],edx
48f836: fild QWORD PTR [ebp-0x14]
48f839: xor eax,eax
48f83b: mov al,BYTE PTR [ebx-0x7]
48f83e: imul eax,eax,0x16
48f841: mov edx,DWORD PTR ds:0x4b0ef0
48f847: fsubr QWORD PTR [edx+eax*8-0xb0]
48f84e: fstp QWORD PTR [ebx-0x2b]
48f851: fwait
48f852: xor eax,eax
48f854: mov al,BYTE PTR [ebx+0x4]
48f857: mov DWORD PTR [ebp-0xc],eax
48f85a: fild DWORD PTR [ebp-0xc]
48f85d: fdiv DWORD PTR ds:0x49056c
48f863: call 0x40286c
48f868: fmul DWORD PTR ds:0x490570
48f86e: call 0x402894
48f873: mov DWORD PTR [ebp-0x14],eax
48f876: mov DWORD PTR [ebp-0x10],edx
48f879: fild QWORD PTR [ebp-0x14]
48f87c: xor eax,eax
48f87e: mov al,BYTE PTR [ebx-0x7]
48f881: imul eax,eax,0x16
48f884: mov edx,DWORD PTR ds:0x4b0ef0
48f88a: fld QWORD PTR [edx+eax*8-0xa8]
48f891: fsub DWORD PTR ds:0x490574
48f897: faddp st(1),st
48f899: fstp QWORD PTR [ebx-0x23]
48f89c: fwait
48f89d: cmp BYTE PTR [ebx],0x1f
48f8a0: je 0x48f8a7
48f8a2: cmp BYTE PTR [ebx],0x20
48f8a5: jne 0x48f8f4
48f8a7: xor eax,eax
48f8a9: mov al,BYTE PTR [ebx+0x4]
48f8ac: mov DWORD PTR [ebp-0xc],eax
48f8af: fild DWORD PTR [ebp-0xc]
48f8b2: fdiv DWORD PTR ds:0x490578
48f8b8: call 0x40287c
48f8bd: xor eax,eax
48f8bf: mov al,BYTE PTR [ebx+0x4]
48f8c2: mov DWORD PTR [ebp-0x18],eax
48f8c5: fild DWORD PTR [ebp-0x18]
48f8c8: fdiv DWORD PTR ds:0x490578
48f8ce: fcompp
48f8d0: fnstsw ax
48f8d2: sahf
48f8d3: jne 0x48f8f4
48f8d5: mov BYTE PTR [ebx+0x6],0x1
48f8d9: inc BYTE PTR [ebx+0x4]
48f8dc: xor eax,eax
48f8de: mov al,BYTE PTR [ebx-0x7]
48f8e1: imul eax,eax,0x16
48f8e4: mov edx,DWORD PTR ds:0x4b0ef0
48f8ea: cmp BYTE PTR [edx+eax*8-0x45],0x1d
48f8ef: je 0x48f8f4
48f8f1: mov BYTE PTR [ebx],0x0
48f8f4: cmp BYTE PTR [ebx],0x1e
48f8f7: jne 0x48f911
48f8f9: xor eax,eax
48f8fb: mov al,BYTE PTR [ebx-0x7]
48f8fe: imul eax,eax,0x16
48f901: mov edx,DWORD PTR ds:0x4b0ef0
48f907: cmp BYTE PTR [edx+eax*8-0x45],0x1a
48f90c: je 0x48f911
48f90e: mov BYTE PTR [ebx],0x0
48f911: cmp BYTE PTR [ebx],0x22
48f914: jne 0x48f920
48f916: cmp BYTE PTR [ebx+0x1],0xe
48f91a: jb 0x48f920
48f91c: mov BYTE PTR [ebx+0x6],0x0
48f920: cmp BYTE PTR [ebx],0x18
48f923: jne 0x48f95d
48f925: xor eax,eax
48f927: mov al,BYTE PTR [ebx+0x1]
48f92a: mov DWORD PTR [ebp-0xc],eax
48f92d: fild DWORD PTR [ebp-0xc]
48f930: call 0x40286c
48f935: fmul DWORD PTR ds:0x49057c
48f93b: call 0x402894
48f940: mov DWORD PTR [ebp-0x14],eax
48f943: mov DWORD PTR [ebp-0x10],edx
48f946: fild QWORD PTR [ebp-0x14]
48f949: fadd QWORD PTR [ebx-0x2b]
48f94c: fstp QWORD PTR [ebx-0x2b]
48f94f: fld QWORD PTR [ebx-0x23]
48f953: fsub DWORD PTR ds:0x490568
48f959: fstp QWORD PTR [ebx-0x23]
48f95c: fwait
48f95d: cmp BYTE PTR [ebx+0x9],0x1
48f961: jne 0x48f9cb
48f963: mov eax,ds:0x4b1074
48f968: cmp BYTE PTR [eax],0x0
48f96b: jne 0x48f9cb
48f96d: mov eax,ds:0x4b0e84
48f972: cmp BYTE PTR [eax],0x0
48f975: jne 0x48f9cb
48f977: fild WORD PTR [ebx-0x5]
48f97a: fadd QWORD PTR [ebx-0x23]
48f97d: fstp QWORD PTR [ebx-0x23]
48f980: fwait
48f981: add WORD PTR [ebx-0x5],0x4
48f986: mov eax,ds:0x4b11f8
48f98b: movsx eax,WORD PTR [eax]
48f98e: sub eax,0x5
48f991: mov DWORD PTR [ebp-0xc],eax
48f994: fild DWORD PTR [ebp-0xc]
48f997: fcomp QWORD PTR [ebx-0x23]
48f99a: fnstsw ax
48f99c: sahf
48f99d: jae 0x48f9cb
48f99f: mov eax,ds:0x4b11f8
48f9a4: movsx eax,WORD PTR [eax]
48f9a7: sub eax,0x5
48f9aa: mov DWORD PTR [ebp-0xc],eax
48f9ad: fild DWORD PTR [ebp-0xc]
48f9b0: fstp QWORD PTR [ebx-0x23]
48f9b3: fwait
48f9b4: mov BYTE PTR [ebx-0xa],0x0
48f9b8: mov WORD PTR [ebx-0x5],0x0
48f9be: cmp BYTE PTR [ebx],0x16
48f9c1: jne 0x48f9cb
48f9c3: mov BYTE PTR [ebx-0x3],0x1
48f9c7: mov BYTE PTR [ebx+0x6],0x0
48f9cb: mov eax,ds:0x4b1074
48f9d0: cmp BYTE PTR [eax],0x0
48f9d3: jne 0x48fa54
48f9d5: mov eax,ds:0x4b1074
48f9da: cmp BYTE PTR [eax],0x0
48f9dd: jne 0x48fa54
48f9df: mov eax,ds:0x4b0e84
48f9e4: cmp BYTE PTR [eax],0x0
48f9e7: jne 0x48fa54
48f9e9: cmp BYTE PTR [ebx-0xb],0x1
48f9ed: jne 0x48fa01
48f9ef: xor eax,eax
48f9f1: mov al,BYTE PTR [ebx-0xa]
48f9f4: mov DWORD PTR [ebp-0xc],eax
48f9f7: fild DWORD PTR [ebp-0xc]
48f9fa: fadd QWORD PTR [ebx-0x2b]
48f9fd: fstp QWORD PTR [ebx-0x2b]
48fa00: fwait
48fa01: cmp BYTE PTR [ebx-0xb],0x2
48fa05: jne 0x48fa19
48fa07: xor eax,eax
48fa09: mov al,BYTE PTR [ebx-0xa]
48fa0c: mov DWORD PTR [ebp-0xc],eax
48fa0f: fild DWORD PTR [ebp-0xc]
48fa12: fsubr QWORD PTR [ebx-0x2b]
48fa15: fstp QWORD PTR [ebx-0x2b]
48fa18: fwait
48fa19: cmp BYTE PTR [ebx],0x13
48fa1c: jne 0x48fa30
48fa1e: xor eax,eax
48fa20: mov al,BYTE PTR [ebx-0xa]
48fa23: mov DWORD PTR [ebp-0xc],eax
48fa26: fild DWORD PTR [ebp-0xc]
48fa29: fadd QWORD PTR [ebx-0x23]
48fa2c: fstp QWORD PTR [ebx-0x23]
48fa2f: fwait
48fa30: cmp BYTE PTR [ebx],0x14
48fa33: jne 0x48fa54
48fa35: mov eax,0xd
48fa3a: call 0x402a1c
48fa3f: mov DWORD PTR [ebp-0xc],eax
48fa42: fild DWORD PTR [ebp-0xc]
48fa45: fld QWORD PTR [ebx-0x23]
48fa48: fsub DWORD PTR ds:0x490580
48fa4e: faddp st(1),st
48fa50: fstp QWORD PTR [ebx-0x23]
48fa53: fwait
48fa54: mov eax,ds:0x4b0fcc
48fa59: cmp BYTE PTR [eax],0x1
48fa5c: jne 0x48faca
48fa5e: fld QWORD PTR [ebx-0x2b]
48fa61: call 0x402894
48fa66: mov esi,eax
48fa68: mov eax,esi
48fa6a: add eax,DWORD PTR [ebx-0x13]
48fa6d: mov edx,DWORD PTR ds:0x4b11b4
48fa73: sub eax,DWORD PTR [edx]
48fa75: push eax
48fa76: fld QWORD PTR [ebx-0x23]
48fa79: call 0x402894
48fa7e: mov edi,eax
48fa80: mov eax,edi
48fa82: add eax,DWORD PTR [ebx-0xf]
48fa85: mov edx,DWORD PTR ds:0x4b1144
48fa8b: sub eax,DWORD PTR [edx]
48fa8d: push eax
48fa8e: mov cl,0x32
48fa90: mov dl,0xff
48fa92: mov al,0x32
48fa94: call 0x406de4
48fa99: push eax
48fa9a: fld QWORD PTR [ebx-0x23]
48fa9d: call 0x402894
48faa2: add edi,DWORD PTR [ebx-0x17]
48faa5: mov eax,ds:0x4b1144
48faaa: sub edi,DWORD PTR [eax]
48faac: push edi
48faad: fld QWORD PTR [ebx-0x2b]
48fab0: call 0x402894
48fab5: mov edx,esi
48fab7: add edx,DWORD PTR [ebx-0x1b]
48faba: mov eax,ds:0x4b11b4
48fabf: sub edx,DWORD PTR [eax]
48fac1: mov eax,DWORD PTR [ebp-0x4]
48fac4: pop ecx
48fac5: call 0x48e444
48faca: mov eax,DWORD PTR [ebp-0x4]
48facd: mov eax,DWORD PTR [eax+0x2d0]
48fad3: mov eax,DWORD PTR [eax+0x270]
48fad9: call 0x45cd9c
48fade: call 0x45bb18
48fae3: mov eax,DWORD PTR [ebp-0x4]
48fae6: mov eax,DWORD PTR [eax+0x308]
48faec: mov eax,DWORD PTR [eax+0x28]
48faef: call 0x40efcc
48faf4: movzx esi,BYTE PTR [ebx+0x3]
48faf8: cmp eax,esi
48fafa: jle 0x48fc8d
48fb00: cmp BYTE PTR [ebx],0x5
48fb03: je 0x48fc8d
48fb09: mov edx,esi
48fb0b: mov eax,DWORD PTR [ebp-0x4]
48fb0e: mov eax,DWORD PTR [eax+0x308]
48fb14: mov eax,DWORD PTR [eax+0x28]
48fb17: call 0x461dcc
48fb1c: call 0x461608
48fb21: mov DWORD PTR [ebp-0xc],eax
48fb24: fild DWORD PTR [ebp-0xc]
48fb27: fdiv DWORD PTR ds:0x49057c
48fb2d: call 0x402894
48fb32: mov edi,eax
48fb34: xor edx,edx
48fb36: mov dl,BYTE PTR [ebx+0x3]
48fb39: mov eax,DWORD PTR [ebp-0x4]
48fb3c: mov eax,DWORD PTR [eax+0x308]
48fb42: mov eax,DWORD PTR [eax+0x28]
48fb45: call 0x461dcc
48fb4a: call 0x4615e0
48fb4f: mov DWORD PTR [ebp-0xc],eax
48fb52: fild DWORD PTR [ebp-0xc]
48fb55: fdiv DWORD PTR ds:0x49057c
48fb5b: call 0x402894
48fb60: mov esi,eax
48fb62: cmp BYTE PTR [ebx+0x8],0x1
48fb66: jne 0x48fb85
48fb68: xor edx,edx
48fb6a: mov dl,BYTE PTR [ebx+0x3]
48fb6d: mov eax,DWORD PTR [ebp-0x4]
48fb70: mov eax,DWORD PTR [eax+0x308]
48fb76: mov eax,DWORD PTR [eax+0x28]
48fb79: call 0x461dcc
48fb7e: call 0x4615e0
48fb83: mov esi,eax
48fb85: cmp BYTE PTR [ebx-0x3],0x0
48fb89: je 0x48fbcd
48fb8b: cmp BYTE PTR [ebx-0x3],0x1
48fb8f: jne 0x48fc8d
48fb95: mov eax,ds:0x4b1094
48fb9a: movzx eax,BYTE PTR [eax]
48fb9d: mov DWORD PTR [ebp-0xc],eax
48fba0: fild DWORD PTR [ebp-0xc]
48fba3: fdiv DWORD PTR ds:0x49057c
48fba9: call 0x40287c
48fbae: mov eax,ds:0x4b1094
48fbb3: movzx eax,BYTE PTR [eax]
48fbb6: mov DWORD PTR [ebp-0x18],eax
48fbb9: fild DWORD PTR [ebp-0x18]
48fbbc: fdiv DWORD PTR ds:0x49057c
48fbc2: fcompp
48fbc4: fnstsw ax
48fbc6: sahf
48fbc7: jne 0x48fc8d
48fbcd: cmp BYTE PTR [ebx-0xb],0x1
48fbd1: jne 0x48fc2d
48fbd3: fld QWORD PTR [ebx-0x23]
48fbd6: call 0x402894
48fbdb: mov edx,DWORD PTR ds:0x4b1144
48fbe1: sub eax,DWORD PTR [edx]
48fbe3: movsx edx,si
48fbe6: sub eax,edx
48fbe8: push eax
48fbe9: push 0x0
48fbeb: xor edx,edx
48fbed: mov dl,BYTE PTR [ebx+0x3]
48fbf0: mov eax,DWORD PTR [ebp-0x4]
48fbf3: mov eax,DWORD PTR [eax+0x308]
48fbf9: mov eax,DWORD PTR [eax+0x28]
48fbfc: call 0x461dcc
48fc01: push eax
48fc02: fld QWORD PTR [ebx-0x2b]
48fc05: call 0x402894
48fc0a: mov ecx,eax
48fc0c: mov eax,ds:0x4b11b4
48fc11: sub ecx,DWORD PTR [eax]
48fc13: movsx eax,di
48fc16: sub ecx,eax
48fc18: mov eax,DWORD PTR [ebp-0x4]
48fc1b: mov eax,DWORD PTR [eax+0x2d0]
48fc21: mov edx,DWORD PTR [eax+0x270]
48fc27: pop eax
48fc28: call 0x46161c
48fc2d: cmp BYTE PTR [ebx-0xb],0x2
48fc31: jne 0x48fc8d
48fc33: fld QWORD PTR [ebx-0x23]
48fc36: call 0x402894
48fc3b: mov edx,DWORD PTR ds:0x4b1144
48fc41: sub eax,DWORD PTR [edx]
48fc43: movsx edx,si
48fc46: sub eax,edx
48fc48: push eax
48fc49: push 0x0
48fc4b: xor edx,edx
48fc4d: mov dl,BYTE PTR [ebx+0x3]
48fc50: mov eax,DWORD PTR [ebp-0x4]
48fc53: mov eax,DWORD PTR [eax+0x33c]
48fc59: mov eax,DWORD PTR [eax+0x28]
48fc5c: call 0x461dcc
48fc61: push eax
48fc62: fld QWORD PTR [ebx-0x2b]
48fc65: call 0x402894
48fc6a: mov ecx,eax
48fc6c: mov eax,ds:0x4b11b4
48fc71: sub ecx,DWORD PTR [eax]
48fc73: movsx eax,di
48fc76: sub ecx,eax
48fc78: mov eax,DWORD PTR [ebp-0x4]
48fc7b: mov eax,DWORD PTR [eax+0x2d0]
48fc81: mov edx,DWORD PTR [eax+0x270]
48fc87: pop eax
48fc88: call 0x46161c
48fc8d: cmp BYTE PTR [ebx],0x5
48fc90: jne 0x48fda7
48fc96: cmp BYTE PTR [ebx-0x3],0x0
48fc9a: jne 0x48fcf7
48fc9c: lea ecx,[ebp-0x1c]
48fc9f: mov eax,DWORD PTR [ebp-0x4]
48fca2: mov eax,DWORD PTR [eax+0x2f4]
48fca8: mov eax,DWORD PTR [eax+0x208]
48fcae: mov edx,0x5
48fcb3: mov esi,DWORD PTR [eax]
48fcb5: call DWORD PTR [esi+0xc]
48fcb8: mov eax,DWORD PTR [ebp-0x1c]
48fcbb: push eax
48fcbc: push 0x63
48fcbe: push 0xa
48fcc0: mov cl,0x8c
48fcc2: mov dl,0xff
48fcc4: mov al,0x50
48fcc6: call 0x406de4
48fccb: push eax
48fccc: fld QWORD PTR [ebx-0x23]
48fccf: call 0x402894
48fcd4: mov edx,DWORD PTR ds:0x4b1144
48fcda: sub eax,DWORD PTR [edx]
48fcdc: push eax
48fcdd: fld QWORD PTR [ebx-0x2b]
48fce0: call 0x402894
48fce5: mov edx,eax
48fce7: mov eax,ds:0x4b11b4
48fcec: sub edx,DWORD PTR [eax]
48fcee: mov eax,DWORD PTR [ebp-0x4]
48fcf1: pop ecx
48fcf2: call 0x48e720
48fcf7: cmp BYTE PTR [ebx-0x3],0x1
48fcfb: jne 0x48fd90
48fd01: mov eax,ds:0x4b1094
48fd06: movzx eax,BYTE PTR [eax]
48fd09: mov DWORD PTR [ebp-0xc],eax
48fd0c: fild DWORD PTR [ebp-0xc]
48fd0f: fdiv DWORD PTR ds:0x49057c
48fd15: call 0x40287c
48fd1a: mov eax,ds:0x4b1094
48fd1f: movzx eax,BYTE PTR [eax]
48fd22: mov DWORD PTR [ebp-0x18],eax
48fd25: fild DWORD PTR [ebp-0x18]
48fd28: fdiv DWORD PTR ds:0x49057c
48fd2e: fcompp
48fd30: fnstsw ax
48fd32: sahf
48fd33: jne 0x48fd90
48fd35: lea ecx,[ebp-0x20]
48fd38: mov eax,DWORD PTR [ebp-0x4]
48fd3b: mov eax,DWORD PTR [eax+0x2f4]
48fd41: mov eax,DWORD PTR [eax+0x208]
48fd47: mov edx,0x5
48fd4c: mov esi,DWORD PTR [eax]
48fd4e: call DWORD PTR [esi+0xc]
48fd51: mov eax,DWORD PTR [ebp-0x20]
48fd54: push eax
48fd55: push 0x63
48fd57: push 0xa
48fd59: mov cl,0x8c
48fd5b: mov dl,0xff
48fd5d: mov al,0x50
48fd5f: call 0x406de4
48fd64: push eax
48fd65: fld QWORD PTR [ebx-0x23]
48fd68: call 0x402894
48fd6d: mov edx,DWORD PTR ds:0x4b1144
48fd73: sub eax,DWORD PTR [edx]
48fd75: push eax
48fd76: fld QWORD PTR [ebx-0x2b]
48fd79: call 0x402894
48fd7e: mov edx,eax
48fd80: mov eax,ds:0x4b11b4
48fd85: sub edx,DWORD PTR [eax]
48fd87: mov eax,DWORD PTR [ebp-0x4]
48fd8a: pop ecx
48fd8b: call 0x48e720
48fd90: mov eax,ds:0x4b1074
48fd95: cmp BYTE PTR [eax],0x0
48fd98: jne 0x48fda7
48fd9a: fld QWORD PTR [ebx-0x23]
48fd9d: fsub DWORD PTR ds:0x490584
48fda3: fstp QWORD PTR [ebx-0x23]
48fda6: fwait
48fda7: mov edi,0x1
48fdac: mov esi,DWORD PTR ds:0x4b1118
48fdb2: fild DWORD PTR [esi+0x10]
48fdb5: fadd QWORD PTR [esi]
48fdb7: fild DWORD PTR [ebx-0x13]
48fdba: fadd QWORD PTR [ebx-0x2b]
48fdbd: fcompp
48fdbf: fnstsw ax
48fdc1: sahf
48fdc2: jbe 0x48feda
48fdc8: fild DWORD PTR [esi+0x18]
48fdcb: fadd QWORD PTR [esi]
48fdcd: fild DWORD PTR [ebx-0x1b]
48fdd0: fadd QWORD PTR [ebx-0x2b]
48fdd3: fcompp
48fdd5: fnstsw ax
48fdd7: sahf
48fdd8: jae 0x48feda
48fdde: fild DWORD PTR [esi+0x14]
48fde1: fadd QWORD PTR [esi+0x8]
48fde4: fild DWORD PTR [ebx-0xf]
48fde7: fadd QWORD PTR [ebx-0x23]
48fdea: fcompp
48fdec: fnstsw ax
48fdee: sahf
48fdef: jbe 0x48feda
48fdf5: fild DWORD PTR [esi+0x1c]
48fdf8: fadd QWORD PTR [esi+0x8]
48fdfb: fild DWORD PTR [ebx-0x17]
48fdfe: fadd QWORD PTR [ebx-0x23]
48fe01: fcompp
48fe03: fnstsw ax
48fe05: sahf
48fe06: jae 0x48feda
48fe0c: cmp BYTE PTR [esi+0x31],0x1
48fe10: jne 0x48feda
48fe16: cmp BYTE PTR [ebx+0x6],0x1
48fe1a: jne 0x48feda
48fe20: cmp BYTE PTR [esi+0x2b],0x0
48fe24: je 0x48feda
48fe2a: cmp BYTE PTR [ebx],0x0
48fe2d: je 0x48feda
48fe33: cmp BYTE PTR [esi+0x22],0x0
48fe37: jbe 0x48feda
48fe3d: cmp BYTE PTR [ebx-0x9],0x0
48fe41: jbe 0x48feda
48fe47: cmp edi,DWORD PTR [ebp-0x8]
48fe4a: je 0x48feda
48fe50: cmp BYTE PTR [ebx+0x7],0x1
48fe54: jne 0x48fe71
48fe56: mov al,BYTE PTR [ebx-0x7]
48fe59: mov BYTE PTR [esi+0x24],al
48fe5c: xor eax,eax
48fe5e: mov al,BYTE PTR [ebx-0x7]
48fe61: imul eax,eax,0x16
48fe64: mov edx,DWORD PTR ds:0x4b0ef0
48fe6a: mov al,BYTE PTR [edx+eax*8-0x43]
48fe6e: mov BYTE PTR [esi+0x20],al
48fe71: cmp BYTE PTR [esi+0x32],0x1
48fe75: jne 0x48fe92
48fe77: mov al,BYTE PTR [esi+0x24]
48fe7a: mov BYTE PTR [ebx-0x7],al
48fe7d: xor eax,eax
48fe7f: mov al,BYTE PTR [esi+0x24]
48fe82: imul eax,eax,0x16
48fe85: mov edx,DWORD PTR ds:0x4b0ef0
48fe8b: mov al,BYTE PTR [edx+eax*8-0x43]
48fe8f: mov BYTE PTR [ebx-0xb],al
48fe92: mov al,BYTE PTR [esi+0x24]
48fe95: cmp al,BYTE PTR [ebx-0x7]
48fe98: je 0x48feda
48fe9a: cmp BYTE PTR [ebx-0x1],0x0
48fe9e: jne 0x48feba
48fea0: push DWORD PTR [ebx-0x27]
48fea3: push DWORD PTR [ebx-0x2b]
48fea6: push DWORD PTR [ebx-0x1f]
48fea9: push DWORD PTR [ebx-0x23]
48feac: xor ecx,ecx
48feae: xor edx,edx
48feb0: mov al,0x1
48feb2: call 0x476a04
48feb7: mov BYTE PTR [ebx],0x0
48feba: cmp BYTE PTR [esi+0x2a],0x0
48febe: jne 0x48feda
48fec0: push DWORD PTR [esi+0x4]
48fec3: push DWORD PTR [esi]
48fec5: push DWORD PTR [esi+0xc]
48fec8: push DWORD PTR [esi+0x8]
48fecb: xor ecx,ecx
48fecd: xor edx,edx
48fecf: mov al,0x1
48fed1: call 0x476a04
48fed6: mov BYTE PTR [esi+0x2b],0x0
48feda: inc edi
48fedb: add esi,0x38
48fede: cmp edi,0x51
48fee1: jne 0x48fdb2
48fee7: mov edi,0x1
48feec: mov esi,DWORD PTR ds:0x4b0ef0
48fef2: fild DWORD PTR [esi+0x20]
48fef5: fadd QWORD PTR [esi]
48fef7: fild DWORD PTR [ebx-0x13]
48fefa: fadd QWORD PTR [ebx-0x2b]
48fefd: fcompp
48feff: fnstsw ax
48ff01: sahf
48ff02: jbe 0x490390
48ff08: fild DWORD PTR [esi+0x28]
48ff0b: fadd QWORD PTR [esi]
48ff0d: fild DWORD PTR [ebx-0x1b]
48ff10: fadd QWORD PTR [ebx-0x2b]
48ff13: fcompp
48ff15: fnstsw ax
48ff17: sahf
48ff18: jae 0x490390
48ff1e: fild WORD PTR [esi+0x7a]
48ff21: fsubr QWORD PTR [esi+0x8]
48ff24: fild DWORD PTR [esi+0x24]
48ff27: faddp st(1),st
48ff29: fild DWORD PTR [ebx-0xf]
48ff2c: fadd QWORD PTR [ebx-0x23]
48ff2f: fcompp
48ff31: fnstsw ax
48ff33: sahf
48ff34: jbe 0x490390
48ff3a: fild WORD PTR [esi+0x7a]
48ff3d: fsubr QWORD PTR [esi+0x8]
48ff40: fild DWORD PTR [esi+0x2c]
48ff43: faddp st(1),st
48ff45: fild DWORD PTR [ebx-0x17]
48ff48: fadd QWORD PTR [ebx-0x23]
48ff4b: fcompp
48ff4d: fnstsw ax
48ff4f: sahf
48ff50: jae 0x490390
48ff56: cmp BYTE PTR [esi+0x93],0x1
48ff5d: jne 0x49004c
48ff63: cmp BYTE PTR [ebx+0x6],0x1
48ff67: jne 0x49004c
48ff6d: cmp BYTE PTR [ebx-0x9],0x0
48ff71: jbe 0x49004c
48ff77: xor eax,eax
48ff79: mov al,BYTE PTR [ebx-0x7]
48ff7c: cmp edi,eax
48ff7e: je 0x49004c
48ff84: mov WORD PTR [esi+0x74],0x1
48ff8a: mov eax,ds:0x4b1098
48ff8f: mov BYTE PTR [eax],0xa
48ff92: push DWORD PTR [ebx-0x27]
48ff95: push DWORD PTR [ebx-0x2b]
48ff98: push DWORD PTR [ebx-0x1f]
48ff9b: push DWORD PTR [ebx-0x23]
48ff9e: xor ecx,ecx
48ffa0: xor edx,edx
48ffa2: mov al,0xe
48ffa4: call 0x476a04
48ffa9: cmp BYTE PTR [esi+0x6d],0x1
48ffad: jne 0x48ffbd
48ffaf: push 0xc0240000
48ffb4: push 0x0
48ffb6: mov eax,edi
48ffb8: call 0x47648c
48ffbd: cmp BYTE PTR [esi+0x6d],0x2
48ffc1: jne 0x48ffd1
48ffc3: push 0x40240000
48ffc8: push 0x0
48ffca: mov eax,edi
48ffcc: call 0x47648c
48ffd1: mov eax,ds:0x4b1004
48ffd6: cmp BYTE PTR [eax],0x0
48ffd9: jne 0x49000a
48ffdb: mov eax,ds:0x4b110c
48ffe0: cmp BYTE PTR [eax],0x0
48ffe3: jne 0x49000a
48ffe5: xor eax,eax
48ffe7: mov al,BYTE PTR [ebx-0x8]
48ffea: mov DWORD PTR [ebp-0xc],eax
48ffed: fild DWORD PTR [ebp-0xc]
48fff0: mov eax,ds:0x4b11f4
48fff5: fmul QWORD PTR [eax]
48fff7: fsubr QWORD PTR [esi+0x40]
48fffa: fstp QWORD PTR [esi+0x40]
48fffd: fwait
48fffe: xor eax,eax
490000: mov DWORD PTR [esi+0x50],eax
490003: mov DWORD PTR [esi+0x54],0x40340000
49000a: fld QWORD PTR [esi+0x40]
49000d: fcomp DWORD PTR ds:0x490588
490013: fnstsw ax
490015: sahf
490016: ja 0x490029
490018: mov eax,ds:0x4b1098
49001d: mov BYTE PTR [eax],0x9
490020: mov eax,edi
490022: mov dl,0xa
490024: call 0x4775fc
490029: cmp BYTE PTR [ebx-0x1],0x0
49002d: jne 0x490032
49002f: mov BYTE PTR [ebx],0x0
490032: mov BYTE PTR [ebx+0x6],0x0
490036: fld QWORD PTR [esi+0x40]
490039: fcomp DWORD PTR ds:0x490588
49003f: fnstsw ax
490041: sahf
490042: jbe 0x49004c
490044: mov eax,ds:0x4b0e84
490049: mov BYTE PTR [eax],0x2
49004c: cmp BYTE PTR [ebx+0x6],0x1
490050: jne 0x490308
490056: cmp BYTE PTR [ebx-0x9],0x0
49005a: jbe 0x490308
490060: cmp BYTE PTR [esi+0x92],0x0
490067: jne 0x490308
49006d: xor eax,eax
49006f: mov al,BYTE PTR [ebx-0x7]
490072: cmp edi,eax
490074: je 0x490308
49007a: cmp BYTE PTR [esi+0x93],0x0
490081: jne 0x490308
490087: fld QWORD PTR [esi]
490089: mov eax,0x3
49008e: sub eax,edi
490090: imul edx,eax,0x16
490093: mov eax,ds:0x4b0ef0
490098: fcomp QWORD PTR [eax+edx*8-0xb0]
49009f: fnstsw ax
4900a1: sahf
4900a2: jae 0x4900a8
4900a4: mov BYTE PTR [esi+0x6d],0x1
4900a8: fld QWORD PTR [esi]
4900aa: mov eax,ds:0x4b0ef0
4900af: fcomp QWORD PTR [eax+edx*8-0xb0]
4900b6: fnstsw ax
4900b8: sahf
4900b9: jb 0x4900bf
4900bb: mov BYTE PTR [esi+0x6d],0x2
4900bf: mov eax,ds:0x4b1098
4900c4: mov BYTE PTR [eax],0x9
4900c7: push DWORD PTR [ebx-0x27]
4900ca: push DWORD PTR [ebx-0x2b]
4900cd: push DWORD PTR [ebx-0x1f]
4900d0: push DWORD PTR [ebx-0x23]
4900d3: xor ecx,ecx
4900d5: xor edx,edx
4900d7: mov al,0x1
4900d9: call 0x476a04
4900de: mov eax,ds:0x4b0d98
4900e3: cmp BYTE PTR [eax],0x1
4900e6: jne 0x4900fe
4900e8: mov eax,0x3
4900ed: call 0x402a1c
4900f2: test eax,eax
4900f4: jne 0x4900fe
4900f6: mov eax,ds:0x4b0fc8
4900fb: mov BYTE PTR [eax],0x4
4900fe: mov eax,ds:0x4b1024
490103: cmp BYTE PTR [eax],0x1
490106: jne 0x490116
490108: mov eax,0x3
49010d: call 0x402a1c
490112: test eax,eax
490114: je 0x490120
490116: mov eax,ds:0x4b1058
49011b: cmp BYTE PTR [eax],0x1
49011e: jne 0x490147
490120: push DWORD PTR [esi+0x4]
490123: push DWORD PTR [esi]
490125: movsx eax,WORD PTR [esi+0x7a]
490129: sub eax,0x28
49012c: mov DWORD PTR [ebp-0xc],eax
49012f: fild DWORD PTR [ebp-0xc]
490132: fsubr QWORD PTR [esi+0x8]
490135: add esp,0xfffffff8
490138: fstp QWORD PTR [esp]
49013b: fwait
49013c: xor ecx,ecx
49013e: xor edx,edx
490140: mov al,0xa
490142: call 0x476a04
490147: mov eax,0x3
49014c: sub eax,edi
49014e: imul edx,eax,0x16
490151: mov eax,ds:0x4b0ef0
490156: cmp BYTE PTR [eax+edx*8-0x12],0x1
49015b: jne 0x490175
49015d: fld QWORD PTR [esi+0x40]
490160: fcomp DWORD PTR ds:0x490588
490166: fnstsw ax
490168: sahf
490169: jbe 0x490175
49016b: mov eax,ds:0x4b0ef0
490170: add DWORD PTR [eax+edx*8-0x28],0xa
490175: mov eax,ds:0x4b0ef0
49017a: cmp BYTE PTR [eax+edx*8-0x1a],0x23
49017f: ja 0x49018b
490181: mov eax,ds:0x4b0ef0
490186: mov BYTE PTR [eax+edx*8-0x1b],0x0
49018b: mov eax,ds:0x4b0ef0
490190: inc BYTE PTR [eax+edx*8-0x1b]
490194: mov eax,ds:0x4b0ef0
490199: mov BYTE PTR [eax+edx*8-0x1a],0x32
49019e: mov eax,ds:0x4b1004
4901a3: cmp BYTE PTR [eax],0x0
4901a6: jne 0x4901f9
4901a8: mov eax,ds:0x4b110c
4901ad: cmp BYTE PTR [eax],0x0
4901b0: jne 0x4901f9
4901b2: xor eax,eax
4901b4: mov al,BYTE PTR [ebx-0x9]
4901b7: mov DWORD PTR [ebp-0xc],eax
4901ba: fild DWORD PTR [ebp-0xc]
4901bd: mov eax,ds:0x4b11f4
4901c2: fmul QWORD PTR [eax]
4901c4: fsubr QWORD PTR [esi+0x40]
4901c7: fstp QWORD PTR [esi+0x40]
4901ca: fld QWORD PTR [esi+0x60]
4901ce: fcomp DWORD PTR ds:0x49058c
4901d4: fnstsw ax
4901d6: sahf
4901d7: jae 0x4901ed
4901d9: fld DWORD PTR ds:0x490568
4901df: mov eax,ds:0x4b0fe8
4901e4: fmul QWORD PTR [eax]
4901e6: fadd QWORD PTR [esi+0x60]
4901e9: fstp QWORD PTR [esi+0x60]
4901ec: fwait
4901ed: xor eax,eax
4901ef: mov DWORD PTR [esi+0x50],eax
4901f2: mov DWORD PTR [esi+0x54],0x40340000
4901f9: cmp BYTE PTR [ebx-0x2],0x1
4901fd: je 0x490213
4901ff: cmp BYTE PTR [esi+0x78],0x0
490203: jne 0x490213
490205: fld QWORD PTR [esi+0x40]
490208: fcomp DWORD PTR ds:0x490588
49020e: fnstsw ax
490210: sahf
490211: ja 0x49021c
490213: mov eax,edi
490215: mov dl,0xa
490217: call 0x4775fc
49021c: mov eax,edi
49021e: mov dl,0x9
490220: call 0x4775fc
490225: mov BYTE PTR [esi+0x72],0x8
490229: mov eax,ds:0x4b0d4c
49022e: cmp BYTE PTR [eax],0x0
490231: jne 0x490276
490233: mov eax,0x3
490238: sub eax,edi
49023a: imul eax,eax,0x16
49023d: mov edx,DWORD PTR ds:0x4b0ef0
490243: mov BYTE PTR [edx+eax*8-0x21],0x1
490248: mov edx,DWORD PTR ds:0x4b0ef0
49024e: mov BYTE PTR [edx+eax*8-0x20],0x32
490253: mov edx,DWORD PTR ds:0x4b0ef0
490259: cmp BYTE PTR [edx+eax*8-0x12],0x1
49025e: jne 0x49026e
490260: mov edx,DWORD PTR ds:0x4b0ef0
490266: add DWORD PTR [edx+eax*8-0x28],0x12c
49026e: mov eax,ds:0x4b0d4c
490273: mov BYTE PTR [eax],0x1
490276: mov eax,0x3
49027b: sub eax,edi
49027d: imul eax,eax,0x16
490280: mov edx,DWORD PTR ds:0x4b0ef0
490286: mov BYTE PTR [edx+eax*8-0x1f],0x1
49028b: mov BYTE PTR [esi+0x91],0x0
490292: fld QWORD PTR [esi+0x40]
490295: fcomp DWORD PTR ds:0x490588
49029b: fnstsw ax
49029d: sahf
49029e: jbe 0x4902a8
4902a0: mov eax,ds:0x4b0e84
4902a5: mov BYTE PTR [eax],0x5
4902a8: cmp BYTE PTR [ebx],0x8
4902ab: jne 0x4902b1
4902ad: mov BYTE PTR [esi+0x72],0xa
4902b1: cmp BYTE PTR [ebx],0x8
4902b4: jne 0x4902ba
4902b6: mov BYTE PTR [esi+0x78],0xc4
4902ba: cmp BYTE PTR [ebx],0x14
4902bd: jne 0x4902ce
4902bf: mov BYTE PTR [esi+0x78],0xec
4902c3: mov BYTE PTR [esi+0x92],0x0
4902ca: mov BYTE PTR [esi+0x72],0x6
4902ce: mov al,BYTE PTR [ebx]
4902d0: cmp al,0x8
4902d2: je 0x4902d8
4902d4: cmp al,0x14
4902d6: jne 0x4902f4
4902d8: mov BYTE PTR [esi+0x6b],0x13
4902dc: cmp BYTE PTR [esi+0x6d],0x1
4902e0: jne 0x4902e8
4902e2: mov WORD PTR [esi+0x18],0xffec
4902e8: cmp BYTE PTR [esi+0x6d],0x2
4902ec: jne 0x4902f4
4902ee: mov WORD PTR [esi+0x18],0x14
4902f4: cmp BYTE PTR [ebx-0x1],0x0
4902f8: jne 0x4902fd
4902fa: mov BYTE PTR [ebx],0x0
4902fd: mov BYTE PTR [ebx+0x6],0x0
490301: mov eax,edi
490303: call 0x47d21c
490308: mov dl,BYTE PTR [ebx]
49030a: cmp dl,0x3
49030d: je 0x490314
49030f: cmp dl,0x4
490312: jne 0x490390
490314: cmp BYTE PTR [ebx+0x1],0xd
490318: jbe 0x490390
49031a: fld QWORD PTR [esi+0x40]
49031d: fcomp DWORD PTR ds:0x490588
490323: fnstsw ax
490325: sahf
490326: jbe 0x490390
490328: mov eax,ds:0x4b110c
49032d: cmp BYTE PTR [eax],0x0
490330: jne 0x490390
490332: mov eax,ds:0x4b1004
490337: cmp BYTE PTR [eax],0x0
49033a: jne 0x49036e
49033c: cmp dl,0x3
49033f: jne 0x490355
490341: fld DWORD PTR ds:0x490590
490347: mov eax,ds:0x4b11f4
49034c: fmul QWORD PTR [eax]
49034e: fadd QWORD PTR [esi+0x40]
490351: fstp QWORD PTR [esi+0x40]
490354: fwait
490355: cmp BYTE PTR [ebx],0x4
490358: jne 0x49036e
49035a: fld DWORD PTR ds:0x490594
490360: mov eax,ds:0x4b11f4
490365: fmul QWORD PTR [eax]
490367: fadd QWORD PTR [esi+0x40]
49036a: fstp QWORD PTR [esi+0x40]
49036d: fwait
49036e: mov eax,ds:0x4b1098
490373: mov BYTE PTR [eax],0xb
490376: push DWORD PTR [ebx-0x27]
490379: push DWORD PTR [ebx-0x2b]
49037c: push DWORD PTR [ebx-0x1f]
49037f: push DWORD PTR [ebx-0x23]
490382: xor ecx,ecx
490384: xor edx,edx
490386: mov al,0x5
490388: call 0x476a04
49038d: mov BYTE PTR [ebx],0x0
490390: inc edi
490391: add esi,0xb0
490397: cmp edi,0x3
49039a: jne 0x48fef2
4903a0: cmp BYTE PTR [ebx+0x2],0x63
4903a4: je 0x4903c8
4903a6: mov eax,ds:0x4b1074
4903ab: cmp BYTE PTR [eax],0x0
4903ae: jne 0x4903c8
4903b0: mov eax,ds:0x4b0e84
4903b5: cmp BYTE PTR [eax],0x0
4903b8: jne 0x4903c8
4903ba: inc BYTE PTR [ebx+0x1]
4903bd: mov al,BYTE PTR [ebx+0x1]
4903c0: cmp al,BYTE PTR [ebx+0x2]
4903c3: jbe 0x4903c8
4903c5: mov BYTE PTR [ebx],0x0
4903c8: cmp BYTE PTR [ebx+0x5],0x0
4903cc: je 0x4904a9
4903d2: mov eax,ds:0x4b1074
4903d7: cmp BYTE PTR [eax],0x0
4903da: jne 0x4904a9
4903e0: mov eax,ds:0x4b0e84
4903e5: cmp BYTE PTR [eax],0x0
4903e8: jne 0x4904a9
4903ee: inc BYTE PTR [ebx+0x4]
4903f1: cmp BYTE PTR [ebx],0x1b
4903f4: jne 0x49049e
4903fa: xor eax,eax
4903fc: mov al,BYTE PTR [ebx+0x4]
4903ff: xor edx,edx
490401: mov dl,BYTE PTR [ebx+0x5]
490404: sub edx,0x2
490407: cmp eax,edx
490409: jl 0x49040f
49040b: mov BYTE PTR [ebx+0x6],0x1
49040f: mov al,BYTE PTR [ebx+0x4]
490412: cmp al,BYTE PTR [ebx+0x5]
490415: jb 0x49049e
49041b: fld QWORD PTR [ebx-0x2b]
49041e: fsub DWORD PTR ds:0x490594
490424: add esp,0xfffffff8
490427: fstp QWORD PTR [esp]
49042a: fld QWORD PTR [ebx-0x23]
49042e: fadd DWORD PTR ds:0x490590
490434: add esp,0xfffffff8
490437: fstp QWORD PTR [esp]
49043a: fwait
49043b: mov cl,BYTE PTR [ebx-0x7]
49043e: mov edx,0x4905a0
490443: mov al,0x1c
490445: call 0x476a04
49044a: fld QWORD PTR [ebx-0x2b]
49044d: fadd DWORD PTR ds:0x490594
490453: add esp,0xfffffff8
490456: fstp QWORD PTR [esp]
490459: fld QWORD PTR [ebx-0x23]
49045d: fadd DWORD PTR ds:0x490590
490463: add esp,0xfffffff8
490466: fstp QWORD PTR [esp]
490469: fwait
49046a: mov cl,BYTE PTR [ebx-0x7]
49046d: mov edx,0x4905a0
490472: mov al,0x1c
490474: call 0x476a04
490479: push DWORD PTR [ebx-0x27]
49047c: push DWORD PTR [ebx-0x2b]
49047f: fld QWORD PTR [ebx-0x23]
490482: fsub DWORD PTR ds:0x4905a4
490488: add esp,0xfffffff8
49048b: fstp QWORD PTR [esp]
49048e: fwait
49048f: mov cl,BYTE PTR [ebx-0x7]
490492: mov edx,0x4905a0
490497: mov al,0x1c
490499: call 0x476a04
49049e: mov al,BYTE PTR [ebx+0x4]
4904a1: cmp al,BYTE PTR [ebx+0x5]
4904a4: jb 0x4904a9
4904a6: mov BYTE PTR [ebx],0x0
4904a9: mov eax,ds:0x4b11b4
4904ae: mov eax,DWORD PTR [eax]
4904b0: sub eax,0x32
4904b3: mov DWORD PTR [ebp-0xc],eax
4904b6: fild DWORD PTR [ebp-0xc]
4904b9: fcomp QWORD PTR [ebx-0x2b]
4904bc: fnstsw ax
4904be: sahf
4904bf: jbe 0x4904c4
4904c1: mov BYTE PTR [ebx],0x0
4904c4: mov eax,ds:0x4b11b4
4904c9: mov eax,DWORD PTR [eax]
4904cb: add eax,0x1c2
4904d0: mov DWORD PTR [ebp-0xc],eax
4904d3: fild DWORD PTR [ebp-0xc]
4904d6: fcomp QWORD PTR [ebx-0x2b]
4904d9: fnstsw ax
4904db: sahf
4904dc: jae 0x4904e1
4904de: mov BYTE PTR [ebx],0x0
4904e1: mov eax,ds:0x4b1144
4904e6: mov eax,DWORD PTR [eax]
4904e8: sub eax,0x32
4904eb: mov DWORD PTR [ebp-0xc],eax
4904ee: fild DWORD PTR [ebp-0xc]
4904f1: fcomp QWORD PTR [ebx-0x23]
4904f4: fnstsw ax
4904f6: sahf
4904f7: jbe 0x4904fc
4904f9: mov BYTE PTR [ebx],0x0
4904fc: fild DWORD PTR [ebx-0xf]
4904ff: fadd QWORD PTR [ebx-0x23]
490502: mov eax,ds:0x4b11f8
490507: fild WORD PTR [eax]
490509: fcompp
49050b: fnstsw ax
49050d: sahf
49050e: jae 0x49052f
490510: cmp BYTE PTR [ebx],0x13
490513: jne 0x49052f
490515: mov BYTE PTR [ebx],0x0
490518: push DWORD PTR [ebx-0x27]
49051b: push DWORD PTR [ebx-0x2b]
49051e: push DWORD PTR [ebx-0x1f]
490521: push DWORD PTR [ebx-0x23]
490524: xor ecx,ecx
490526: xor edx,edx
490528: mov al,0x1
49052a: call 0x476a04
49052f: inc DWORD PTR [ebp-0x8]
490532: add ebx,0x38
490535: cmp DWORD PTR [ebp-0x8],0x51
490539: jne 0x48ee2e
49053f: xor eax,eax
490541: pop edx
490542: pop ecx
490543: pop ecx
490544: mov DWORD PTR fs:[eax],edx
490547: push 0x490561
49054c: lea eax,[ebp-0x20]
49054f: mov edx,0x2
490554: call 0x4039f4
490559: ret
49055a: jmp 0x403468
490561: pop edi
490562: pop esi
490563: pop ebx
490564: mov esp,ebp
490566: pop ebp
490567: ret
.data 4b1118 48464b00d6444b0040b6
.data 4b1074 f8574b00c8274b00d470
.data 4b0e84 f9574b00c8b64000f0b6
.data 490568 0000803f000040400000
.data 49056c 0000404000008c420000
.data 490570 00008c420000a0420000
.data 4b0ef0 e8444b000c204b0030b8
.data 490574 0000a042000020410000
.data 490578 00002041000000400000
.data 49057c 000000400000e0400000
.data 4b11f8 98444b00db444b004027
.data 490580 0000e0400000a0400000
.data 4b0fcc a5584b00a1584b00df44
.data 4b11b4 c8444b00a0b640003470
.data 4b1144 cc444b0004004b0098b8
.data 4b1094 c0444b0009584b0078b6
.data 490584 0000a040000000000000
.data 4b1098 09584b0078b640005472
.data 4b1004 fa574b00447140008471
.data 4b110c e0444b00d8574b00ec70
.data 4b11f4 88584b0098444b00db44
.data 490588 000000000000cc420000
.data 4b0d98 a8584b0004204b000024
.data 4b0fc8 9b444b00a5584b00a158
.data 4b1024 e1444b00547040005062
.data 4b1058 ad584b0080b64000fc71
.data 49058c 0000cc420000a0410000
.data 4b0fe8 90584b00d0264b00e061
.data 4b0d4c f4574b00d9444b000470
.data 490590 0000a0410000f041ffff
.data 490594 0000f041ffffffff0100
.data 4905a4 00002042558bec83c4f8
.string 4905a0 41
