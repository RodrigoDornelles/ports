; entry 47648c
47648c: push ebp
47648d: mov ebp,esp
47648f: push ecx
476490: push ebx
476491: push esi
476492: push edi
476493: mov edx,eax
476495: mov ecx,DWORD PTR ds:0x4b0ef0
47649b: xor eax,eax
47649d: mov al,dl
47649f: imul eax,eax,0x16
4764a2: fld QWORD PTR [ecx+eax*8-0xb0]
4764a9: fadd QWORD PTR [ebp+0x8]
4764ac: fstp QWORD PTR [ecx+eax*8-0xb0]
4764b3: fwait
4764b4: xor eax,eax
4764b6: mov al,dl
4764b8: imul ebx,eax,0x16
4764bb: fild DWORD PTR [ecx+ebx*8-0x90]
4764c2: mov esi,edx
4764c4: and esi,0xff
4764ca: fadd QWORD PTR [ecx+ebx*8-0xb0]
4764d1: xor eax,eax
4764d3: mov al,dl
4764d5: mov edi,0x3
4764da: sub edi,eax
4764dc: imul eax,edi,0x16
4764df: fild DWORD PTR [ecx+eax*8-0x88]
4764e6: mov eax,0x3
4764eb: sub eax,esi
4764ed: imul eax,eax,0x16
4764f0: fadd QWORD PTR [ecx+eax*8-0xb0]
4764f7: fcompp
4764f9: fnstsw ax
4764fb: sahf
4764fc: jbe 0x4767dc
476502: fild DWORD PTR [ecx+ebx*8-0x88]
476509: xor eax,eax
47650b: mov al,dl
47650d: imul eax,eax,0x16
476510: fadd QWORD PTR [ecx+eax*8-0xb0]
476517: xor eax,eax
476519: mov al,dl
47651b: mov esi,0x3
476520: sub esi,eax
476522: imul eax,esi,0x16
476525: fild DWORD PTR [ecx+eax*8-0x90]
47652c: xor eax,eax
47652e: mov al,dl
476530: mov esi,0x3
476535: sub esi,eax
476537: imul eax,esi,0x16
47653a: fadd QWORD PTR [ecx+eax*8-0xb0]
476541: fcompp
476543: fnstsw ax
476545: sahf
476546: jae 0x4767dc
47654c: fild DWORD PTR [ecx+ebx*8-0x8c]
476553: fadd QWORD PTR [ecx+ebx*8-0xa8]
47655a: xor eax,eax
47655c: mov al,dl
47655e: mov esi,0x3
476563: sub esi,eax
476565: imul eax,esi,0x16
476568: fild DWORD PTR [ecx+eax*8-0x84]
47656f: xor eax,eax
476571: mov al,dl
476573: mov esi,0x3
476578: sub esi,eax
47657a: imul eax,esi,0x16
47657d: fadd QWORD PTR [ecx+eax*8-0xa8]
476584: fcompp
476586: fnstsw ax
476588: sahf
476589: jbe 0x4767dc
47658f: fild DWORD PTR [ecx+ebx*8-0x84]
476596: fadd QWORD PTR [ecx+ebx*8-0xa8]
47659d: xor eax,eax
47659f: mov al,dl
4765a1: mov esi,0x3
4765a6: sub esi,eax
4765a8: imul eax,esi,0x16
4765ab: fild DWORD PTR [ecx+eax*8-0x8c]
4765b2: xor eax,eax
4765b4: mov al,dl
4765b6: mov esi,0x3
4765bb: sub esi,eax
4765bd: imul eax,esi,0x16
4765c0: fadd QWORD PTR [ecx+eax*8-0xa8]
4765c7: fcompp
4765c9: fnstsw ax
4765cb: sahf
4765cc: jae 0x4767dc
4765d2: cmp BYTE PTR [ecx+ebx*8-0x45],0x17
4765d7: je 0x4767dc
4765dd: cmp BYTE PTR [ecx+ebx*8-0x45],0x14
4765e2: je 0x4767dc
4765e8: xor ebx,ebx
4765ea: mov bl,dl
4765ec: imul esi,ebx,0x16
4765ef: fld QWORD PTR [ecx+esi*8-0xb0]
4765f6: mov eax,0x3
4765fb: sub eax,ebx
4765fd: imul eax,eax,0x16
476600: fcomp QWORD PTR [ecx+eax*8-0xb0]
476607: fnstsw ax
476609: sahf
47660a: ja 0x4766e4
476610: mov eax,ds:0x4b110c
476615: cmp BYTE PTR [eax],0x0
476618: jne 0x4766e4
47661e: xor eax,eax
476620: mov al,dl
476622: mov ebx,0x3
476627: sub ebx,eax
476629: imul eax,ebx,0x16
47662c: fld QWORD PTR [ecx+eax*8-0xb0]
476633: fadd DWORD PTR ds:0x476868
476639: xor eax,eax
47663b: mov al,dl
47663d: mov ebx,0x3
476642: sub ebx,eax
476644: imul eax,ebx,0x16
476647: fstp QWORD PTR [ecx+eax*8-0xb0]
47664e: fwait
47664f: mov eax,ds:0x4b11b4
476654: mov eax,DWORD PTR [eax]
476656: add eax,0x172
47665b: mov DWORD PTR [ebp-0x4],eax
47665e: fild DWORD PTR [ebp-0x4]
476661: xor eax,eax
476663: mov al,dl
476665: mov ebx,0x3
47666a: sub ebx,eax
47666c: imul eax,ebx,0x16
47666f: fcomp QWORD PTR [ecx+eax*8-0xb0]
476676: fnstsw ax
476678: sahf
476679: jae 0x4766a3
47667b: mov eax,ds:0x4b11b4
476680: mov eax,DWORD PTR [eax]
476682: add eax,0x172
476687: mov DWORD PTR [ebp-0x4],eax
47668a: fild DWORD PTR [ebp-0x4]
47668d: xor eax,eax
47668f: mov al,dl
476691: mov ebx,0x3
476696: sub ebx,eax
476698: imul eax,ebx,0x16
47669b: fstp QWORD PTR [ecx+eax*8-0xb0]
4766a2: fwait
4766a3: xor eax,eax
4766a5: mov al,dl
4766a7: mov ebx,0x3
4766ac: sub ebx,eax
4766ae: imul eax,ebx,0x16
4766b1: fild DWORD PTR [ecx+eax*8-0x90]
4766b8: xor eax,eax
4766ba: mov al,dl
4766bc: mov ebx,0x3
4766c1: sub ebx,eax
4766c3: imul eax,ebx,0x16
4766c6: fadd QWORD PTR [ecx+eax*8-0xb0]
4766cd: fild DWORD PTR [ecx+esi*8-0x88]
4766d4: fsubp st(1),st
4766d6: fsub DWORD PTR ds:0x476868
4766dc: fstp QWORD PTR [ecx+esi*8-0xb0]
4766e3: fwait
4766e4: xor ebx,ebx
4766e6: mov bl,dl
4766e8: imul esi,ebx,0x16
4766eb: fld QWORD PTR [ecx+esi*8-0xb0]
4766f2: mov eax,0x3
4766f7: sub eax,ebx
4766f9: imul eax,eax,0x16
4766fc: fcomp QWORD PTR [ecx+eax*8-0xb0]
476703: fnstsw ax
476705: sahf
476706: jbe 0x4767dc
47670c: mov eax,ds:0x4b110c
476711: cmp BYTE PTR [eax],0x0
476714: jne 0x4767dc
47671a: xor eax,eax
47671c: mov al,dl
47671e: mov ebx,0x3
476723: sub ebx,eax
476725: imul eax,ebx,0x16
476728: fld QWORD PTR [ecx+eax*8-0xb0]
47672f: fsub DWORD PTR ds:0x476868
476735: xor eax,eax
476737: mov al,dl
476739: mov ebx,0x3
47673e: sub ebx,eax
476740: imul eax,ebx,0x16
476743: fstp QWORD PTR [ecx+eax*8-0xb0]
47674a: fwait
47674b: mov eax,ds:0x4b11b4
476750: mov eax,DWORD PTR [eax]
476752: add eax,0x1e
476755: mov DWORD PTR [ebp-0x4],eax
476758: fild DWORD PTR [ebp-0x4]
47675b: xor eax,eax
47675d: mov al,dl
47675f: mov ebx,0x3
476764: sub ebx,eax
476766: imul eax,ebx,0x16
476769: fcomp QWORD PTR [ecx+eax*8-0xb0]
476770: fnstsw ax
476772: sahf
476773: jbe 0x47679b
476775: mov eax,ds:0x4b11b4
47677a: mov eax,DWORD PTR [eax]
47677c: add eax,0x1e
47677f: mov DWORD PTR [ebp-0x4],eax
476782: fild DWORD PTR [ebp-0x4]
476785: xor eax,eax
476787: mov al,dl
476789: mov ebx,0x3
47678e: sub ebx,eax
476790: imul eax,ebx,0x16
476793: fstp QWORD PTR [ecx+eax*8-0xb0]
47679a: fwait
47679b: xor eax,eax
47679d: mov al,dl
47679f: mov ebx,0x3
4767a4: sub ebx,eax
4767a6: imul eax,ebx,0x16
4767a9: fild DWORD PTR [ecx+eax*8-0x88]
4767b0: xor eax,eax
4767b2: mov al,dl
4767b4: mov ebx,0x3
4767b9: sub ebx,eax
4767bb: imul eax,ebx,0x16
4767be: fadd QWORD PTR [ecx+eax*8-0xb0]
4767c5: fild DWORD PTR [ecx+esi*8-0x90]
4767cc: fsubp st(1),st
4767ce: fadd DWORD PTR ds:0x476868
4767d4: fstp QWORD PTR [ecx+esi*8-0xb0]
4767db: fwait
4767dc: xor eax,eax
4767de: mov al,dl
4767e0: imul ebx,eax,0x16
4767e3: fld QWORD PTR [ecx+ebx*8-0x70]
4767e7: fcomp DWORD PTR ds:0x47686c
4767ed: fnstsw ax
4767ef: sahf
4767f0: jbe 0x47685e
4767f2: mov eax,ds:0x4b11b4
4767f7: mov eax,DWORD PTR [eax]
4767f9: add eax,0x1e
4767fc: mov DWORD PTR [ebp-0x4],eax
4767ff: fild DWORD PTR [ebp-0x4]
476802: fcomp QWORD PTR [ecx+ebx*8-0xb0]
476809: fnstsw ax
47680b: sahf
47680c: jbe 0x476826
47680e: mov eax,ds:0x4b11b4
476813: mov eax,DWORD PTR [eax]
476815: add eax,0x1e
476818: mov DWORD PTR [ebp-0x4],eax
47681b: fild DWORD PTR [ebp-0x4]
47681e: fstp QWORD PTR [ecx+ebx*8-0xb0]
476825: fwait
476826: mov eax,ds:0x4b11b4
47682b: mov eax,DWORD PTR [eax]
47682d: add eax,0x172
476832: mov DWORD PTR [ebp-0x4],eax
476835: fild DWORD PTR [ebp-0x4]
476838: fcomp QWORD PTR [ecx+ebx*8-0xb0]
47683f: fnstsw ax
476841: sahf
476842: jae 0x47685e
476844: mov eax,ds:0x4b11b4
476849: mov eax,DWORD PTR [eax]
47684b: add eax,0x172
476850: mov DWORD PTR [ebp-0x4],eax
476853: fild DWORD PTR [ebp-0x4]
476856: fstp QWORD PTR [ecx+ebx*8-0xb0]
47685d: fwait
47685e: pop edi
47685f: pop esi
476860: pop ebx
476861: pop ecx
476862: pop ebp
476863: ret 0x8
.data 4b0ef0 e8444b000c204b0030b8
.data 4b110c e0444b00d8574b00ec70
.data 476868 0000a04000000000558b
.data 4b11b4 c8444b00a0b640003470
.data 47686c 00000000558bec53566b
