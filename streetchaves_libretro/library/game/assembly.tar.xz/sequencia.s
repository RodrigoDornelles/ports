; entry 4951b8
4951b8: push ebp
4951b9: mov ebp,esp
4951bb: push ebx
4951bc: imul eax,edx,0x16
4951bf: mov ebx,DWORD PTR ds:0x4b0ef0
4951c5: movzx ebx,BYTE PTR [ebx+eax*8-0x18]
4951ca: cmp ecx,ebx
4951cc: jne 0x4951e6
4951ce: mov ecx,DWORD PTR ds:0x4b0ef0
4951d4: mov bl,BYTE PTR [ebp+0x8]
4951d7: mov BYTE PTR [ecx+eax*8-0x18],bl
4951db: mov edx,DWORD PTR ds:0x4b0ef0
4951e1: mov BYTE PTR [edx+eax*8-0x17],0x9
4951e6: pop ebx
4951e7: pop ebp
4951e8: ret 0x4
.data 4b0ef0 e8444b000c204b0030b8
