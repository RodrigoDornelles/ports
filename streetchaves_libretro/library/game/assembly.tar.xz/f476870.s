; entry 476870
476870: push ebp
476871: mov ebp,esp
476873: push ebx
476874: push esi
476875: imul esi,eax,0x16
476878: mov ebx,DWORD PTR ds:0x4b0ef0
47687e: movzx ebx,BYTE PTR [ebx+esi*8-0x44]
476883: cmp edx,ebx
476885: jne 0x4768f1
476887: mov edx,DWORD PTR ds:0x4b0ef0
47688d: mov DWORD PTR [edx+esi*8-0x90],ecx
476894: mov edx,DWORD PTR ds:0x4b0ef0
47689a: mov ebx,DWORD PTR [ebp+0x10]
47689d: mov DWORD PTR [edx+esi*8-0x8c],ebx
4768a4: mov edx,DWORD PTR ds:0x4b0ef0
4768aa: mov ebx,DWORD PTR [ebp+0xc]
4768ad: mov DWORD PTR [edx+esi*8-0x88],ebx
4768b4: mov edx,DWORD PTR ds:0x4b0ef0
4768ba: mov ebx,DWORD PTR [ebp+0x8]
4768bd: mov DWORD PTR [edx+esi*8-0x84],ebx
4768c4: mov edx,DWORD PTR ds:0x4b0ef0
4768ca: cmp BYTE PTR [edx+esi*8-0x43],0x2
4768cf: jne 0x4768f1
4768d1: mov edx,DWORD PTR ds:0x4b0ef0
4768d7: mov ebx,DWORD PTR [ebp+0xc]
4768da: neg ebx
4768dc: mov DWORD PTR [edx+esi*8-0x90],ebx
4768e3: mov eax,ds:0x4b0ef0
4768e8: neg ecx
4768ea: mov DWORD PTR [eax+esi*8-0x88],ecx
4768f1: pop esi
4768f2: pop ebx
4768f3: pop ebp
4768f4: ret 0xc
.data 4b0ef0 e8444b000c204b0030b8
