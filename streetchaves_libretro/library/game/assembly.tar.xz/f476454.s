; entry 476454
476454: push ebx
476455: push esi
476456: push edi
476457: xor ecx,ecx
476459: mov esi,0x50
47645e: mov edi,DWORD PTR ds:0x4b1118
476464: add edi,0x2b
476467: cmp al,BYTE PTR [edi]
476469: jne 0x47647d
47646b: mov ebx,DWORD PTR ds:0x4b0e30
476471: cmp BYTE PTR [ebx],0x0
476474: jne 0x47647d
476476: cmp dl,BYTE PTR [edi-0x7]
476479: jne 0x47647d
47647b: mov cl,0x1
47647d: add edi,0x38
476480: dec esi
476481: jne 0x476467
476483: mov eax,ecx
476485: pop edi
476486: pop esi
476487: pop ebx
476488: ret
.data 4b1118 48464b00d6444b0040b6
.data 4b0e30 b0584b0090444b001020
