; entry 48e5fc
48e5fc: push ebp
48e5fd: mov ebp,esp
48e5ff: push ebx
48e600: push esi
48e601: push edi
48e602: mov edi,ecx
48e604: mov esi,edx
48e606: mov ebx,eax
48e608: mov eax,DWORD PTR [ebx+0x2d0]
48e60e: mov eax,DWORD PTR [eax+0x270]
48e614: call 0x45cd9c
48e619: mov eax,DWORD PTR [eax+0x10]
48e61c: mov edx,DWORD PTR [ebp+0x8]
48e61f: call 0x417ed8
48e624: mov eax,DWORD PTR [ebx+0x2d0]
48e62a: mov eax,DWORD PTR [eax+0x270]
48e630: call 0x45cd9c
48e635: mov eax,DWORD PTR [eax+0x14]
48e638: mov dl,0x1
48e63a: call 0x4182d8
48e63f: mov eax,DWORD PTR [ebp+0x10]
48e642: push eax
48e643: mov eax,DWORD PTR [ebp+0xc]
48e646: push eax
48e647: mov eax,DWORD PTR [ebx+0x2d0]
48e64d: mov eax,DWORD PTR [eax+0x270]
48e653: call 0x45cd9c
48e658: mov ecx,edi
48e65a: mov edx,esi
48e65c: call 0x418560
48e661: mov eax,DWORD PTR [ebx+0x2d0]
48e667: mov eax,DWORD PTR [eax+0x270]
48e66d: call 0x45cd9c
48e672: mov eax,DWORD PTR [eax+0x14]
48e675: xor edx,edx
48e677: call 0x4182d8
48e67c: mov eax,DWORD PTR [ebx+0x2d0]
48e682: mov eax,DWORD PTR [eax+0x270]
48e688: call 0x45cd9c
48e68d: call 0x45bb18
48e692: pop edi
48e693: pop esi
48e694: pop ebx
48e695: pop ebp
48e696: ret 0xc
