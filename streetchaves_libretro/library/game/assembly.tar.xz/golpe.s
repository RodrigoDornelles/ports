; entry 4951ec
4951ec: push ebx
4951ed: push esi
4951ee: push ecx
4951ef: mov BYTE PTR [esp],cl
4951f2: mov ebx,edx
4951f4: mov esi,DWORD PTR ds:0x4b0ef0
4951fa: mov eax,ds:0x4b1074
4951ff: cmp BYTE PTR [eax],0x0
495202: jne 0x4968a9
495208: xor eax,eax
49520a: mov al,bl
49520c: imul eax,eax,0x16
49520f: cmp BYTE PTR [esi+eax*8-0xa0],0x1
495217: jne 0x49533f
49521d: cmp BYTE PTR [esp],0x1
495221: jne 0x49523a
495223: xor eax,eax
495225: mov al,bl
495227: imul eax,eax,0x16
49522a: cmp BYTE PTR [esi+eax*8-0x18],0x2
49522f: jne 0x49523a
495231: mov dl,0x10
495233: mov eax,ebx
495235: call 0x4775fc
49523a: cmp BYTE PTR [esp],0x3
49523e: jne 0x495257
495240: xor eax,eax
495242: mov al,bl
495244: imul eax,eax,0x16
495247: cmp BYTE PTR [esi+eax*8-0x18],0x2
49524c: jne 0x495257
49524e: mov dl,0x11
495250: mov eax,ebx
495252: call 0x4775fc
495257: cmp BYTE PTR [esp],0x1
49525b: jne 0x495274
49525d: xor eax,eax
49525f: mov al,bl
495261: imul eax,eax,0x16
495264: cmp BYTE PTR [esi+eax*8-0x18],0x3
495269: jne 0x495274
49526b: mov dl,0x12
49526d: mov eax,ebx
49526f: call 0x4775fc
495274: cmp BYTE PTR [esp],0x3
495278: jne 0x495291
49527a: xor eax,eax
49527c: mov al,bl
49527e: imul eax,eax,0x16
495281: cmp BYTE PTR [esi+eax*8-0x18],0x3
495286: jne 0x495291
495288: mov dl,0x13
49528a: mov eax,ebx
49528c: call 0x4775fc
495291: cmp BYTE PTR [esp],0x1
495295: jne 0x4952ae
495297: xor eax,eax
495299: mov al,bl
49529b: imul eax,eax,0x16
49529e: cmp BYTE PTR [esi+eax*8-0x18],0x4
4952a3: jne 0x4952ae
4952a5: mov dl,0x14
4952a7: mov eax,ebx
4952a9: call 0x4775fc
4952ae: cmp BYTE PTR [esp],0x3
4952b2: jne 0x4952cb
4952b4: xor eax,eax
4952b6: mov al,bl
4952b8: imul eax,eax,0x16
4952bb: cmp BYTE PTR [esi+eax*8-0x18],0x4
4952c0: jne 0x4952cb
4952c2: mov dl,0x15
4952c4: mov eax,ebx
4952c6: call 0x4775fc
4952cb: cmp BYTE PTR [esp],0x2
4952cf: jne 0x4952e8
4952d1: xor eax,eax
4952d3: mov al,bl
4952d5: imul eax,eax,0x16
4952d8: cmp BYTE PTR [esi+eax*8-0x18],0x3
4952dd: jne 0x4952e8
4952df: mov dl,0x16
4952e1: mov eax,ebx
4952e3: call 0x4775fc
4952e8: cmp BYTE PTR [esp],0x4
4952ec: jne 0x495305
4952ee: xor eax,eax
4952f0: mov al,bl
4952f2: imul eax,eax,0x16
4952f5: cmp BYTE PTR [esi+eax*8-0x18],0x3
4952fa: jne 0x495305
4952fc: mov dl,0x17
4952fe: mov eax,ebx
495300: call 0x4775fc
495305: cmp BYTE PTR [esp],0x1
495309: jne 0x495322
49530b: xor eax,eax
49530d: mov al,bl
49530f: imul eax,eax,0x16
495312: cmp BYTE PTR [esi+eax*8-0x18],0x6
495317: jne 0x495322
495319: mov dl,0x18
49531b: mov eax,ebx
49531d: call 0x4775fc
495322: cmp BYTE PTR [esp],0x3
495326: jne 0x49533f
495328: xor eax,eax
49532a: mov al,bl
49532c: imul eax,eax,0x16
49532f: cmp BYTE PTR [esi+eax*8-0x18],0x6
495334: jne 0x49533f
495336: mov dl,0x18
495338: mov eax,ebx
49533a: call 0x4775fc
49533f: xor eax,eax
495341: mov al,bl
495343: imul eax,eax,0x16
495346: cmp BYTE PTR [esi+eax*8-0xa0],0x2
49534e: jne 0x495476
495354: cmp BYTE PTR [esp],0x1
495358: jne 0x495371
49535a: xor eax,eax
49535c: mov al,bl
49535e: imul eax,eax,0x16
495361: cmp BYTE PTR [esi+eax*8-0x18],0x2
495366: jne 0x495371
495368: mov dl,0x10
49536a: mov eax,ebx
49536c: call 0x4775fc
495371: cmp BYTE PTR [esp],0x3
495375: jne 0x49538e
495377: xor eax,eax
495379: mov al,bl
49537b: imul eax,eax,0x16
49537e: cmp BYTE PTR [esi+eax*8-0x18],0x2
495383: jne 0x49538e
495385: mov dl,0x11
495387: mov eax,ebx
495389: call 0x4775fc
49538e: cmp BYTE PTR [esp],0x1
495392: jne 0x4953ab
495394: xor eax,eax
495396: mov al,bl
495398: imul eax,eax,0x16
49539b: cmp BYTE PTR [esi+eax*8-0x18],0x5
4953a0: jne 0x4953ab
4953a2: mov dl,0x12
4953a4: mov eax,ebx
4953a6: call 0x4775fc
4953ab: cmp BYTE PTR [esp],0x3
4953af: jne 0x4953c8
4953b1: xor eax,eax
4953b3: mov al,bl
4953b5: imul eax,eax,0x16
4953b8: cmp BYTE PTR [esi+eax*8-0x18],0x5
4953bd: jne 0x4953c8
4953bf: mov dl,0x13
4953c1: mov eax,ebx
4953c3: call 0x4775fc
4953c8: cmp BYTE PTR [esp],0x2
4953cc: jne 0x4953e5
4953ce: xor eax,eax
4953d0: mov al,bl
4953d2: imul eax,eax,0x16
4953d5: cmp BYTE PTR [esi+eax*8-0x18],0x6
4953da: jne 0x4953e5
4953dc: mov dl,0x14
4953de: mov eax,ebx
4953e0: call 0x4775fc
4953e5: cmp BYTE PTR [esp],0x4
4953e9: jne 0x495402
4953eb: xor eax,eax
4953ed: mov al,bl
4953ef: imul eax,eax,0x16
4953f2: cmp BYTE PTR [esi+eax*8-0x18],0x6
4953f7: jne 0x495402
4953f9: mov dl,0x15
4953fb: mov eax,ebx
4953fd: call 0x4775fc
495402: cmp BYTE PTR [esp],0x2
495406: jne 0x49541f
495408: xor eax,eax
49540a: mov al,bl
49540c: imul eax,eax,0x16
49540f: cmp BYTE PTR [esi+eax*8-0x18],0x8
495414: jne 0x49541f
495416: mov dl,0x16
495418: mov eax,ebx
49541a: call 0x4775fc
49541f: cmp BYTE PTR [esp],0x4
495423: jne 0x49543c
495425: xor eax,eax
495427: mov al,bl
495429: imul eax,eax,0x16
49542c: cmp BYTE PTR [esi+eax*8-0x18],0x8
495431: jne 0x49543c
495433: mov dl,0x16
495435: mov eax,ebx
495437: call 0x4775fc
49543c: cmp BYTE PTR [esp],0x1
495440: jne 0x495459
495442: xor eax,eax
495444: mov al,bl
495446: imul eax,eax,0x16
495449: cmp BYTE PTR [esi+eax*8-0x18],0xa
49544e: jne 0x495459
495450: mov dl,0x17
495452: mov eax,ebx
495454: call 0x4775fc
495459: cmp BYTE PTR [esp],0x3
49545d: jne 0x495476
49545f: xor eax,eax
495461: mov al,bl
495463: imul eax,eax,0x16
495466: cmp BYTE PTR [esi+eax*8-0x18],0xa
49546b: jne 0x495476
49546d: mov dl,0x17
49546f: mov eax,ebx
495471: call 0x4775fc
495476: xor eax,eax
495478: mov al,bl
49547a: imul eax,eax,0x16
49547d: cmp BYTE PTR [esi+eax*8-0xa0],0x3
495485: jne 0x4955ad
49548b: cmp BYTE PTR [esp],0x1
49548f: jne 0x4954a8
495491: xor eax,eax
495493: mov al,bl
495495: imul eax,eax,0x16
495498: cmp BYTE PTR [esi+eax*8-0x18],0x2
49549d: jne 0x4954a8
49549f: mov dl,0x10
4954a1: mov eax,ebx
4954a3: call 0x4775fc
4954a8: cmp BYTE PTR [esp],0x3
4954ac: jne 0x4954c5
4954ae: xor eax,eax
4954b0: mov al,bl
4954b2: imul eax,eax,0x16
4954b5: cmp BYTE PTR [esi+eax*8-0x18],0x2
4954ba: jne 0x4954c5
4954bc: mov dl,0x11
4954be: mov eax,ebx
4954c0: call 0x4775fc
4954c5: cmp BYTE PTR [esp],0x1
4954c9: jne 0x4954e2
4954cb: xor eax,eax
4954cd: mov al,bl
4954cf: imul eax,eax,0x16
4954d2: cmp BYTE PTR [esi+eax*8-0x18],0x5
4954d7: jne 0x4954e2
4954d9: mov dl,0x12
4954db: mov eax,ebx
4954dd: call 0x4775fc
4954e2: cmp BYTE PTR [esp],0x3
4954e6: jne 0x4954ff
4954e8: xor eax,eax
4954ea: mov al,bl
4954ec: imul eax,eax,0x16
4954ef: cmp BYTE PTR [esi+eax*8-0x18],0x5
4954f4: jne 0x4954ff
4954f6: mov dl,0x13
4954f8: mov eax,ebx
4954fa: call 0x4775fc
4954ff: cmp BYTE PTR [esp],0x1
495503: jne 0x49551c
495505: xor eax,eax
495507: mov al,bl
495509: imul eax,eax,0x16
49550c: cmp BYTE PTR [esi+eax*8-0x18],0x6
495511: jne 0x49551c
495513: mov dl,0x14
495515: mov eax,ebx
495517: call 0x4775fc
49551c: cmp BYTE PTR [esp],0x3
495520: jne 0x495539
495522: xor eax,eax
495524: mov al,bl
495526: imul eax,eax,0x16
495529: cmp BYTE PTR [esi+eax*8-0x18],0x6
49552e: jne 0x495539
495530: mov dl,0x15
495532: mov eax,ebx
495534: call 0x4775fc
495539: cmp BYTE PTR [esp],0x2
49553d: jne 0x495556
49553f: xor eax,eax
495541: mov al,bl
495543: imul eax,eax,0x16
495546: cmp BYTE PTR [esi+eax*8-0x18],0x6
49554b: jne 0x495556
49554d: mov dl,0x16
49554f: mov eax,ebx
495551: call 0x4775fc
495556: cmp BYTE PTR [esp],0x4
49555a: jne 0x495573
49555c: xor eax,eax
49555e: mov al,bl
495560: imul eax,eax,0x16
495563: cmp BYTE PTR [esi+eax*8-0x18],0x6
495568: jne 0x495573
49556a: mov dl,0x17
49556c: mov eax,ebx
49556e: call 0x4775fc
495573: cmp BYTE PTR [esp],0x2
495577: jne 0x495590
495579: xor eax,eax
49557b: mov al,bl
49557d: imul eax,eax,0x16
495580: cmp BYTE PTR [esi+eax*8-0x18],0x8
495585: jne 0x495590
495587: mov dl,0x18
495589: mov eax,ebx
49558b: call 0x4775fc
495590: cmp BYTE PTR [esp],0x4
495594: jne 0x4955ad
495596: xor eax,eax
495598: mov al,bl
49559a: imul eax,eax,0x16
49559d: cmp BYTE PTR [esi+eax*8-0x18],0x8
4955a2: jne 0x4955ad
4955a4: mov dl,0x18
4955a6: mov eax,ebx
4955a8: call 0x4775fc
4955ad: xor eax,eax
4955af: mov al,bl
4955b1: imul eax,eax,0x16
4955b4: cmp BYTE PTR [esi+eax*8-0xa0],0x4
4955bc: jne 0x495792
4955c2: cmp BYTE PTR [esp],0x1
4955c6: jne 0x4955df
4955c8: xor eax,eax
4955ca: mov al,bl
4955cc: imul eax,eax,0x16
4955cf: cmp BYTE PTR [esi+eax*8-0x18],0x2
4955d4: jne 0x4955df
4955d6: mov dl,0x10
4955d8: mov eax,ebx
4955da: call 0x4775fc
4955df: cmp BYTE PTR [esp],0x3
4955e3: jne 0x4955fc
4955e5: xor eax,eax
4955e7: mov al,bl
4955e9: imul eax,eax,0x16
4955ec: cmp BYTE PTR [esi+eax*8-0x18],0x2
4955f1: jne 0x4955fc
4955f3: mov dl,0x11
4955f5: mov eax,ebx
4955f7: call 0x4775fc
4955fc: cmp BYTE PTR [esp],0x1
495600: jne 0x495619
495602: xor eax,eax
495604: mov al,bl
495606: imul eax,eax,0x16
495609: cmp BYTE PTR [esi+eax*8-0x18],0x5
49560e: jne 0x495619
495610: mov dl,0x12
495612: mov eax,ebx
495614: call 0x4775fc
495619: cmp BYTE PTR [esp],0x3
49561d: jne 0x495636
49561f: xor eax,eax
495621: mov al,bl
495623: imul eax,eax,0x16
495626: cmp BYTE PTR [esi+eax*8-0x18],0x5
49562b: jne 0x495636
49562d: mov dl,0x13
49562f: mov eax,ebx
495631: call 0x4775fc
495636: cmp BYTE PTR [esp],0x2
49563a: jne 0x495653
49563c: xor eax,eax
49563e: mov al,bl
495640: imul eax,eax,0x16
495643: cmp BYTE PTR [esi+eax*8-0x18],0x8
495648: jne 0x495653
49564a: mov dl,0x14
49564c: mov eax,ebx
49564e: call 0x4775fc
495653: cmp BYTE PTR [esp],0x4
495657: jne 0x495670
495659: xor eax,eax
49565b: mov al,bl
49565d: imul eax,eax,0x16
495660: cmp BYTE PTR [esi+eax*8-0x18],0x8
495665: jne 0x495670
495667: mov dl,0x15
495669: mov eax,ebx
49566b: call 0x4775fc
495670: cmp BYTE PTR [esp],0x1
495674: jne 0x49568d
495676: xor eax,eax
495678: mov al,bl
49567a: imul eax,eax,0x16
49567d: cmp BYTE PTR [esi+eax*8-0x18],0x9
495682: jne 0x49568d
495684: mov dl,0x16
495686: mov eax,ebx
495688: call 0x4775fc
49568d: cmp BYTE PTR [esp],0x3
495691: jne 0x4956aa
495693: xor eax,eax
495695: mov al,bl
495697: imul eax,eax,0x16
49569a: cmp BYTE PTR [esi+eax*8-0x18],0x9
49569f: jne 0x4956aa
4956a1: mov dl,0x17
4956a3: mov eax,ebx
4956a5: call 0x4775fc
4956aa: cmp BYTE PTR [esp],0x1
4956ae: jne 0x4956c7
4956b0: xor eax,eax
4956b2: mov al,bl
4956b4: imul eax,eax,0x16
4956b7: cmp BYTE PTR [esi+eax*8-0x18],0x8
4956bc: jne 0x4956c7
4956be: mov dl,0x16
4956c0: mov eax,ebx
4956c2: call 0x4775fc
4956c7: cmp BYTE PTR [esp],0x3
4956cb: jne 0x4956e4
4956cd: xor eax,eax
4956cf: mov al,bl
4956d1: imul eax,eax,0x16
4956d4: cmp BYTE PTR [esi+eax*8-0x18],0x8
4956d9: jne 0x4956e4
4956db: mov dl,0x17
4956dd: mov eax,ebx
4956df: call 0x4775fc
4956e4: cmp BYTE PTR [esp],0x2
4956e8: jne 0x495701
4956ea: xor eax,eax
4956ec: mov al,bl
4956ee: imul eax,eax,0x16
4956f1: cmp BYTE PTR [esi+eax*8-0x18],0xb
4956f6: jne 0x495701
4956f8: mov dl,0x18
4956fa: mov eax,ebx
4956fc: call 0x4775fc
495701: cmp BYTE PTR [esp],0x4
495705: jne 0x49571e
495707: xor eax,eax
495709: mov al,bl
49570b: imul eax,eax,0x16
49570e: cmp BYTE PTR [esi+eax*8-0x18],0xb
495713: jne 0x49571e
495715: mov dl,0x18
495717: mov eax,ebx
495719: call 0x4775fc
49571e: cmp BYTE PTR [esp],0x2
495722: jne 0x49573b
495724: xor eax,eax
495726: mov al,bl
495728: imul eax,eax,0x16
49572b: cmp BYTE PTR [esi+eax*8-0x18],0xb
495730: jne 0x49573b
495732: mov dl,0x14
495734: mov eax,ebx
495736: call 0x4775fc
49573b: cmp BYTE PTR [esp],0x4
49573f: jne 0x495758
495741: xor eax,eax
495743: mov al,bl
495745: imul eax,eax,0x16
495748: cmp BYTE PTR [esi+eax*8-0x18],0xb
49574d: jne 0x495758
49574f: mov dl,0x15
495751: mov eax,ebx
495753: call 0x4775fc
495758: cmp BYTE PTR [esp],0x1
49575c: jne 0x495775
49575e: xor eax,eax
495760: mov al,bl
495762: imul eax,eax,0x16
495765: cmp BYTE PTR [esi+eax*8-0x18],0xb
49576a: jne 0x495775
49576c: mov dl,0x16
49576e: mov eax,ebx
495770: call 0x4775fc
495775: cmp BYTE PTR [esp],0x3
495779: jne 0x495792
49577b: xor eax,eax
49577d: mov al,bl
49577f: imul eax,eax,0x16
495782: cmp BYTE PTR [esi+eax*8-0x18],0xb
495787: jne 0x495792
495789: mov dl,0x17
49578b: mov eax,ebx
49578d: call 0x4775fc
495792: xor eax,eax
495794: mov al,bl
495796: imul eax,eax,0x16
495799: cmp BYTE PTR [esi+eax*8-0xa0],0x5
4957a1: jne 0x495903
4957a7: cmp BYTE PTR [esp],0x1
4957ab: jne 0x4957c4
4957ad: xor eax,eax
4957af: mov al,bl
4957b1: imul eax,eax,0x16
4957b4: cmp BYTE PTR [esi+eax*8-0x18],0x2
4957b9: jne 0x4957c4
4957bb: mov dl,0x10
4957bd: mov eax,ebx
4957bf: call 0x4775fc
4957c4: cmp BYTE PTR [esp],0x3
4957c8: jne 0x4957e1
4957ca: xor eax,eax
4957cc: mov al,bl
4957ce: imul eax,eax,0x16
4957d1: cmp BYTE PTR [esi+eax*8-0x18],0x2
4957d6: jne 0x4957e1
4957d8: mov dl,0x11
4957da: mov eax,ebx
4957dc: call 0x4775fc
4957e1: cmp BYTE PTR [esp],0x1
4957e5: jne 0x4957fe
4957e7: xor eax,eax
4957e9: mov al,bl
4957eb: imul eax,eax,0x16
4957ee: cmp BYTE PTR [esi+eax*8-0x18],0x6
4957f3: jne 0x4957fe
4957f5: mov dl,0x10
4957f7: mov eax,ebx
4957f9: call 0x4775fc
4957fe: cmp BYTE PTR [esp],0x3
495802: jne 0x49581b
495804: xor eax,eax
495806: mov al,bl
495808: imul eax,eax,0x16
49580b: cmp BYTE PTR [esi+eax*8-0x18],0x6
495810: jne 0x49581b
495812: mov dl,0x11
495814: mov eax,ebx
495816: call 0x4775fc
49581b: cmp BYTE PTR [esp],0x2
49581f: jne 0x495838
495821: xor eax,eax
495823: mov al,bl
495825: imul eax,eax,0x16
495828: cmp BYTE PTR [esi+eax*8-0x18],0x3
49582d: jne 0x495838
49582f: mov dl,0x12
495831: mov eax,ebx
495833: call 0x4775fc
495838: cmp BYTE PTR [esp],0x4
49583c: jne 0x495855
49583e: xor eax,eax
495840: mov al,bl
495842: imul eax,eax,0x16
495845: cmp BYTE PTR [esi+eax*8-0x18],0x3
49584a: jne 0x495855
49584c: mov dl,0x13
49584e: mov eax,ebx
495850: call 0x4775fc
495855: cmp BYTE PTR [esp],0x2
495859: jne 0x495872
49585b: xor eax,eax
49585d: mov al,bl
49585f: imul eax,eax,0x16
495862: cmp BYTE PTR [esi+eax*8-0x18],0x4
495867: jne 0x495872
495869: mov dl,0x14
49586b: mov eax,ebx
49586d: call 0x4775fc
495872: cmp BYTE PTR [esp],0x4
495876: jne 0x49588f
495878: xor eax,eax
49587a: mov al,bl
49587c: imul eax,eax,0x16
49587f: cmp BYTE PTR [esi+eax*8-0x18],0x4
495884: jne 0x49588f
495886: mov dl,0x15
495888: mov eax,ebx
49588a: call 0x4775fc
49588f: cmp BYTE PTR [esp],0x2
495893: jne 0x4958ac
495895: xor eax,eax
495897: mov al,bl
495899: imul eax,eax,0x16
49589c: cmp BYTE PTR [esi+eax*8-0x13],0x6
4958a1: jb 0x4958ac
4958a3: mov dl,0x16
4958a5: mov eax,ebx
4958a7: call 0x4775fc
4958ac: cmp BYTE PTR [esp],0x4
4958b0: jne 0x4958c9
4958b2: xor eax,eax
4958b4: mov al,bl
4958b6: imul eax,eax,0x16
4958b9: cmp BYTE PTR [esi+eax*8-0x13],0x6
4958be: jb 0x4958c9
4958c0: mov dl,0x17
4958c2: mov eax,ebx
4958c4: call 0x4775fc
4958c9: cmp BYTE PTR [esp],0x2
4958cd: jne 0x4958e6
4958cf: xor eax,eax
4958d1: mov al,bl
4958d3: imul eax,eax,0x16
4958d6: cmp BYTE PTR [esi+eax*8-0x18],0x6
4958db: jne 0x4958e6
4958dd: mov dl,0x18
4958df: mov eax,ebx
4958e1: call 0x4775fc
4958e6: cmp BYTE PTR [esp],0x4
4958ea: jne 0x495903
4958ec: xor eax,eax
4958ee: mov al,bl
4958f0: imul eax,eax,0x16
4958f3: cmp BYTE PTR [esi+eax*8-0x18],0x6
4958f8: jne 0x495903
4958fa: mov dl,0x18
4958fc: mov eax,ebx
4958fe: call 0x4775fc
495903: xor eax,eax
495905: mov al,bl
495907: imul eax,eax,0x16
49590a: cmp BYTE PTR [esi+eax*8-0xa0],0x6
495912: jne 0x495aae
495918: cmp BYTE PTR [esp],0x1
49591c: jne 0x495935
49591e: xor eax,eax
495920: mov al,bl
495922: imul eax,eax,0x16
495925: cmp BYTE PTR [esi+eax*8-0x18],0x2
49592a: jne 0x495935
49592c: mov dl,0x10
49592e: mov eax,ebx
495930: call 0x4775fc
495935: cmp BYTE PTR [esp],0x3
495939: jne 0x495952
49593b: xor eax,eax
49593d: mov al,bl
49593f: imul eax,eax,0x16
495942: cmp BYTE PTR [esi+eax*8-0x18],0x2
495947: jne 0x495952
495949: mov dl,0x11
49594b: mov eax,ebx
49594d: call 0x4775fc
495952: cmp BYTE PTR [esp],0x2
495956: jne 0x49596f
495958: xor eax,eax
49595a: mov al,bl
49595c: imul eax,eax,0x16
49595f: cmp BYTE PTR [esi+eax*8-0x18],0x2
495964: jne 0x49596f
495966: mov dl,0x12
495968: mov eax,ebx
49596a: call 0x4775fc
49596f: cmp BYTE PTR [esp],0x4
495973: jne 0x49598c
495975: xor eax,eax
495977: mov al,bl
495979: imul eax,eax,0x16
49597c: cmp BYTE PTR [esi+eax*8-0x18],0x2
495981: jne 0x49598c
495983: mov dl,0x13
495985: mov eax,ebx
495987: call 0x4775fc
49598c: cmp BYTE PTR [esp],0x1
495990: jne 0x4959a9
495992: xor eax,eax
495994: mov al,bl
495996: imul eax,eax,0x16
495999: cmp BYTE PTR [esi+eax*8-0x18],0x5
49599e: jne 0x4959a9
4959a0: mov dl,0x14
4959a2: mov eax,ebx
4959a4: call 0x4775fc
4959a9: cmp BYTE PTR [esp],0x3
4959ad: jne 0x4959c6
4959af: xor eax,eax
4959b1: mov al,bl
4959b3: imul eax,eax,0x16
4959b6: cmp BYTE PTR [esi+eax*8-0x18],0x5
4959bb: jne 0x4959c6
4959bd: mov dl,0x15
4959bf: mov eax,ebx
4959c1: call 0x4775fc
4959c6: cmp BYTE PTR [esp],0x1
4959ca: jne 0x4959e3
4959cc: xor eax,eax
4959ce: mov al,bl
4959d0: imul eax,eax,0x16
4959d3: cmp BYTE PTR [esi+eax*8-0x18],0x7
4959d8: jne 0x4959e3
4959da: mov dl,0x14
4959dc: mov eax,ebx
4959de: call 0x4775fc
4959e3: cmp BYTE PTR [esp],0x3
4959e7: jne 0x495a00
4959e9: xor eax,eax
4959eb: mov al,bl
4959ed: imul eax,eax,0x16
4959f0: cmp BYTE PTR [esi+eax*8-0x18],0x7
4959f5: jne 0x495a00
4959f7: mov dl,0x15
4959f9: mov eax,ebx
4959fb: call 0x4775fc
495a00: cmp BYTE PTR [esp],0x2
495a04: jne 0x495a1d
495a06: xor eax,eax
495a08: mov al,bl
495a0a: imul eax,eax,0x16
495a0d: cmp BYTE PTR [esi+eax*8-0x18],0x5
495a12: jne 0x495a1d
495a14: mov dl,0x16
495a16: mov eax,ebx
495a18: call 0x4775fc
495a1d: cmp BYTE PTR [esp],0x4
495a21: jne 0x495a3a
495a23: xor eax,eax
495a25: mov al,bl
495a27: imul eax,eax,0x16
495a2a: cmp BYTE PTR [esi+eax*8-0x18],0x5
495a2f: jne 0x495a3a
495a31: mov dl,0x17
495a33: mov eax,ebx
495a35: call 0x4775fc
495a3a: cmp BYTE PTR [esp],0x2
495a3e: jne 0x495a57
495a40: xor eax,eax
495a42: mov al,bl
495a44: imul eax,eax,0x16
495a47: cmp BYTE PTR [esi+eax*8-0x18],0x7
495a4c: jne 0x495a57
495a4e: mov dl,0x18
495a50: mov eax,ebx
495a52: call 0x4775fc
495a57: cmp BYTE PTR [esp],0x4
495a5b: jne 0x495a74
495a5d: xor eax,eax
495a5f: mov al,bl
495a61: imul eax,eax,0x16
495a64: cmp BYTE PTR [esi+eax*8-0x18],0x7
495a69: jne 0x495a74
495a6b: mov dl,0x18
495a6d: mov eax,ebx
495a6f: call 0x4775fc
495a74: cmp BYTE PTR [esp],0x2
495a78: jne 0x495a91
495a7a: xor eax,eax
495a7c: mov al,bl
495a7e: imul eax,eax,0x16
495a81: cmp BYTE PTR [esi+eax*8-0x18],0x7
495a86: jne 0x495a91
495a88: mov dl,0x16
495a8a: mov eax,ebx
495a8c: call 0x4775fc
495a91: cmp BYTE PTR [esp],0x4
495a95: jne 0x495aae
495a97: xor eax,eax
495a99: mov al,bl
495a9b: imul eax,eax,0x16
495a9e: cmp BYTE PTR [esi+eax*8-0x18],0x7
495aa3: jne 0x495aae
495aa5: mov dl,0x17
495aa7: mov eax,ebx
495aa9: call 0x4775fc
495aae: xor eax,eax
495ab0: mov al,bl
495ab2: imul eax,eax,0x16
495ab5: cmp BYTE PTR [esi+eax*8-0xa0],0x7
495abd: jne 0x495be5
495ac3: cmp BYTE PTR [esp],0x1
495ac7: jne 0x495ae0
495ac9: xor eax,eax
495acb: mov al,bl
495acd: imul eax,eax,0x16
495ad0: cmp BYTE PTR [esi+eax*8-0x14],0x6
495ad5: jb 0x495ae0
495ad7: mov dl,0x10
495ad9: mov eax,ebx
495adb: call 0x4775fc
495ae0: cmp BYTE PTR [esp],0x3
495ae4: jne 0x495afd
495ae6: xor eax,eax
495ae8: mov al,bl
495aea: imul eax,eax,0x16
495aed: cmp BYTE PTR [esi+eax*8-0x14],0x6
495af2: jb 0x495afd
495af4: mov dl,0x11
495af6: mov eax,ebx
495af8: call 0x4775fc
495afd: cmp BYTE PTR [esp],0x1
495b01: jne 0x495b1a
495b03: xor eax,eax
495b05: mov al,bl
495b07: imul eax,eax,0x16
495b0a: cmp BYTE PTR [esi+eax*8-0x18],0x1
495b0f: jne 0x495b1a
495b11: mov dl,0x12
495b13: mov eax,ebx
495b15: call 0x4775fc
495b1a: cmp BYTE PTR [esp],0x3
495b1e: jne 0x495b37
495b20: xor eax,eax
495b22: mov al,bl
495b24: imul eax,eax,0x16
495b27: cmp BYTE PTR [esi+eax*8-0x18],0x1
495b2c: jne 0x495b37
495b2e: mov dl,0x13
495b30: mov eax,ebx
495b32: call 0x4775fc
495b37: cmp BYTE PTR [esp],0x2
495b3b: jne 0x495b54
495b3d: xor eax,eax
495b3f: mov al,bl
495b41: imul eax,eax,0x16
495b44: cmp BYTE PTR [esi+eax*8-0x18],0x2
495b49: jne 0x495b54
495b4b: mov dl,0x14
495b4d: mov eax,ebx
495b4f: call 0x4775fc
495b54: cmp BYTE PTR [esp],0x4
495b58: jne 0x495b71
495b5a: xor eax,eax
495b5c: mov al,bl
495b5e: imul eax,eax,0x16
495b61: cmp BYTE PTR [esi+eax*8-0x18],0x2
495b66: jne 0x495b71
495b68: mov dl,0x15
495b6a: mov eax,ebx
495b6c: call 0x4775fc
495b71: cmp BYTE PTR [esp],0x1
495b75: jne 0x495b8e
495b77: xor eax,eax
495b79: mov al,bl
495b7b: imul eax,eax,0x16
495b7e: cmp BYTE PTR [esi+eax*8-0x18],0x2
495b83: jne 0x495b8e
495b85: mov dl,0x16
495b87: mov eax,ebx
495b89: call 0x4775fc
495b8e: cmp BYTE PTR [esp],0x3
495b92: jne 0x495bab
495b94: xor eax,eax
495b96: mov al,bl
495b98: imul eax,eax,0x16
495b9b: cmp BYTE PTR [esi+eax*8-0x18],0x2
495ba0: jne 0x495bab
495ba2: mov dl,0x17
495ba4: mov eax,ebx
495ba6: call 0x4775fc
495bab: cmp BYTE PTR [esp],0x1
495baf: jne 0x495bc8
495bb1: xor eax,eax
495bb3: mov al,bl
495bb5: imul eax,eax,0x16
495bb8: cmp BYTE PTR [esi+eax*8-0x18],0x6
495bbd: jne 0x495bc8
495bbf: mov dl,0x18
495bc1: mov eax,ebx
495bc3: call 0x4775fc
495bc8: cmp BYTE PTR [esp],0x3
495bcc: jne 0x495be5
495bce: xor eax,eax
495bd0: mov al,bl
495bd2: imul eax,eax,0x16
495bd5: cmp BYTE PTR [esi+eax*8-0x18],0x6
495bda: jne 0x495be5
495bdc: mov dl,0x18
495bde: mov eax,ebx
495be0: call 0x4775fc
495be5: xor eax,eax
495be7: mov al,bl
495be9: imul eax,eax,0x16
495bec: cmp BYTE PTR [esi+eax*8-0xa0],0x8
495bf4: jne 0x495e1e
495bfa: cmp BYTE PTR [esp],0x1
495bfe: jne 0x495c17
495c00: xor eax,eax
495c02: mov al,bl
495c04: imul eax,eax,0x16
495c07: cmp BYTE PTR [esi+eax*8-0x18],0x2
495c0c: jne 0x495c17
495c0e: mov dl,0x10
495c10: mov eax,ebx
495c12: call 0x4775fc
495c17: cmp BYTE PTR [esp],0x3
495c1b: jne 0x495c34
495c1d: xor eax,eax
495c1f: mov al,bl
495c21: imul eax,eax,0x16
495c24: cmp BYTE PTR [esi+eax*8-0x18],0x2
495c29: jne 0x495c34
495c2b: mov dl,0x11
495c2d: mov eax,ebx
495c2f: call 0x4775fc
495c34: cmp BYTE PTR [esp],0x1
495c38: jne 0x495c5f
495c3a: xor eax,eax
495c3c: mov al,bl
495c3e: imul eax,eax,0x16
495c41: cmp BYTE PTR [esi+eax*8-0x18],0x2
495c46: jne 0x495c5f
495c48: xor eax,eax
495c4a: mov al,bl
495c4c: imul eax,eax,0x16
495c4f: cmp BYTE PTR [esi+eax*8-0x38],0x0
495c54: je 0x495c5f
495c56: mov dl,0x12
495c58: mov eax,ebx
495c5a: call 0x4775fc
495c5f: cmp BYTE PTR [esp],0x3
495c63: jne 0x495c8a
495c65: xor eax,eax
495c67: mov al,bl
495c69: imul eax,eax,0x16
495c6c: cmp BYTE PTR [esi+eax*8-0x18],0x2
495c71: jne 0x495c8a
495c73: xor eax,eax
495c75: mov al,bl
495c77: imul eax,eax,0x16
495c7a: cmp BYTE PTR [esi+eax*8-0x38],0x0
495c7f: je 0x495c8a
495c81: mov dl,0x13
495c83: mov eax,ebx
495c85: call 0x4775fc
495c8a: cmp BYTE PTR [esp],0x1
495c8e: jne 0x495cb5
495c90: xor eax,eax
495c92: mov al,bl
495c94: imul eax,eax,0x16
495c97: cmp BYTE PTR [esi+eax*8-0x18],0x5
495c9c: jne 0x495cb5
495c9e: xor eax,eax
495ca0: mov al,bl
495ca2: imul eax,eax,0x16
495ca5: cmp BYTE PTR [esi+eax*8-0x38],0x0
495caa: je 0x495cb5
495cac: mov dl,0x12
495cae: mov eax,ebx
495cb0: call 0x4775fc
495cb5: cmp BYTE PTR [esp],0x3
495cb9: jne 0x495ce0
495cbb: xor eax,eax
495cbd: mov al,bl
495cbf: imul eax,eax,0x16
495cc2: cmp BYTE PTR [esi+eax*8-0x18],0x5
495cc7: jne 0x495ce0
495cc9: xor eax,eax
495ccb: mov al,bl
495ccd: imul eax,eax,0x16
495cd0: cmp BYTE PTR [esi+eax*8-0x38],0x0
495cd5: je 0x495ce0
495cd7: mov dl,0x13
495cd9: mov eax,ebx
495cdb: call 0x4775fc
495ce0: cmp BYTE PTR [esp],0x1
495ce4: jne 0x495cfd
495ce6: xor eax,eax
495ce8: mov al,bl
495cea: imul eax,eax,0x16
495ced: cmp BYTE PTR [esi+eax*8-0x18],0x5
495cf2: jne 0x495cfd
495cf4: mov dl,0x14
495cf6: mov eax,ebx
495cf8: call 0x4775fc
495cfd: cmp BYTE PTR [esp],0x3
495d01: jne 0x495d1a
495d03: xor eax,eax
495d05: mov al,bl
495d07: imul eax,eax,0x16
495d0a: cmp BYTE PTR [esi+eax*8-0x18],0x5
495d0f: jne 0x495d1a
495d11: mov dl,0x15
495d13: mov eax,ebx
495d15: call 0x4775fc
495d1a: cmp BYTE PTR [esp],0x2
495d1e: jne 0x495d37
495d20: xor eax,eax
495d22: mov al,bl
495d24: imul eax,eax,0x16
495d27: cmp BYTE PTR [esi+eax*8-0x18],0x6
495d2c: jne 0x495d37
495d2e: mov dl,0x16
495d30: mov eax,ebx
495d32: call 0x4775fc
495d37: cmp BYTE PTR [esp],0x4
495d3b: jne 0x495d54
495d3d: xor eax,eax
495d3f: mov al,bl
495d41: imul eax,eax,0x16
495d44: cmp BYTE PTR [esi+eax*8-0x18],0x6
495d49: jne 0x495d54
495d4b: mov dl,0x17
495d4d: mov eax,ebx
495d4f: call 0x4775fc
495d54: cmp BYTE PTR [esp],0x2
495d58: jne 0x495d71
495d5a: xor eax,eax
495d5c: mov al,bl
495d5e: imul eax,eax,0x16
495d61: cmp BYTE PTR [esi+eax*8-0x18],0x8
495d66: jne 0x495d71
495d68: mov dl,0x18
495d6a: mov eax,ebx
495d6c: call 0x4775fc
495d71: cmp BYTE PTR [esp],0x4
495d75: jne 0x495d8e
495d77: xor eax,eax
495d79: mov al,bl
495d7b: imul eax,eax,0x16
495d7e: cmp BYTE PTR [esi+eax*8-0x18],0x8
495d83: jne 0x495d8e
495d85: mov dl,0x18
495d87: mov eax,ebx
495d89: call 0x4775fc
495d8e: cmp BYTE PTR [esp],0x1
495d92: jne 0x495dab
495d94: xor eax,eax
495d96: mov al,bl
495d98: imul eax,eax,0x16
495d9b: cmp BYTE PTR [esi+eax*8-0x18],0x8
495da0: jne 0x495dab
495da2: mov dl,0x14
495da4: mov eax,ebx
495da6: call 0x4775fc
495dab: cmp BYTE PTR [esp],0x3
495daf: jne 0x495dc8
495db1: xor eax,eax
495db3: mov al,bl
495db5: imul eax,eax,0x16
495db8: cmp BYTE PTR [esi+eax*8-0x18],0x8
495dbd: jne 0x495dc8
495dbf: mov dl,0x15
495dc1: mov eax,ebx
495dc3: call 0x4775fc
495dc8: cmp BYTE PTR [esp],0x1
495dcc: jne 0x495df3
495dce: xor eax,eax
495dd0: mov al,bl
495dd2: imul eax,eax,0x16
495dd5: cmp BYTE PTR [esi+eax*8-0x18],0x8
495dda: jne 0x495df3
495ddc: xor eax,eax
495dde: mov al,bl
495de0: imul eax,eax,0x16
495de3: cmp BYTE PTR [esi+eax*8-0x38],0x0
495de8: je 0x495df3
495dea: mov dl,0x12
495dec: mov eax,ebx
495dee: call 0x4775fc
495df3: cmp BYTE PTR [esp],0x3
495df7: jne 0x495e1e
495df9: xor eax,eax
495dfb: mov al,bl
495dfd: imul eax,eax,0x16
495e00: cmp BYTE PTR [esi+eax*8-0x18],0x8
495e05: jne 0x495e1e
495e07: xor eax,eax
495e09: mov al,bl
495e0b: imul eax,eax,0x16
495e0e: cmp BYTE PTR [esi+eax*8-0x38],0x0
495e13: je 0x495e1e
495e15: mov dl,0x13
495e17: mov eax,ebx
495e19: call 0x4775fc
495e1e: xor eax,eax
495e20: mov al,bl
495e22: imul eax,eax,0x16
495e25: cmp BYTE PTR [esi+eax*8-0xa0],0x9
495e2d: jne 0x495fc9
495e33: cmp BYTE PTR [esp],0x2
495e37: jne 0x495e50
495e39: xor eax,eax
495e3b: mov al,bl
495e3d: imul eax,eax,0x16
495e40: cmp BYTE PTR [esi+eax*8-0x18],0x2
495e45: jne 0x495e50
495e47: mov dl,0x10
495e49: mov eax,ebx
495e4b: call 0x4775fc
495e50: cmp BYTE PTR [esp],0x4
495e54: jne 0x495e6d
495e56: xor eax,eax
495e58: mov al,bl
495e5a: imul eax,eax,0x16
495e5d: cmp BYTE PTR [esi+eax*8-0x18],0x2
495e62: jne 0x495e6d
495e64: mov dl,0x11
495e66: mov eax,ebx
495e68: call 0x4775fc
495e6d: cmp BYTE PTR [esp],0x2
495e71: jne 0x495e8a
495e73: xor eax,eax
495e75: mov al,bl
495e77: imul eax,eax,0x16
495e7a: cmp BYTE PTR [esi+eax*8-0x18],0x5
495e7f: jne 0x495e8a
495e81: mov dl,0x12
495e83: mov eax,ebx
495e85: call 0x4775fc
495e8a: cmp BYTE PTR [esp],0x4
495e8e: jne 0x495ea7
495e90: xor eax,eax
495e92: mov al,bl
495e94: imul eax,eax,0x16
495e97: cmp BYTE PTR [esi+eax*8-0x18],0x5
495e9c: jne 0x495ea7
495e9e: mov dl,0x13
495ea0: mov eax,ebx
495ea2: call 0x4775fc
495ea7: cmp BYTE PTR [esp],0x1
495eab: jne 0x495ec4
495ead: xor eax,eax
495eaf: mov al,bl
495eb1: imul eax,eax,0x16
495eb4: cmp BYTE PTR [esi+eax*8-0x18],0x2
495eb9: jne 0x495ec4
495ebb: mov dl,0x14
495ebd: mov eax,ebx
495ebf: call 0x4775fc
495ec4: cmp BYTE PTR [esp],0x3
495ec8: jne 0x495ee1
495eca: xor eax,eax
495ecc: mov al,bl
495ece: imul eax,eax,0x16
495ed1: cmp BYTE PTR [esi+eax*8-0x18],0x2
495ed6: jne 0x495ee1
495ed8: mov dl,0x15
495eda: mov eax,ebx
495edc: call 0x4775fc
495ee1: cmp BYTE PTR [esp],0x1
495ee5: jne 0x495efe
495ee7: xor eax,eax
495ee9: mov al,bl
495eeb: imul eax,eax,0x16
495eee: cmp BYTE PTR [esi+eax*8-0x18],0x8
495ef3: jne 0x495efe
495ef5: mov dl,0x14
495ef7: mov eax,ebx
495ef9: call 0x4775fc
495efe: cmp BYTE PTR [esp],0x3
495f02: jne 0x495f1b
495f04: xor eax,eax
495f06: mov al,bl
495f08: imul eax,eax,0x16
495f0b: cmp BYTE PTR [esi+eax*8-0x18],0x8
495f10: jne 0x495f1b
495f12: mov dl,0x15
495f14: mov eax,ebx
495f16: call 0x4775fc
495f1b: cmp BYTE PTR [esp],0x2
495f1f: jne 0x495f38
495f21: xor eax,eax
495f23: mov al,bl
495f25: imul eax,eax,0x16
495f28: cmp BYTE PTR [esi+eax*8-0x18],0x6
495f2d: jne 0x495f38
495f2f: mov dl,0x16
495f31: mov eax,ebx
495f33: call 0x4775fc
495f38: cmp BYTE PTR [esp],0x4
495f3c: jne 0x495f55
495f3e: xor eax,eax
495f40: mov al,bl
495f42: imul eax,eax,0x16
495f45: cmp BYTE PTR [esi+eax*8-0x18],0x6
495f4a: jne 0x495f55
495f4c: mov dl,0x17
495f4e: mov eax,ebx
495f50: call 0x4775fc
495f55: cmp BYTE PTR [esp],0x2
495f59: jne 0x495f72
495f5b: xor eax,eax
495f5d: mov al,bl
495f5f: imul eax,eax,0x16
495f62: cmp BYTE PTR [esi+eax*8-0x18],0x8
495f67: jne 0x495f72
495f69: mov dl,0x18
495f6b: mov eax,ebx
495f6d: call 0x4775fc
495f72: cmp BYTE PTR [esp],0x4
495f76: jne 0x495f8f
495f78: xor eax,eax
495f7a: mov al,bl
495f7c: imul eax,eax,0x16
495f7f: cmp BYTE PTR [esi+eax*8-0x18],0x8
495f84: jne 0x495f8f
495f86: mov dl,0x18
495f88: mov eax,ebx
495f8a: call 0x4775fc
495f8f: cmp BYTE PTR [esp],0x2
495f93: jne 0x495fac
495f95: xor eax,eax
495f97: mov al,bl
495f99: imul eax,eax,0x16
495f9c: cmp BYTE PTR [esi+eax*8-0x18],0x8
495fa1: jne 0x495fac
495fa3: mov dl,0x10
495fa5: mov eax,ebx
495fa7: call 0x4775fc
495fac: cmp BYTE PTR [esp],0x4
495fb0: jne 0x495fc9
495fb2: xor eax,eax
495fb4: mov al,bl
495fb6: imul eax,eax,0x16
495fb9: cmp BYTE PTR [esi+eax*8-0x18],0x8
495fbe: jne 0x495fc9
495fc0: mov dl,0x11
495fc2: mov eax,ebx
495fc4: call 0x4775fc
495fc9: xor eax,eax
495fcb: mov al,bl
495fcd: imul eax,eax,0x16
495fd0: cmp BYTE PTR [esi+eax*8-0xa0],0xa
495fd8: jne 0x496100
495fde: cmp BYTE PTR [esp],0x1
495fe2: jne 0x495ffb
495fe4: xor eax,eax
495fe6: mov al,bl
495fe8: imul eax,eax,0x16
495feb: cmp BYTE PTR [esi+eax*8-0x14],0x6
495ff0: jb 0x495ffb
495ff2: mov dl,0x10
495ff4: mov eax,ebx
495ff6: call 0x4775fc
495ffb: cmp BYTE PTR [esp],0x3
495fff: jne 0x496018
496001: xor eax,eax
496003: mov al,bl
496005: imul eax,eax,0x16
496008: cmp BYTE PTR [esi+eax*8-0x14],0x6
49600d: jb 0x496018
49600f: mov dl,0x11
496011: mov eax,ebx
496013: call 0x4775fc
496018: cmp BYTE PTR [esp],0x1
49601c: jne 0x496035
49601e: xor eax,eax
496020: mov al,bl
496022: imul eax,eax,0x16
496025: cmp BYTE PTR [esi+eax*8-0x18],0x1
49602a: jne 0x496035
49602c: mov dl,0x12
49602e: mov eax,ebx
496030: call 0x4775fc
496035: cmp BYTE PTR [esp],0x3
496039: jne 0x496052
49603b: xor eax,eax
49603d: mov al,bl
49603f: imul eax,eax,0x16
496042: cmp BYTE PTR [esi+eax*8-0x18],0x1
496047: jne 0x496052
496049: mov dl,0x13
49604b: mov eax,ebx
49604d: call 0x4775fc
496052: cmp BYTE PTR [esp],0x2
496056: jne 0x49606f
496058: xor eax,eax
49605a: mov al,bl
49605c: imul eax,eax,0x16
49605f: cmp BYTE PTR [esi+eax*8-0x18],0x2
496064: jne 0x49606f
496066: mov dl,0x14
496068: mov eax,ebx
49606a: call 0x4775fc
49606f: cmp BYTE PTR [esp],0x4
496073: jne 0x49608c
496075: xor eax,eax
496077: mov al,bl
496079: imul eax,eax,0x16
49607c: cmp BYTE PTR [esi+eax*8-0x18],0x2
496081: jne 0x49608c
496083: mov dl,0x15
496085: mov eax,ebx
496087: call 0x4775fc
49608c: cmp BYTE PTR [esp],0x2
496090: jne 0x4960a9
496092: xor eax,eax
496094: mov al,bl
496096: imul eax,eax,0x16
496099: cmp BYTE PTR [esi+eax*8-0x18],0x4
49609e: jne 0x4960a9
4960a0: mov dl,0x16
4960a2: mov eax,ebx
4960a4: call 0x4775fc
4960a9: cmp BYTE PTR [esp],0x4
4960ad: jne 0x4960c6
4960af: xor eax,eax
4960b1: mov al,bl
4960b3: imul eax,eax,0x16
4960b6: cmp BYTE PTR [esi+eax*8-0x18],0x4
4960bb: jne 0x4960c6
4960bd: mov dl,0x17
4960bf: mov eax,ebx
4960c1: call 0x4775fc
4960c6: cmp BYTE PTR [esp],0x1
4960ca: jne 0x4960e3
4960cc: xor eax,eax
4960ce: mov al,bl
4960d0: imul eax,eax,0x16
4960d3: cmp BYTE PTR [esi+eax*8-0x18],0x6
4960d8: jne 0x4960e3
4960da: mov dl,0x18
4960dc: mov eax,ebx
4960de: call 0x4775fc
4960e3: cmp BYTE PTR [esp],0x3
4960e7: jne 0x496100
4960e9: xor eax,eax
4960eb: mov al,bl
4960ed: imul eax,eax,0x16
4960f0: cmp BYTE PTR [esi+eax*8-0x18],0x6
4960f5: jne 0x496100
4960f7: mov dl,0x18
4960f9: mov eax,ebx
4960fb: call 0x4775fc
496100: xor eax,eax
496102: mov al,bl
496104: imul eax,eax,0x16
496107: cmp BYTE PTR [esi+eax*8-0xa0],0xb
49610f: jne 0x4962ab
496115: cmp BYTE PTR [esp],0x1
496119: jne 0x496132
49611b: xor eax,eax
49611d: mov al,bl
49611f: imul eax,eax,0x16
496122: cmp BYTE PTR [esi+eax*8-0x18],0x2
496127: jne 0x496132
496129: mov dl,0x10
49612b: mov eax,ebx
49612d: call 0x4775fc
496132: cmp BYTE PTR [esp],0x3
496136: jne 0x49614f
496138: xor eax,eax
49613a: mov al,bl
49613c: imul eax,eax,0x16
49613f: cmp BYTE PTR [esi+eax*8-0x18],0x2
496144: jne 0x49614f
496146: mov dl,0x11
496148: mov eax,ebx
49614a: call 0x4775fc
49614f: cmp BYTE PTR [esp],0x1
496153: jne 0x49616c
496155: xor eax,eax
496157: mov al,bl
496159: imul eax,eax,0x16
49615c: cmp BYTE PTR [esi+eax*8-0x18],0x5
496161: jne 0x49616c
496163: mov dl,0x10
496165: mov eax,ebx
496167: call 0x4775fc
49616c: cmp BYTE PTR [esp],0x3
496170: jne 0x496189
496172: xor eax,eax
496174: mov al,bl
496176: imul eax,eax,0x16
496179: cmp BYTE PTR [esi+eax*8-0x18],0x5
49617e: jne 0x496189
496180: mov dl,0x11
496182: mov eax,ebx
496184: call 0x4775fc
496189: cmp BYTE PTR [esp],0x1
49618d: jne 0x4961a6
49618f: xor eax,eax
496191: mov al,bl
496193: imul eax,eax,0x16
496196: cmp BYTE PTR [esi+eax*8-0x18],0x3
49619b: jne 0x4961a6
49619d: mov dl,0x12
49619f: mov eax,ebx
4961a1: call 0x4775fc
4961a6: cmp BYTE PTR [esp],0x3
4961aa: jne 0x4961c3
4961ac: xor eax,eax
4961ae: mov al,bl
4961b0: imul eax,eax,0x16
4961b3: cmp BYTE PTR [esi+eax*8-0x18],0x3
4961b8: jne 0x4961c3
4961ba: mov dl,0x13
4961bc: mov eax,ebx
4961be: call 0x4775fc
4961c3: cmp BYTE PTR [esp],0x2
4961c7: jne 0x4961e0
4961c9: xor eax,eax
4961cb: mov al,bl
4961cd: imul eax,eax,0x16
4961d0: cmp BYTE PTR [esi+eax*8-0x18],0x2
4961d5: jne 0x4961e0
4961d7: mov dl,0x14
4961d9: mov eax,ebx
4961db: call 0x4775fc
4961e0: cmp BYTE PTR [esp],0x4
4961e4: jne 0x4961fd
4961e6: xor eax,eax
4961e8: mov al,bl
4961ea: imul eax,eax,0x16
4961ed: cmp BYTE PTR [esi+eax*8-0x18],0x2
4961f2: jne 0x4961fd
4961f4: mov dl,0x15
4961f6: mov eax,ebx
4961f8: call 0x4775fc
4961fd: cmp BYTE PTR [esp],0x2
496201: jne 0x49621a
496203: xor eax,eax
496205: mov al,bl
496207: imul eax,eax,0x16
49620a: cmp BYTE PTR [esi+eax*8-0x18],0x3
49620f: jne 0x49621a
496211: mov dl,0x16
496213: mov eax,ebx
496215: call 0x4775fc
49621a: cmp BYTE PTR [esp],0x4
49621e: jne 0x496237
496220: xor eax,eax
496222: mov al,bl
496224: imul eax,eax,0x16
496227: cmp BYTE PTR [esi+eax*8-0x18],0x3
49622c: jne 0x496237
49622e: mov dl,0x17
496230: mov eax,ebx
496232: call 0x4775fc
496237: cmp BYTE PTR [esp],0x2
49623b: jne 0x496254
49623d: xor eax,eax
49623f: mov al,bl
496241: imul eax,eax,0x16
496244: cmp BYTE PTR [esi+eax*8-0x18],0x5
496249: jne 0x496254
49624b: mov dl,0x18
49624d: mov eax,ebx
49624f: call 0x4775fc
496254: cmp BYTE PTR [esp],0x4
496258: jne 0x496271
49625a: xor eax,eax
49625c: mov al,bl
49625e: imul eax,eax,0x16
496261: cmp BYTE PTR [esi+eax*8-0x18],0x5
496266: jne 0x496271
496268: mov dl,0x18
49626a: mov eax,ebx
49626c: call 0x4775fc
496271: cmp BYTE PTR [esp],0x2
496275: jne 0x49628e
496277: xor eax,eax
496279: mov al,bl
49627b: imul eax,eax,0x16
49627e: cmp BYTE PTR [esi+eax*8-0x18],0x5
496283: jne 0x49628e
496285: mov dl,0x14
496287: mov eax,ebx
496289: call 0x4775fc
49628e: cmp BYTE PTR [esp],0x4
496292: jne 0x4962ab
496294: xor eax,eax
496296: mov al,bl
496298: imul eax,eax,0x16
49629b: cmp BYTE PTR [esi+eax*8-0x18],0x5
4962a0: jne 0x4962ab
4962a2: mov dl,0x15
4962a4: mov eax,ebx
4962a6: call 0x4775fc
4962ab: xor eax,eax
4962ad: mov al,bl
4962af: imul eax,eax,0x16
4962b2: cmp BYTE PTR [esi+eax*8-0xa0],0xc
4962ba: jne 0x4963e2
4962c0: cmp BYTE PTR [esp],0x1
4962c4: jne 0x4962dd
4962c6: xor eax,eax
4962c8: mov al,bl
4962ca: imul eax,eax,0x16
4962cd: cmp BYTE PTR [esi+eax*8-0x18],0x2
4962d2: jne 0x4962dd
4962d4: mov dl,0x10
4962d6: mov eax,ebx
4962d8: call 0x4775fc
4962dd: cmp BYTE PTR [esp],0x3
4962e1: jne 0x4962fa
4962e3: xor eax,eax
4962e5: mov al,bl
4962e7: imul eax,eax,0x16
4962ea: cmp BYTE PTR [esi+eax*8-0x18],0x2
4962ef: jne 0x4962fa
4962f1: mov dl,0x11
4962f3: mov eax,ebx
4962f5: call 0x4775fc
4962fa: cmp BYTE PTR [esp],0x1
4962fe: jne 0x496317
496300: xor eax,eax
496302: mov al,bl
496304: imul eax,eax,0x16
496307: cmp BYTE PTR [esi+eax*8-0x18],0x5
49630c: jne 0x496317
49630e: mov dl,0x12
496310: mov eax,ebx
496312: call 0x4775fc
496317: cmp BYTE PTR [esp],0x3
49631b: jne 0x496334
49631d: xor eax,eax
49631f: mov al,bl
496321: imul eax,eax,0x16
496324: cmp BYTE PTR [esi+eax*8-0x18],0x5
496329: jne 0x496334
49632b: mov dl,0x13
49632d: mov eax,ebx
49632f: call 0x4775fc
496334: cmp BYTE PTR [esp],0x2
496338: jne 0x496351
49633a: xor eax,eax
49633c: mov al,bl
49633e: imul eax,eax,0x16
496341: cmp BYTE PTR [esi+eax*8-0x18],0x6
496346: jne 0x496351
496348: mov dl,0x14
49634a: mov eax,ebx
49634c: call 0x4775fc
496351: cmp BYTE PTR [esp],0x4
496355: jne 0x49636e
496357: xor eax,eax
496359: mov al,bl
49635b: imul eax,eax,0x16
49635e: cmp BYTE PTR [esi+eax*8-0x18],0x6
496363: jne 0x49636e
496365: mov dl,0x15
496367: mov eax,ebx
496369: call 0x4775fc
49636e: cmp BYTE PTR [esp],0x2
496372: jne 0x49638b
496374: xor eax,eax
496376: mov al,bl
496378: imul eax,eax,0x16
49637b: cmp BYTE PTR [esi+eax*8-0x18],0x8
496380: jne 0x49638b
496382: mov dl,0x16
496384: mov eax,ebx
496386: call 0x4775fc
49638b: cmp BYTE PTR [esp],0x4
49638f: jne 0x4963a8
496391: xor eax,eax
496393: mov al,bl
496395: imul eax,eax,0x16
496398: cmp BYTE PTR [esi+eax*8-0x18],0x8
49639d: jne 0x4963a8
49639f: mov dl,0x16
4963a1: mov eax,ebx
4963a3: call 0x4775fc
4963a8: cmp BYTE PTR [esp],0x1
4963ac: jne 0x4963c5
4963ae: xor eax,eax
4963b0: mov al,bl
4963b2: imul eax,eax,0x16
4963b5: cmp BYTE PTR [esi+eax*8-0x18],0x8
4963ba: jne 0x4963c5
4963bc: mov dl,0x10
4963be: mov eax,ebx
4963c0: call 0x4775fc
4963c5: cmp BYTE PTR [esp],0x3
4963c9: jne 0x4963e2
4963cb: xor eax,eax
4963cd: mov al,bl
4963cf: imul eax,eax,0x16
4963d2: cmp BYTE PTR [esi+eax*8-0x18],0x8
4963d7: jne 0x4963e2
4963d9: mov dl,0x11
4963db: mov eax,ebx
4963dd: call 0x4775fc
4963e2: xor eax,eax
4963e4: mov al,bl
4963e6: imul eax,eax,0x16
4963e9: cmp BYTE PTR [esi+eax*8-0xa0],0xd
4963f1: jne 0x496553
4963f7: cmp BYTE PTR [esp],0x1
4963fb: jne 0x496414
4963fd: xor eax,eax
4963ff: mov al,bl
496401: imul eax,eax,0x16
496404: cmp BYTE PTR [esi+eax*8-0x18],0x2
496409: jne 0x496414
49640b: mov dl,0x10
49640d: mov eax,ebx
49640f: call 0x4775fc
496414: cmp BYTE PTR [esp],0x3
496418: jne 0x496431
49641a: xor eax,eax
49641c: mov al,bl
49641e: imul eax,eax,0x16
496421: cmp BYTE PTR [esi+eax*8-0x18],0x2
496426: jne 0x496431
496428: mov dl,0x11
49642a: mov eax,ebx
49642c: call 0x4775fc
496431: cmp BYTE PTR [esp],0x2
496435: jne 0x49644e
496437: xor eax,eax
496439: mov al,bl
49643b: imul eax,eax,0x16
49643e: cmp BYTE PTR [esi+eax*8-0x18],0x2
496443: jne 0x49644e
496445: mov dl,0x12
496447: mov eax,ebx
496449: call 0x4775fc
49644e: cmp BYTE PTR [esp],0x4
496452: jne 0x49646b
496454: xor eax,eax
496456: mov al,bl
496458: imul eax,eax,0x16
49645b: cmp BYTE PTR [esi+eax*8-0x18],0x2
496460: jne 0x49646b
496462: mov dl,0x13
496464: mov eax,ebx
496466: call 0x4775fc
49646b: cmp BYTE PTR [esp],0x1
49646f: jne 0x496488
496471: xor eax,eax
496473: mov al,bl
496475: imul eax,eax,0x16
496478: cmp BYTE PTR [esi+eax*8-0x18],0x3
49647d: jne 0x496488
49647f: mov dl,0x14
496481: mov eax,ebx
496483: call 0x4775fc
496488: cmp BYTE PTR [esp],0x3
49648c: jne 0x4964a5
49648e: xor eax,eax
496490: mov al,bl
496492: imul eax,eax,0x16
496495: cmp BYTE PTR [esi+eax*8-0x18],0x3
49649a: jne 0x4964a5
49649c: mov dl,0x15
49649e: mov eax,ebx
4964a0: call 0x4775fc
4964a5: cmp BYTE PTR [esp],0x1
4964a9: jne 0x4964c2
4964ab: xor eax,eax
4964ad: mov al,bl
4964af: imul eax,eax,0x16
4964b2: cmp BYTE PTR [esi+eax*8-0x18],0x6
4964b7: jne 0x4964c2
4964b9: mov dl,0x16
4964bb: mov eax,ebx
4964bd: call 0x4775fc
4964c2: cmp BYTE PTR [esp],0x2
4964c6: jne 0x4964df
4964c8: xor eax,eax
4964ca: mov al,bl
4964cc: imul eax,eax,0x16
4964cf: cmp BYTE PTR [esi+eax*8-0x18],0x6
4964d4: jne 0x4964df
4964d6: mov dl,0x17
4964d8: mov eax,ebx
4964da: call 0x4775fc
4964df: cmp BYTE PTR [esp],0x3
4964e3: jne 0x4964fc
4964e5: xor eax,eax
4964e7: mov al,bl
4964e9: imul eax,eax,0x16
4964ec: cmp BYTE PTR [esi+eax*8-0x18],0x6
4964f1: jne 0x4964fc
4964f3: mov dl,0x18
4964f5: mov eax,ebx
4964f7: call 0x4775fc
4964fc: cmp BYTE PTR [esp],0x4
496500: jne 0x496519
496502: xor eax,eax
496504: mov al,bl
496506: imul eax,eax,0x16
496509: cmp BYTE PTR [esi+eax*8-0x18],0x6
49650e: jne 0x496519
496510: mov dl,0x19
496512: mov eax,ebx
496514: call 0x4775fc
496519: cmp BYTE PTR [esp],0x1
49651d: jne 0x496536
49651f: xor eax,eax
496521: mov al,bl
496523: imul eax,eax,0x16
496526: cmp BYTE PTR [esi+eax*8-0x18],0xa
49652b: jne 0x496536
49652d: mov dl,0x1a
49652f: mov eax,ebx
496531: call 0x4775fc
496536: cmp BYTE PTR [esp],0x3
49653a: jne 0x496553
49653c: xor eax,eax
49653e: mov al,bl
496540: imul eax,eax,0x16
496543: cmp BYTE PTR [esi+eax*8-0x18],0xa
496548: jne 0x496553
49654a: mov dl,0x1a
49654c: mov eax,ebx
49654e: call 0x4775fc
496553: xor eax,eax
496555: mov al,bl
496557: imul eax,eax,0x16
49655a: cmp BYTE PTR [esi+eax*8-0xa0],0xe
496562: jne 0x496738
496568: cmp BYTE PTR [esp],0x1
49656c: jne 0x496585
49656e: xor eax,eax
496570: mov al,bl
496572: imul eax,eax,0x16
496575: cmp BYTE PTR [esi+eax*8-0x18],0x2
49657a: jne 0x496585
49657c: mov dl,0x10
49657e: mov eax,ebx
496580: call 0x4775fc
496585: cmp BYTE PTR [esp],0x3
496589: jne 0x4965a2
49658b: xor eax,eax
49658d: mov al,bl
49658f: imul eax,eax,0x16
496592: cmp BYTE PTR [esi+eax*8-0x18],0x2
496597: jne 0x4965a2
496599: mov dl,0x11
49659b: mov eax,ebx
49659d: call 0x4775fc
4965a2: cmp BYTE PTR [esp],0x2
4965a6: jne 0x4965bf
4965a8: xor eax,eax
4965aa: mov al,bl
4965ac: imul eax,eax,0x16
4965af: cmp BYTE PTR [esi+eax*8-0x18],0x2
4965b4: jne 0x4965bf
4965b6: mov dl,0x12
4965b8: mov eax,ebx
4965ba: call 0x4775fc
4965bf: cmp BYTE PTR [esp],0x4
4965c3: jne 0x4965dc
4965c5: xor eax,eax
4965c7: mov al,bl
4965c9: imul eax,eax,0x16
4965cc: cmp BYTE PTR [esi+eax*8-0x18],0x2
4965d1: jne 0x4965dc
4965d3: mov dl,0x13
4965d5: mov eax,ebx
4965d7: call 0x4775fc
4965dc: cmp BYTE PTR [esp],0x2
4965e0: jne 0x4965f9
4965e2: xor eax,eax
4965e4: mov al,bl
4965e6: imul eax,eax,0x16
4965e9: cmp BYTE PTR [esi+eax*8-0x18],0x2
4965ee: jne 0x4965f9
4965f0: mov dl,0x14
4965f2: mov eax,ebx
4965f4: call 0x4775fc
4965f9: cmp BYTE PTR [esp],0x4
4965fd: jne 0x496616
4965ff: xor eax,eax
496601: mov al,bl
496603: imul eax,eax,0x16
496606: cmp BYTE PTR [esi+eax*8-0x18],0x2
49660b: jne 0x496616
49660d: mov dl,0x15
49660f: mov eax,ebx
496611: call 0x4775fc
496616: cmp BYTE PTR [esp],0x1
49661a: jne 0x496633
49661c: xor eax,eax
49661e: mov al,bl
496620: imul eax,eax,0x16
496623: cmp BYTE PTR [esi+eax*8-0x18],0x5
496628: jne 0x496633
49662a: mov dl,0x16
49662c: mov eax,ebx
49662e: call 0x4775fc
496633: cmp BYTE PTR [esp],0x3
496637: jne 0x496650
496639: xor eax,eax
49663b: mov al,bl
49663d: imul eax,eax,0x16
496640: cmp BYTE PTR [esi+eax*8-0x18],0x5
496645: jne 0x496650
496647: mov dl,0x17
496649: mov eax,ebx
49664b: call 0x4775fc
496650: cmp BYTE PTR [esp],0x1
496654: jne 0x49666d
496656: xor eax,eax
496658: mov al,bl
49665a: imul eax,eax,0x16
49665d: cmp BYTE PTR [esi+eax*8-0x18],0x8
496662: jne 0x49666d
496664: mov dl,0x18
496666: mov eax,ebx
496668: call 0x4775fc
49666d: cmp BYTE PTR [esp],0x3
496671: jne 0x49668a
496673: xor eax,eax
496675: mov al,bl
496677: imul eax,eax,0x16
49667a: cmp BYTE PTR [esi+eax*8-0x18],0x8
49667f: jne 0x49668a
496681: mov dl,0x18
496683: mov eax,ebx
496685: call 0x4775fc
49668a: cmp BYTE PTR [esp],0x1
49668e: jne 0x4966a7
496690: xor eax,eax
496692: mov al,bl
496694: imul eax,eax,0x16
496697: cmp BYTE PTR [esi+eax*8-0x18],0x8
49669c: jne 0x4966a7
49669e: mov dl,0x11
4966a0: mov eax,ebx
4966a2: call 0x4775fc
4966a7: cmp BYTE PTR [esp],0x3
4966ab: jne 0x4966c4
4966ad: xor eax,eax
4966af: mov al,bl
4966b1: imul eax,eax,0x16
4966b4: cmp BYTE PTR [esi+eax*8-0x18],0x8
4966b9: jne 0x4966c4
4966bb: mov dl,0x11
4966bd: mov eax,ebx
4966bf: call 0x4775fc
4966c4: cmp BYTE PTR [esp],0x2
4966c8: jne 0x4966e1
4966ca: xor eax,eax
4966cc: mov al,bl
4966ce: imul eax,eax,0x16
4966d1: cmp BYTE PTR [esi+eax*8-0x18],0x8
4966d6: jne 0x4966e1
4966d8: mov dl,0x12
4966da: mov eax,ebx
4966dc: call 0x4775fc
4966e1: cmp BYTE PTR [esp],0x4
4966e5: jne 0x4966fe
4966e7: xor eax,eax
4966e9: mov al,bl
4966eb: imul eax,eax,0x16
4966ee: cmp BYTE PTR [esi+eax*8-0x18],0x8
4966f3: jne 0x4966fe
4966f5: mov dl,0x13
4966f7: mov eax,ebx
4966f9: call 0x4775fc
4966fe: cmp BYTE PTR [esp],0x2
496702: jne 0x49671b
496704: xor eax,eax
496706: mov al,bl
496708: imul eax,eax,0x16
49670b: cmp BYTE PTR [esi+eax*8-0x18],0x8
496710: jne 0x49671b
496712: mov dl,0x14
496714: mov eax,ebx
496716: call 0x4775fc
49671b: cmp BYTE PTR [esp],0x4
49671f: jne 0x496738
496721: xor eax,eax
496723: mov al,bl
496725: imul eax,eax,0x16
496728: cmp BYTE PTR [esi+eax*8-0x18],0x8
49672d: jne 0x496738
49672f: mov dl,0x15
496731: mov eax,ebx
496733: call 0x4775fc
496738: xor eax,eax
49673a: mov al,bl
49673c: imul eax,eax,0x16
49673f: cmp BYTE PTR [esi+eax*8-0xa0],0xf
496747: jne 0x4968a9
49674d: cmp BYTE PTR [esp],0x1
496751: jne 0x49676a
496753: xor eax,eax
496755: mov al,bl
496757: imul eax,eax,0x16
49675a: cmp BYTE PTR [esi+eax*8-0x18],0x2
49675f: jne 0x49676a
496761: mov dl,0x10
496763: mov eax,ebx
496765: call 0x4775fc
49676a: cmp BYTE PTR [esp],0x3
49676e: jne 0x496787
496770: xor eax,eax
496772: mov al,bl
496774: imul eax,eax,0x16
496777: cmp BYTE PTR [esi+eax*8-0x18],0x2
49677c: jne 0x496787
49677e: mov dl,0x11
496780: mov eax,ebx
496782: call 0x4775fc
496787: cmp BYTE PTR [esp],0x1
49678b: jne 0x4967a4
49678d: xor eax,eax
49678f: mov al,bl
496791: imul eax,eax,0x16
496794: cmp BYTE PTR [esi+eax*8-0x18],0x6
496799: jne 0x4967a4
49679b: mov dl,0x10
49679d: mov eax,ebx
49679f: call 0x4775fc
4967a4: cmp BYTE PTR [esp],0x3
4967a8: jne 0x4967c1
4967aa: xor eax,eax
4967ac: mov al,bl
4967ae: imul eax,eax,0x16
4967b1: cmp BYTE PTR [esi+eax*8-0x18],0x6
4967b6: jne 0x4967c1
4967b8: mov dl,0x11
4967ba: mov eax,ebx
4967bc: call 0x4775fc
4967c1: cmp BYTE PTR [esp],0x1
4967c5: jne 0x4967de
4967c7: xor eax,eax
4967c9: mov al,bl
4967cb: imul eax,eax,0x16
4967ce: cmp BYTE PTR [esi+eax*8-0x18],0x3
4967d3: jne 0x4967de
4967d5: mov dl,0x12
4967d7: mov eax,ebx
4967d9: call 0x4775fc
4967de: cmp BYTE PTR [esp],0x3
4967e2: jne 0x4967fb
4967e4: xor eax,eax
4967e6: mov al,bl
4967e8: imul eax,eax,0x16
4967eb: cmp BYTE PTR [esi+eax*8-0x18],0x3
4967f0: jne 0x4967fb
4967f2: mov dl,0x13
4967f4: mov eax,ebx
4967f6: call 0x4775fc
4967fb: cmp BYTE PTR [esp],0x2
4967ff: jne 0x496818
496801: xor eax,eax
496803: mov al,bl
496805: imul eax,eax,0x16
496808: cmp BYTE PTR [esi+eax*8-0x18],0x6
49680d: jne 0x496818
49680f: mov dl,0x14
496811: mov eax,ebx
496813: call 0x4775fc
496818: cmp BYTE PTR [esp],0x4
49681c: jne 0x496835
49681e: xor eax,eax
496820: mov al,bl
496822: imul eax,eax,0x16
496825: cmp BYTE PTR [esi+eax*8-0x18],0x6
49682a: jne 0x496835
49682c: mov dl,0x15
49682e: mov eax,ebx
496830: call 0x4775fc
496835: cmp BYTE PTR [esp],0x2
496839: jne 0x496852
49683b: xor eax,eax
49683d: mov al,bl
49683f: imul eax,eax,0x16
496842: cmp BYTE PTR [esi+eax*8-0x18],0x2
496847: jne 0x496852
496849: mov dl,0x16
49684b: mov eax,ebx
49684d: call 0x4775fc
496852: cmp BYTE PTR [esp],0x4
496856: jne 0x49686f
496858: xor eax,eax
49685a: mov al,bl
49685c: imul eax,eax,0x16
49685f: cmp BYTE PTR [esi+eax*8-0x18],0x2
496864: jne 0x49686f
496866: mov dl,0x17
496868: mov eax,ebx
49686a: call 0x4775fc
49686f: cmp BYTE PTR [esp],0x2
496873: jne 0x49688c
496875: xor eax,eax
496877: mov al,bl
496879: imul eax,eax,0x16
49687c: cmp BYTE PTR [esi+eax*8-0x18],0x8
496881: jne 0x49688c
496883: mov dl,0x18
496885: mov eax,ebx
496887: call 0x4775fc
49688c: cmp BYTE PTR [esp],0x4
496890: jne 0x4968a9
496892: xor eax,eax
496894: mov al,bl
496896: imul eax,eax,0x16
496899: cmp BYTE PTR [esi+eax*8-0x18],0x8
49689e: jne 0x4968a9
4968a0: mov dl,0x18
4968a2: mov eax,ebx
4968a4: call 0x4775fc
4968a9: pop edx
4968aa: pop esi
4968ab: pop ebx
4968ac: ret
.data 4b0ef0 e8444b000c204b0030b8
.data 4b1074 f8574b00c8274b00d470
