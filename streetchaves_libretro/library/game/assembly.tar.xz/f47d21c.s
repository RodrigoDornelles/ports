; entry 47d21c
47d21c: push ebx
47d21d: push esi
47d21e: push edi
47d21f: push ebp
47d220: add esp,0xffffffe4
47d223: mov ebx,eax
47d225: mov esi,DWORD PTR ds:0x4b0ef0
47d22b: cmp bl,0x1
47d22e: jne 0x47d235
47d230: mov BYTE PTR [esp+0x1],0x0
47d235: cmp bl,0x2
47d238: jne 0x47d23f
47d23a: mov BYTE PTR [esp+0x1],0x32
47d23f: xor eax,eax
47d241: mov al,bl
47d243: imul eax,eax,0x16
47d246: cmp BYTE PTR [esi+eax*8-0x45],0x1
47d24b: jne 0x47d269
47d24d: xor eax,eax
47d24f: mov al,bl
47d251: imul eax,eax,0x16
47d254: mov dl,BYTE PTR [esp+0x1]
47d258: inc edx
47d259: mov BYTE PTR [esi+eax*8-0x44],dl
47d25d: xor eax,eax
47d25f: mov al,bl
47d261: imul eax,eax,0x16
47d264: mov BYTE PTR [esi+eax*8-0x1e],0x0
47d269: xor eax,eax
47d26b: mov al,bl
47d26d: imul eax,eax,0x16
47d270: cmp BYTE PTR [esi+eax*8-0x45],0x2
47d275: jne 0x47d28a
47d277: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d27d: jne 0x47d28a
47d27f: mov dl,BYTE PTR [esp+0x1]
47d283: add dl,0x2
47d286: mov BYTE PTR [esi+eax*8-0x44],dl
47d28a: xor eax,eax
47d28c: mov al,bl
47d28e: imul eax,eax,0x16
47d291: cmp BYTE PTR [esi+eax*8-0x45],0x2
47d296: jne 0x47d2ab
47d298: cmp WORD PTR [esi+eax*8-0x3c],0x4
47d29e: jne 0x47d2ab
47d2a0: mov dl,BYTE PTR [esp+0x1]
47d2a4: add dl,0x3
47d2a7: mov BYTE PTR [esi+eax*8-0x44],dl
47d2ab: xor eax,eax
47d2ad: mov al,bl
47d2af: imul eax,eax,0x16
47d2b2: cmp BYTE PTR [esi+eax*8-0x45],0x2
47d2b7: jne 0x47d2cc
47d2b9: cmp WORD PTR [esi+eax*8-0x3c],0x8
47d2bf: jne 0x47d2cc
47d2c1: mov dl,BYTE PTR [esp+0x1]
47d2c5: add dl,0x2
47d2c8: mov BYTE PTR [esi+eax*8-0x44],dl
47d2cc: xor eax,eax
47d2ce: mov al,bl
47d2d0: imul eax,eax,0x16
47d2d3: cmp BYTE PTR [esi+eax*8-0x45],0x2
47d2d8: jne 0x47d2eb
47d2da: cmp WORD PTR [esi+eax*8-0x3c],0xc
47d2e0: jne 0x47d2eb
47d2e2: mov dl,BYTE PTR [esp+0x1]
47d2e6: inc edx
47d2e7: mov BYTE PTR [esi+eax*8-0x44],dl
47d2eb: xor eax,eax
47d2ed: mov al,bl
47d2ef: imul edi,eax,0x16
47d2f2: cmp BYTE PTR [esi+edi*8-0xa0],0x8
47d2fa: jne 0x47d378
47d2fc: cmp BYTE PTR [esi+edi*8-0x45],0x2
47d301: jne 0x47d378
47d303: cmp BYTE PTR [esi+edi*8-0x1c],0x1
47d308: jne 0x47d314
47d30a: mov al,BYTE PTR [esp+0x1]
47d30e: add al,0x2
47d310: mov BYTE PTR [esi+edi*8-0x44],al
47d314: cmp BYTE PTR [esi+edi*8-0x1c],0x0
47d319: jne 0x47d325
47d31b: mov al,BYTE PTR [esp+0x1]
47d31f: add al,0x3
47d321: mov BYTE PTR [esi+edi*8-0x44],al
47d325: mov eax,0x14
47d32a: call 0x402a1c
47d32f: mov DWORD PTR [esp+0x4],eax
47d333: fild DWORD PTR [esp+0x4]
47d337: fld QWORD PTR [esi+edi*8-0xb0]
47d33e: fsub DWORD PTR ds:0x48dcc0
47d344: faddp st(1),st
47d346: add esp,0xfffffff8
47d349: fstp QWORD PTR [esp]
47d34c: fwait
47d34d: mov eax,0xa
47d352: call 0x402a1c
47d357: mov DWORD PTR [esp+0x10],eax
47d35b: fild DWORD PTR [esp+0x10]
47d35f: fadd QWORD PTR [esi+edi*8-0xa8]
47d366: add esp,0xfffffff8
47d369: fstp QWORD PTR [esp]
47d36c: fwait
47d36d: xor ecx,ecx
47d36f: xor edx,edx
47d371: mov al,0x2
47d373: call 0x476a04
47d378: xor eax,eax
47d37a: mov al,bl
47d37c: imul eax,eax,0x16
47d37f: cmp BYTE PTR [esi+eax*8-0x45],0x3
47d384: jne 0x47d399
47d386: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d38c: jne 0x47d399
47d38e: mov dl,BYTE PTR [esp+0x1]
47d392: add dl,0x4
47d395: mov BYTE PTR [esi+eax*8-0x44],dl
47d399: xor eax,eax
47d39b: mov al,bl
47d39d: imul eax,eax,0x16
47d3a0: cmp BYTE PTR [esi+eax*8-0x45],0x3
47d3a5: jne 0x47d3ba
47d3a7: cmp WORD PTR [esi+eax*8-0x3c],0x2
47d3ad: jne 0x47d3ba
47d3af: mov dl,BYTE PTR [esp+0x1]
47d3b3: add dl,0x5
47d3b6: mov BYTE PTR [esi+eax*8-0x44],dl
47d3ba: xor eax,eax
47d3bc: mov al,bl
47d3be: imul eax,eax,0x16
47d3c1: cmp BYTE PTR [esi+eax*8-0x45],0x3
47d3c6: jne 0x47d3db
47d3c8: cmp WORD PTR [esi+eax*8-0x3c],0x4
47d3ce: jne 0x47d3db
47d3d0: mov dl,BYTE PTR [esp+0x1]
47d3d4: add dl,0x4
47d3d7: mov BYTE PTR [esi+eax*8-0x44],dl
47d3db: xor eax,eax
47d3dd: mov al,bl
47d3df: imul eax,eax,0x16
47d3e2: cmp BYTE PTR [esi+eax*8-0x45],0x4
47d3e7: jne 0x47d3fc
47d3e9: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d3ef: jne 0x47d3fc
47d3f1: mov dl,BYTE PTR [esp+0x1]
47d3f5: add dl,0x6
47d3f8: mov BYTE PTR [esi+eax*8-0x44],dl
47d3fc: xor eax,eax
47d3fe: mov al,bl
47d400: imul eax,eax,0x16
47d403: cmp BYTE PTR [esi+eax*8-0x45],0x4
47d408: jne 0x47d41d
47d40a: cmp WORD PTR [esi+eax*8-0x3c],0x2
47d410: jne 0x47d41d
47d412: mov dl,BYTE PTR [esp+0x1]
47d416: add dl,0x7
47d419: mov BYTE PTR [esi+eax*8-0x44],dl
47d41d: xor eax,eax
47d41f: mov al,bl
47d421: imul eax,eax,0x16
47d424: cmp BYTE PTR [esi+eax*8-0x45],0x4
47d429: jne 0x47d43e
47d42b: cmp WORD PTR [esi+eax*8-0x3c],0x4
47d431: jne 0x47d43e
47d433: mov dl,BYTE PTR [esp+0x1]
47d437: add dl,0x6
47d43a: mov BYTE PTR [esi+eax*8-0x44],dl
47d43e: xor eax,eax
47d440: mov al,bl
47d442: imul eax,eax,0x16
47d445: cmp BYTE PTR [esi+eax*8-0x45],0x5
47d44a: jne 0x47d45f
47d44c: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d452: jne 0x47d45f
47d454: mov dl,BYTE PTR [esp+0x1]
47d458: add dl,0x8
47d45b: mov BYTE PTR [esi+eax*8-0x44],dl
47d45f: xor eax,eax
47d461: mov al,bl
47d463: imul eax,eax,0x16
47d466: cmp BYTE PTR [esi+eax*8-0x45],0x5
47d46b: jne 0x47d480
47d46d: cmp WORD PTR [esi+eax*8-0x3c],0x5
47d473: jne 0x47d480
47d475: mov dl,BYTE PTR [esp+0x1]
47d479: add dl,0x9
47d47c: mov BYTE PTR [esi+eax*8-0x44],dl
47d480: xor eax,eax
47d482: mov al,bl
47d484: imul eax,eax,0x16
47d487: cmp BYTE PTR [esi+eax*8-0x45],0x5
47d48c: jne 0x47d4a1
47d48e: cmp WORD PTR [esi+eax*8-0x3c],0x8
47d494: jne 0x47d4a1
47d496: mov dl,BYTE PTR [esp+0x1]
47d49a: add dl,0x8
47d49d: mov BYTE PTR [esi+eax*8-0x44],dl
47d4a1: xor eax,eax
47d4a3: mov al,bl
47d4a5: imul eax,eax,0x16
47d4a8: cmp BYTE PTR [esi+eax*8-0x45],0x6
47d4ad: jne 0x47d4c2
47d4af: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d4b5: jne 0x47d4c2
47d4b7: mov dl,BYTE PTR [esp+0x1]
47d4bb: add dl,0xa
47d4be: mov BYTE PTR [esi+eax*8-0x44],dl
47d4c2: xor eax,eax
47d4c4: mov al,bl
47d4c6: imul eax,eax,0x16
47d4c9: cmp BYTE PTR [esi+eax*8-0x45],0x6
47d4ce: jne 0x47d4f1
47d4d0: xor eax,eax
47d4d2: mov al,bl
47d4d4: imul eax,eax,0x16
47d4d7: cmp WORD PTR [esi+eax*8-0x3c],0x5
47d4dd: jne 0x47d4f1
47d4df: xor eax,eax
47d4e1: mov al,bl
47d4e3: imul eax,eax,0x16
47d4e6: mov dl,BYTE PTR [esp+0x1]
47d4ea: add dl,0xb
47d4ed: mov BYTE PTR [esi+eax*8-0x44],dl
47d4f1: xor eax,eax
47d4f3: mov al,bl
47d4f5: imul eax,eax,0x16
47d4f8: cmp BYTE PTR [esi+eax*8-0x45],0x6
47d4fd: jne 0x47d512
47d4ff: cmp WORD PTR [esi+eax*8-0x3c],0x8
47d505: jne 0x47d512
47d507: mov dl,BYTE PTR [esp+0x1]
47d50b: add dl,0xa
47d50e: mov BYTE PTR [esi+eax*8-0x44],dl
47d512: cmp BYTE PTR [esi+eax*8-0x45],0x7
47d517: jne 0x47d524
47d519: mov dl,BYTE PTR [esp+0x1]
47d51d: add dl,0xc
47d520: mov BYTE PTR [esi+eax*8-0x44],dl
47d524: xor eax,eax
47d526: mov al,bl
47d528: imul eax,eax,0x16
47d52b: cmp BYTE PTR [esi+eax*8-0x45],0x8
47d530: jne 0x47d553
47d532: xor eax,eax
47d534: mov al,bl
47d536: imul eax,eax,0x16
47d539: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d53f: jne 0x47d553
47d541: xor eax,eax
47d543: mov al,bl
47d545: imul eax,eax,0x16
47d548: mov dl,BYTE PTR [esp+0x1]
47d54c: add dl,0xd
47d54f: mov BYTE PTR [esi+eax*8-0x44],dl
47d553: xor eax,eax
47d555: mov al,bl
47d557: imul eax,eax,0x16
47d55a: cmp BYTE PTR [esi+eax*8-0x45],0x8
47d55f: jne 0x47d582
47d561: xor eax,eax
47d563: mov al,bl
47d565: imul eax,eax,0x16
47d568: cmp WORD PTR [esi+eax*8-0x3c],0x2
47d56e: jne 0x47d582
47d570: xor eax,eax
47d572: mov al,bl
47d574: imul eax,eax,0x16
47d577: mov dl,BYTE PTR [esp+0x1]
47d57b: add dl,0xe
47d57e: mov BYTE PTR [esi+eax*8-0x44],dl
47d582: xor eax,eax
47d584: mov al,bl
47d586: imul eax,eax,0x16
47d589: cmp BYTE PTR [esi+eax*8-0x45],0x8
47d58e: jne 0x47d5b1
47d590: xor eax,eax
47d592: mov al,bl
47d594: imul eax,eax,0x16
47d597: cmp WORD PTR [esi+eax*8-0x3c],0x4
47d59d: jne 0x47d5b1
47d59f: xor eax,eax
47d5a1: mov al,bl
47d5a3: imul eax,eax,0x16
47d5a6: mov dl,BYTE PTR [esp+0x1]
47d5aa: add dl,0xd
47d5ad: mov BYTE PTR [esi+eax*8-0x44],dl
47d5b1: xor eax,eax
47d5b3: mov al,bl
47d5b5: imul eax,eax,0x16
47d5b8: cmp BYTE PTR [esi+eax*8-0x45],0x9
47d5bd: jne 0x47d5e0
47d5bf: xor eax,eax
47d5c1: mov al,bl
47d5c3: imul eax,eax,0x16
47d5c6: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d5cc: jne 0x47d5e0
47d5ce: xor eax,eax
47d5d0: mov al,bl
47d5d2: imul eax,eax,0x16
47d5d5: mov dl,BYTE PTR [esp+0x1]
47d5d9: add dl,0xf
47d5dc: mov BYTE PTR [esi+eax*8-0x44],dl
47d5e0: xor eax,eax
47d5e2: mov al,bl
47d5e4: imul eax,eax,0x16
47d5e7: cmp BYTE PTR [esi+eax*8-0x45],0x9
47d5ec: jne 0x47d60f
47d5ee: xor eax,eax
47d5f0: mov al,bl
47d5f2: imul eax,eax,0x16
47d5f5: cmp WORD PTR [esi+eax*8-0x3c],0x2
47d5fb: jne 0x47d60f
47d5fd: xor eax,eax
47d5ff: mov al,bl
47d601: imul eax,eax,0x16
47d604: mov dl,BYTE PTR [esp+0x1]
47d608: add dl,0x10
47d60b: mov BYTE PTR [esi+eax*8-0x44],dl
47d60f: xor eax,eax
47d611: mov al,bl
47d613: imul eax,eax,0x16
47d616: cmp BYTE PTR [esi+eax*8-0x45],0x9
47d61b: jne 0x47d63e
47d61d: xor eax,eax
47d61f: mov al,bl
47d621: imul eax,eax,0x16
47d624: cmp WORD PTR [esi+eax*8-0x3c],0x4
47d62a: jne 0x47d63e
47d62c: xor eax,eax
47d62e: mov al,bl
47d630: imul eax,eax,0x16
47d633: mov dl,BYTE PTR [esp+0x1]
47d637: add dl,0xf
47d63a: mov BYTE PTR [esi+eax*8-0x44],dl
47d63e: xor eax,eax
47d640: mov al,bl
47d642: imul eax,eax,0x16
47d645: cmp BYTE PTR [esi+eax*8-0x45],0xa
47d64a: jne 0x47d66d
47d64c: xor eax,eax
47d64e: mov al,bl
47d650: imul eax,eax,0x16
47d653: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d659: jne 0x47d66d
47d65b: xor eax,eax
47d65d: mov al,bl
47d65f: imul eax,eax,0x16
47d662: mov dl,BYTE PTR [esp+0x1]
47d666: add dl,0x11
47d669: mov BYTE PTR [esi+eax*8-0x44],dl
47d66d: xor eax,eax
47d66f: mov al,bl
47d671: imul eax,eax,0x16
47d674: cmp BYTE PTR [esi+eax*8-0x45],0xa
47d679: jne 0x47d69c
47d67b: xor eax,eax
47d67d: mov al,bl
47d67f: imul eax,eax,0x16
47d682: cmp WORD PTR [esi+eax*8-0x3c],0x5
47d688: jne 0x47d69c
47d68a: xor eax,eax
47d68c: mov al,bl
47d68e: imul eax,eax,0x16
47d691: mov dl,BYTE PTR [esp+0x1]
47d695: add dl,0x12
47d698: mov BYTE PTR [esi+eax*8-0x44],dl
47d69c: xor eax,eax
47d69e: mov al,bl
47d6a0: imul eax,eax,0x16
47d6a3: cmp BYTE PTR [esi+eax*8-0x45],0xa
47d6a8: jne 0x47d6bd
47d6aa: cmp WORD PTR [esi+eax*8-0x3c],0x8
47d6b0: jne 0x47d6bd
47d6b2: mov dl,BYTE PTR [esp+0x1]
47d6b6: add dl,0x11
47d6b9: mov BYTE PTR [esi+eax*8-0x44],dl
47d6bd: cmp BYTE PTR [esi+eax*8-0xa0],0xd
47d6c5: je 0x47d765
47d6cb: xor eax,eax
47d6cd: mov al,bl
47d6cf: imul eax,eax,0x16
47d6d2: cmp BYTE PTR [esi+eax*8-0x45],0xb
47d6d7: jne 0x47d6fa
47d6d9: xor eax,eax
47d6db: mov al,bl
47d6dd: imul eax,eax,0x16
47d6e0: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d6e6: jne 0x47d6fa
47d6e8: xor eax,eax
47d6ea: mov al,bl
47d6ec: imul eax,eax,0x16
47d6ef: mov dl,BYTE PTR [esp+0x1]
47d6f3: add dl,0x13
47d6f6: mov BYTE PTR [esi+eax*8-0x44],dl
47d6fa: xor eax,eax
47d6fc: mov al,bl
47d6fe: imul eax,eax,0x16
47d701: cmp BYTE PTR [esi+eax*8-0x45],0xb
47d706: jne 0x47d729
47d708: xor eax,eax
47d70a: mov al,bl
47d70c: imul eax,eax,0x16
47d70f: cmp WORD PTR [esi+eax*8-0x3c],0x5
47d715: jne 0x47d729
47d717: xor eax,eax
47d719: mov al,bl
47d71b: imul eax,eax,0x16
47d71e: mov dl,BYTE PTR [esp+0x1]
47d722: add dl,0x14
47d725: mov BYTE PTR [esi+eax*8-0x44],dl
47d729: xor eax,eax
47d72b: mov al,bl
47d72d: imul eax,eax,0x16
47d730: cmp BYTE PTR [esi+eax*8-0x45],0xb
47d735: jne 0x47d861
47d73b: xor eax,eax
47d73d: mov al,bl
47d73f: imul eax,eax,0x16
47d742: cmp WORD PTR [esi+eax*8-0x3c],0x8
47d748: jne 0x47d861
47d74e: xor eax,eax
47d750: mov al,bl
47d752: imul eax,eax,0x16
47d755: mov dl,BYTE PTR [esp+0x1]
47d759: add dl,0x13
47d75c: mov BYTE PTR [esi+eax*8-0x44],dl
47d760: jmp 0x47d861
47d765: xor eax,eax
47d767: mov al,bl
47d769: imul edi,eax,0x16
47d76c: cmp BYTE PTR [esi+edi*8-0xa0],0xd
47d774: jne 0x47d861
47d77a: cmp BYTE PTR [esi+edi*8-0x45],0xb
47d77f: jne 0x47d861
47d785: cmp WORD PTR [esi+edi*8-0x3c],0x0
47d78b: jne 0x47d797
47d78d: mov al,BYTE PTR [esp+0x1]
47d791: add al,0x13
47d793: mov BYTE PTR [esi+edi*8-0x44],al
47d797: cmp WORD PTR [esi+edi*8-0x3c],0x4
47d79d: jne 0x47d7a9
47d79f: mov al,BYTE PTR [esp+0x1]
47d7a3: add al,0x14
47d7a5: mov BYTE PTR [esi+edi*8-0x44],al
47d7a9: cmp WORD PTR [esi+edi*8-0x3c],0x10
47d7af: jne 0x47d7bb
47d7b1: mov al,BYTE PTR [esp+0x1]
47d7b5: add al,0x13
47d7b7: mov BYTE PTR [esi+edi*8-0x44],al
47d7bb: cmp BYTE PTR [esi+edi*8-0x43],0x1
47d7c0: jne 0x47d7d0
47d7c2: push 0x40220000
47d7c7: push 0x0
47d7c9: mov eax,ebx
47d7cb: call 0x47648c
47d7d0: cmp BYTE PTR [esi+edi*8-0x43],0x2
47d7d5: jne 0x47d7e5
47d7d7: push 0xc0220000
47d7dc: push 0x0
47d7de: mov eax,ebx
47d7e0: call 0x47648c
47d7e5: fld QWORD PTR [esi+edi*8-0xb0]
47d7ec: call 0x402894
47d7f1: sub eax,0x14
47d7f4: sbb edx,0x0
47d7f7: push edx
47d7f8: push eax
47d7f9: mov eax,0x28
47d7fe: call 0x402a1c
47d803: cdq
47d804: add eax,DWORD PTR [esp]
47d807: adc edx,DWORD PTR [esp+0x4]
47d80b: add esp,0x8
47d80e: mov DWORD PTR [esp+0xc],eax
47d812: mov DWORD PTR [esp+0x10],edx
47d816: fild QWORD PTR [esp+0xc]
47d81a: add esp,0xfffffff8
47d81d: fstp QWORD PTR [esp]
47d820: fld QWORD PTR [esi+edi*8-0xa8]
47d828: call 0x402894
47d82d: push edx
47d82e: push eax
47d82f: mov eax,0x5
47d834: call 0x402a1c
47d839: cdq
47d83a: sub DWORD PTR [esp],eax
47d83d: sbb DWORD PTR [esp+0x4],edx
47d841: pop eax
47d842: pop edx
47d843: mov DWORD PTR [esp+0x1c],eax
47d847: mov DWORD PTR [esp+0x20],edx
47d84b: fild QWORD PTR [esp+0x1c]
47d84f: add esp,0xfffffff8
47d852: fstp QWORD PTR [esp]
47d855: fwait
47d856: xor ecx,ecx
47d858: xor edx,edx
47d85a: mov al,0x2
47d85c: call 0x476a04
47d861: xor eax,eax
47d863: mov al,bl
47d865: imul eax,eax,0x16
47d868: cmp BYTE PTR [esi+eax*8-0x45],0xc
47d86d: jne 0x47d881
47d86f: xor eax,eax
47d871: mov al,bl
47d873: imul eax,eax,0x16
47d876: mov dl,BYTE PTR [esp+0x1]
47d87a: add dl,0x15
47d87d: mov BYTE PTR [esi+eax*8-0x44],dl
47d881: xor eax,eax
47d883: mov al,bl
47d885: imul eax,eax,0x16
47d888: cmp BYTE PTR [esi+eax*8-0x45],0xd
47d88d: jne 0x47d8b0
47d88f: xor eax,eax
47d891: mov al,bl
47d893: imul eax,eax,0x16
47d896: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d89c: jne 0x47d8b0
47d89e: xor eax,eax
47d8a0: mov al,bl
47d8a2: imul eax,eax,0x16
47d8a5: mov dl,BYTE PTR [esp+0x1]
47d8a9: add dl,0x16
47d8ac: mov BYTE PTR [esi+eax*8-0x44],dl
47d8b0: xor eax,eax
47d8b2: mov al,bl
47d8b4: imul eax,eax,0x16
47d8b7: cmp BYTE PTR [esi+eax*8-0x45],0xd
47d8bc: jne 0x47d8df
47d8be: xor eax,eax
47d8c0: mov al,bl
47d8c2: imul eax,eax,0x16
47d8c5: cmp WORD PTR [esi+eax*8-0x3c],0x3
47d8cb: jne 0x47d8df
47d8cd: xor eax,eax
47d8cf: mov al,bl
47d8d1: imul eax,eax,0x16
47d8d4: mov dl,BYTE PTR [esp+0x1]
47d8d8: add dl,0x17
47d8db: mov BYTE PTR [esi+eax*8-0x44],dl
47d8df: xor eax,eax
47d8e1: mov al,bl
47d8e3: imul eax,eax,0x16
47d8e6: cmp BYTE PTR [esi+eax*8-0x45],0xe
47d8eb: jne 0x47d90e
47d8ed: xor eax,eax
47d8ef: mov al,bl
47d8f1: imul eax,eax,0x16
47d8f4: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d8fa: jne 0x47d90e
47d8fc: xor eax,eax
47d8fe: mov al,bl
47d900: imul eax,eax,0x16
47d903: mov dl,BYTE PTR [esp+0x1]
47d907: add dl,0x18
47d90a: mov BYTE PTR [esi+eax*8-0x44],dl
47d90e: xor eax,eax
47d910: mov al,bl
47d912: imul eax,eax,0x16
47d915: cmp BYTE PTR [esi+eax*8-0x45],0xe
47d91a: jne 0x47d93d
47d91c: xor eax,eax
47d91e: mov al,bl
47d920: imul eax,eax,0x16
47d923: cmp WORD PTR [esi+eax*8-0x3c],0x3
47d929: jne 0x47d93d
47d92b: xor eax,eax
47d92d: mov al,bl
47d92f: imul eax,eax,0x16
47d932: mov dl,BYTE PTR [esp+0x1]
47d936: add dl,0x19
47d939: mov BYTE PTR [esi+eax*8-0x44],dl
47d93d: xor eax,eax
47d93f: mov al,bl
47d941: imul eax,eax,0x16
47d944: cmp BYTE PTR [esi+eax*8-0x45],0xf
47d949: jne 0x47d96c
47d94b: xor eax,eax
47d94d: mov al,bl
47d94f: imul eax,eax,0x16
47d952: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d958: jne 0x47d96c
47d95a: xor eax,eax
47d95c: mov al,bl
47d95e: imul eax,eax,0x16
47d961: mov dl,BYTE PTR [esp+0x1]
47d965: add dl,0x16
47d968: mov BYTE PTR [esi+eax*8-0x44],dl
47d96c: xor eax,eax
47d96e: mov al,bl
47d970: imul eax,eax,0x16
47d973: cmp BYTE PTR [esi+eax*8-0x45],0xf
47d978: jne 0x47d99b
47d97a: xor eax,eax
47d97c: mov al,bl
47d97e: imul eax,eax,0x16
47d981: cmp WORD PTR [esi+eax*8-0x3c],0x5
47d987: jne 0x47d99b
47d989: xor eax,eax
47d98b: mov al,bl
47d98d: imul eax,eax,0x16
47d990: mov dl,BYTE PTR [esp+0x1]
47d994: add dl,0x17
47d997: mov BYTE PTR [esi+eax*8-0x44],dl
47d99b: xor eax,eax
47d99d: mov al,bl
47d99f: imul eax,eax,0x16
47d9a2: cmp BYTE PTR [esi+eax*8-0x45],0xf
47d9a7: jne 0x47d9ca
47d9a9: xor eax,eax
47d9ab: mov al,bl
47d9ad: imul eax,eax,0x16
47d9b0: cmp WORD PTR [esi+eax*8-0x3c],0x8
47d9b6: jne 0x47d9ca
47d9b8: xor eax,eax
47d9ba: mov al,bl
47d9bc: imul eax,eax,0x16
47d9bf: mov dl,BYTE PTR [esp+0x1]
47d9c3: add dl,0x16
47d9c6: mov BYTE PTR [esi+eax*8-0x44],dl
47d9ca: xor eax,eax
47d9cc: mov al,bl
47d9ce: imul eax,eax,0x16
47d9d1: cmp BYTE PTR [esi+eax*8-0x45],0x10
47d9d6: jne 0x47d9f9
47d9d8: xor eax,eax
47d9da: mov al,bl
47d9dc: imul eax,eax,0x16
47d9df: cmp WORD PTR [esi+eax*8-0x3c],0x0
47d9e5: jne 0x47d9f9
47d9e7: xor eax,eax
47d9e9: mov al,bl
47d9eb: imul eax,eax,0x16
47d9ee: mov dl,BYTE PTR [esp+0x1]
47d9f2: add dl,0x18
47d9f5: mov BYTE PTR [esi+eax*8-0x44],dl
47d9f9: xor eax,eax
47d9fb: mov al,bl
47d9fd: imul eax,eax,0x16
47da00: cmp BYTE PTR [esi+eax*8-0x45],0x10
47da05: jne 0x47da28
47da07: xor eax,eax
47da09: mov al,bl
47da0b: imul eax,eax,0x16
47da0e: cmp WORD PTR [esi+eax*8-0x3c],0x5
47da14: jne 0x47da28
47da16: xor eax,eax
47da18: mov al,bl
47da1a: imul eax,eax,0x16
47da1d: mov dl,BYTE PTR [esp+0x1]
47da21: add dl,0x19
47da24: mov BYTE PTR [esi+eax*8-0x44],dl
47da28: xor eax,eax
47da2a: mov al,bl
47da2c: imul eax,eax,0x16
47da2f: cmp BYTE PTR [esi+eax*8-0x45],0x10
47da34: jne 0x47da57
47da36: xor eax,eax
47da38: mov al,bl
47da3a: imul eax,eax,0x16
47da3d: cmp WORD PTR [esi+eax*8-0x3c],0x8
47da43: jne 0x47da57
47da45: xor eax,eax
47da47: mov al,bl
47da49: imul eax,eax,0x16
47da4c: mov dl,BYTE PTR [esp+0x1]
47da50: add dl,0x18
47da53: mov BYTE PTR [esi+eax*8-0x44],dl
47da57: xor eax,eax
47da59: mov al,bl
47da5b: imul eax,eax,0x16
47da5e: cmp BYTE PTR [esi+eax*8-0x45],0x11
47da63: jne 0x47da86
47da65: xor eax,eax
47da67: mov al,bl
47da69: imul eax,eax,0x16
47da6c: cmp WORD PTR [esi+eax*8-0x3c],0x0
47da72: jne 0x47da86
47da74: xor eax,eax
47da76: mov al,bl
47da78: imul eax,eax,0x16
47da7b: mov dl,BYTE PTR [esp+0x1]
47da7f: add dl,0x1a
47da82: mov BYTE PTR [esi+eax*8-0x44],dl
47da86: xor eax,eax
47da88: mov al,bl
47da8a: imul eax,eax,0x16
47da8d: cmp BYTE PTR [esi+eax*8-0x45],0x12
47da92: jne 0x47dab5
47da94: xor eax,eax
47da96: mov al,bl
47da98: imul eax,eax,0x16
47da9b: cmp WORD PTR [esi+eax*8-0x3c],0x0
47daa1: jne 0x47dab5
47daa3: xor eax,eax
47daa5: mov al,bl
47daa7: imul eax,eax,0x16
47daaa: mov dl,BYTE PTR [esp+0x1]
47daae: add dl,0x1b
47dab1: mov BYTE PTR [esi+eax*8-0x44],dl
47dab5: xor eax,eax
47dab7: mov al,bl
47dab9: imul eax,eax,0x16
47dabc: cmp BYTE PTR [esi+eax*8-0x45],0x12
47dac1: jne 0x47dad6
47dac3: cmp WORD PTR [esi+eax*8-0x3c],0x1
47dac9: jne 0x47dad6
47dacb: mov dl,BYTE PTR [esp+0x1]
47dacf: add dl,0x1b
47dad2: mov BYTE PTR [esi+eax*8-0x44],dl
47dad6: cmp BYTE PTR [esi+eax*8-0x45],0x13
47dadb: jne 0x47dae8
47dadd: mov dl,BYTE PTR [esp+0x1]
47dae1: add dl,0x1c
47dae4: mov BYTE PTR [esi+eax*8-0x44],dl
47dae8: xor eax,eax
47daea: mov al,bl
47daec: imul eax,eax,0x16
47daef: cmp BYTE PTR [esi+eax*8-0x45],0x14
47daf4: jne 0x47db17
47daf6: xor eax,eax
47daf8: mov al,bl
47dafa: imul eax,eax,0x16
47dafd: cmp WORD PTR [esi+eax*8-0x3c],0x0
47db03: jne 0x47db17
47db05: xor eax,eax
47db07: mov al,bl
47db09: imul eax,eax,0x16
47db0c: mov dl,BYTE PTR [esp+0x1]
47db10: add dl,0x1d
47db13: mov BYTE PTR [esi+eax*8-0x44],dl
47db17: xor eax,eax
47db19: mov al,bl
47db1b: imul eax,eax,0x16
47db1e: cmp BYTE PTR [esi+eax*8-0x45],0x14
47db23: jne 0x47db46
47db25: xor eax,eax
47db27: mov al,bl
47db29: imul eax,eax,0x16
47db2c: cmp WORD PTR [esi+eax*8-0x3c],0x12
47db32: jne 0x47db46
47db34: xor eax,eax
47db36: mov al,bl
47db38: imul eax,eax,0x16
47db3b: mov dl,BYTE PTR [esp+0x1]
47db3f: add dl,0x1e
47db42: mov BYTE PTR [esi+eax*8-0x44],dl
47db46: xor eax,eax
47db48: mov al,bl
47db4a: imul edx,eax,0x16
47db4d: cmp BYTE PTR [esi+edx*8-0x45],0x14
47db52: jne 0x47db80
47db54: cmp BYTE PTR [esi+edx*8-0x38],0x0
47db59: jne 0x47db80
47db5b: fld QWORD PTR [esi+edx*8-0x70]
47db5f: fcomp DWORD PTR ds:0x48dcc4
47db65: fnstsw ax
47db67: sahf
47db68: ja 0x47db80
47db6a: mov WORD PTR [esi+edx*8-0x3c],0x0
47db71: mov eax,ds:0x4b11f8
47db76: fild WORD PTR [eax]
47db78: fstp QWORD PTR [esi+edx*8-0xa8]
47db7f: fwait
47db80: cmp BYTE PTR [esi+edx*8-0x45],0x15
47db85: jne 0x47db91
47db87: mov al,BYTE PTR [esp+0x1]
47db8b: add al,0x1f
47db8d: mov BYTE PTR [esi+edx*8-0x44],al
47db91: cmp BYTE PTR [esi+edx*8-0x45],0x16
47db96: jne 0x47dba2
47db98: mov al,BYTE PTR [esp+0x1]
47db9c: add al,0x20
47db9e: mov BYTE PTR [esi+edx*8-0x44],al
47dba2: xor eax,eax
47dba4: mov al,bl
47dba6: imul eax,eax,0x16
47dba9: cmp BYTE PTR [esi+eax*8-0x45],0x15
47dbae: je 0x47dbbe
47dbb0: xor edx,edx
47dbb2: mov dl,bl
47dbb4: imul edx,edx,0x16
47dbb7: cmp BYTE PTR [esi+edx*8-0x45],0x16
47dbbc: jne 0x47dbc3
47dbbe: mov BYTE PTR [esi+eax*8-0x1d],0x1
47dbc3: cmp BYTE PTR [esi+eax*8-0xa0],0x1
47dbcb: jne 0x47ea86
47dbd1: cmp BYTE PTR [esi+eax*8-0x45],0x17
47dbd6: jne 0x47dc46
47dbd8: cmp WORD PTR [esi+eax*8-0x3c],0x0
47dbde: jne 0x47dbeb
47dbe0: mov dl,BYTE PTR [esp+0x1]
47dbe4: add dl,0x21
47dbe7: mov BYTE PTR [esi+eax*8-0x44],dl
47dbeb: cmp WORD PTR [esi+eax*8-0x3c],0x7
47dbf1: jne 0x47dbfe
47dbf3: mov dl,BYTE PTR [esp+0x1]
47dbf7: add dl,0x22
47dbfa: mov BYTE PTR [esi+eax*8-0x44],dl
47dbfe: cmp WORD PTR [esi+eax*8-0x3c],0xe
47dc04: jne 0x47dc11
47dc06: mov dl,BYTE PTR [esp+0x1]
47dc0a: add dl,0x23
47dc0d: mov BYTE PTR [esi+eax*8-0x44],dl
47dc11: cmp WORD PTR [esi+eax*8-0x3c],0x15
47dc17: jne 0x47dc24
47dc19: mov dl,BYTE PTR [esp+0x1]
47dc1d: add dl,0x22
47dc20: mov BYTE PTR [esi+eax*8-0x44],dl
47dc24: cmp WORD PTR [esi+eax*8-0x3c],0x1c
47dc2a: jne 0x47dc37
47dc2c: mov dl,BYTE PTR [esp+0x1]
47dc30: add dl,0x21
47dc33: mov BYTE PTR [esi+eax*8-0x44],dl
47dc37: cmp WORD PTR [esi+eax*8-0x3c],0x1c
47dc3d: jne 0x47dc46
47dc3f: mov WORD PTR [esi+eax*8-0x3c],0x0
47dc46: xor eax,eax
47dc48: mov al,bl
47dc4a: imul eax,eax,0x16
47dc4d: cmp BYTE PTR [esi+eax*8-0x45],0x18
47dc52: jne 0x47dc75
47dc54: xor eax,eax
47dc56: mov al,bl
47dc58: imul eax,eax,0x16
47dc5b: cmp WORD PTR [esi+eax*8-0x3c],0x0
47dc61: jne 0x47dc75
47dc63: xor eax,eax
47dc65: mov al,bl
47dc67: imul eax,eax,0x16
47dc6a: mov dl,BYTE PTR [esp+0x1]
47dc6e: add dl,0xc
47dc71: mov BYTE PTR [esi+eax*8-0x44],dl
47dc75: xor eax,eax
47dc77: mov al,bl
47dc79: imul eax,eax,0x16
47dc7c: cmp BYTE PTR [esi+eax*8-0x45],0x18
47dc81: jne 0x47dc96
47dc83: cmp WORD PTR [esi+eax*8-0x3c],0x2
47dc89: jne 0x47dc96
47dc8b: mov dl,BYTE PTR [esp+0x1]
47dc8f: add dl,0x1e
47dc92: mov BYTE PTR [esi+eax*8-0x44],dl
47dc96: cmp BYTE PTR [esi+eax*8-0x45],0x19
47dc9b: jne 0x47de61
47dca1: cmp WORD PTR [esi+eax*8-0x3c],0x0
47dca7: jne 0x47dcb4
47dca9: mov dl,BYTE PTR [esp+0x1]
47dcad: add dl,0x24
47dcb0: mov BYTE PTR [esi+eax*8-0x44],dl
47dcb4: cmp WORD PTR [esi+eax*8-0x3c],0x4
47dcba: jne 0x47dcc7
47dcbc: mov dl,BYTE PTR [esp+0x1]
47dcc0: add dl,0x25
47dcc3: mov BYTE PTR [esi+eax*8-0x44],dl
47dcc7: cmp WORD PTR [esi+eax*8-0x3c],0x7
47dccd: jne 0x47dcda
47dccf: mov dl,BYTE PTR [esp+0x1]
47dcd3: add dl,0x26
47dcd6: mov BYTE PTR [esi+eax*8-0x44],dl
47dcda: cmp WORD PTR [esi+eax*8-0x3c],0xa
47dce0: jne 0x47de61
47dce6: mov dl,BYTE PTR [esp+0x1]
47dcea: add dl,0x27
47dced: mov BYTE PTR [esi+eax*8-0x44],dl
47dcf1: xor eax,eax
47dcf3: mov al,bl
47dcf5: imul eax,eax,0x16
47dcf8: cmp BYTE PTR [esi+eax*8-0x43],0x1
47dcfd: jne 0x47dd4b
47dcff: xor eax,eax
47dd01: mov al,bl
47dd03: imul eax,eax,0x16
47dd06: cmp BYTE PTR [esi+eax*8-0x41],0x1
47dd0b: jne 0x47dd4b
47dd0d: xor eax,eax
47dd0f: mov al,bl
47dd11: imul eax,eax,0x16
47dd14: fld QWORD PTR [esi+eax*8-0xb0]
47dd1b: fadd DWORD PTR ds:0x48dcc8
47dd21: add esp,0xfffffff8
47dd24: fstp QWORD PTR [esp]
47dd27: fwait
47dd28: xor eax,eax
47dd2a: mov al,bl
47dd2c: imul eax,eax,0x16
47dd2f: push DWORD PTR [esi+eax*8-0xa4]
47dd36: push DWORD PTR [esi+eax*8-0xa8]
47dd3d: mov ecx,ebx
47dd3f: mov edx,0x48dcd4
47dd44: mov al,0x7
47dd46: call 0x476a04
47dd4b: xor eax,eax
47dd4d: mov al,bl
47dd4f: imul eax,eax,0x16
47dd52: cmp BYTE PTR [esi+eax*8-0x43],0x2
47dd57: jne 0x47dda5
47dd59: xor eax,eax
47dd5b: mov al,bl
47dd5d: imul eax,eax,0x16
47dd60: cmp BYTE PTR [esi+eax*8-0x41],0x1
47dd65: jne 0x47dda5
47dd67: xor eax,eax
47dd69: mov al,bl
47dd6b: imul eax,eax,0x16
47dd6e: fld QWORD PTR [esi+eax*8-0xb0]
47dd75: fsub DWORD PTR ds:0x48dcc8
47dd7b: add esp,0xfffffff8
47dd7e: fstp QWORD PTR [esp]
47dd81: fwait
47dd82: xor eax,eax
47dd84: mov al,bl
47dd86: imul eax,eax,0x16
47dd89: push DWORD PTR [esi+eax*8-0xa4]
47dd90: push DWORD PTR [esi+eax*8-0xa8]
47dd97: mov ecx,ebx
47dd99: mov edx,0x48dcd4
47dd9e: mov al,0x7
47dda0: call 0x476a04
47dda5: xor eax,eax
47dda7: mov al,bl
47dda9: imul eax,eax,0x16
47ddac: cmp BYTE PTR [esi+eax*8-0x43],0x1
47ddb1: jne 0x47ddff
47ddb3: xor eax,eax
47ddb5: mov al,bl
47ddb7: imul eax,eax,0x16
47ddba: cmp BYTE PTR [esi+eax*8-0x41],0x2
47ddbf: jne 0x47ddff
47ddc1: xor eax,eax
47ddc3: mov al,bl
47ddc5: imul eax,eax,0x16
47ddc8: fld QWORD PTR [esi+eax*8-0xb0]
47ddcf: fadd DWORD PTR ds:0x48dcc8
47ddd5: add esp,0xfffffff8
47ddd8: fstp QWORD PTR [esp]
47dddb: fwait
47dddc: xor eax,eax
47ddde: mov al,bl
47dde0: imul eax,eax,0x16
47dde3: push DWORD PTR [esi+eax*8-0xa4]
47ddea: push DWORD PTR [esi+eax*8-0xa8]
47ddf1: mov ecx,ebx
47ddf3: mov edx,0x48dce0
47ddf8: mov al,0x7
47ddfa: call 0x476a04
47ddff: xor eax,eax
47de01: mov al,bl
47de03: imul eax,eax,0x16
47de06: cmp BYTE PTR [esi+eax*8-0x43],0x2
47de0b: jne 0x47de59
47de0d: xor eax,eax
47de0f: mov al,bl
47de11: imul eax,eax,0x16
47de14: cmp BYTE PTR [esi+eax*8-0x41],0x2
47de19: jne 0x47de59
47de1b: xor eax,eax
47de1d: mov al,bl
47de1f: imul eax,eax,0x16
47de22: fld QWORD PTR [esi+eax*8-0xb0]
47de29: fsub DWORD PTR ds:0x48dcc8
47de2f: add esp,0xfffffff8
47de32: fstp QWORD PTR [esp]
47de35: fwait
47de36: xor eax,eax
47de38: mov al,bl
47de3a: imul eax,eax,0x16
47de3d: push DWORD PTR [esi+eax*8-0xa4]
47de44: push DWORD PTR [esi+eax*8-0xa8]
47de4b: mov ecx,ebx
47de4d: mov edx,0x48dce0
47de52: mov al,0x7
47de54: call 0x476a04
47de59: mov eax,ds:0x4b1098
47de5e: mov BYTE PTR [eax],0xe
47de61: xor eax,eax
47de63: mov al,bl
47de65: imul eax,eax,0x16
47de68: cmp BYTE PTR [esi+eax*8-0x45],0x1a
47de6d: jne 0x47e15e
47de73: xor eax,eax
47de75: mov al,bl
47de77: imul eax,eax,0x16
47de7a: cmp WORD PTR [esi+eax*8-0x3c],0x0
47de80: jne 0x47de8a
47de82: mov eax,ds:0x4b1098
47de87: mov BYTE PTR [eax],0xf
47de8a: xor eax,eax
47de8c: mov al,bl
47de8e: imul eax,eax,0x16
47de91: cmp WORD PTR [esi+eax*8-0x3c],0x0
47de97: jne 0x47deab
47de99: xor eax,eax
47de9b: mov al,bl
47de9d: imul eax,eax,0x16
47dea0: mov dl,BYTE PTR [esp+0x1]
47dea4: add dl,0x28
47dea7: mov BYTE PTR [esi+eax*8-0x44],dl
47deab: xor eax,eax
47dead: mov al,bl
47deaf: imul eax,eax,0x16
47deb2: cmp WORD PTR [esi+eax*8-0x3c],0x6
47deb8: jne 0x47deda
47deba: xor eax,eax
47debc: mov al,bl
47debe: imul eax,eax,0x16
47dec1: cmp BYTE PTR [esi+eax*8-0x41],0x1
47dec6: jne 0x47deda
47dec8: xor eax,eax
47deca: mov al,bl
47decc: imul eax,eax,0x16
47decf: mov dl,BYTE PTR [esp+0x1]
47ded3: add dl,0x29
47ded6: mov BYTE PTR [esi+eax*8-0x44],dl
47deda: xor eax,eax
47dedc: mov al,bl
47dede: imul eax,eax,0x16
47dee1: cmp WORD PTR [esi+eax*8-0x3c],0xa
47dee7: jne 0x47df09
47dee9: xor eax,eax
47deeb: mov al,bl
47deed: imul eax,eax,0x16
47def0: cmp BYTE PTR [esi+eax*8-0x41],0x2
47def5: jne 0x47df09
47def7: xor eax,eax
47def9: mov al,bl
47defb: imul eax,eax,0x16
47defe: mov dl,BYTE PTR [esp+0x1]
47df02: add dl,0x29
47df05: mov BYTE PTR [esi+eax*8-0x44],dl
47df09: xor eax,eax
47df0b: mov al,bl
47df0d: imul eax,eax,0x16
47df10: cmp WORD PTR [esi+eax*8-0x3c],0xc
47df16: jne 0x47df38
47df18: xor eax,eax
47df1a: mov al,bl
47df1c: imul eax,eax,0x16
47df1f: cmp BYTE PTR [esi+eax*8-0x41],0x1
47df24: jne 0x47df38
47df26: xor eax,eax
47df28: mov al,bl
47df2a: imul eax,eax,0x16
47df2d: mov dl,BYTE PTR [esp+0x1]
47df31: add dl,0x2a
47df34: mov BYTE PTR [esi+eax*8-0x44],dl
47df38: xor eax,eax
47df3a: mov al,bl
47df3c: imul eax,eax,0x16
47df3f: cmp WORD PTR [esi+eax*8-0x3c],0x13
47df45: jne 0x47df67
47df47: xor eax,eax
47df49: mov al,bl
47df4b: imul eax,eax,0x16
47df4e: cmp BYTE PTR [esi+eax*8-0x41],0x2
47df53: jne 0x47df67
47df55: xor eax,eax
47df57: mov al,bl
47df59: imul eax,eax,0x16
47df5c: mov dl,BYTE PTR [esp+0x1]
47df60: add dl,0x2a
47df63: mov BYTE PTR [esi+eax*8-0x44],dl
47df67: xor eax,eax
47df69: mov al,bl
47df6b: imul eax,eax,0x16
47df6e: movzx eax,BYTE PTR [esi+eax*8-0x44]
47df73: xor edx,edx
47df75: mov dl,BYTE PTR [esp+0x1]
47df79: add edx,0x29
47df7c: cmp eax,edx
47df7e: jne 0x47e096
47df84: mov BYTE PTR [esp],0x3
47df88: mov eax,0x28
47df8d: call 0x402a1c
47df92: mov DWORD PTR [esp+0x4],eax
47df96: fild DWORD PTR [esp+0x4]
47df9a: xor eax,eax
47df9c: mov al,bl
47df9e: imul eax,eax,0x16
47dfa1: fld QWORD PTR [esi+eax*8-0xb0]
47dfa8: fsub DWORD PTR ds:0x48dce4
47dfae: faddp st(1),st
47dfb0: add esp,0xfffffff8
47dfb3: fstp QWORD PTR [esp]
47dfb6: fwait
47dfb7: mov eax,0xa
47dfbc: call 0x402a1c
47dfc1: mov DWORD PTR [esp+0x10],eax
47dfc5: fild DWORD PTR [esp+0x10]
47dfc9: xor eax,eax
47dfcb: mov al,bl
47dfcd: imul eax,eax,0x16
47dfd0: fadd QWORD PTR [esi+eax*8-0xa8]
47dfd7: add esp,0xfffffff8
47dfda: fstp QWORD PTR [esp]
47dfdd: fwait
47dfde: xor ecx,ecx
47dfe0: xor edx,edx
47dfe2: mov al,0x2
47dfe4: call 0x476a04
47dfe9: dec BYTE PTR [esp]
47dfec: jne 0x47df88
47dfee: xor eax,eax
47dff0: mov al,bl
47dff2: imul eax,eax,0x16
47dff5: cmp BYTE PTR [esi+eax*8-0x43],0x1
47dffa: jne 0x47e018
47dffc: xor eax,eax
47dffe: mov al,bl
47e000: imul eax,eax,0x16
47e003: cmp BYTE PTR [esi+eax*8-0x41],0x1
47e008: jne 0x47e018
47e00a: push 0x40330000
47e00f: push 0x0
47e011: mov eax,ebx
47e013: call 0x47648c
47e018: xor eax,eax
47e01a: mov al,bl
47e01c: imul eax,eax,0x16
47e01f: cmp BYTE PTR [esi+eax*8-0x43],0x2
47e024: jne 0x47e042
47e026: xor eax,eax
47e028: mov al,bl
47e02a: imul eax,eax,0x16
47e02d: cmp BYTE PTR [esi+eax*8-0x41],0x1
47e032: jne 0x47e042
47e034: push 0xc0330000
47e039: push 0x0
47e03b: mov eax,ebx
47e03d: call 0x47648c
47e042: xor eax,eax
47e044: mov al,bl
47e046: imul eax,eax,0x16
47e049: cmp BYTE PTR [esi+eax*8-0x43],0x1
47e04e: jne 0x47e06c
47e050: xor eax,eax
47e052: mov al,bl
47e054: imul eax,eax,0x16
47e057: cmp BYTE PTR [esi+eax*8-0x41],0x2
47e05c: jne 0x47e06c
47e05e: push 0x40350000
47e063: push 0x0
47e065: mov eax,ebx
47e067: call 0x47648c
47e06c: xor eax,eax
47e06e: mov al,bl
47e070: imul eax,eax,0x16
47e073: cmp BYTE PTR [esi+eax*8-0x43],0x2
47e078: jne 0x47e096
47e07a: xor eax,eax
47e07c: mov al,bl
47e07e: imul eax,eax,0x16
47e081: cmp BYTE PTR [esi+eax*8-0x41],0x2
47e086: jne 0x47e096
47e088: push 0xc0350000
47e08d: push 0x0
47e08f: mov eax,ebx
47e091: call 0x47648c
47e096: xor eax,eax
47e098: mov al,bl
47e09a: imul eax,eax,0x16
47e09d: cmp BYTE PTR [esi+eax*8-0x43],0x1
47e0a2: jne 0x47e0f4
47e0a4: xor eax,eax
47e0a6: mov al,bl
47e0a8: imul eax,eax,0x16
47e0ab: cmp WORD PTR [esi+eax*8-0x3c],0x9
47e0b1: jl 0x47e0f4
47e0b3: xor eax,eax
47e0b5: mov al,bl
47e0b7: imul eax,eax,0x16
47e0ba: fld QWORD PTR [esi+eax*8-0xb0]
47e0c1: fadd DWORD PTR ds:0x48dce8
47e0c7: add esp,0xfffffff8
47e0ca: fstp QWORD PTR [esp]
47e0cd: fwait
47e0ce: xor eax,eax
47e0d0: mov al,bl
47e0d2: imul eax,eax,0x16
47e0d5: fld QWORD PTR [esi+eax*8-0xa8]
47e0dc: fsub DWORD PTR ds:0x48dcec
47e0e2: add esp,0xfffffff8
47e0e5: fstp QWORD PTR [esp]
47e0e8: fwait
47e0e9: mov ecx,ebx
47e0eb: xor edx,edx
47e0ed: mov al,0x10
47e0ef: call 0x476a04
47e0f4: xor eax,eax
47e0f6: mov al,bl
47e0f8: imul eax,eax,0x16
47e0fb: cmp BYTE PTR [esi+eax*8-0x43],0x2
47e100: jne 0x47e152
47e102: xor eax,eax
47e104: mov al,bl
47e106: imul eax,eax,0x16
47e109: cmp WORD PTR [esi+eax*8-0x3c],0x9
47e10f: jl 0x47e152
47e111: xor eax,eax
47e113: mov al,bl
47e115: imul eax,eax,0x16
47e118: fld QWORD PTR [esi+eax*8-0xb0]
47e11f: fsub DWORD PTR ds:0x48dce8
47e125: add esp,0xfffffff8
47e128: fstp QWORD PTR [esp]
47e12b: fwait
47e12c: xor eax,eax
47e12e: mov al,bl
47e130: imul eax,eax,0x16
47e133: fld QWORD PTR [esi+eax*8-0xa8]
47e13a: fsub DWORD PTR ds:0x48dcec
47e140: add esp,0xfffffff8
47e143: fstp QWORD PTR [esp]
47e146: fwait
47e147: mov ecx,ebx
47e149: xor edx,edx
47e14b: mov al,0x10
47e14d: call 0x476a04
47e152: xor eax,eax
47e154: mov al,bl
47e156: imul eax,eax,0x16
47e159: mov BYTE PTR [esi+eax*8-0x47],0x1
47e15e: xor eax,eax
47e160: mov al,bl
47e162: imul edi,eax,0x16
47e165: cmp BYTE PTR [esi+edi*8-0x45],0x1b
47e16a: jne 0x47e277
47e170: cmp BYTE PTR [esi+edi*8-0x1b],0x1
47e175: jb 0x47e18a
47e177: xor eax,eax
47e179: mov al,bl
47e17b: mov edx,0x3
47e180: sub edx,eax
47e182: imul eax,edx,0x16
47e185: mov BYTE PTR [esi+eax*8-0x1e],0x0
47e18a: cmp BYTE PTR [esi+edi*8-0x1b],0x4
47e18f: jb 0x47e1a4
47e191: xor eax,eax
47e193: mov al,bl
47e195: mov edx,0x3
47e19a: sub edx,eax
47e19c: imul eax,edx,0x16
47e19f: mov BYTE PTR [esi+eax*8-0x1e],0x1
47e1a4: cmp WORD PTR [esi+edi*8-0x3c],0x7
47e1aa: jle 0x47e1bf
47e1ac: xor eax,eax
47e1ae: mov al,bl
47e1b0: mov edx,0x3
47e1b5: sub edx,eax
47e1b7: imul eax,edx,0x16
47e1ba: mov BYTE PTR [esi+eax*8-0x1e],0x1
47e1bf: cmp WORD PTR [esi+edi*8-0x3c],0x0
47e1c5: jne 0x47e1cf
47e1c7: mov eax,ds:0x4b1098
47e1cc: mov BYTE PTR [eax],0x10
47e1cf: xor eax,eax
47e1d1: mov al,bl
47e1d3: imul eax,eax,0x16
47e1d6: fild WORD PTR [esi+eax*8-0x3c]
47e1da: fdiv DWORD PTR ds:0x48dcf0
47e1e0: call 0x40287c
47e1e5: xor eax,eax
47e1e7: mov al,bl
47e1e9: imul eax,eax,0x16
47e1ec: fild WORD PTR [esi+eax*8-0x3c]
47e1f0: fdiv DWORD PTR ds:0x48dcf0
47e1f6: fcompp
47e1f8: fnstsw ax
47e1fa: sahf
47e1fb: jne 0x47e226
47e1fd: xor eax,eax
47e1ff: mov al,BYTE PTR [esi+edi*8-0x44]
47e203: xor edx,edx
47e205: mov dl,BYTE PTR [esp+0x1]
47e209: add edx,0x2b
47e20c: cmp eax,edx
47e20e: jne 0x47e21c
47e210: mov al,BYTE PTR [esp+0x1]
47e214: add al,0x2c
47e216: mov BYTE PTR [esi+edi*8-0x44],al
47e21a: jmp 0x47e226
47e21c: mov al,BYTE PTR [esp+0x1]
47e220: add al,0x2b
47e222: mov BYTE PTR [esi+edi*8-0x44],al
47e226: fld QWORD PTR [esi+edi*8-0xa8]
47e22d: fsub DWORD PTR ds:0x48dcc0
47e233: fstp QWORD PTR [esi+edi*8-0xa8]
47e23a: fwait
47e23b: cmp BYTE PTR [esi+edi*8-0x43],0x1
47e240: jne 0x47e250
47e242: push 0x40140000
47e247: push 0x0
47e249: mov eax,ebx
47e24b: call 0x47648c
47e250: cmp BYTE PTR [esi+edi*8-0x43],0x2
47e255: jne 0x47e265
47e257: push 0xc0140000
47e25c: push 0x0
47e25e: mov eax,ebx
47e260: call 0x47648c
47e265: cmp WORD PTR [esi+edi*8-0x3c],0x14
47e26b: jne 0x47e272
47e26d: mov BYTE PTR [esi+edi*8-0x46],0x1
47e272: mov BYTE PTR [esi+edi*8-0x47],0x1
47e277: cmp BYTE PTR [esi+edi*8-0x45],0x1c
47e27c: jne 0x47e3ee
47e282: cmp WORD PTR [esi+edi*8-0x3c],0x0
47e288: jne 0x47e292
47e28a: mov eax,ds:0x4b1098
47e28f: mov BYTE PTR [eax],0x11
47e292: xor eax,eax
47e294: mov al,bl
47e296: imul eax,eax,0x16
47e299: cmp WORD PTR [esi+eax*8-0x3c],0x0
47e29f: jne 0x47e2ab
47e2a1: mov al,BYTE PTR [esp+0x1]
47e2a5: add al,0x2d
47e2a7: mov BYTE PTR [esi+edi*8-0x44],al
47e2ab: cmp WORD PTR [esi+edi*8-0x3c],0x4
47e2b1: jne 0x47e2bd
47e2b3: mov al,BYTE PTR [esp+0x1]
47e2b7: add al,0x2e
47e2b9: mov BYTE PTR [esi+edi*8-0x44],al
47e2bd: cmp WORD PTR [esi+edi*8-0x3c],0x8
47e2c3: jne 0x47e2cf
47e2c5: mov al,BYTE PTR [esp+0x1]
47e2c9: add al,0x2f
47e2cb: mov BYTE PTR [esi+edi*8-0x44],al
47e2cf: cmp WORD PTR [esi+edi*8-0x3c],0xc
47e2d5: jne 0x47e2e1
47e2d7: mov al,BYTE PTR [esp+0x1]
47e2db: add al,0x30
47e2dd: mov BYTE PTR [esi+edi*8-0x44],al
47e2e1: cmp WORD PTR [esi+edi*8-0x3c],0xf
47e2e7: jne 0x47e2f3
47e2e9: mov al,BYTE PTR [esp+0x1]
47e2ed: add al,0x31
47e2ef: mov BYTE PTR [esi+edi*8-0x44],al
47e2f3: cmp WORD PTR [esi+edi*8-0x3c],0x12
47e2f9: jne 0x47e305
47e2fb: mov al,BYTE PTR [esp+0x1]
47e2ff: add al,0xc
47e301: mov BYTE PTR [esi+edi*8-0x44],al
47e305: xor eax,eax
47e307: mov al,bl
47e309: imul eax,eax,0x16
47e30c: cmp WORD PTR [esi+eax*8-0x3c],0x4
47e312: jl 0x47e3d3
47e318: xor eax,eax
47e31a: mov al,bl
47e31c: imul eax,eax,0x16
47e31f: cmp WORD PTR [esi+eax*8-0x3c],0xd
47e325: jg 0x47e3d3
47e32b: xor eax,eax
47e32d: mov al,bl
47e32f: imul eax,eax,0x16
47e332: cmp BYTE PTR [esi+eax*8-0x43],0x1
47e337: jne 0x47e355
47e339: xor eax,eax
47e33b: mov al,bl
47e33d: imul eax,eax,0x16
47e340: cmp BYTE PTR [esi+eax*8-0x41],0x1
47e345: jne 0x47e355
47e347: push 0x40310000
47e34c: push 0x0
47e34e: mov eax,ebx
47e350: call 0x47648c
47e355: xor eax,eax
47e357: mov al,bl
47e359: imul eax,eax,0x16
47e35c: cmp BYTE PTR [esi+eax*8-0x43],0x2
47e361: jne 0x47e37f
47e363: xor eax,eax
47e365: mov al,bl
47e367: imul eax,eax,0x16
47e36a: cmp BYTE PTR [esi+eax*8-0x41],0x1
47e36f: jne 0x47e37f
47e371: push 0xc0310000
47e376: push 0x0
47e378: mov eax,ebx
47e37a: call 0x47648c
47e37f: xor eax,eax
47e381: mov al,bl
47e383: imul eax,eax,0x16
47e386: cmp BYTE PTR [esi+eax*8-0x43],0x1
47e38b: jne 0x47e3a9
47e38d: xor eax,eax
47e38f: mov al,bl
47e391: imul eax,eax,0x16
47e394: cmp BYTE PTR [esi+eax*8-0x41],0x2
47e399: jne 0x47e3a9
47e39b: push 0x40350000
47e3a0: push 0x0
47e3a2: mov eax,ebx
47e3a4: call 0x47648c
47e3a9: xor eax,eax
47e3ab: mov al,bl
47e3ad: imul eax,eax,0x16
47e3b0: cmp BYTE PTR [esi+eax*8-0x43],0x2
47e3b5: jne 0x47e3d3
47e3b7: xor eax,eax
47e3b9: mov al,bl
47e3bb: imul eax,eax,0x16
47e3be: cmp BYTE PTR [esi+eax*8-0x41],0x2
47e3c3: jne 0x47e3d3
47e3c5: push 0xc0350000
47e3ca: push 0x0
47e3cc: mov eax,ebx
47e3ce: call 0x47648c
47e3d3: xor eax,eax
47e3d5: mov al,bl
47e3d7: imul eax,eax,0x16
47e3da: cmp WORD PTR [esi+eax*8-0x3c],0xc
47e3e0: jl 0x47e3ee
47e3e2: xor eax,eax
47e3e4: mov al,bl
47e3e6: imul eax,eax,0x16
47e3e9: mov BYTE PTR [esi+eax*8-0x47],0x1
47e3ee: mov edi,ebx
47e3f0: and edi,0xff
47e3f6: imul eax,edi,0x16
47e3f9: cmp BYTE PTR [esi+eax*8-0x45],0x1d
47e3fe: jne 0x47e543
47e404: xor eax,eax
47e406: mov al,bl
47e408: imul eax,eax,0x16
47e40b: cmp WORD PTR [esi+eax*8-0x3c],0x0
47e411: jne 0x47e425
47e413: xor eax,eax
47e415: mov al,bl
47e417: imul eax,eax,0x16
47e41a: mov dl,BYTE PTR [esp+0x1]
47e41e: add dl,0x24
47e421: mov BYTE PTR [esi+eax*8-0x44],dl
47e425: xor eax,eax
47e427: mov al,bl
47e429: imul eax,eax,0x16
47e42c: cmp WORD PTR [esi+eax*8-0x3c],0x3
47e432: jne 0x47e446
47e434: xor eax,eax
47e436: mov al,bl
47e438: imul eax,eax,0x16
47e43b: mov dl,BYTE PTR [esp+0x1]
47e43f: add dl,0x25
47e442: mov BYTE PTR [esi+eax*8-0x44],dl
47e446: xor eax,eax
47e448: mov al,bl
47e44a: imul eax,eax,0x16
47e44d: cmp WORD PTR [esi+eax*8-0x3c],0x6
47e453: jne 0x47e467
47e455: xor eax,eax
47e457: mov al,bl
47e459: imul eax,eax,0x16
47e45c: mov dl,BYTE PTR [esp+0x1]
47e460: add dl,0x26
47e463: mov BYTE PTR [esi+eax*8-0x44],dl
47e467: xor eax,eax
47e469: mov al,bl
47e46b: imul eax,eax,0x16
47e46e: cmp WORD PTR [esi+eax*8-0x3c],0x9
47e474: jne 0x47e47e
47e476: mov eax,ds:0x4b1098
47e47b: mov BYTE PTR [eax],0x12
47e47e: xor eax,eax
47e480: mov al,bl
47e482: imul eax,eax,0x16
47e485: cmp WORD PTR [esi+eax*8-0x3c],0x9
47e48b: jne 0x47e543
47e491: xor eax,eax
47e493: mov al,bl
47e495: imul eax,eax,0x16
47e498: mov dl,BYTE PTR [esp+0x1]
47e49c: add dl,0x27
47e49f: mov BYTE PTR [esi+eax*8-0x44],dl
47e4a3: xor eax,eax
47e4a5: mov al,bl
47e4a7: imul eax,eax,0x16
47e4aa: cmp BYTE PTR [esi+eax*8-0x43],0x1
47e4af: jne 0x47e4ef
47e4b1: xor eax,eax
47e4b3: mov al,bl
47e4b5: imul eax,eax,0x16
47e4b8: fld QWORD PTR [esi+eax*8-0xb0]
47e4bf: fadd DWORD PTR ds:0x48dcf4
47e4c5: add esp,0xfffffff8
47e4c8: fstp QWORD PTR [esp]
47e4cb: fwait
47e4cc: xor eax,eax
47e4ce: mov al,bl
47e4d0: imul eax,eax,0x16
47e4d3: push DWORD PTR [esi+eax*8-0xa4]
47e4da: push DWORD PTR [esi+eax*8-0xa8]
47e4e1: mov ecx,ebx
47e4e3: mov edx,0x48dcd4
47e4e8: mov al,0x8
47e4ea: call 0x476a04
47e4ef: xor eax,eax
47e4f1: mov al,bl
47e4f3: imul eax,eax,0x16
47e4f6: cmp BYTE PTR [esi+eax*8-0x43],0x2
47e4fb: jne 0x47e53b
47e4fd: xor eax,eax
47e4ff: mov al,bl
47e501: imul eax,eax,0x16
47e504: fld QWORD PTR [esi+eax*8-0xb0]
47e50b: fsub DWORD PTR ds:0x48dcf4
47e511: add esp,0xfffffff8
47e514: fstp QWORD PTR [esp]
47e517: fwait
47e518: xor eax,eax
47e51a: mov al,bl
47e51c: imul eax,eax,0x16
47e51f: push DWORD PTR [esi+eax*8-0xa4]
47e526: push DWORD PTR [esi+eax*8-0xa8]
47e52d: mov ecx,ebx
47e52f: mov edx,0x48dcd4
47e534: mov al,0x8
47e536: call 0x476a04
47e53b: mov eax,ds:0x4b0d68
47e540: mov BYTE PTR [eax],0x14
47e543: push 0x23
47e545: push 0x13
47e547: push 0xa4
47e54c: movzx ebp,BYTE PTR [esp+0xd]
47e551: mov edx,ebp
47e553: inc edx
47e554: mov eax,edi
47e556: mov ecx,0xfffffff3
47e55b: call 0x476870
47e560: push 0x23
47e562: push 0x13
47e564: push 0xa4
47e569: mov edx,ebp
47e56b: add edx,0x2
47e56e: mov eax,edi
47e570: mov ecx,0xfffffff3
47e575: call 0x476870
47e57a: push 0x23
47e57c: push 0x13
47e57e: push 0xa4
47e583: mov edx,ebp
47e585: add edx,0x3
47e588: mov eax,edi
47e58a: mov ecx,0xfffffff3
47e58f: call 0x476870
47e594: push 0x23
47e596: push 0x13
47e598: push 0xa4
47e59d: mov edx,ebp
47e59f: add edx,0x4
47e5a2: mov eax,edi
47e5a4: mov ecx,0xfffffff3
47e5a9: call 0x476870
47e5ae: push 0x23
47e5b0: push 0x13
47e5b2: push 0xa4
47e5b7: mov edx,ebp
47e5b9: add edx,0x6
47e5bc: mov eax,edi
47e5be: mov ecx,0xfffffff3
47e5c3: call 0x476870
47e5c8: push 0x23
47e5ca: push 0x13
47e5cc: push 0xa4
47e5d1: mov edx,ebp
47e5d3: add edx,0x8
47e5d6: mov eax,edi
47e5d8: mov ecx,0xfffffff3
47e5dd: call 0x476870
47e5e2: push 0x23
47e5e4: push 0x13
47e5e6: push 0xa4
47e5eb: mov edx,ebp
47e5ed: add edx,0xa
47e5f0: mov eax,edi
47e5f2: mov ecx,0xfffffff3
47e5f7: call 0x476870
47e5fc: push 0x41
47e5fe: push 0x13
47e600: push 0xa4
47e605: mov edx,ebp
47e607: add edx,0xc
47e60a: mov eax,edi
47e60c: mov ecx,0xfffffff3
47e611: call 0x476870
47e616: push 0x41
47e618: push 0x13
47e61a: push 0xa4
47e61f: mov edx,ebp
47e621: add edx,0xd
47e624: mov eax,edi
47e626: mov ecx,0xfffffff3
47e62b: call 0x476870
47e630: push 0x41
47e632: push 0x13
47e634: push 0xa4
47e639: mov edx,ebp
47e63b: add edx,0xf
47e63e: mov eax,edi
47e640: mov ecx,0xfffffff3
47e645: call 0x476870
47e64a: push 0x41
47e64c: push 0x13
47e64e: push 0xa4
47e653: mov edx,ebp
47e655: add edx,0x11
47e658: mov eax,edi
47e65a: mov ecx,0xfffffff3
47e65f: call 0x476870
47e664: push 0x41
47e666: push 0x13
47e668: push 0xa4
47e66d: mov edx,ebp
47e66f: add edx,0x13
47e672: mov eax,edi
47e674: mov ecx,0xfffffff3
47e679: call 0x476870
47e67e: push 0x28
47e680: push 0x13
47e682: push 0x78
47e684: mov edx,ebp
47e686: add edx,0x15
47e689: mov eax,edi
47e68b: mov ecx,0xfffffff3
47e690: call 0x476870
47e695: push 0x46
47e697: push 0x20
47e699: push 0x78
47e69b: xor edx,edx
47e69d: mov dl,BYTE PTR [esp+0xd]
47e6a1: add edx,0x1c
47e6a4: mov eax,edi
47e6a6: mov ecx,0xffffffec
47e6ab: call 0x476870
47e6b0: push 0x6e
47e6b2: push 0x20
47e6b4: push 0x96
47e6b9: xor edx,edx
47e6bb: mov dl,BYTE PTR [esp+0xd]
47e6bf: add edx,0x1d
47e6c2: mov eax,edi
47e6c4: mov ecx,0xffffffec
47e6c9: call 0x476870
47e6ce: push 0x23
47e6d0: push 0x13
47e6d2: push 0xa4
47e6d7: xor edx,edx
47e6d9: mov dl,BYTE PTR [esp+0xd]
47e6dd: add edx,0x1f
47e6e0: mov eax,edi
47e6e2: mov ecx,0xfffffff3
47e6e7: call 0x476870
47e6ec: push 0x41
47e6ee: push 0x13
47e6f0: push 0xa4
47e6f5: xor edx,edx
47e6f7: mov dl,BYTE PTR [esp+0xd]
47e6fb: add edx,0x20
47e6fe: mov eax,edi
47e700: mov ecx,0xfffffff3
47e705: call 0x476870
47e70a: push 0x28
47e70c: push 0xc
47e70e: push 0xa4
47e713: xor edx,edx
47e715: mov dl,BYTE PTR [esp+0xd]
47e719: add edx,0x23
47e71c: mov eax,edi
47e71e: mov ecx,0xffffffec
47e723: call 0x476870
47e728: push 0x50
47e72a: push 0x2d
47e72c: push 0xa4
47e731: xor edx,edx
47e733: mov dl,BYTE PTR [esp+0xd]
47e737: add edx,0x25
47e73a: mov eax,edi
47e73c: mov ecx,0xfffffff6
47e741: call 0x476870
47e746: push 0x46
47e748: push 0x28
47e74a: push 0xa4
47e74f: xor edx,edx
47e751: mov dl,BYTE PTR [esp+0xd]
47e755: add edx,0x27
47e758: mov eax,edi
47e75a: mov ecx,0xffffffe2
47e75f: call 0x476870
47e764: push 0x32
47e766: push 0x23
47e768: push 0x96
47e76d: xor edx,edx
47e76f: mov dl,BYTE PTR [esp+0xd]
47e773: add edx,0x29
47e776: mov eax,edi
47e778: xor ecx,ecx
47e77a: call 0x476870
47e77f: push 0x32
47e781: push 0x16
47e783: push 0x7d
47e785: xor edx,edx
47e787: mov dl,BYTE PTR [esp+0xd]
47e78b: add edx,0x2b
47e78e: mov eax,edi
47e790: mov ecx,0xfffffff1
47e795: call 0x476870
47e79a: push 0x32
47e79c: push 0x16
47e79e: push 0x6e
47e7a0: xor edx,edx
47e7a2: mov dl,BYTE PTR [esp+0xd]
47e7a6: add edx,0x2d
47e7a9: mov eax,edi
47e7ab: mov ecx,0xfffffff1
47e7b0: call 0x476870
47e7b5: push 0xf
47e7b7: push 0x2f
47e7b9: push 0x3f
47e7bb: push 0x39
47e7bd: push 0x1
47e7bf: push 0x1
47e7c1: push 0x7
47e7c3: push 0x0
47e7c5: mov eax,edi
47e7c7: mov ecx,0x2
47e7cc: mov edx,0x3
47e7d1: call 0x4768f8
47e7d6: push 0x19
47e7d8: push 0x54
47e7da: push 0x54
47e7dc: push 0x7c
47e7de: push 0x1
47e7e0: push 0x1
47e7e2: push 0x7
47e7e4: push 0x0
47e7e6: mov eax,edi
47e7e8: mov ecx,0x2
47e7ed: mov edx,0x4
47e7f2: call 0x4768f8
47e7f7: push 0x19
47e7f9: push 0x2e
47e7fb: push 0x41
47e7fd: push 0x3a
47e7ff: push 0x1
47e801: push 0x2
47e803: push 0xe
47e805: push 0x0
47e807: mov eax,edi
47e809: mov ecx,0x5
47e80e: mov edx,0x5
47e813: call 0x4768f8
47e818: push 0x19
47e81a: push 0x52
47e81c: push 0x53
47e81e: push 0x6b
47e820: push 0x1
47e822: push 0x2
47e824: push 0xe
47e826: push 0x0
47e828: mov eax,edi
47e82a: mov ecx,0x5
47e82f: mov edx,0x6
47e834: call 0x4768f8
47e839: push 0xf
47e83b: push 0x43
47e83d: push 0x4b
47e83f: push 0x52
47e841: push 0x1
47e843: push 0x1
47e845: push 0x7
47e847: push 0x0
47e849: mov eax,edi
47e84b: mov ecx,0x2
47e850: mov edx,0x8
47e855: call 0x4768f8
47e85a: push 0xa
47e85c: push 0x73
47e85e: push 0x46
47e860: push 0x9b
47e865: push 0x1
47e867: push 0x1
47e869: push 0x7
47e86b: push 0x0
47e86d: mov eax,edi
47e86f: mov ecx,0x2
47e874: mov edx,0x9
47e879: call 0x4768f8
47e87e: push 0xf
47e880: push 0x43
47e882: push 0x46
47e884: push 0x52
47e886: push 0x1
47e888: push 0x2
47e88a: push 0xe
47e88c: push 0x0
47e88e: mov eax,edi
47e890: mov ecx,0x5
47e895: mov edx,0xa
47e89a: call 0x4768f8
47e89f: push 0x5
47e8a1: push 0x5f
47e8a3: push 0x62
47e8a5: push 0x71
47e8a7: push 0x1
47e8a9: push 0x2
47e8ab: push 0xe
47e8ad: push 0x0
47e8af: mov eax,edi
47e8b1: mov ecx,0x5
47e8b6: mov edx,0xb
47e8bb: call 0x4768f8
47e8c0: push 0xf
47e8c2: push 0x3c
47e8c4: push 0x50
47e8c6: push 0x5e
47e8c8: push 0x1
47e8ca: push 0x1
47e8cc: push 0x7
47e8ce: push 0x0
47e8d0: mov eax,edi
47e8d2: mov ecx,0x2
47e8d7: mov edx,0xd
47e8dc: call 0x4768f8
47e8e1: push 0xa
47e8e3: push 0x4b
47e8e5: push 0x4b
47e8e7: push 0x61
47e8e9: push 0x1
47e8eb: push 0x1
47e8ed: push 0x7
47e8ef: push 0x0
47e8f1: mov eax,edi
47e8f3: mov ecx,0x2
47e8f8: mov edx,0xe
47e8fd: call 0x4768f8
47e902: push 0xf
47e904: push 0x3c
47e906: push 0x50
47e908: push 0x5e
47e90a: push 0x1
47e90c: push 0x2
47e90e: push 0xe
47e910: push 0x0
47e912: mov eax,edi
47e914: mov ecx,0x5
47e919: mov edx,0xf
47e91e: call 0x4768f8
47e923: push 0xa
47e925: push 0x4b
47e927: push 0x4b
47e929: push 0x61
47e92b: push 0x1
47e92d: push 0x2
47e92f: push 0xe
47e931: push 0x0
47e933: mov eax,edi
47e935: mov ecx,0x5
47e93a: mov edx,0x10
47e93f: call 0x4768f8
47e944: xor eax,eax
47e946: mov al,bl
47e948: imul eax,eax,0x16
47e94b: cmp BYTE PTR [esi+eax*8-0x41],0x1
47e950: jne 0x47e973
47e952: push 0x28
47e954: push 0x49
47e956: push 0x64
47e958: push 0x56
47e95a: push 0x1
47e95c: push 0x0
47e95e: push 0x10
47e960: push 0x2
47e962: mov eax,edi
47e964: mov ecx,0x6
47e969: mov edx,0x1a
47e96e: call 0x4768f8
47e973: xor eax,eax
47e975: mov al,bl
47e977: imul eax,eax,0x16
47e97a: cmp BYTE PTR [esi+eax*8-0x41],0x2
47e97f: jne 0x47e9a2
47e981: push 0x28
47e983: push 0x49
47e985: push 0x64
47e987: push 0x56
47e989: push 0x1
47e98b: push 0x0
47e98d: push 0x14
47e98f: push 0x3
47e991: mov eax,edi
47e993: mov ecx,0xa
47e998: mov edx,0x1a
47e99d: call 0x4768f8
47e9a2: push 0xffffffe0
47e9a4: push 0x5
47e9a6: push 0x20
47e9a8: push 0x7d
47e9aa: push 0x1
47e9ac: push 0x0
47e9ae: push 0xa
47e9b0: push 0x2
47e9b2: mov eax,edi
47e9b4: xor ecx,ecx
47e9b6: mov edx,0x1b
47e9bb: call 0x4768f8
47e9c0: push 0xffffffe0
47e9c2: push 0x5
47e9c4: push 0x20
47e9c6: push 0x7d
47e9c8: push 0x1
47e9ca: push 0x0
47e9cc: push 0x6
47e9ce: push 0x2
47e9d0: mov eax,edi
47e9d2: mov ecx,0x2
47e9d7: mov edx,0x1b
47e9dc: call 0x4768f8
47e9e1: push 0xffffffe0
47e9e3: push 0x5
47e9e5: push 0x20
47e9e7: push 0x7d
47e9e9: push 0x1
47e9eb: push 0x0
47e9ed: push 0x4
47e9ef: push 0x2
47e9f1: mov eax,edi
47e9f3: mov ecx,0x4
47e9f8: mov edx,0x1b
47e9fd: call 0x4768f8
47ea02: push 0xffffffe0
47ea04: push 0x5
47ea06: push 0x20
47ea08: push 0x7d
47ea0a: push 0x1
47ea0c: push 0x0
47ea0e: push 0x2
47ea10: push 0x2
47ea12: mov eax,edi
47ea14: mov ecx,0x7
47ea19: mov edx,0x1b
47ea1e: call 0x4768f8
47ea23: push 0xffffffe2
47ea25: push 0xa
47ea27: push 0x23
47ea29: push 0x46
47ea2b: push 0x1
47ea2d: push 0x0
47ea2f: push 0xa
47ea31: push 0x3
47ea33: mov eax,edi
47ea35: mov ecx,0x6
47ea3a: mov edx,0x1c
47ea3f: call 0x4768f8
47ea44: push 0xffffffe2
47ea46: push 0xa
47ea48: push 0x23
47ea4a: push 0x46
47ea4c: push 0x1
47ea4e: push 0x0
47ea50: push 0x7
47ea52: push 0x2
47ea54: mov eax,edi
47ea56: mov ecx,0x9
47ea5b: mov edx,0x1c
47ea60: call 0x4768f8
47ea65: push 0xfffffff6
47ea67: push 0x32
47ea69: push 0x2d
47ea6b: push 0x64
47ea6d: push 0x1
47ea6f: push 0x0
47ea71: push 0x5
47ea73: push 0x1
47ea75: mov eax,edi
47ea77: mov ecx,0xc
47ea7c: mov edx,0x1c
47ea81: call 0x4768f8
47ea86: xor eax,eax
47ea88: mov al,bl
47ea8a: imul eax,eax,0x16
47ea8d: cmp BYTE PTR [esi+eax*8-0xa0],0x2
47ea95: jne 0x480004
47ea9b: xor eax,eax
47ea9d: mov al,bl
47ea9f: imul eax,eax,0x16
47eaa2: cmp BYTE PTR [esi+eax*8-0x45],0x17
47eaa7: jne 0x47eabb
47eaa9: xor eax,eax
47eaab: mov al,bl
47eaad: imul eax,eax,0x16
47eab0: mov dl,BYTE PTR [esp+0x1]
47eab4: add dl,0x21
47eab7: mov BYTE PTR [esi+eax*8-0x44],dl
47eabb: xor eax,eax
47eabd: mov al,bl
47eabf: imul eax,eax,0x16
47eac2: cmp BYTE PTR [esi+eax*8-0x45],0x17
47eac7: jne 0x47eae9
47eac9: mov eax,0x2
47eace: call 0x402a1c
47ead3: test eax,eax
47ead5: jne 0x47eae9
47ead7: xor eax,eax
47ead9: mov al,bl
47eadb: imul eax,eax,0x16
47eade: mov dl,BYTE PTR [esp+0x1]
47eae2: add dl,0x22
47eae5: mov BYTE PTR [esi+eax*8-0x44],dl
47eae9: xor eax,eax
47eaeb: mov al,bl
47eaed: imul eax,eax,0x16
47eaf0: cmp BYTE PTR [esi+eax*8-0x45],0x18
47eaf5: jne 0x47eb18
47eaf7: xor eax,eax
47eaf9: mov al,bl
47eafb: imul eax,eax,0x16
47eafe: cmp WORD PTR [esi+eax*8-0x3c],0x0
47eb04: jne 0x47eb18
47eb06: xor eax,eax
47eb08: mov al,bl
47eb0a: imul eax,eax,0x16
47eb0d: mov dl,BYTE PTR [esp+0x1]
47eb11: add dl,0xc
47eb14: mov BYTE PTR [esi+eax*8-0x44],dl
47eb18: xor eax,eax
47eb1a: mov al,bl
47eb1c: imul eax,eax,0x16
47eb1f: cmp BYTE PTR [esi+eax*8-0x45],0x18
47eb24: jne 0x47eb39
47eb26: cmp WORD PTR [esi+eax*8-0x3c],0x2
47eb2c: jne 0x47eb39
47eb2e: mov dl,BYTE PTR [esp+0x1]
47eb32: add dl,0x1e
47eb35: mov BYTE PTR [esi+eax*8-0x44],dl
47eb39: cmp BYTE PTR [esi+eax*8-0x45],0x19
47eb3e: jne 0x47ed09
47eb44: cmp WORD PTR [esi+eax*8-0x3c],0x0
47eb4a: jne 0x47eb57
47eb4c: mov dl,BYTE PTR [esp+0x1]
47eb50: add dl,0x23
47eb53: mov BYTE PTR [esi+eax*8-0x44],dl
47eb57: cmp WORD PTR [esi+eax*8-0x3c],0x8
47eb5d: jne 0x47eb6a
47eb5f: mov dl,BYTE PTR [esp+0x1]
47eb63: add dl,0x24
47eb66: mov BYTE PTR [esi+eax*8-0x44],dl
47eb6a: cmp WORD PTR [esi+eax*8-0x3c],0xa
47eb70: jne 0x47ed09
47eb76: mov dl,BYTE PTR [esp+0x1]
47eb7a: add dl,0x25
47eb7d: mov BYTE PTR [esi+eax*8-0x44],dl
47eb81: xor eax,eax
47eb83: mov al,bl
47eb85: imul eax,eax,0x16
47eb88: cmp BYTE PTR [esi+eax*8-0x43],0x1
47eb8d: jne 0x47ebe1
47eb8f: xor eax,eax
47eb91: mov al,bl
47eb93: imul eax,eax,0x16
47eb96: cmp BYTE PTR [esi+eax*8-0x41],0x1
47eb9b: jne 0x47ebe1
47eb9d: xor eax,eax
47eb9f: mov al,bl
47eba1: imul eax,eax,0x16
47eba4: fld QWORD PTR [esi+eax*8-0xb0]
47ebab: fadd DWORD PTR ds:0x48dcf8
47ebb1: add esp,0xfffffff8
47ebb4: fstp QWORD PTR [esp]
47ebb7: fwait
47ebb8: xor eax,eax
47ebba: mov al,bl
47ebbc: imul eax,eax,0x16
47ebbf: fld QWORD PTR [esi+eax*8-0xa8]
47ebc6: fsub DWORD PTR ds:0x48dcfc
47ebcc: add esp,0xfffffff8
47ebcf: fstp QWORD PTR [esp]
47ebd2: fwait
47ebd3: mov ecx,ebx
47ebd5: mov edx,0x48dcd4
47ebda: mov al,0x9
47ebdc: call 0x476a04
47ebe1: xor eax,eax
47ebe3: mov al,bl
47ebe5: imul eax,eax,0x16
47ebe8: cmp BYTE PTR [esi+eax*8-0x43],0x2
47ebed: jne 0x47ec41
47ebef: xor eax,eax
47ebf1: mov al,bl
47ebf3: imul eax,eax,0x16
47ebf6: cmp BYTE PTR [esi+eax*8-0x41],0x1
47ebfb: jne 0x47ec41
47ebfd: xor eax,eax
47ebff: mov al,bl
47ec01: imul eax,eax,0x16
47ec04: fld QWORD PTR [esi+eax*8-0xb0]
47ec0b: fsub DWORD PTR ds:0x48dcf8
47ec11: add esp,0xfffffff8
47ec14: fstp QWORD PTR [esp]
47ec17: fwait
47ec18: xor eax,eax
47ec1a: mov al,bl
47ec1c: imul eax,eax,0x16
47ec1f: fld QWORD PTR [esi+eax*8-0xa8]
47ec26: fsub DWORD PTR ds:0x48dcfc
47ec2c: add esp,0xfffffff8
47ec2f: fstp QWORD PTR [esp]
47ec32: fwait
47ec33: mov ecx,ebx
47ec35: mov edx,0x48dcd4
47ec3a: mov al,0x9
47ec3c: call 0x476a04
47ec41: xor eax,eax
47ec43: mov al,bl
47ec45: imul eax,eax,0x16
47ec48: cmp BYTE PTR [esi+eax*8-0x43],0x1
47ec4d: jne 0x47eca1
47ec4f: xor eax,eax
47ec51: mov al,bl
47ec53: imul eax,eax,0x16
47ec56: cmp BYTE PTR [esi+eax*8-0x41],0x2
47ec5b: jne 0x47eca1
47ec5d: xor eax,eax
47ec5f: mov al,bl
47ec61: imul eax,eax,0x16
47ec64: fld QWORD PTR [esi+eax*8-0xb0]
47ec6b: fadd DWORD PTR ds:0x48dcf8
47ec71: add esp,0xfffffff8
47ec74: fstp QWORD PTR [esp]
47ec77: fwait
47ec78: xor eax,eax
47ec7a: mov al,bl
47ec7c: imul eax,eax,0x16
47ec7f: fld QWORD PTR [esi+eax*8-0xa8]
47ec86: fsub DWORD PTR ds:0x48dcfc
47ec8c: add esp,0xfffffff8
47ec8f: fstp QWORD PTR [esp]
47ec92: fwait
47ec93: mov ecx,ebx
47ec95: mov edx,0x48dce0
47ec9a: mov al,0x9
47ec9c: call 0x476a04
47eca1: xor eax,eax
47eca3: mov al,bl
47eca5: imul eax,eax,0x16
47eca8: cmp BYTE PTR [esi+eax*8-0x43],0x2
47ecad: jne 0x47ed01
47ecaf: xor eax,eax
47ecb1: mov al,bl
47ecb3: imul eax,eax,0x16
47ecb6: cmp BYTE PTR [esi+eax*8-0x41],0x2
47ecbb: jne 0x47ed01
47ecbd: xor eax,eax
47ecbf: mov al,bl
47ecc1: imul eax,eax,0x16
47ecc4: fld QWORD PTR [esi+eax*8-0xb0]
47eccb: fsub DWORD PTR ds:0x48dcf8
47ecd1: add esp,0xfffffff8
47ecd4: fstp QWORD PTR [esp]
47ecd7: fwait
47ecd8: xor eax,eax
47ecda: mov al,bl
47ecdc: imul eax,eax,0x16
47ecdf: fld QWORD PTR [esi+eax*8-0xa8]
47ece6: fsub DWORD PTR ds:0x48dcfc
47ecec: add esp,0xfffffff8
47ecef: fstp QWORD PTR [esp]
47ecf2: fwait
47ecf3: mov ecx,ebx
47ecf5: mov edx,0x48dce0
47ecfa: mov al,0x9
47ecfc: call 0x476a04
47ed01: mov eax,ds:0x4b1098
47ed06: mov BYTE PTR [eax],0x14
47ed09: xor eax,eax
47ed0b: mov al,bl
47ed0d: imul eax,eax,0x16
47ed10: cmp BYTE PTR [esi+eax*8-0x45],0x1a
47ed15: jne 0x47ef6b
47ed1b: xor eax,eax
47ed1d: mov al,bl
47ed1f: imul eax,eax,0x16
47ed22: cmp WORD PTR [esi+eax*8-0x3c],0x0
47ed28: jne 0x47ed3c
47ed2a: xor eax,eax
47ed2c: mov al,bl
47ed2e: imul eax,eax,0x16
47ed31: mov dl,BYTE PTR [esp+0x1]
47ed35: add dl,0x26
47ed38: mov BYTE PTR [esi+eax*8-0x44],dl
47ed3c: xor eax,eax
47ed3e: mov al,bl
47ed40: imul eax,eax,0x16
47ed43: cmp WORD PTR [esi+eax*8-0x3c],0x5
47ed49: jne 0x47ed5d
47ed4b: xor eax,eax
47ed4d: mov al,bl
47ed4f: imul eax,eax,0x16
47ed52: mov dl,BYTE PTR [esp+0x1]
47ed56: add dl,0x27
47ed59: mov BYTE PTR [esi+eax*8-0x44],dl
47ed5d: xor eax,eax
47ed5f: mov al,bl
47ed61: imul eax,eax,0x16
47ed64: cmp WORD PTR [esi+eax*8-0x3c],0xb
47ed6a: jne 0x47ed7a
47ed6c: xor eax,eax
47ed6e: mov al,bl
47ed70: imul eax,eax,0x16
47ed73: cmp BYTE PTR [esi+eax*8-0x41],0x1
47ed78: je 0x47ed97
47ed7a: xor eax,eax
47ed7c: mov al,bl
47ed7e: imul eax,eax,0x16
47ed81: cmp WORD PTR [esi+eax*8-0x3c],0xf
47ed87: jne 0x47edc1
47ed89: xor eax,eax
47ed8b: mov al,bl
47ed8d: imul eax,eax,0x16
47ed90: cmp BYTE PTR [esi+eax*8-0x41],0x2
47ed95: jne 0x47edc1
47ed97: xor eax,eax
47ed99: mov al,bl
47ed9b: imul eax,eax,0x16
47ed9e: mov dl,BYTE PTR [esp+0x1]
47eda2: add dl,0x28
47eda5: mov BYTE PTR [esi+eax*8-0x44],dl
47eda9: xor eax,eax
47edab: mov al,bl
47edad: imul eax,eax,0x16
47edb0: mov BYTE PTR [esi+eax*8-0x46],0x1
47edb5: xor eax,eax
47edb7: mov al,bl
47edb9: imul eax,eax,0x16
47edbc: mov BYTE PTR [esi+eax*8-0x38],0xfa
47edc1: xor eax,eax
47edc3: mov al,bl
47edc5: imul eax,eax,0x16
47edc8: movzx eax,BYTE PTR [esi+eax*8-0x44]
47edcd: xor edx,edx
47edcf: mov dl,BYTE PTR [esp+0x1]
47edd3: add edx,0x27
47edd6: cmp eax,edx
47edd8: jne 0x47ef0a
47edde: xor eax,eax
47ede0: mov al,bl
47ede2: imul eax,eax,0x16
47ede5: cmp BYTE PTR [esi+eax*8-0x41],0x1
47edea: jne 0x47ee47
47edec: xor eax,eax
47edee: mov al,bl
47edf0: imul eax,eax,0x16
47edf3: fld QWORD PTR [esi+eax*8-0xa8]
47edfa: fsub DWORD PTR ds:0x48dd00
47ee00: xor eax,eax
47ee02: mov al,bl
47ee04: imul eax,eax,0x16
47ee07: fstp QWORD PTR [esi+eax*8-0xa8]
47ee0e: fwait
47ee0f: xor eax,eax
47ee11: mov al,bl
47ee13: imul eax,eax,0x16
47ee16: cmp BYTE PTR [esi+eax*8-0x43],0x1
47ee1b: jne 0x47ee2b
47ee1d: push 0x40100000
47ee22: push 0x0
47ee24: mov eax,ebx
47ee26: call 0x47648c
47ee2b: xor eax,eax
47ee2d: mov al,bl
47ee2f: imul eax,eax,0x16
47ee32: cmp BYTE PTR [esi+eax*8-0x43],0x2
47ee37: jne 0x47ee47
47ee39: push 0xc0100000
47ee3e: push 0x0
47ee40: mov eax,ebx
47ee42: call 0x47648c
47ee47: xor eax,eax
47ee49: mov al,bl
47ee4b: imul eax,eax,0x16
47ee4e: cmp BYTE PTR [esi+eax*8-0x41],0x2
47ee53: jne 0x47ef0a
47ee59: xor eax,eax
47ee5b: mov al,bl
47ee5d: imul eax,eax,0x16
47ee60: fld QWORD PTR [esi+eax*8-0xa8]
47ee67: fsub DWORD PTR ds:0x48dd04
47ee6d: xor eax,eax
47ee6f: mov al,bl
47ee71: imul eax,eax,0x16
47ee74: fstp QWORD PTR [esi+eax*8-0xa8]
47ee7b: fwait
47ee7c: xor eax,eax
47ee7e: mov al,bl
47ee80: imul eax,eax,0x16
47ee83: cmp WORD PTR [esi+eax*8-0x3c],0xa
47ee89: jge 0x47eec3
47ee8b: xor eax,eax
47ee8d: mov al,bl
47ee8f: imul eax,eax,0x16
47ee92: cmp BYTE PTR [esi+eax*8-0x43],0x1
47ee97: jne 0x47eea7
47ee99: push 0x40220000
47ee9e: push 0x0
47eea0: mov eax,ebx
47eea2: call 0x47648c
47eea7: xor eax,eax
47eea9: mov al,bl
47eeab: imul eax,eax,0x16
47eeae: cmp BYTE PTR [esi+eax*8-0x43],0x2
47eeb3: jne 0x47eec3
47eeb5: push 0xc0220000
47eeba: push 0x0
47eebc: mov eax,ebx
47eebe: call 0x47648c
47eec3: xor eax,eax
47eec5: mov al,bl
47eec7: imul eax,eax,0x16
47eeca: cmp WORD PTR [esi+eax*8-0x3c],0xa
47eed0: jl 0x47ef0a
47eed2: xor eax,eax
47eed4: mov al,bl
47eed6: imul eax,eax,0x16
47eed9: cmp BYTE PTR [esi+eax*8-0x43],0x1
47eede: jne 0x47eeee
47eee0: push 0x40080000
47eee5: push 0x0
47eee7: mov eax,ebx
47eee9: call 0x47648c
47eeee: xor eax,eax
47eef0: mov al,bl
47eef2: imul eax,eax,0x16
47eef5: cmp BYTE PTR [esi+eax*8-0x43],0x2
47eefa: jne 0x47ef0a
47eefc: push 0xc0080000
47ef01: push 0x0
47ef03: mov eax,ebx
47ef05: call 0x47648c
47ef0a: xor eax,eax
47ef0c: mov al,bl
47ef0e: imul eax,eax,0x16
47ef11: movzx eax,BYTE PTR [esi+eax*8-0x44]
47ef16: xor edx,edx
47ef18: mov dl,BYTE PTR [esp+0x1]
47ef1c: add edx,0x28
47ef1f: cmp eax,edx
47ef21: jne 0x47ef2f
47ef23: xor eax,eax
47ef25: mov al,bl
47ef27: imul eax,eax,0x16
47ef2a: mov BYTE PTR [esi+eax*8-0x46],0x1
47ef2f: xor eax,eax
47ef31: mov al,bl
47ef33: imul eax,eax,0x16
47ef36: cmp WORD PTR [esi+eax*8-0x3c],0x5
47ef3c: jl 0x47ef4a
47ef3e: xor eax,eax
47ef40: mov al,bl
47ef42: imul eax,eax,0x16
47ef45: mov BYTE PTR [esi+eax*8-0x47],0x1
47ef4a: xor eax,eax
47ef4c: mov al,bl
47ef4e: imul eax,eax,0x16
47ef51: cmp BYTE PTR [esi+eax*8-0x1b],0x1
47ef56: jne 0x47ef6b
47ef58: xor eax,eax
47ef5a: mov al,bl
47ef5c: mov edx,0x3
47ef61: sub edx,eax
47ef63: imul eax,edx,0x16
47ef66: mov BYTE PTR [esi+eax*8-0x1e],0x0
47ef6b: xor eax,eax
47ef6d: mov al,bl
47ef6f: imul eax,eax,0x16
47ef72: cmp BYTE PTR [esi+eax*8-0x45],0x1b
47ef77: jne 0x47f11c
47ef7d: xor eax,eax
47ef7f: mov al,bl
47ef81: imul eax,eax,0x16
47ef84: cmp WORD PTR [esi+eax*8-0x3c],0x0
47ef8a: jne 0x47efb6
47ef8c: xor eax,eax
47ef8e: mov al,bl
47ef90: imul eax,eax,0x16
47ef93: mov dl,BYTE PTR [esp+0x1]
47ef97: add dl,0x18
47ef9a: mov BYTE PTR [esi+eax*8-0x44],dl
47ef9e: xor eax,eax
47efa0: mov al,bl
47efa2: imul eax,eax,0x16
47efa5: mov BYTE PTR [esi+eax*8-0x38],0x0
47efaa: xor eax,eax
47efac: mov al,bl
47efae: imul eax,eax,0x16
47efb1: mov BYTE PTR [esi+eax*8-0x42],0x0
47efb6: xor eax,eax
47efb8: mov al,bl
47efba: imul eax,eax,0x16
47efbd: cmp BYTE PTR [esi+eax*8-0x45],0x1b
47efc2: jne 0x47f11c
47efc8: xor eax,eax
47efca: mov al,bl
47efcc: imul eax,eax,0x16
47efcf: cmp WORD PTR [esi+eax*8-0x3c],0x3
47efd5: jl 0x47f11c
47efdb: xor eax,eax
47efdd: mov al,bl
47efdf: imul eax,eax,0x16
47efe2: mov dl,BYTE PTR [esp+0x1]
47efe6: add dl,0x19
47efe9: mov BYTE PTR [esi+eax*8-0x44],dl
47efed: xor eax,eax
47efef: mov al,bl
47eff1: imul eax,eax,0x16
47eff4: cmp BYTE PTR [esi+eax*8-0x41],0x1
47eff9: jne 0x47f01e
47effb: xor eax,eax
47effd: mov al,bl
47efff: imul eax,eax,0x16
47f002: fld QWORD PTR [esi+eax*8-0xa8]
47f009: fadd DWORD PTR ds:0x48dce4
47f00f: xor eax,eax
47f011: mov al,bl
47f013: imul eax,eax,0x16
47f016: fstp QWORD PTR [esi+eax*8-0xa8]
47f01d: fwait
47f01e: xor eax,eax
47f020: mov al,bl
47f022: imul eax,eax,0x16
47f025: cmp BYTE PTR [esi+eax*8-0x41],0x2
47f02a: jne 0x47f04f
47f02c: xor eax,eax
47f02e: mov al,bl
47f030: imul eax,eax,0x16
47f033: fld QWORD PTR [esi+eax*8-0xa8]
47f03a: fadd DWORD PTR ds:0x48dd08
47f040: xor eax,eax
47f042: mov al,bl
47f044: imul eax,eax,0x16
47f047: fstp QWORD PTR [esi+eax*8-0xa8]
47f04e: fwait
47f04f: xor eax,eax
47f051: mov al,bl
47f053: imul eax,eax,0x16
47f056: cmp BYTE PTR [esi+eax*8-0x43],0x1
47f05b: jne 0x47f079
47f05d: xor eax,eax
47f05f: mov al,bl
47f061: imul eax,eax,0x16
47f064: cmp BYTE PTR [esi+eax*8-0x41],0x1
47f069: jne 0x47f079
47f06b: push 0x40260000
47f070: push 0x0
47f072: mov eax,ebx
47f074: call 0x47648c
47f079: xor eax,eax
47f07b: mov al,bl
47f07d: imul eax,eax,0x16
47f080: cmp BYTE PTR [esi+eax*8-0x43],0x2
47f085: jne 0x47f0a3
47f087: xor eax,eax
47f089: mov al,bl
47f08b: imul eax,eax,0x16
47f08e: cmp BYTE PTR [esi+eax*8-0x41],0x1
47f093: jne 0x47f0a3
47f095: push 0xc0260000
47f09a: push 0x0
47f09c: mov eax,ebx
47f09e: call 0x47648c
47f0a3: xor eax,eax
47f0a5: mov al,bl
47f0a7: imul eax,eax,0x16
47f0aa: cmp BYTE PTR [esi+eax*8-0x43],0x1
47f0af: jne 0x47f0cd
47f0b1: xor eax,eax
47f0b3: mov al,bl
47f0b5: imul eax,eax,0x16
47f0b8: cmp BYTE PTR [esi+eax*8-0x41],0x2
47f0bd: jne 0x47f0cd
47f0bf: push 0x402e0000
47f0c4: push 0x0
47f0c6: mov eax,ebx
47f0c8: call 0x47648c
47f0cd: xor eax,eax
47f0cf: mov al,bl
47f0d1: imul eax,eax,0x16
47f0d4: cmp BYTE PTR [esi+eax*8-0x43],0x2
47f0d9: jne 0x47f0f7
47f0db: xor eax,eax
47f0dd: mov al,bl
47f0df: imul eax,eax,0x16
47f0e2: cmp BYTE PTR [esi+eax*8-0x41],0x2
47f0e7: jne 0x47f0f7
47f0e9: push 0xc02e0000
47f0ee: push 0x0
47f0f0: mov eax,ebx
47f0f2: call 0x47648c
47f0f7: xor eax,eax
47f0f9: mov al,bl
47f0fb: imul eax,eax,0x16
47f0fe: fld QWORD PTR [esi+eax*8-0xa8]
47f105: fcomp DWORD PTR ds:0x48dd0c
47f10b: fnstsw ax
47f10d: sahf
47f10e: jbe 0x47f11c
47f110: xor eax,eax
47f112: mov al,bl
47f114: imul eax,eax,0x16
47f117: mov BYTE PTR [esi+eax*8-0x38],0x2
47f11c: xor eax,eax
47f11e: mov al,bl
47f120: imul eax,eax,0x16
47f123: cmp BYTE PTR [esi+eax*8-0x45],0x1c
47f128: je 0x47f13c
47f12a: xor eax,eax
47f12c: mov al,bl
47f12e: imul eax,eax,0x16
47f131: cmp BYTE PTR [esi+eax*8-0x45],0x1d
47f136: jne 0x47f517
47f13c: xor eax,eax
47f13e: mov al,bl
47f140: imul eax,eax,0x16
47f143: cmp WORD PTR [esi+eax*8-0x3c],0x0
47f149: jl 0x47f517
47f14f: xor eax,eax
47f151: mov al,bl
47f153: imul eax,eax,0x16
47f156: cmp BYTE PTR [esi+eax*8-0x45],0x1c
47f15b: jne 0x47f174
47f15d: xor eax,eax
47f15f: mov al,bl
47f161: imul eax,eax,0x16
47f164: cmp WORD PTR [esi+eax*8-0x3c],0x0
47f16a: jne 0x47f174
47f16c: mov eax,ds:0x4b1098
47f171: mov BYTE PTR [eax],0x16
47f174: xor eax,eax
47f176: mov al,bl
47f178: imul eax,eax,0x16
47f17b: mov al,BYTE PTR [esi+eax*8-0x44]
47f17f: mov BYTE PTR [esp],al
47f182: jmp 0x47f19a
47f184: mov eax,0x3
47f189: call 0x402a1c
47f18e: mov dl,BYTE PTR [esp+0x1]
47f192: add dl,0x29
47f195: add al,dl
47f197: mov BYTE PTR [esp],al
47f19a: xor eax,eax
47f19c: mov al,bl
47f19e: imul eax,eax,0x16
47f1a1: mov al,BYTE PTR [esi+eax*8-0x44]
47f1a5: cmp al,BYTE PTR [esp]
47f1a8: je 0x47f184
47f1aa: xor eax,eax
47f1ac: mov al,bl
47f1ae: imul eax,eax,0x16
47f1b1: mov dl,BYTE PTR [esp]
47f1b4: mov BYTE PTR [esi+eax*8-0x44],dl
47f1b8: mov eax,0x2
47f1bd: call 0x402a1c
47f1c2: test eax,eax
47f1c4: jne 0x47f1ce
47f1c6: mov eax,ds:0x4b1098
47f1cb: mov BYTE PTR [eax],0x5
47f1ce: mov eax,0x2
47f1d3: call 0x402a1c
47f1d8: test eax,eax
47f1da: jne 0x47f1e4
47f1dc: mov eax,ds:0x4b1098
47f1e1: mov BYTE PTR [eax],0x6
47f1e4: mov eax,0x2
47f1e9: call 0x402a1c
47f1ee: test eax,eax
47f1f0: jne 0x47f1fa
47f1f2: mov eax,ds:0x4b1098
47f1f7: mov BYTE PTR [eax],0x5
47f1fa: mov eax,0x2
47f1ff: call 0x402a1c
47f204: test eax,eax
47f206: jne 0x47f210
47f208: mov eax,ds:0x4b1098
47f20d: mov BYTE PTR [eax],0x6
47f210: xor eax,eax
47f212: mov al,bl
47f214: imul eax,eax,0x16
47f217: cmp BYTE PTR [esi+eax*8-0x45],0x1d
47f21c: jne 0x47f517
47f222: mov eax,ds:0x4b0d98
47f227: cmp BYTE PTR [eax],0x1
47f22a: jne 0x47f242
47f22c: mov eax,0x6
47f231: call 0x402a1c
47f236: test eax,eax
47f238: jne 0x47f242
47f23a: mov eax,ds:0x4b0fc8
47f23f: mov BYTE PTR [eax],0x3
47f242: xor eax,eax
47f244: mov al,bl
47f246: imul eax,eax,0x16
47f249: mov BYTE PTR [esi+eax*8-0x3e],0x0
47f24e: mov eax,0x2
47f253: call 0x402a1c
47f258: add al,0x1a
47f25a: mov dl,0x32
47f25c: sub dl,BYTE PTR [esp+0x1]
47f260: add al,dl
47f262: xor edx,edx
47f264: mov dl,bl
47f266: mov ecx,0x3
47f26b: sub ecx,edx
47f26d: imul edx,ecx,0x16
47f270: mov BYTE PTR [esi+edx*8-0x44],al
47f274: xor eax,eax
47f276: mov al,bl
47f278: mov edx,0x3
47f27d: sub edx,eax
47f27f: imul eax,edx,0x16
47f282: mov WORD PTR [esi+eax*8-0x3c],0x0
47f289: xor eax,eax
47f28b: mov al,bl
47f28d: mov edx,0x3
47f292: sub edx,eax
47f294: imul eax,edx,0x16
47f297: mov WORD PTR [esi+eax*8-0x3a],0x5
47f29e: xor eax,eax
47f2a0: mov al,bl
47f2a2: mov edx,0x3
47f2a7: sub edx,eax
47f2a9: imul eax,edx,0x16
47f2ac: mov BYTE PTR [esi+eax*8-0x38],0x0
47f2b1: xor eax,eax
47f2b3: mov al,bl
47f2b5: mov edx,0x3
47f2ba: sub edx,eax
47f2bc: imul eax,edx,0x16
47f2bf: fld QWORD PTR [esi+eax*8-0xa8]
47f2c6: fadd DWORD PTR ds:0x48dcc0
47f2cc: xor eax,eax
47f2ce: mov al,bl
47f2d0: mov edx,0x3
47f2d5: sub edx,eax
47f2d7: imul eax,edx,0x16
47f2da: fstp QWORD PTR [esi+eax*8-0xa8]
47f2e1: fwait
47f2e2: mov eax,ds:0x4b11f8
47f2e7: fild WORD PTR [eax]
47f2e9: xor eax,eax
47f2eb: mov al,bl
47f2ed: mov edx,0x3
47f2f2: sub edx,eax
47f2f4: imul eax,edx,0x16
47f2f7: fcomp QWORD PTR [esi+eax*8-0xa8]
47f2fe: fnstsw ax
47f300: sahf
47f301: jae 0x47f320
47f303: mov eax,ds:0x4b11f8
47f308: fild WORD PTR [eax]
47f30a: xor eax,eax
47f30c: mov al,bl
47f30e: mov edx,0x3
47f313: sub edx,eax
47f315: imul eax,edx,0x16
47f318: fstp QWORD PTR [esi+eax*8-0xa8]
47f31f: fwait
47f320: xor eax,eax
47f322: mov al,bl
47f324: imul eax,eax,0x16
47f327: cmp BYTE PTR [esi+eax*8-0x43],0x1
47f32c: jne 0x47f36f
47f32e: mov eax,0x2
47f333: call 0x402a1c
47f338: shl eax,0x3
47f33b: mov DWORD PTR [esp+0x4],eax
47f33f: fild DWORD PTR [esp+0x4]
47f343: xor eax,eax
47f345: mov al,bl
47f347: imul eax,eax,0x16
47f34a: fld QWORD PTR [esi+eax*8-0xb0]
47f351: fadd DWORD PTR ds:0x48dd10
47f357: faddp st(1),st
47f359: xor eax,eax
47f35b: mov al,bl
47f35d: mov edx,0x3
47f362: sub edx,eax
47f364: imul eax,edx,0x16
47f367: fstp QWORD PTR [esi+eax*8-0xb0]
47f36e: fwait
47f36f: xor eax,eax
47f371: mov al,bl
47f373: imul eax,eax,0x16
47f376: cmp BYTE PTR [esi+eax*8-0x43],0x2
47f37b: jne 0x47f3be
47f37d: mov eax,0x2
47f382: call 0x402a1c
47f387: shl eax,0x3
47f38a: mov DWORD PTR [esp+0x4],eax
47f38e: fild DWORD PTR [esp+0x4]
47f392: xor eax,eax
47f394: mov al,bl
47f396: imul eax,eax,0x16
47f399: fld QWORD PTR [esi+eax*8-0xb0]
47f3a0: fsub DWORD PTR ds:0x48dd10
47f3a6: fsubrp st(1),st
47f3a8: xor eax,eax
47f3aa: mov al,bl
47f3ac: mov edx,0x3
47f3b1: sub edx,eax
47f3b3: imul eax,edx,0x16
47f3b6: fstp QWORD PTR [esi+eax*8-0xb0]
47f3bd: fwait
47f3be: xor eax,eax
47f3c0: mov al,bl
47f3c2: imul eax,eax,0x16
47f3c5: inc BYTE PTR [esi+eax*8-0x1b]
47f3c9: xor eax,eax
47f3cb: mov al,bl
47f3cd: imul eax,eax,0x16
47f3d0: mov BYTE PTR [esi+eax*8-0x1a],0x14
47f3d5: mov eax,0x4
47f3da: call 0x402a1c
47f3df: test eax,eax
47f3e1: jne 0x47f3eb
47f3e3: mov eax,ds:0x4b1098
47f3e8: mov BYTE PTR [eax],0x7
47f3eb: mov eax,0x4
47f3f0: call 0x402a1c
47f3f5: test eax,eax
47f3f7: jne 0x47f401
47f3f9: mov eax,ds:0x4b1098
47f3fe: mov BYTE PTR [eax],0x8
47f401: mov eax,0x4
47f406: call 0x402a1c
47f40b: test eax,eax
47f40d: jne 0x47f417
47f40f: mov eax,ds:0x4b1098
47f414: mov BYTE PTR [eax],0x9
47f417: mov eax,0x14
47f41c: call 0x402a1c
47f421: mov DWORD PTR [esp+0x4],eax
47f425: fild DWORD PTR [esp+0x4]
47f429: xor eax,eax
47f42b: mov al,bl
47f42d: mov edx,0x3
47f432: sub edx,eax
47f434: imul eax,edx,0x16
47f437: fld QWORD PTR [esi+eax*8-0xb0]
47f43e: fsub DWORD PTR ds:0x48dd14
47f444: faddp st(1),st
47f446: add esp,0xfffffff8
47f449: fstp QWORD PTR [esp]
47f44c: fwait
47f44d: mov eax,0x78
47f452: call 0x402a1c
47f457: mov DWORD PTR [esp+0x10],eax
47f45b: fild DWORD PTR [esp+0x10]
47f45f: xor eax,eax
47f461: mov al,bl
47f463: mov edx,0x3
47f468: sub edx,eax
47f46a: imul eax,edx,0x16
47f46d: fld QWORD PTR [esi+eax*8-0xa8]
47f474: fsub DWORD PTR ds:0x48dd18
47f47a: faddp st(1),st
47f47c: add esp,0xfffffff8
47f47f: fstp QWORD PTR [esp]
47f482: fwait
47f483: xor ecx,ecx
47f485: xor edx,edx
47f487: mov al,0x1
47f489: call 0x476a04
47f48e: xor eax,eax
47f490: mov al,bl
47f492: imul eax,eax,0x16
47f495: movsx eax,WORD PTR [esi+eax*8-0x3c]
47f49a: xor edx,edx
47f49c: mov dl,bl
47f49e: imul edx,edx,0x16
47f4a1: movsx edx,WORD PTR [esi+edx*8-0x3a]
47f4a6: sub edx,0x2
47f4a9: cmp eax,edx
47f4ab: jle 0x47f517
47f4ad: xor eax,eax
47f4af: mov al,bl
47f4b1: imul eax,eax,0x16
47f4b4: mov BYTE PTR [esi+eax*8-0x40],0x14
47f4b9: xor eax,eax
47f4bb: mov al,bl
47f4bd: imul eax,eax,0x16
47f4c0: movzx eax,BYTE PTR [esi+eax*8-0x40]
47f4c5: mov DWORD PTR [esp+0x4],eax
47f4c9: fild DWORD PTR [esp+0x4]
47f4cd: mov eax,ds:0x4b11f4
47f4d2: fmul QWORD PTR [eax]
47f4d4: xor eax,eax
47f4d6: mov al,bl
47f4d8: mov edx,0x3
47f4dd: sub edx,eax
47f4df: imul eax,edx,0x16
47f4e2: fsubr QWORD PTR [esi+eax*8-0x70]
47f4e6: xor eax,eax
47f4e8: mov al,bl
47f4ea: mov edx,0x3
47f4ef: sub edx,eax
47f4f1: imul eax,edx,0x16
47f4f4: fstp QWORD PTR [esi+eax*8-0x70]
47f4f8: fwait
47f4f9: mov al,0x3
47f4fb: sub al,bl
47f4fd: mov dl,0xa
47f4ff: call 0x4775fc
47f504: xor eax,eax
47f506: mov al,bl
47f508: mov edx,0x3
47f50d: sub edx,eax
47f50f: imul eax,edx,0x16
47f512: mov BYTE PTR [esi+eax*8-0x3e],0x1e
47f517: xor eax,eax
47f519: mov al,bl
47f51b: imul eax,eax,0x16
47f51e: cmp BYTE PTR [esi+eax*8-0x45],0x1e
47f523: jne 0x47f546
47f525: xor eax,eax
47f527: mov al,bl
47f529: imul eax,eax,0x16
47f52c: cmp WORD PTR [esi+eax*8-0x3c],0x0
47f532: jne 0x47f546
47f534: xor eax,eax
47f536: mov al,bl
47f538: imul eax,eax,0x16
47f53b: mov dl,BYTE PTR [esp+0x1]
47f53f: add dl,0x2c
47f542: mov BYTE PTR [esi+eax*8-0x44],dl
47f546: xor eax,eax
47f548: mov al,bl
47f54a: imul eax,eax,0x16
47f54d: cmp BYTE PTR [esi+eax*8-0x45],0x1e
47f552: jne 0x47f61f
47f558: xor eax,eax
47f55a: mov al,bl
47f55c: imul eax,eax,0x16
47f55f: cmp WORD PTR [esi+eax*8-0x3c],0x2
47f565: jle 0x47f61f
47f56b: mov BYTE PTR [esp],0x8
47f56f: mov eax,0x28
47f574: call 0x402a1c
47f579: mov DWORD PTR [esp+0x4],eax
47f57d: fild DWORD PTR [esp+0x4]
47f581: xor eax,eax
47f583: mov al,bl
47f585: imul eax,eax,0x16
47f588: fld QWORD PTR [esi+eax*8-0xb0]
47f58f: fsub DWORD PTR ds:0x48dce4
47f595: faddp st(1),st
47f597: add esp,0xfffffff8
47f59a: fstp QWORD PTR [esp]
47f59d: fwait
47f59e: mov eax,0xa
47f5a3: call 0x402a1c
47f5a8: mov DWORD PTR [esp+0x10],eax
47f5ac: fild DWORD PTR [esp+0x10]
47f5b0: xor eax,eax
47f5b2: mov al,bl
47f5b4: imul eax,eax,0x16
47f5b7: fadd QWORD PTR [esi+eax*8-0xa8]
47f5be: add esp,0xfffffff8
47f5c1: fstp QWORD PTR [esp]
47f5c4: fwait
47f5c5: xor ecx,ecx
47f5c7: xor edx,edx
47f5c9: mov al,0x2
47f5cb: call 0x476a04
47f5d0: dec BYTE PTR [esp]
47f5d3: jne 0x47f56f
47f5d5: xor eax,eax
47f5d7: mov al,bl
47f5d9: imul eax,eax,0x16
47f5dc: mov dl,BYTE PTR [esp+0x1]
47f5e0: add dl,0x2d
47f5e3: mov BYTE PTR [esi+eax*8-0x44],dl
47f5e7: xor eax,eax
47f5e9: mov al,bl
47f5eb: imul eax,eax,0x16
47f5ee: cmp BYTE PTR [esi+eax*8-0x43],0x1
47f5f3: jne 0x47f603
47f5f5: push 0x40370000
47f5fa: push 0x0
47f5fc: mov eax,ebx
47f5fe: call 0x47648c
47f603: xor eax,eax
47f605: mov al,bl
47f607: imul eax,eax,0x16
47f60a: cmp BYTE PTR [esi+eax*8-0x43],0x2
47f60f: jne 0x47f61f
47f611: push 0xc0370000
47f616: push 0x0
47f618: mov eax,ebx
47f61a: call 0x47648c
47f61f: xor eax,eax
47f621: mov al,bl
47f623: imul eax,eax,0x16
47f626: cmp BYTE PTR [esi+eax*8-0x45],0x1f
47f62b: jne 0x47fa58
47f631: xor eax,eax
47f633: mov al,bl
47f635: imul eax,eax,0x16
47f638: mov BYTE PTR [esi+eax*8-0x3e],0x0
47f63d: mov eax,0x2d
47f642: call 0x402a1c
47f647: inc eax
47f648: add al,BYTE PTR [esp+0x1]
47f64c: xor edx,edx
47f64e: mov dl,bl
47f650: imul edx,edx,0x16
47f653: mov BYTE PTR [esi+edx*8-0x44],al
47f657: mov eax,ds:0x4b0d98
47f65c: cmp BYTE PTR [eax],0x1
47f65f: jne 0x47f677
47f661: mov eax,0x5
47f666: call 0x402a1c
47f66b: test eax,eax
47f66d: jne 0x47f677
47f66f: mov eax,ds:0x4b0fc8
47f674: mov BYTE PTR [eax],0x3
47f677: xor eax,eax
47f679: mov al,bl
47f67b: imul eax,eax,0x16
47f67e: cmp BYTE PTR [esi+eax*8-0x43],0x1
47f683: jne 0x47f693
47f685: push 0x40080000
47f68a: push 0x0
47f68c: mov eax,ebx
47f68e: call 0x47648c
47f693: xor eax,eax
47f695: mov al,bl
47f697: imul eax,eax,0x16
47f69a: cmp BYTE PTR [esi+eax*8-0x43],0x2
47f69f: jne 0x47f6af
47f6a1: push 0xc0080000
47f6a6: push 0x0
47f6a8: mov eax,ebx
47f6aa: call 0x47648c
47f6af: mov eax,0x2
47f6b4: call 0x402a1c
47f6b9: add al,0x1a
47f6bb: mov dl,0x32
47f6bd: sub dl,BYTE PTR [esp+0x1]
47f6c1: add al,dl
47f6c3: xor edx,edx
47f6c5: mov dl,bl
47f6c7: mov ecx,0x3
47f6cc: sub ecx,edx
47f6ce: imul edx,ecx,0x16
47f6d1: mov BYTE PTR [esi+edx*8-0x44],al
47f6d5: xor eax,eax
47f6d7: mov al,bl
47f6d9: mov edx,0x3
47f6de: sub edx,eax
47f6e0: imul eax,edx,0x16
47f6e3: mov WORD PTR [esi+eax*8-0x3c],0x0
47f6ea: xor eax,eax
47f6ec: mov al,bl
47f6ee: mov edx,0x3
47f6f3: sub edx,eax
47f6f5: imul eax,edx,0x16
47f6f8: mov WORD PTR [esi+eax*8-0x3a],0x5
47f6ff: xor eax,eax
47f701: mov al,bl
47f703: mov edx,0x3
47f708: sub edx,eax
47f70a: imul eax,edx,0x16
47f70d: mov BYTE PTR [esi+eax*8-0x38],0x0
47f712: xor eax,eax
47f714: mov al,bl
47f716: mov edx,0x3
47f71b: sub edx,eax
47f71d: imul eax,edx,0x16
47f720: fld QWORD PTR [esi+eax*8-0xa8]
47f727: fadd DWORD PTR ds:0x48dcc0
47f72d: xor eax,eax
47f72f: mov al,bl
47f731: mov edx,0x3
47f736: sub edx,eax
47f738: imul eax,edx,0x16
47f73b: fstp QWORD PTR [esi+eax*8-0xa8]
47f742: fwait
47f743: mov eax,ds:0x4b11f8
47f748: fild WORD PTR [eax]
47f74a: xor eax,eax
47f74c: mov al,bl
47f74e: mov edx,0x3
47f753: sub edx,eax
47f755: imul eax,edx,0x16
47f758: fcomp QWORD PTR [esi+eax*8-0xa8]
47f75f: fnstsw ax
47f761: sahf
47f762: jae 0x47f781
47f764: mov eax,ds:0x4b11f8
47f769: fild WORD PTR [eax]
47f76b: xor eax,eax
47f76d: mov al,bl
47f76f: mov edx,0x3
47f774: sub edx,eax
47f776: imul eax,edx,0x16
47f779: fstp QWORD PTR [esi+eax*8-0xa8]
47f780: fwait
47f781: xor eax,eax
47f783: mov al,bl
47f785: imul eax,eax,0x16
47f788: cmp BYTE PTR [esi+eax*8-0x43],0x1
47f78d: jne 0x47f7d0
47f78f: mov eax,0x2
47f794: call 0x402a1c
47f799: shl eax,0x3
47f79c: mov DWORD PTR [esp+0x4],eax
47f7a0: fild DWORD PTR [esp+0x4]
47f7a4: xor eax,eax
47f7a6: mov al,bl
47f7a8: imul eax,eax,0x16
47f7ab: fld QWORD PTR [esi+eax*8-0xb0]
47f7b2: fadd DWORD PTR ds:0x48dd10
47f7b8: faddp st(1),st
47f7ba: xor eax,eax
47f7bc: mov al,bl
47f7be: mov edx,0x3
47f7c3: sub edx,eax
47f7c5: imul eax,edx,0x16
47f7c8: fstp QWORD PTR [esi+eax*8-0xb0]
47f7cf: fwait
47f7d0: xor eax,eax
47f7d2: mov al,bl
47f7d4: imul eax,eax,0x16
47f7d7: cmp BYTE PTR [esi+eax*8-0x43],0x2
47f7dc: jne 0x47f81f
47f7de: mov eax,0x2
47f7e3: call 0x402a1c
47f7e8: shl eax,0x3
47f7eb: mov DWORD PTR [esp+0x4],eax
47f7ef: fild DWORD PTR [esp+0x4]
47f7f3: xor eax,eax
47f7f5: mov al,bl
47f7f7: imul eax,eax,0x16
47f7fa: fld QWORD PTR [esi+eax*8-0xb0]
47f801: fsub DWORD PTR ds:0x48dd10
47f807: fsubrp st(1),st
47f809: xor eax,eax
47f80b: mov al,bl
47f80d: mov edx,0x3
47f812: sub edx,eax
47f814: imul eax,edx,0x16
47f817: fstp QWORD PTR [esi+eax*8-0xb0]
47f81e: fwait
47f81f: xor eax,eax
47f821: mov al,bl
47f823: imul eax,eax,0x16
47f826: add BYTE PTR [esi+eax*8-0x1b],0x2
47f82b: xor eax,eax
47f82d: mov al,bl
47f82f: imul eax,eax,0x16
47f832: mov BYTE PTR [esi+eax*8-0x1a],0x2b
47f837: mov eax,0x1e
47f83c: call 0x402a1c
47f841: test eax,eax
47f843: jne 0x47f86a
47f845: xor eax,eax
47f847: mov al,bl
47f849: mov edx,0x3
47f84e: sub edx,eax
47f850: imul eax,edx,0x16
47f853: fld QWORD PTR [esi+eax*8-0x70]
47f857: fcomp DWORD PTR ds:0x48dcc4
47f85d: fnstsw ax
47f85f: sahf
47f860: jbe 0x47f86a
47f862: mov eax,ds:0x4b0e84
47f867: mov BYTE PTR [eax],0x5
47f86a: mov eax,0x4
47f86f: call 0x402a1c
47f874: test eax,eax
47f876: jne 0x47f880
47f878: mov eax,ds:0x4b1098
47f87d: mov BYTE PTR [eax],0x7
47f880: mov eax,0x4
47f885: call 0x402a1c
47f88a: test eax,eax
47f88c: jne 0x47f896
47f88e: mov eax,ds:0x4b1098
47f893: mov BYTE PTR [eax],0x8
47f896: mov eax,0x4
47f89b: call 0x402a1c
47f8a0: test eax,eax
47f8a2: jne 0x47f8ac
47f8a4: mov eax,ds:0x4b1098
47f8a9: mov BYTE PTR [eax],0x9
47f8ac: mov eax,0x14
47f8b1: call 0x402a1c
47f8b6: mov DWORD PTR [esp+0x4],eax
47f8ba: fild DWORD PTR [esp+0x4]
47f8be: xor eax,eax
47f8c0: mov al,bl
47f8c2: mov edx,0x3
47f8c7: sub edx,eax
47f8c9: imul eax,edx,0x16
47f8cc: fld QWORD PTR [esi+eax*8-0xb0]
47f8d3: fsub DWORD PTR ds:0x48dcc0
47f8d9: faddp st(1),st
47f8db: add esp,0xfffffff8
47f8de: fstp QWORD PTR [esp]
47f8e1: fwait
47f8e2: mov eax,0x64
47f8e7: call 0x402a1c
47f8ec: mov DWORD PTR [esp+0x10],eax
47f8f0: fild DWORD PTR [esp+0x10]
47f8f4: xor eax,eax
47f8f6: mov al,bl
47f8f8: mov edx,0x3
47f8fd: sub edx,eax
47f8ff: imul eax,edx,0x16
47f902: fld QWORD PTR [esi+eax*8-0xa8]
47f909: fsub DWORD PTR ds:0x48dd1c
47f90f: faddp st(1),st
47f911: add esp,0xfffffff8
47f914: fstp QWORD PTR [esp]
47f917: fwait
47f918: xor ecx,ecx
47f91a: xor edx,edx
47f91c: mov al,0x1
47f91e: call 0x476a04
47f923: xor eax,eax
47f925: mov al,bl
47f927: imul eax,eax,0x16
47f92a: movsx eax,WORD PTR [esi+eax*8-0x3c]
47f92f: xor edx,edx
47f931: mov dl,bl
47f933: imul edx,edx,0x16
47f936: movsx edx,WORD PTR [esi+edx*8-0x3a]
47f93b: sub edx,0x2
47f93e: cmp eax,edx
47f940: jle 0x47fa58
47f946: xor eax,eax
47f948: mov al,bl
47f94a: imul eax,eax,0x16
47f94d: mov BYTE PTR [esi+eax*8-0x40],0x2f
47f952: xor eax,eax
47f954: mov al,bl
47f956: imul eax,eax,0x16
47f959: movzx eax,BYTE PTR [esi+eax*8-0x40]
47f95e: mov DWORD PTR [esp+0x4],eax
47f962: fild DWORD PTR [esp+0x4]
47f966: mov eax,ds:0x4b11f4
47f96b: fmul QWORD PTR [eax]
47f96d: xor eax,eax
47f96f: mov al,bl
47f971: mov edx,0x3
47f976: sub edx,eax
47f978: imul eax,edx,0x16
47f97b: fsubr QWORD PTR [esi+eax*8-0x70]
47f97f: xor eax,eax
47f981: mov al,bl
47f983: mov edx,0x3
47f988: sub edx,eax
47f98a: imul eax,edx,0x16
47f98d: fstp QWORD PTR [esi+eax*8-0x70]
47f991: fwait
47f992: xor eax,eax
47f994: mov al,bl
47f996: imul eax,eax,0x16
47f999: mov BYTE PTR [esi+eax*8-0x45],0x1
47f99e: xor eax,eax
47f9a0: mov al,bl
47f9a2: imul eax,eax,0x16
47f9a5: mov dl,BYTE PTR [esp+0x1]
47f9a9: add dl,0x26
47f9ac: mov BYTE PTR [esi+eax*8-0x44],dl
47f9b0: mov eax,ds:0x4b0e84
47f9b5: mov BYTE PTR [eax],0x5
47f9b8: mov dl,0x13
47f9ba: mov eax,ebx
47f9bc: call 0x4775fc
47f9c1: mov al,0x3
47f9c3: sub al,bl
47f9c5: mov dl,0xa
47f9c7: call 0x4775fc
47f9cc: xor eax,eax
47f9ce: mov al,bl
47f9d0: imul eax,eax,0x16
47f9d3: mov BYTE PTR [esi+eax*8-0x48],0x0
47f9d8: xor eax,eax
47f9da: mov al,bl
47f9dc: mov edx,0x3
47f9e1: sub edx,eax
47f9e3: imul eax,edx,0x16
47f9e6: mov BYTE PTR [esi+eax*8-0x3e],0x1c
47f9eb: xor eax,eax
47f9ed: mov al,bl
47f9ef: mov edx,0x3
47f9f4: sub edx,eax
47f9f6: imul eax,edx,0x16
47f9f9: mov BYTE PTR [esi+eax*8-0x38],0xe2
47f9fe: xor eax,eax
47fa00: mov al,bl
47fa02: mov edx,0x3
47fa07: sub edx,eax
47fa09: imul eax,edx,0x16
47fa0c: cmp BYTE PTR [esi+eax*8-0x43],0x1
47fa11: jne 0x47fa2b
47fa13: xor eax,eax
47fa15: mov al,bl
47fa17: mov edx,0x3
47fa1c: sub edx,eax
47fa1e: imul eax,edx,0x16
47fa21: mov WORD PTR [esi+eax*8-0x98],0xffe7
47fa2b: xor eax,eax
47fa2d: mov al,bl
47fa2f: mov edx,0x3
47fa34: sub edx,eax
47fa36: imul eax,edx,0x16
47fa39: cmp BYTE PTR [esi+eax*8-0x43],0x2
47fa3e: jne 0x47fa58
47fa40: xor eax,eax
47fa42: mov al,bl
47fa44: mov edx,0x3
47fa49: sub edx,eax
47fa4b: imul eax,edx,0x16
47fa4e: mov WORD PTR [esi+eax*8-0x98],0x19
47fa58: push 0x1e
47fa5a: push 0xd
47fa5c: push 0xaa
47fa61: xor edx,edx
47fa63: mov dl,BYTE PTR [esp+0xd]
47fa67: inc edx
47fa68: xor eax,eax
47fa6a: mov al,bl
47fa6c: mov ecx,0xffffffee
47fa71: call 0x476870
47fa76: push 0x1e
47fa78: push 0x14
47fa7a: push 0xaa
47fa7f: xor edx,edx
47fa81: mov dl,BYTE PTR [esp+0xd]
47fa85: add edx,0x2
47fa88: xor eax,eax
47fa8a: mov al,bl
47fa8c: mov ecx,0xfffffff4
47fa91: call 0x476870
47fa96: push 0x1e
47fa98: push 0x14
47fa9a: push 0xaa
47fa9f: xor edx,edx
47faa1: mov dl,BYTE PTR [esp+0xd]
47faa5: add edx,0x3
47faa8: xor eax,eax
47faaa: mov al,bl
47faac: mov ecx,0xfffffff4
47fab1: call 0x476870
47fab6: push 0x1e
47fab8: push 0x14
47faba: push 0xaa
47fabf: xor edx,edx
47fac1: mov dl,BYTE PTR [esp+0xd]
47fac5: add edx,0x4
47fac8: xor eax,eax
47faca: mov al,bl
47facc: mov ecx,0xfffffff4
47fad1: call 0x476870
47fad6: push 0x1e
47fad8: push 0x14
47fada: push 0xaa
47fadf: xor edx,edx
47fae1: mov dl,BYTE PTR [esp+0xd]
47fae5: add edx,0x6
47fae8: xor eax,eax
47faea: mov al,bl
47faec: mov ecx,0xfffffff4
47faf1: call 0x476870
47faf6: push 0x1e
47faf8: push 0x14
47fafa: push 0xaa
47faff: xor edx,edx
47fb01: mov dl,BYTE PTR [esp+0xd]
47fb05: add edx,0x8
47fb08: xor eax,eax
47fb0a: mov al,bl
47fb0c: mov ecx,0xfffffff4
47fb11: call 0x476870
47fb16: push 0x1e
47fb18: push 0x14
47fb1a: push 0xaa
47fb1f: xor edx,edx
47fb21: mov dl,BYTE PTR [esp+0xd]
47fb25: add edx,0xa
47fb28: xor eax,eax
47fb2a: mov al,bl
47fb2c: mov ecx,0xfffffff4
47fb31: call 0x476870
47fb36: push 0x46
47fb38: push 0x14
47fb3a: push 0xaa
47fb3f: xor edx,edx
47fb41: mov dl,BYTE PTR [esp+0xd]
47fb45: add edx,0xc
47fb48: xor eax,eax
47fb4a: mov al,bl
47fb4c: mov ecx,0xfffffff4
47fb51: call 0x476870
47fb56: push 0x46
47fb58: push 0x14
47fb5a: push 0xaa
47fb5f: xor edx,edx
47fb61: mov dl,BYTE PTR [esp+0xd]
47fb65: add edx,0xd
47fb68: xor eax,eax
47fb6a: mov al,bl
47fb6c: mov ecx,0xfffffff4
47fb71: call 0x476870
47fb76: push 0x46
47fb78: push 0x14
47fb7a: push 0xaa
47fb7f: xor edx,edx
47fb81: mov dl,BYTE PTR [esp+0xd]
47fb85: add edx,0xf
47fb88: xor eax,eax
47fb8a: mov al,bl
47fb8c: mov ecx,0xfffffff4
47fb91: call 0x476870
47fb96: push 0x46
47fb98: push 0x14
47fb9a: push 0xaa
47fb9f: xor edx,edx
47fba1: mov dl,BYTE PTR [esp+0xd]
47fba5: add edx,0x11
47fba8: xor eax,eax
47fbaa: mov al,bl
47fbac: mov ecx,0xfffffff4
47fbb1: call 0x476870
47fbb6: push 0x46
47fbb8: push 0x14
47fbba: push 0xaa
47fbbf: xor edx,edx
47fbc1: mov dl,BYTE PTR [esp+0xd]
47fbc5: add edx,0x13
47fbc8: xor eax,eax
47fbca: mov al,bl
47fbcc: mov ecx,0xfffffff4
47fbd1: call 0x476870
47fbd6: push 0x28
47fbd8: push 0x14
47fbda: push 0x8c
47fbdf: xor edx,edx
47fbe1: mov dl,BYTE PTR [esp+0xd]
47fbe5: add edx,0x15
47fbe8: xor eax,eax
47fbea: mov al,bl
47fbec: mov ecx,0xfffffff4
47fbf1: call 0x476870
47fbf6: push 0x3c
47fbf8: push 0x1e
47fbfa: push 0x6e
47fbfc: xor edx,edx
47fbfe: mov dl,BYTE PTR [esp+0xd]
47fc02: add edx,0x1c
47fc05: xor eax,eax
47fc07: mov al,bl
47fc09: mov ecx,0xffffffea
47fc0e: call 0x476870
47fc13: push 0x73
47fc15: push 0x1e
47fc17: push 0xaa
47fc1c: xor edx,edx
47fc1e: mov dl,BYTE PTR [esp+0xd]
47fc22: add edx,0x1d
47fc25: xor eax,eax
47fc27: mov al,bl
47fc29: mov ecx,0xffffffea
47fc2e: call 0x476870
47fc33: push 0x28
47fc35: push 0x14
47fc37: push 0xaa
47fc3c: xor edx,edx
47fc3e: mov dl,BYTE PTR [esp+0xd]
47fc42: add edx,0x1f
47fc45: xor eax,eax
47fc47: mov al,bl
47fc49: mov ecx,0xfffffff4
47fc4e: call 0x476870
47fc53: push 0x46
47fc55: push 0x14
47fc57: push 0xaa
47fc5c: xor edx,edx
47fc5e: mov dl,BYTE PTR [esp+0xd]
47fc62: add edx,0x20
47fc65: xor eax,eax
47fc67: mov al,bl
47fc69: mov ecx,0xfffffff4
47fc6e: call 0x476870
47fc73: push 0x1e
47fc75: push 0x14
47fc77: push 0xaa
47fc7c: xor edx,edx
47fc7e: mov dl,BYTE PTR [esp+0xd]
47fc82: add edx,0x23
47fc85: xor eax,eax
47fc87: mov al,bl
47fc89: mov ecx,0xfffffff4
47fc8e: call 0x476870
47fc93: push 0x28
47fc95: push 0xf
47fc97: push 0x8c
47fc9c: xor edx,edx
47fc9e: mov dl,BYTE PTR [esp+0xd]
47fca2: add edx,0x27
47fca5: xor eax,eax
47fca7: mov al,bl
47fca9: mov ecx,0xfffffff4
47fcae: call 0x476870
47fcb3: push 0x1e
47fcb5: push 0xd
47fcb7: push 0xaa
47fcbc: xor edx,edx
47fcbe: mov dl,BYTE PTR [esp+0xd]
47fcc2: add edx,0x29
47fcc5: xor eax,eax
47fcc7: mov al,bl
47fcc9: mov ecx,0xffffffee
47fcce: call 0x476870
47fcd3: push 0x28
47fcd5: push 0x28
47fcd7: push 0xaa
47fcdc: xor edx,edx
47fcde: mov dl,BYTE PTR [esp+0xd]
47fce2: add edx,0x2d
47fce5: xor eax,eax
47fce7: mov al,bl
47fce9: mov ecx,0xfffffff4
47fcee: call 0x476870
47fcf3: push 0x14
47fcf5: push 0x32
47fcf7: push 0x43
47fcf9: push 0x3c
47fcfb: push 0x1
47fcfd: push 0x1
47fcff: push 0x7
47fd01: push 0x0
47fd03: xor eax,eax
47fd05: mov al,bl
47fd07: mov ecx,0x2
47fd0c: mov edx,0x3
47fd11: call 0x4768f8
47fd16: push 0x19
47fd18: push 0x5f
47fd1a: push 0x46
47fd1c: push 0x85
47fd21: push 0x1
47fd23: push 0x1
47fd25: push 0x7
47fd27: push 0x0
47fd29: xor eax,eax
47fd2b: mov al,bl
47fd2d: mov ecx,0x2
47fd32: mov edx,0x4
47fd37: call 0x4768f8
47fd3c: push 0x5
47fd3e: push 0x5
47fd40: push 0x44
47fd42: push 0x3a
47fd44: push 0x1
47fd46: push 0x2
47fd48: push 0xe
47fd4a: push 0x0
47fd4c: xor eax,eax
47fd4e: mov al,bl
47fd50: mov ecx,0x5
47fd55: mov edx,0x5
47fd5a: call 0x4768f8
47fd5f: push 0x12
47fd61: push 0x37
47fd63: push 0x5c
47fd65: push 0x5a
47fd67: push 0x1
47fd69: push 0x2
47fd6b: push 0xe
47fd6d: push 0x0
47fd6f: xor eax,eax
47fd71: mov al,bl
47fd73: mov ecx,0x5
47fd78: mov edx,0x6
47fd7d: call 0x4768f8
47fd82: push 0x14
47fd84: push 0x52
47fd86: push 0x43
47fd88: push 0x5e
47fd8a: push 0x1
47fd8c: push 0x1
47fd8e: push 0x7
47fd90: push 0x0
47fd92: xor eax,eax
47fd94: mov al,bl
47fd96: mov ecx,0x2
47fd9b: mov edx,0x8
47fda0: call 0x4768f8
47fda5: push 0x14
47fda7: push 0x91
47fdac: push 0x46
47fdae: push 0xa5
47fdb3: push 0x1
47fdb5: push 0x1
47fdb7: push 0x7
47fdb9: push 0x0
47fdbb: xor eax,eax
47fdbd: mov al,bl
47fdbf: mov ecx,0x2
47fdc4: mov edx,0x9
47fdc9: call 0x4768f8
47fdce: push 0xf
47fdd0: push 0x23
47fdd2: push 0x2d
47fdd4: push 0x5c
47fdd6: push 0x1
47fdd8: push 0x2
47fdda: push 0xe
47fddc: push 0x0
47fdde: xor eax,eax
47fde0: mov al,bl
47fde2: mov ecx,0x5
47fde7: mov edx,0xa
47fdec: call 0x4768f8
47fdf1: push 0x1e
47fdf3: push 0x73
47fdf5: push 0x5a
47fdf7: push 0x8a
47fdfc: push 0x1
47fdfe: push 0x2
47fe00: push 0xe
47fe02: push 0x0
47fe04: xor eax,eax
47fe06: mov al,bl
47fe08: mov ecx,0x5
47fe0d: mov edx,0xb
47fe12: call 0x4768f8
47fe17: push 0x32
47fe19: push 0x28
47fe1b: push 0x55
47fe1d: push 0x4e
47fe1f: push 0x1
47fe21: push 0x1
47fe23: push 0x7
47fe25: push 0x0
47fe27: xor eax,eax
47fe29: mov al,bl
47fe2b: mov ecx,0x2
47fe30: mov edx,0xd
47fe35: call 0x4768f8
47fe3a: push 0x0
47fe3c: push 0x73
47fe3e: push 0x37
47fe40: push 0x91
47fe45: push 0x1
47fe47: push 0x1
47fe49: push 0x7
47fe4b: push 0x0
47fe4d: xor eax,eax
47fe4f: mov al,bl
47fe51: mov ecx,0x2
47fe56: mov edx,0xe
47fe5b: call 0x4768f8
47fe60: push 0x32
47fe62: push 0x28
47fe64: push 0x55
47fe66: push 0x4e
47fe68: push 0x1
47fe6a: push 0x1
47fe6c: push 0xe
47fe6e: push 0x0
47fe70: xor eax,eax
47fe72: mov al,bl
47fe74: mov ecx,0x5
47fe79: mov edx,0xf
47fe7e: call 0x4768f8
47fe83: push 0x0
47fe85: push 0x73
47fe87: push 0x37
47fe89: push 0x91
47fe8e: push 0x1
47fe90: push 0x2
47fe92: push 0xe
47fe94: push 0x0
47fe96: xor eax,eax
47fe98: mov al,bl
47fe9a: mov ecx,0x5
47fe9f: mov edx,0x10
47fea4: call 0x4768f8
47fea9: xor eax,eax
47feab: mov al,bl
47fead: imul eax,eax,0x16
47feb0: cmp BYTE PTR [esi+eax*8-0x41],0x2
47feb5: jne 0x47feda
47feb7: push 0xa
47feb9: push 0xfffffffb
47febb: push 0x32
47febd: push 0x5a
47febf: push 0x1
47fec1: push 0x0
47fec3: push 0x3
47fec5: push 0x1
47fec7: xor eax,eax
47fec9: mov al,bl
47fecb: mov ecx,0x3
47fed0: mov edx,0x1a
47fed5: call 0x4768f8
47feda: push 0xa
47fedc: push 0xfffffffb
47fede: push 0x32
47fee0: push 0x5a
47fee2: push 0x1
47fee4: push 0x0
47fee6: push 0x12
47fee8: push 0x4
47feea: xor eax,eax
47feec: mov al,bl
47feee: mov ecx,0x5
47fef3: mov edx,0x1a
47fef8: call 0x4768f8
47fefd: push 0x0
47feff: push 0x0
47ff01: push 0x0
47ff03: push 0x0
47ff05: push 0x0
47ff07: push 0x0
47ff09: push 0x0
47ff0b: push 0x0
47ff0d: xor eax,eax
47ff0f: mov al,bl
47ff11: mov ecx,0x9
47ff16: mov edx,0x1a
47ff1b: call 0x4768f8
47ff20: push 0x0
47ff22: push 0x73
47ff24: push 0x37
47ff26: push 0x91
47ff2b: push 0x1
47ff2d: push 0x0
47ff2f: push 0x12
47ff31: push 0x2
47ff33: xor eax,eax
47ff35: mov al,bl
47ff37: mov ecx,0x3
47ff3c: mov edx,0x1b
47ff41: call 0x4768f8
47ff46: push 0x14
47ff48: push 0x28
47ff4a: push 0x3c
47ff4c: push 0xa0
47ff51: push 0x1
47ff53: push 0x0
47ff55: push 0x0
47ff57: push 0x2
47ff59: xor eax,eax
47ff5b: mov al,bl
47ff5d: mov ecx,0x1
47ff62: mov edx,0x1c
47ff67: call 0x4768f8
47ff6c: push 0x14
47ff6e: push 0x28
47ff70: push 0x3c
47ff72: push 0xa0
47ff77: push 0x1
47ff79: push 0x0
47ff7b: push 0x0
47ff7d: push 0x1
47ff7f: xor eax,eax
47ff81: mov al,bl
47ff83: mov ecx,0x5
47ff88: mov edx,0x1c
47ff8d: call 0x4768f8
47ff92: push 0x14
47ff94: push 0x28
47ff96: push 0x3c
47ff98: push 0xa0
47ff9d: push 0x1
47ff9f: push 0x0
47ffa1: push 0x0
47ffa3: push 0x1
47ffa5: xor eax,eax
47ffa7: mov al,bl
47ffa9: mov ecx,0x9
47ffae: mov edx,0x1c
47ffb3: call 0x4768f8
47ffb8: push 0x14
47ffba: push 0x28
47ffbc: push 0x3c
47ffbe: push 0xa0
47ffc3: push 0x1
47ffc5: push 0x0
47ffc7: push 0x0
47ffc9: push 0x2
47ffcb: xor eax,eax
47ffcd: mov al,bl
47ffcf: mov ecx,0xd
47ffd4: mov edx,0x1c
47ffd9: call 0x4768f8
47ffde: push 0x14
47ffe0: push 0x50
47ffe2: push 0x3c
47ffe4: push 0xa0
47ffe9: push 0x1
47ffeb: push 0x0
47ffed: push 0x0
47ffef: push 0x0
47fff1: xor eax,eax
47fff3: mov al,bl
47fff5: mov ecx,0x3
47fffa: mov edx,0x1e
47ffff: call 0x4768f8
480004: xor eax,eax
480006: mov al,bl
480008: imul eax,eax,0x16
48000b: cmp BYTE PTR [esi+eax*8-0xa0],0x3
480013: jne 0x48137b
480019: xor eax,eax
48001b: mov al,bl
48001d: imul eax,eax,0x16
480020: cmp BYTE PTR [esi+eax*8-0x45],0x17
480025: jne 0x480048
480027: xor eax,eax
480029: mov al,bl
48002b: imul eax,eax,0x16
48002e: cmp WORD PTR [esi+eax*8-0x3c],0x5
480034: jge 0x480048
480036: xor eax,eax
480038: mov al,bl
48003a: imul eax,eax,0x16
48003d: mov dl,BYTE PTR [esp+0x1]
480041: add dl,0x21
480044: mov BYTE PTR [esi+eax*8-0x44],dl
480048: xor eax,eax
48004a: mov al,bl
48004c: imul eax,eax,0x16
48004f: cmp BYTE PTR [esi+eax*8-0x45],0x17
480054: jne 0x480077
480056: xor eax,eax
480058: mov al,bl
48005a: imul eax,eax,0x16
48005d: cmp WORD PTR [esi+eax*8-0x3c],0x5
480063: jne 0x480077
480065: xor eax,eax
480067: mov al,bl
480069: imul eax,eax,0x16
48006c: mov dl,BYTE PTR [esp+0x1]
480070: add dl,0x22
480073: mov BYTE PTR [esi+eax*8-0x44],dl
480077: xor eax,eax
480079: mov al,bl
48007b: imul eax,eax,0x16
48007e: cmp BYTE PTR [esi+eax*8-0x45],0x17
480083: jne 0x4800a6
480085: xor eax,eax
480087: mov al,bl
480089: imul eax,eax,0x16
48008c: cmp WORD PTR [esi+eax*8-0x3c],0xa
480092: jne 0x4800a6
480094: xor eax,eax
480096: mov al,bl
480098: imul eax,eax,0x16
48009b: mov dl,BYTE PTR [esp+0x1]
48009f: add dl,0x23
4800a2: mov BYTE PTR [esi+eax*8-0x44],dl
4800a6: xor eax,eax
4800a8: mov al,bl
4800aa: imul eax,eax,0x16
4800ad: cmp BYTE PTR [esi+eax*8-0x45],0x17
4800b2: jne 0x4800d5
4800b4: xor eax,eax
4800b6: mov al,bl
4800b8: imul eax,eax,0x16
4800bb: cmp WORD PTR [esi+eax*8-0x3c],0xf
4800c1: jne 0x4800d5
4800c3: xor eax,eax
4800c5: mov al,bl
4800c7: imul eax,eax,0x16
4800ca: mov dl,BYTE PTR [esp+0x1]
4800ce: add dl,0x22
4800d1: mov BYTE PTR [esi+eax*8-0x44],dl
4800d5: xor eax,eax
4800d7: mov al,bl
4800d9: imul eax,eax,0x16
4800dc: cmp BYTE PTR [esi+eax*8-0x45],0x17
4800e1: jne 0x480104
4800e3: xor eax,eax
4800e5: mov al,bl
4800e7: imul eax,eax,0x16
4800ea: cmp WORD PTR [esi+eax*8-0x3c],0x14
4800f0: jne 0x480104
4800f2: xor eax,eax
4800f4: mov al,bl
4800f6: imul eax,eax,0x16
4800f9: mov dl,BYTE PTR [esp+0x1]
4800fd: add dl,0x21
480100: mov BYTE PTR [esi+eax*8-0x44],dl
480104: xor eax,eax
480106: mov al,bl
480108: imul eax,eax,0x16
48010b: cmp BYTE PTR [esi+eax*8-0x45],0x17
480110: jne 0x480133
480112: xor eax,eax
480114: mov al,bl
480116: imul eax,eax,0x16
480119: cmp WORD PTR [esi+eax*8-0x3c],0x19
48011f: jne 0x480133
480121: xor eax,eax
480123: mov al,bl
480125: imul eax,eax,0x16
480128: mov dl,BYTE PTR [esp+0x1]
48012c: add dl,0x22
48012f: mov BYTE PTR [esi+eax*8-0x44],dl
480133: xor eax,eax
480135: mov al,bl
480137: imul eax,eax,0x16
48013a: cmp BYTE PTR [esi+eax*8-0x45],0x17
48013f: jne 0x480162
480141: xor eax,eax
480143: mov al,bl
480145: imul eax,eax,0x16
480148: cmp WORD PTR [esi+eax*8-0x3c],0x1e
48014e: jne 0x480162
480150: xor eax,eax
480152: mov al,bl
480154: imul eax,eax,0x16
480157: mov dl,BYTE PTR [esp+0x1]
48015b: add dl,0x23
48015e: mov BYTE PTR [esi+eax*8-0x44],dl
480162: xor eax,eax
480164: mov al,bl
480166: imul eax,eax,0x16
480169: cmp BYTE PTR [esi+eax*8-0x45],0x17
48016e: jne 0x480191
480170: xor eax,eax
480172: mov al,bl
480174: imul eax,eax,0x16
480177: cmp WORD PTR [esi+eax*8-0x3c],0x23
48017d: jne 0x480191
48017f: xor eax,eax
480181: mov al,bl
480183: imul eax,eax,0x16
480186: mov dl,BYTE PTR [esp+0x1]
48018a: add dl,0x22
48018d: mov BYTE PTR [esi+eax*8-0x44],dl
480191: xor eax,eax
480193: mov al,bl
480195: imul eax,eax,0x16
480198: cmp BYTE PTR [esi+eax*8-0x45],0x18
48019d: jne 0x4801c0
48019f: xor eax,eax
4801a1: mov al,bl
4801a3: imul eax,eax,0x16
4801a6: cmp WORD PTR [esi+eax*8-0x3c],0x0
4801ac: jne 0x4801c0
4801ae: xor eax,eax
4801b0: mov al,bl
4801b2: imul eax,eax,0x16
4801b5: mov dl,BYTE PTR [esp+0x1]
4801b9: add dl,0xc
4801bc: mov BYTE PTR [esi+eax*8-0x44],dl
4801c0: xor eax,eax
4801c2: mov al,bl
4801c4: imul eax,eax,0x16
4801c7: cmp BYTE PTR [esi+eax*8-0x45],0x18
4801cc: jne 0x4801ef
4801ce: xor eax,eax
4801d0: mov al,bl
4801d2: imul eax,eax,0x16
4801d5: cmp WORD PTR [esi+eax*8-0x3c],0x2
4801db: jne 0x4801ef
4801dd: xor eax,eax
4801df: mov al,bl
4801e1: imul eax,eax,0x16
4801e4: mov dl,BYTE PTR [esp+0x1]
4801e8: add dl,0x1e
4801eb: mov BYTE PTR [esi+eax*8-0x44],dl
4801ef: xor eax,eax
4801f1: mov al,bl
4801f3: imul eax,eax,0x16
4801f6: cmp BYTE PTR [esi+eax*8-0x45],0x19
4801fb: jne 0x4803e8
480201: xor eax,eax
480203: mov al,bl
480205: imul eax,eax,0x16
480208: cmp WORD PTR [esi+eax*8-0x3c],0x0
48020e: jne 0x480222
480210: xor eax,eax
480212: mov al,bl
480214: imul eax,eax,0x16
480217: mov dl,BYTE PTR [esp+0x1]
48021b: add dl,0x24
48021e: mov BYTE PTR [esi+eax*8-0x44],dl
480222: xor eax,eax
480224: mov al,bl
480226: imul eax,eax,0x16
480229: cmp WORD PTR [esi+eax*8-0x3c],0x5
48022f: jne 0x480243
480231: xor eax,eax
480233: mov al,bl
480235: imul eax,eax,0x16
480238: mov dl,BYTE PTR [esp+0x1]
48023c: add dl,0x25
48023f: mov BYTE PTR [esi+eax*8-0x44],dl
480243: xor eax,eax
480245: mov al,bl
480247: imul eax,eax,0x16
48024a: cmp WORD PTR [esi+eax*8-0x3c],0xa
480250: jne 0x4803e8
480256: xor eax,eax
480258: mov al,bl
48025a: imul eax,eax,0x16
48025d: mov dl,BYTE PTR [esp+0x1]
480261: add dl,0x26
480264: mov BYTE PTR [esi+eax*8-0x44],dl
480268: xor eax,eax
48026a: mov al,bl
48026c: imul eax,eax,0x16
48026f: cmp BYTE PTR [esi+eax*8-0x43],0x1
480274: jne 0x4802c8
480276: xor eax,eax
480278: mov al,bl
48027a: imul eax,eax,0x16
48027d: cmp BYTE PTR [esi+eax*8-0x41],0x1
480282: jne 0x4802c8
480284: xor eax,eax
480286: mov al,bl
480288: imul eax,eax,0x16
48028b: fld QWORD PTR [esi+eax*8-0xb0]
480292: fadd DWORD PTR ds:0x48dd10
480298: add esp,0xfffffff8
48029b: fstp QWORD PTR [esp]
48029e: fwait
48029f: xor eax,eax
4802a1: mov al,bl
4802a3: imul eax,eax,0x16
4802a6: fld QWORD PTR [esi+eax*8-0xa8]
4802ad: fsub DWORD PTR ds:0x48dd20
4802b3: add esp,0xfffffff8
4802b6: fstp QWORD PTR [esp]
4802b9: fwait
4802ba: mov ecx,ebx
4802bc: mov edx,0x48dcd4
4802c1: mov al,0x9
4802c3: call 0x476a04
4802c8: xor eax,eax
4802ca: mov al,bl
4802cc: imul eax,eax,0x16
4802cf: cmp BYTE PTR [esi+eax*8-0x43],0x2
4802d4: jne 0x480328
4802d6: xor eax,eax
4802d8: mov al,bl
4802da: imul eax,eax,0x16
4802dd: cmp BYTE PTR [esi+eax*8-0x41],0x1
4802e2: jne 0x480328
4802e4: xor eax,eax
4802e6: mov al,bl
4802e8: imul eax,eax,0x16
4802eb: fld QWORD PTR [esi+eax*8-0xb0]
4802f2: fsub DWORD PTR ds:0x48dd10
4802f8: add esp,0xfffffff8
4802fb: fstp QWORD PTR [esp]
4802fe: fwait
4802ff: xor eax,eax
480301: mov al,bl
480303: imul eax,eax,0x16
480306: fld QWORD PTR [esi+eax*8-0xa8]
48030d: fsub DWORD PTR ds:0x48dd20
480313: add esp,0xfffffff8
480316: fstp QWORD PTR [esp]
480319: fwait
48031a: mov ecx,ebx
48031c: mov edx,0x48dcd4
480321: mov al,0x9
480323: call 0x476a04
480328: xor eax,eax
48032a: mov al,bl
48032c: imul eax,eax,0x16
48032f: cmp BYTE PTR [esi+eax*8-0x43],0x1
480334: jne 0x480388
480336: xor eax,eax
480338: mov al,bl
48033a: imul eax,eax,0x16
48033d: cmp BYTE PTR [esi+eax*8-0x41],0x2
480342: jne 0x480388
480344: xor eax,eax
480346: mov al,bl
480348: imul eax,eax,0x16
48034b: fld QWORD PTR [esi+eax*8-0xb0]
480352: fadd DWORD PTR ds:0x48dd10
480358: add esp,0xfffffff8
48035b: fstp QWORD PTR [esp]
48035e: fwait
48035f: xor eax,eax
480361: mov al,bl
480363: imul eax,eax,0x16
480366: fld QWORD PTR [esi+eax*8-0xa8]
48036d: fsub DWORD PTR ds:0x48dd20
480373: add esp,0xfffffff8
480376: fstp QWORD PTR [esp]
480379: fwait
48037a: mov ecx,ebx
48037c: mov edx,0x48dce0
480381: mov al,0x9
480383: call 0x476a04
480388: xor eax,eax
48038a: mov al,bl
48038c: imul eax,eax,0x16
48038f: cmp BYTE PTR [esi+eax*8-0x43],0x2
480394: jne 0x4803e8
480396: xor eax,eax
480398: mov al,bl
48039a: imul eax,eax,0x16
48039d: cmp BYTE PTR [esi+eax*8-0x41],0x2
4803a2: jne 0x4803e8
4803a4: xor eax,eax
4803a6: mov al,bl
4803a8: imul eax,eax,0x16
4803ab: fld QWORD PTR [esi+eax*8-0xb0]
4803b2: fsub DWORD PTR ds:0x48dd10
4803b8: add esp,0xfffffff8
4803bb: fstp QWORD PTR [esp]
4803be: fwait
4803bf: xor eax,eax
4803c1: mov al,bl
4803c3: imul eax,eax,0x16
4803c6: fld QWORD PTR [esi+eax*8-0xa8]
4803cd: fsub DWORD PTR ds:0x48dd20
4803d3: add esp,0xfffffff8
4803d6: fstp QWORD PTR [esp]
4803d9: fwait
4803da: mov ecx,ebx
4803dc: mov edx,0x48dce0
4803e1: mov al,0x9
4803e3: call 0x476a04
4803e8: xor eax,eax
4803ea: mov al,bl
4803ec: imul eax,eax,0x16
4803ef: cmp BYTE PTR [esi+eax*8-0x45],0x1a
4803f4: jne 0x480526
4803fa: xor eax,eax
4803fc: mov al,bl
4803fe: imul eax,eax,0x16
480401: cmp WORD PTR [esi+eax*8-0x3c],0x0
480407: jne 0x48041b
480409: xor eax,eax
48040b: mov al,bl
48040d: imul eax,eax,0x16
480410: mov dl,BYTE PTR [esp+0x1]
480414: add dl,0x27
480417: mov BYTE PTR [esi+eax*8-0x44],dl
48041b: xor eax,eax
48041d: mov al,bl
48041f: imul eax,eax,0x16
480422: cmp WORD PTR [esi+eax*8-0x3c],0x1
480428: jne 0x48043c
48042a: xor eax,eax
48042c: mov al,bl
48042e: imul eax,eax,0x16
480431: mov dl,BYTE PTR [esp+0x1]
480435: add dl,0x28
480438: mov BYTE PTR [esi+eax*8-0x44],dl
48043c: xor eax,eax
48043e: mov al,bl
480440: imul eax,eax,0x16
480443: cmp WORD PTR [esi+eax*8-0x3c],0x3
480449: jne 0x48045d
48044b: xor eax,eax
48044d: mov al,bl
48044f: imul eax,eax,0x16
480452: mov dl,BYTE PTR [esp+0x1]
480456: add dl,0x29
480459: mov BYTE PTR [esi+eax*8-0x44],dl
48045d: xor eax,eax
48045f: mov al,bl
480461: imul eax,eax,0x16
480464: cmp WORD PTR [esi+eax*8-0x3c],0x8
48046a: jne 0x48047e
48046c: xor eax,eax
48046e: mov al,bl
480470: imul eax,eax,0x16
480473: mov dl,BYTE PTR [esp+0x1]
480477: add dl,0x2a
48047a: mov BYTE PTR [esi+eax*8-0x44],dl
48047e: xor eax,eax
480480: mov al,bl
480482: imul eax,eax,0x16
480485: cmp BYTE PTR [esi+eax*8-0x41],0x1
48048a: jne 0x4804a8
48048c: xor eax,eax
48048e: mov al,bl
480490: imul eax,eax,0x16
480493: cmp BYTE PTR [esi+eax*8-0x43],0x1
480498: jne 0x4804a8
48049a: push 0x40180000
48049f: push 0x0
4804a1: mov eax,ebx
4804a3: call 0x47648c
4804a8: xor eax,eax
4804aa: mov al,bl
4804ac: imul eax,eax,0x16
4804af: cmp BYTE PTR [esi+eax*8-0x41],0x1
4804b4: jne 0x4804d2
4804b6: xor eax,eax
4804b8: mov al,bl
4804ba: imul eax,eax,0x16
4804bd: cmp BYTE PTR [esi+eax*8-0x43],0x2
4804c2: jne 0x4804d2
4804c4: push 0xc0180000
4804c9: push 0x0
4804cb: mov eax,ebx
4804cd: call 0x47648c
4804d2: xor eax,eax
4804d4: mov al,bl
4804d6: imul eax,eax,0x16
4804d9: cmp BYTE PTR [esi+eax*8-0x41],0x2
4804de: jne 0x4804fc
4804e0: xor eax,eax
4804e2: mov al,bl
4804e4: imul eax,eax,0x16
4804e7: cmp BYTE PTR [esi+eax*8-0x43],0x1
4804ec: jne 0x4804fc
4804ee: push 0x40200000
4804f3: push 0x0
4804f5: mov eax,ebx
4804f7: call 0x47648c
4804fc: xor eax,eax
4804fe: mov al,bl
480500: imul eax,eax,0x16
480503: cmp BYTE PTR [esi+eax*8-0x41],0x2
480508: jne 0x480526
48050a: xor eax,eax
48050c: mov al,bl
48050e: imul eax,eax,0x16
480511: cmp BYTE PTR [esi+eax*8-0x43],0x2
480516: jne 0x480526
480518: push 0xc0200000
48051d: push 0x0
48051f: mov eax,ebx
480521: call 0x47648c
480526: xor eax,eax
480528: mov al,bl
48052a: imul eax,eax,0x16
48052d: cmp BYTE PTR [esi+eax*8-0x45],0x1b
480532: jne 0x4806b1
480538: xor eax,eax
48053a: mov al,bl
48053c: imul eax,eax,0x16
48053f: cmp WORD PTR [esi+eax*8-0x3c],0x0
480545: jne 0x480559
480547: xor eax,eax
480549: mov al,bl
48054b: imul eax,eax,0x16
48054e: mov dl,BYTE PTR [esp+0x1]
480552: add dl,0x2b
480555: mov BYTE PTR [esi+eax*8-0x44],dl
480559: xor eax,eax
48055b: mov al,bl
48055d: imul eax,eax,0x16
480560: cmp WORD PTR [esi+eax*8-0x3c],0x3
480566: jne 0x48057a
480568: xor eax,eax
48056a: mov al,bl
48056c: imul eax,eax,0x16
48056f: mov dl,BYTE PTR [esp+0x1]
480573: add dl,0x2c
480576: mov BYTE PTR [esi+eax*8-0x44],dl
48057a: xor eax,eax
48057c: mov al,bl
48057e: imul eax,eax,0x16
480581: cmp WORD PTR [esi+eax*8-0x3c],0x5
480587: jl 0x4806b1
48058d: mov BYTE PTR [esp],0x5
480591: mov eax,0x28
480596: call 0x402a1c
48059b: mov DWORD PTR [esp+0x4],eax
48059f: fild DWORD PTR [esp+0x4]
4805a3: xor eax,eax
4805a5: mov al,bl
4805a7: imul eax,eax,0x16
4805aa: fld QWORD PTR [esi+eax*8-0xb0]
4805b1: fsub DWORD PTR ds:0x48dce4
4805b7: faddp st(1),st
4805b9: add esp,0xfffffff8
4805bc: fstp QWORD PTR [esp]
4805bf: fwait
4805c0: mov eax,0xa
4805c5: call 0x402a1c
4805ca: mov DWORD PTR [esp+0x10],eax
4805ce: fild DWORD PTR [esp+0x10]
4805d2: xor eax,eax
4805d4: mov al,bl
4805d6: imul eax,eax,0x16
4805d9: fadd QWORD PTR [esi+eax*8-0xa8]
4805e0: add esp,0xfffffff8
4805e3: fstp QWORD PTR [esp]
4805e6: fwait
4805e7: xor ecx,ecx
4805e9: xor edx,edx
4805eb: mov al,0x2
4805ed: call 0x476a04
4805f2: dec BYTE PTR [esp]
4805f5: jne 0x480591
4805f7: xor eax,eax
4805f9: mov al,bl
4805fb: imul eax,eax,0x16
4805fe: mov dl,BYTE PTR [esp+0x1]
480602: add dl,0x2d
480605: mov BYTE PTR [esi+eax*8-0x44],dl
480609: xor eax,eax
48060b: mov al,bl
48060d: imul eax,eax,0x16
480610: cmp BYTE PTR [esi+eax*8-0x41],0x1
480615: jne 0x480633
480617: xor eax,eax
480619: mov al,bl
48061b: imul eax,eax,0x16
48061e: cmp BYTE PTR [esi+eax*8-0x43],0x1
480623: jne 0x480633
480625: push 0x40310000
48062a: push 0x0
48062c: mov eax,ebx
48062e: call 0x47648c
480633: xor eax,eax
480635: mov al,bl
480637: imul eax,eax,0x16
48063a: cmp BYTE PTR [esi+eax*8-0x41],0x1
48063f: jne 0x48065d
480641: xor eax,eax
480643: mov al,bl
480645: imul eax,eax,0x16
480648: cmp BYTE PTR [esi+eax*8-0x43],0x2
48064d: jne 0x48065d
48064f: push 0xc0310000
480654: push 0x0
480656: mov eax,ebx
480658: call 0x47648c
48065d: xor eax,eax
48065f: mov al,bl
480661: imul eax,eax,0x16
480664: cmp BYTE PTR [esi+eax*8-0x41],0x2
480669: jne 0x480687
48066b: xor eax,eax
48066d: mov al,bl
48066f: imul eax,eax,0x16
480672: cmp BYTE PTR [esi+eax*8-0x43],0x1
480677: jne 0x480687
480679: push 0x40300000
48067e: push 0x0
480680: mov eax,ebx
480682: call 0x47648c
480687: xor eax,eax
480689: mov al,bl
48068b: imul eax,eax,0x16
48068e: cmp BYTE PTR [esi+eax*8-0x41],0x2
480693: jne 0x4806b1
480695: xor eax,eax
480697: mov al,bl
480699: imul eax,eax,0x16
48069c: cmp BYTE PTR [esi+eax*8-0x43],0x2
4806a1: jne 0x4806b1
4806a3: push 0xc0300000
4806a8: push 0x0
4806aa: mov eax,ebx
4806ac: call 0x47648c
4806b1: xor eax,eax
4806b3: mov al,bl
4806b5: imul eax,eax,0x16
4806b8: cmp BYTE PTR [esi+eax*8-0x45],0x1c
4806bd: jne 0x48082b
4806c3: xor eax,eax
4806c5: mov al,bl
4806c7: imul eax,eax,0x16
4806ca: cmp WORD PTR [esi+eax*8-0x3c],0x0
4806d0: jne 0x4806e4
4806d2: xor eax,eax
4806d4: mov al,bl
4806d6: imul eax,eax,0x16
4806d9: mov dl,BYTE PTR [esp+0x1]
4806dd: add dl,0x2e
4806e0: mov BYTE PTR [esi+eax*8-0x44],dl
4806e4: xor eax,eax
4806e6: mov al,bl
4806e8: imul eax,eax,0x16
4806eb: cmp WORD PTR [esi+eax*8-0x3c],0x2
4806f1: jne 0x480705
4806f3: xor eax,eax
4806f5: mov al,bl
4806f7: imul eax,eax,0x16
4806fa: mov dl,BYTE PTR [esp+0x1]
4806fe: add dl,0x2f
480701: mov BYTE PTR [esi+eax*8-0x44],dl
480705: xor eax,eax
480707: mov al,bl
480709: imul eax,eax,0x16
48070c: cmp WORD PTR [esi+eax*8-0x3c],0x4
480712: jne 0x480726
480714: xor eax,eax
480716: mov al,bl
480718: imul eax,eax,0x16
48071b: mov dl,BYTE PTR [esp+0x1]
48071f: add dl,0x2e
480722: mov BYTE PTR [esi+eax*8-0x44],dl
480726: xor eax,eax
480728: mov al,bl
48072a: imul eax,eax,0x16
48072d: cmp WORD PTR [esi+eax*8-0x3c],0x6
480733: jne 0x480747
480735: xor eax,eax
480737: mov al,bl
480739: imul eax,eax,0x16
48073c: mov dl,BYTE PTR [esp+0x1]
480740: add dl,0x2f
480743: mov BYTE PTR [esi+eax*8-0x44],dl
480747: xor eax,eax
480749: mov al,bl
48074b: imul eax,eax,0x16
48074e: cmp WORD PTR [esi+eax*8-0x3c],0x8
480754: jne 0x480768
480756: xor eax,eax
480758: mov al,bl
48075a: imul eax,eax,0x16
48075d: mov dl,BYTE PTR [esp+0x1]
480761: add dl,0x2e
480764: mov BYTE PTR [esi+eax*8-0x44],dl
480768: xor eax,eax
48076a: mov al,bl
48076c: imul eax,eax,0x16
48076f: cmp BYTE PTR [esi+eax*8-0x43],0x1
480774: jne 0x480792
480776: xor eax,eax
480778: mov al,bl
48077a: imul eax,eax,0x16
48077d: cmp BYTE PTR [esi+eax*8-0x41],0x1
480782: jne 0x480792
480784: push 0x40240000
480789: push 0x0
48078b: mov eax,ebx
48078d: call 0x47648c
480792: xor eax,eax
480794: mov al,bl
480796: imul eax,eax,0x16
480799: cmp BYTE PTR [esi+eax*8-0x43],0x2
48079e: jne 0x4807bc
4807a0: xor eax,eax
4807a2: mov al,bl
4807a4: imul eax,eax,0x16
4807a7: cmp BYTE PTR [esi+eax*8-0x41],0x1
4807ac: jne 0x4807bc
4807ae: push 0xc0240000
4807b3: push 0x0
4807b5: mov eax,ebx
4807b7: call 0x47648c
4807bc: xor eax,eax
4807be: mov al,bl
4807c0: imul eax,eax,0x16
4807c3: cmp BYTE PTR [esi+eax*8-0x43],0x1
4807c8: jne 0x4807e6
4807ca: xor eax,eax
4807cc: mov al,bl
4807ce: imul eax,eax,0x16
4807d1: cmp BYTE PTR [esi+eax*8-0x41],0x2
4807d6: jne 0x4807e6
4807d8: push 0x402c0000
4807dd: push 0x0
4807df: mov eax,ebx
4807e1: call 0x47648c
4807e6: xor eax,eax
4807e8: mov al,bl
4807ea: imul eax,eax,0x16
4807ed: cmp BYTE PTR [esi+eax*8-0x43],0x2
4807f2: jne 0x480810
4807f4: xor eax,eax
4807f6: mov al,bl
4807f8: imul eax,eax,0x16
4807fb: cmp BYTE PTR [esi+eax*8-0x41],0x2
480800: jne 0x480810
480802: push 0xc02c0000
480807: push 0x0
480809: mov eax,ebx
48080b: call 0x47648c
480810: xor eax,eax
480812: mov al,bl
480814: imul eax,eax,0x16
480817: cmp WORD PTR [esi+eax*8-0x3c],0x5
48081d: jl 0x48082b
48081f: xor eax,eax
480821: mov al,bl
480823: imul eax,eax,0x16
480826: mov BYTE PTR [esi+eax*8-0x47],0x1
48082b: xor eax,eax
48082d: mov al,bl
48082f: imul eax,eax,0x16
480832: cmp BYTE PTR [esi+eax*8-0x45],0x1d
480837: jne 0x4808f1
48083d: mov BYTE PTR [esp],0x3
480841: mov eax,0x28
480846: call 0x402a1c
48084b: mov DWORD PTR [esp+0x4],eax
48084f: fild DWORD PTR [esp+0x4]
480853: xor eax,eax
480855: mov al,bl
480857: imul eax,eax,0x16
48085a: fld QWORD PTR [esi+eax*8-0xb0]
480861: fsub DWORD PTR ds:0x48dce4
480867: faddp st(1),st
480869: add esp,0xfffffff8
48086c: fstp QWORD PTR [esp]
48086f: fwait
480870: mov eax,0xa
480875: call 0x402a1c
48087a: mov DWORD PTR [esp+0x10],eax
48087e: fild DWORD PTR [esp+0x10]
480882: xor eax,eax
480884: mov al,bl
480886: imul eax,eax,0x16
480889: fadd QWORD PTR [esi+eax*8-0xa8]
480890: add esp,0xfffffff8
480893: fstp QWORD PTR [esp]
480896: fwait
480897: xor ecx,ecx
480899: xor edx,edx
48089b: mov al,0x2
48089d: call 0x476a04
4808a2: dec BYTE PTR [esp]
4808a5: jne 0x480841
4808a7: xor eax,eax
4808a9: mov al,bl
4808ab: imul eax,eax,0x16
4808ae: mov dl,BYTE PTR [esp+0x1]
4808b2: add dl,0x30
4808b5: mov BYTE PTR [esi+eax*8-0x44],dl
4808b9: xor eax,eax
4808bb: mov al,bl
4808bd: imul eax,eax,0x16
4808c0: cmp BYTE PTR [esi+eax*8-0x43],0x1
4808c5: jne 0x4808d5
4808c7: push 0x40310000
4808cc: push 0x0
4808ce: mov eax,ebx
4808d0: call 0x47648c
4808d5: xor eax,eax
4808d7: mov al,bl
4808d9: imul eax,eax,0x16
4808dc: cmp BYTE PTR [esi+eax*8-0x43],0x2
4808e1: jne 0x4808f1
4808e3: push 0xc0310000
4808e8: push 0x0
4808ea: mov eax,ebx
4808ec: call 0x47648c
4808f1: xor eax,eax
4808f3: mov al,bl
4808f5: imul eax,eax,0x16
4808f8: cmp BYTE PTR [esi+eax*8-0x45],0x1e
4808fd: jne 0x480dc1
480903: xor eax,eax
480905: mov al,bl
480907: imul eax,eax,0x16
48090a: mov BYTE PTR [esi+eax*8-0x3e],0x0
48090f: mov eax,ds:0x4b1094
480914: movzx eax,BYTE PTR [eax]
480917: mov DWORD PTR [esp+0x4],eax
48091b: fild DWORD PTR [esp+0x4]
48091f: fdiv DWORD PTR ds:0x48dd24
480925: call 0x40287c
48092a: mov eax,ds:0x4b1094
48092f: movzx eax,BYTE PTR [eax]
480932: mov DWORD PTR [esp+0x8],eax
480936: fild DWORD PTR [esp+0x8]
48093a: fdiv DWORD PTR ds:0x48dd24
480940: fcompp
480942: fnstsw ax
480944: sahf
480945: jne 0x48095b
480947: xor eax,eax
480949: mov al,bl
48094b: imul eax,eax,0x16
48094e: mov dl,BYTE PTR [esp+0x1]
480952: add dl,0x31
480955: mov BYTE PTR [esi+eax*8-0x44],dl
480959: jmp 0x48096d
48095b: xor eax,eax
48095d: mov al,bl
48095f: imul eax,eax,0x16
480962: mov dl,BYTE PTR [esp+0x1]
480966: add dl,0x32
480969: mov BYTE PTR [esi+eax*8-0x44],dl
48096d: xor eax,eax
48096f: mov al,bl
480971: imul eax,eax,0x16
480974: fld QWORD PTR [esi+eax*8-0xa8]
48097b: fsub DWORD PTR ds:0x48dcf0
480981: xor eax,eax
480983: mov al,bl
480985: imul eax,eax,0x16
480988: fstp QWORD PTR [esi+eax*8-0xa8]
48098f: fwait
480990: mov eax,ds:0x4b0d98
480995: cmp BYTE PTR [eax],0x1
480998: jne 0x4809b0
48099a: mov eax,0x5
48099f: call 0x402a1c
4809a4: test eax,eax
4809a6: jne 0x4809b0
4809a8: mov eax,ds:0x4b0fc8
4809ad: mov BYTE PTR [eax],0x3
4809b0: mov eax,0x2
4809b5: call 0x402a1c
4809ba: add al,0x1a
4809bc: mov dl,0x32
4809be: sub dl,BYTE PTR [esp+0x1]
4809c2: add al,dl
4809c4: xor edx,edx
4809c6: mov dl,bl
4809c8: mov ecx,0x3
4809cd: sub ecx,edx
4809cf: imul edx,ecx,0x16
4809d2: mov BYTE PTR [esi+edx*8-0x44],al
4809d6: xor eax,eax
4809d8: mov al,bl
4809da: mov edx,0x3
4809df: sub edx,eax
4809e1: imul eax,edx,0x16
4809e4: mov WORD PTR [esi+eax*8-0x3c],0x0
4809eb: xor eax,eax
4809ed: mov al,bl
4809ef: mov edx,0x3
4809f4: sub edx,eax
4809f6: imul eax,edx,0x16
4809f9: mov WORD PTR [esi+eax*8-0x3a],0x5
480a00: xor eax,eax
480a02: mov al,bl
480a04: mov edx,0x3
480a09: sub edx,eax
480a0b: imul eax,edx,0x16
480a0e: mov BYTE PTR [esi+eax*8-0x38],0x0
480a13: xor eax,eax
480a15: mov al,bl
480a17: mov edx,0x3
480a1c: sub edx,eax
480a1e: imul eax,edx,0x16
480a21: fld QWORD PTR [esi+eax*8-0xa8]
480a28: fadd DWORD PTR ds:0x48dcc0
480a2e: xor eax,eax
480a30: mov al,bl
480a32: mov edx,0x3
480a37: sub edx,eax
480a39: imul eax,edx,0x16
480a3c: fstp QWORD PTR [esi+eax*8-0xa8]
480a43: fwait
480a44: mov eax,ds:0x4b11f8
480a49: fild WORD PTR [eax]
480a4b: xor eax,eax
480a4d: mov al,bl
480a4f: mov edx,0x3
480a54: sub edx,eax
480a56: imul eax,edx,0x16
480a59: fcomp QWORD PTR [esi+eax*8-0xa8]
480a60: fnstsw ax
480a62: sahf
480a63: jae 0x480a82
480a65: mov eax,ds:0x4b11f8
480a6a: fild WORD PTR [eax]
480a6c: xor eax,eax
480a6e: mov al,bl
480a70: mov edx,0x3
480a75: sub edx,eax
480a77: imul eax,edx,0x16
480a7a: fstp QWORD PTR [esi+eax*8-0xa8]
480a81: fwait
480a82: xor eax,eax
480a84: mov al,bl
480a86: imul eax,eax,0x16
480a89: cmp BYTE PTR [esi+eax*8-0x43],0x1
480a8e: jne 0x480ad1
480a90: mov eax,0x3
480a95: call 0x402a1c
480a9a: lea eax,[eax+eax*4]
480a9d: mov DWORD PTR [esp+0x4],eax
480aa1: fild DWORD PTR [esp+0x4]
480aa5: xor eax,eax
480aa7: mov al,bl
480aa9: imul eax,eax,0x16
480aac: fld QWORD PTR [esi+eax*8-0xb0]
480ab3: fadd DWORD PTR ds:0x48dd28
480ab9: faddp st(1),st
480abb: xor eax,eax
480abd: mov al,bl
480abf: mov edx,0x3
480ac4: sub edx,eax
480ac6: imul eax,edx,0x16
480ac9: fstp QWORD PTR [esi+eax*8-0xb0]
480ad0: fwait
480ad1: xor eax,eax
480ad3: mov al,bl
480ad5: imul eax,eax,0x16
480ad8: cmp BYTE PTR [esi+eax*8-0x43],0x2
480add: jne 0x480b20
480adf: mov eax,0x3
480ae4: call 0x402a1c
480ae9: lea eax,[eax+eax*4]
480aec: mov DWORD PTR [esp+0x4],eax
480af0: fild DWORD PTR [esp+0x4]
480af4: xor eax,eax
480af6: mov al,bl
480af8: imul eax,eax,0x16
480afb: fld QWORD PTR [esi+eax*8-0xb0]
480b02: fsub DWORD PTR ds:0x48dd28
480b08: fsubrp st(1),st
480b0a: xor eax,eax
480b0c: mov al,bl
480b0e: mov edx,0x3
480b13: sub edx,eax
480b15: imul eax,edx,0x16
480b18: fstp QWORD PTR [esi+eax*8-0xb0]
480b1f: fwait
480b20: xor eax,eax
480b22: mov al,bl
480b24: imul eax,eax,0x16
480b27: inc BYTE PTR [esi+eax*8-0x1b]
480b2b: xor eax,eax
480b2d: mov al,bl
480b2f: imul eax,eax,0x16
480b32: mov BYTE PTR [esi+eax*8-0x1a],0x2b
480b37: mov eax,0x14
480b3c: call 0x402a1c
480b41: test eax,eax
480b43: jne 0x480b6a
480b45: xor eax,eax
480b47: mov al,bl
480b49: mov edx,0x3
480b4e: sub edx,eax
480b50: imul eax,edx,0x16
480b53: fld QWORD PTR [esi+eax*8-0x70]
480b57: fcomp DWORD PTR ds:0x48dcc4
480b5d: fnstsw ax
480b5f: sahf
480b60: jbe 0x480b6a
480b62: mov eax,ds:0x4b0e84
480b67: mov BYTE PTR [eax],0x5
480b6a: mov eax,0x6
480b6f: call 0x402a1c
480b74: test eax,eax
480b76: jne 0x480b80
480b78: mov eax,ds:0x4b1098
480b7d: mov BYTE PTR [eax],0x7
480b80: mov eax,0x6
480b85: call 0x402a1c
480b8a: test eax,eax
480b8c: jne 0x480b96
480b8e: mov eax,ds:0x4b1098
480b93: mov BYTE PTR [eax],0x8
480b96: mov eax,0x6
480b9b: call 0x402a1c
480ba0: test eax,eax
480ba2: jne 0x480bac
480ba4: mov eax,ds:0x4b1098
480ba9: mov BYTE PTR [eax],0x9
480bac: xor eax,eax
480bae: mov al,bl
480bb0: imul eax,eax,0x16
480bb3: cmp BYTE PTR [esi+eax*8-0x43],0x1
480bb8: jne 0x480c23
480bba: mov eax,0xa
480bbf: call 0x402a1c
480bc4: mov DWORD PTR [esp+0x4],eax
480bc8: fild DWORD PTR [esp+0x4]
480bcc: xor eax,eax
480bce: mov al,bl
480bd0: imul eax,eax,0x16
480bd3: fld QWORD PTR [esi+eax*8-0xb0]
480bda: fadd DWORD PTR ds:0x48dd10
480be0: faddp st(1),st
480be2: add esp,0xfffffff8
480be5: fstp QWORD PTR [esp]
480be8: fwait
480be9: mov eax,0x1e
480bee: call 0x402a1c
480bf3: mov DWORD PTR [esp+0x10],eax
480bf7: fild DWORD PTR [esp+0x10]
480bfb: xor eax,eax
480bfd: mov al,bl
480bff: imul eax,eax,0x16
480c02: fld QWORD PTR [esi+eax*8-0xa8]
480c09: fsub DWORD PTR ds:0x48dd14
480c0f: faddp st(1),st
480c11: add esp,0xfffffff8
480c14: fstp QWORD PTR [esp]
480c17: fwait
480c18: xor ecx,ecx
480c1a: xor edx,edx
480c1c: mov al,0x1
480c1e: call 0x476a04
480c23: xor eax,eax
480c25: mov al,bl
480c27: imul eax,eax,0x16
480c2a: cmp BYTE PTR [esi+eax*8-0x43],0x2
480c2f: jne 0x480c9a
480c31: mov eax,0xa
480c36: call 0x402a1c
480c3b: mov DWORD PTR [esp+0x4],eax
480c3f: fild DWORD PTR [esp+0x4]
480c43: xor eax,eax
480c45: mov al,bl
480c47: imul eax,eax,0x16
480c4a: fld QWORD PTR [esi+eax*8-0xb0]
480c51: fsub DWORD PTR ds:0x48dd2c
480c57: faddp st(1),st
480c59: add esp,0xfffffff8
480c5c: fstp QWORD PTR [esp]
480c5f: fwait
480c60: mov eax,0x1e
480c65: call 0x402a1c
480c6a: mov DWORD PTR [esp+0x10],eax
480c6e: fild DWORD PTR [esp+0x10]
480c72: xor eax,eax
480c74: mov al,bl
480c76: imul eax,eax,0x16
480c79: fld QWORD PTR [esi+eax*8-0xa8]
480c80: fsub DWORD PTR ds:0x48dd14
480c86: faddp st(1),st
480c88: add esp,0xfffffff8
480c8b: fstp QWORD PTR [esp]
480c8e: fwait
480c8f: xor ecx,ecx
480c91: xor edx,edx
480c93: mov al,0x1
480c95: call 0x476a04
480c9a: xor eax,eax
480c9c: mov al,bl
480c9e: imul eax,eax,0x16
480ca1: movsx eax,WORD PTR [esi+eax*8-0x3c]
480ca6: xor edx,edx
480ca8: mov dl,bl
480caa: imul edx,edx,0x16
480cad: movsx edx,WORD PTR [esi+edx*8-0x3a]
480cb2: sub edx,0x2
480cb5: cmp eax,edx
480cb7: jle 0x480dc1
480cbd: xor eax,eax
480cbf: mov al,bl
480cc1: imul eax,eax,0x16
480cc4: mov BYTE PTR [esi+eax*8-0x40],0x24
480cc9: xor eax,eax
480ccb: mov al,bl
480ccd: imul eax,eax,0x16
480cd0: movzx eax,BYTE PTR [esi+eax*8-0x40]
480cd5: mov DWORD PTR [esp+0x4],eax
480cd9: fild DWORD PTR [esp+0x4]
480cdd: mov eax,ds:0x4b11f4
480ce2: fmul QWORD PTR [eax]
480ce4: xor eax,eax
480ce6: mov al,bl
480ce8: mov edx,0x3
480ced: sub edx,eax
480cef: imul eax,edx,0x16
480cf2: fsubr QWORD PTR [esi+eax*8-0x70]
480cf6: xor eax,eax
480cf8: mov al,bl
480cfa: mov edx,0x3
480cff: sub edx,eax
480d01: imul eax,edx,0x16
480d04: fstp QWORD PTR [esi+eax*8-0x70]
480d08: fwait
480d09: xor eax,eax
480d0b: mov al,bl
480d0d: imul eax,eax,0x16
480d10: mov BYTE PTR [esi+eax*8-0x38],0xe4
480d15: xor eax,eax
480d17: mov al,bl
480d19: imul eax,eax,0x16
480d1c: mov BYTE PTR [esi+eax*8-0x46],0x1
480d21: xor eax,eax
480d23: mov al,bl
480d25: imul eax,eax,0x16
480d28: mov BYTE PTR [esi+eax*8-0x45],0xc
480d2d: xor eax,eax
480d2f: mov al,bl
480d31: imul eax,eax,0x16
480d34: mov WORD PTR [esi+eax*8-0x3c],0x0
480d3b: xor eax,eax
480d3d: mov al,bl
480d3f: imul eax,eax,0x16
480d42: mov WORD PTR [esi+eax*8-0x3a],0x63
480d49: mov al,0x3
480d4b: sub al,bl
480d4d: mov dl,0xa
480d4f: call 0x4775fc
480d54: xor eax,eax
480d56: mov al,bl
480d58: mov edx,0x3
480d5d: sub edx,eax
480d5f: imul eax,edx,0x16
480d62: mov BYTE PTR [esi+eax*8-0x3e],0x1e
480d67: xor eax,eax
480d69: mov al,bl
480d6b: mov edx,0x3
480d70: sub edx,eax
480d72: imul eax,edx,0x16
480d75: cmp BYTE PTR [esi+eax*8-0x43],0x1
480d7a: jne 0x480d94
480d7c: xor eax,eax
480d7e: mov al,bl
480d80: mov edx,0x3
480d85: sub edx,eax
480d87: imul eax,edx,0x16
480d8a: mov WORD PTR [esi+eax*8-0x98],0xfff1
480d94: xor eax,eax
480d96: mov al,bl
480d98: mov edx,0x3
480d9d: sub edx,eax
480d9f: imul eax,edx,0x16
480da2: cmp BYTE PTR [esi+eax*8-0x43],0x2
480da7: jne 0x480dc1
480da9: xor eax,eax
480dab: mov al,bl
480dad: mov edx,0x3
480db2: sub edx,eax
480db4: imul eax,edx,0x16
480db7: mov WORD PTR [esi+eax*8-0x98],0xf
480dc1: push 0x1e
480dc3: push 0xe
480dc5: push 0x9b
480dca: xor edx,edx
480dcc: mov dl,BYTE PTR [esp+0xd]
480dd0: inc edx
480dd1: xor eax,eax
480dd3: mov al,bl
480dd5: mov ecx,0xffffffef
480dda: call 0x476870
480ddf: push 0x1e
480de1: push 0xe
480de3: push 0x9b
480de8: xor edx,edx
480dea: mov dl,BYTE PTR [esp+0xd]
480dee: add edx,0x2
480df1: xor eax,eax
480df3: mov al,bl
480df5: mov ecx,0xffffffef
480dfa: call 0x476870
480dff: push 0x1e
480e01: push 0xe
480e03: push 0x9b
480e08: xor edx,edx
480e0a: mov dl,BYTE PTR [esp+0xd]
480e0e: add edx,0x3
480e11: xor eax,eax
480e13: mov al,bl
480e15: mov ecx,0xffffffef
480e1a: call 0x476870
480e1f: push 0x1e
480e21: push 0xe
480e23: push 0x9b
480e28: xor edx,edx
480e2a: mov dl,BYTE PTR [esp+0xd]
480e2e: add edx,0x4
480e31: xor eax,eax
480e33: mov al,bl
480e35: mov ecx,0xffffffef
480e3a: call 0x476870
480e3f: push 0x1e
480e41: push 0xe
480e43: push 0x9b
480e48: xor edx,edx
480e4a: mov dl,BYTE PTR [esp+0xd]
480e4e: add edx,0x6
480e51: xor eax,eax
480e53: mov al,bl
480e55: mov ecx,0xffffffef
480e5a: call 0x476870
480e5f: push 0x1e
480e61: push 0xe
480e63: push 0x9b
480e68: xor edx,edx
480e6a: mov dl,BYTE PTR [esp+0xd]
480e6e: add edx,0x8
480e71: xor eax,eax
480e73: mov al,bl
480e75: mov ecx,0xffffffef
480e7a: call 0x476870
480e7f: push 0x1e
480e81: push 0xe
480e83: push 0x9b
480e88: xor edx,edx
480e8a: mov dl,BYTE PTR [esp+0xd]
480e8e: add edx,0xa
480e91: xor eax,eax
480e93: mov al,bl
480e95: mov ecx,0xffffffef
480e9a: call 0x476870
480e9f: push 0x41
480ea1: push 0xe
480ea3: push 0x9b
480ea8: xor edx,edx
480eaa: mov dl,BYTE PTR [esp+0xd]
480eae: add edx,0xc
480eb1: xor eax,eax
480eb3: mov al,bl
480eb5: mov ecx,0xffffffef
480eba: call 0x476870
480ebf: push 0x41
480ec1: push 0xe
480ec3: push 0x9b
480ec8: xor edx,edx
480eca: mov dl,BYTE PTR [esp+0xd]
480ece: add edx,0xd
480ed1: xor eax,eax
480ed3: mov al,bl
480ed5: mov ecx,0xffffffef
480eda: call 0x476870
480edf: push 0x41
480ee1: push 0xe
480ee3: push 0x9b
480ee8: xor edx,edx
480eea: mov dl,BYTE PTR [esp+0xd]
480eee: add edx,0xf
480ef1: xor eax,eax
480ef3: mov al,bl
480ef5: mov ecx,0xffffffef
480efa: call 0x476870
480eff: push 0x41
480f01: push 0xe
480f03: push 0x9b
480f08: xor edx,edx
480f0a: mov dl,BYTE PTR [esp+0xd]
480f0e: add edx,0x11
480f11: xor eax,eax
480f13: mov al,bl
480f15: mov ecx,0xffffffef
480f1a: call 0x476870
480f1f: push 0x41
480f21: push 0xe
480f23: push 0x9b
480f28: xor edx,edx
480f2a: mov dl,BYTE PTR [esp+0xd]
480f2e: add edx,0x13
480f31: xor eax,eax
480f33: mov al,bl
480f35: mov ecx,0xffffffef
480f3a: call 0x476870
480f3f: push 0x1e
480f41: push 0xe
480f43: push 0x6e
480f45: xor edx,edx
480f47: mov dl,BYTE PTR [esp+0xd]
480f4b: add edx,0x15
480f4e: xor eax,eax
480f50: mov al,bl
480f52: mov ecx,0xffffffef
480f57: call 0x476870
480f5c: push 0x46
480f5e: push 0x18
480f60: push 0x73
480f62: xor edx,edx
480f64: mov dl,BYTE PTR [esp+0xd]
480f68: add edx,0x1c
480f6b: xor eax,eax
480f6d: mov al,bl
480f6f: mov ecx,0xffffffe5
480f74: call 0x476870
480f79: push 0x73
480f7b: push 0x18
480f7d: push 0x9b
480f82: xor edx,edx
480f84: mov dl,BYTE PTR [esp+0xd]
480f88: add edx,0x1d
480f8b: xor eax,eax
480f8d: mov al,bl
480f8f: mov ecx,0xffffffe5
480f94: call 0x476870
480f99: push 0x28
480f9b: push 0x19
480f9d: push 0x9b
480fa2: xor edx,edx
480fa4: mov dl,BYTE PTR [esp+0xd]
480fa8: add edx,0x1f
480fab: xor eax,eax
480fad: mov al,bl
480faf: mov ecx,0xffffffef
480fb4: call 0x476870
480fb9: push 0x41
480fbb: push 0x1e
480fbd: push 0x9b
480fc2: xor edx,edx
480fc4: mov dl,BYTE PTR [esp+0xd]
480fc8: add edx,0x20
480fcb: xor eax,eax
480fcd: mov al,bl
480fcf: mov ecx,0xfffffff4
480fd4: call 0x476870
480fd9: push 0x1e
480fdb: push 0xe
480fdd: push 0x9b
480fe2: xor edx,edx
480fe4: mov dl,BYTE PTR [esp+0xd]
480fe8: add edx,0x23
480feb: xor eax,eax
480fed: mov al,bl
480fef: mov ecx,0xffffffef
480ff4: call 0x476870
480ff9: push 0x1e
480ffb: push 0x18
480ffd: push 0x8c
481002: xor edx,edx
481004: mov dl,BYTE PTR [esp+0xd]
481008: add edx,0x26
48100b: xor eax,eax
48100d: mov al,bl
48100f: mov ecx,0xfffffff9
481014: call 0x476870
481019: push 0x1e
48101b: push 0xe
48101d: push 0x6e
48101f: xor edx,edx
481021: mov dl,BYTE PTR [esp+0xd]
481025: add edx,0x27
481028: xor eax,eax
48102a: mov al,bl
48102c: mov ecx,0xffffffef
481031: call 0x476870
481036: push 0x32
481038: push 0x1c
48103a: push 0x8c
48103f: xor edx,edx
481041: mov dl,BYTE PTR [esp+0xd]
481045: add edx,0x29
481048: xor eax,eax
48104a: mov al,bl
48104c: xor ecx,ecx
48104e: call 0x476870
481053: push 0x1e
481055: push 0x18
481057: push 0x8c
48105c: xor edx,edx
48105e: mov dl,BYTE PTR [esp+0xd]
481062: add edx,0x2b
481065: xor eax,eax
481067: mov al,bl
481069: mov ecx,0xfffffff9
48106e: call 0x476870
481073: push 0x28
481075: push 0x32
481077: push 0x8c
48107c: xor edx,edx
48107e: mov dl,BYTE PTR [esp+0xd]
481082: add edx,0x2d
481085: xor eax,eax
481087: mov al,bl
481089: mov ecx,0xa
48108e: call 0x476870
481093: push 0x14
481095: push 0x2d
481097: push 0x3c
481099: push 0x37
48109b: push 0x1
48109d: push 0x1
48109f: push 0x7
4810a1: push 0x0
4810a3: xor eax,eax
4810a5: mov al,bl
4810a7: mov ecx,0x2
4810ac: mov edx,0x3
4810b1: call 0x4768f8
4810b6: push 0xf
4810b8: push 0x64
4810ba: push 0x30
4810bc: push 0x8c
4810c1: push 0x1
4810c3: push 0x1
4810c5: push 0x7
4810c7: push 0x0
4810c9: xor eax,eax
4810cb: mov al,bl
4810cd: mov ecx,0x2
4810d2: mov edx,0x4
4810d7: call 0x4768f8
4810dc: push 0xf
4810de: push 0x2d
4810e0: push 0x37
4810e2: push 0x3a
4810e4: push 0x1
4810e6: push 0x2
4810e8: push 0xe
4810ea: push 0x0
4810ec: xor eax,eax
4810ee: mov al,bl
4810f0: mov ecx,0x5
4810f5: mov edx,0x5
4810fa: call 0x4768f8
4810ff: push 0xa
481101: push 0x3c
481103: push 0x3c
481105: push 0x5a
481107: push 0x1
481109: push 0x2
48110b: push 0xe
48110d: push 0x0
48110f: xor eax,eax
481111: mov al,bl
481113: mov ecx,0x5
481118: mov edx,0x6
48111d: call 0x4768f8
481122: push 0xf
481124: push 0x50
481126: push 0x46
481128: push 0x5a
48112a: push 0x1
48112c: push 0x1
48112e: push 0x7
481130: push 0x0
481132: xor eax,eax
481134: mov al,bl
481136: mov ecx,0x2
48113b: mov edx,0x8
481140: call 0x4768f8
481145: push 0x14
481147: push 0x7f
481149: push 0x46
48114b: push 0x8f
481150: push 0x1
481152: push 0x1
481154: push 0x7
481156: push 0x0
481158: xor eax,eax
48115a: mov al,bl
48115c: mov ecx,0x2
481161: mov edx,0x9
481166: call 0x4768f8
48116b: push 0xf
48116d: push 0x50
48116f: push 0x3c
481171: push 0x5f
481173: push 0x1
481175: push 0x2
481177: push 0xe
481179: push 0x0
48117b: xor eax,eax
48117d: mov al,bl
48117f: mov ecx,0x5
481184: mov edx,0xa
481189: call 0x4768f8
48118e: push 0x11
481190: push 0x66
481192: push 0x50
481194: push 0x7b
481196: push 0x1
481198: push 0x2
48119a: push 0xe
48119c: push 0x0
48119e: xor eax,eax
4811a0: mov al,bl
4811a2: mov ecx,0x5
4811a7: mov edx,0xb
4811ac: call 0x4768f8
4811b1: push 0x11
4811b3: push 0x4b
4811b5: push 0x44
4811b7: push 0x69
4811b9: push 0x1
4811bb: push 0x1
4811bd: push 0x7
4811bf: push 0x0
4811c1: xor eax,eax
4811c3: mov al,bl
4811c5: mov ecx,0x2
4811ca: mov edx,0xd
4811cf: call 0x4768f8
4811d4: push 0xa
4811d6: push 0x50
4811d8: push 0x50
4811da: push 0x69
4811dc: push 0x1
4811de: push 0x1
4811e0: push 0x7
4811e2: push 0x0
4811e4: xor eax,eax
4811e6: mov al,bl
4811e8: mov ecx,0x2
4811ed: mov edx,0xe
4811f2: call 0x4768f8
4811f7: push 0x11
4811f9: push 0x4b
4811fb: push 0x44
4811fd: push 0x69
4811ff: push 0x1
481201: push 0x2
481203: push 0xe
481205: push 0x0
481207: xor eax,eax
481209: mov al,bl
48120b: mov ecx,0x5
481210: mov edx,0xf
481215: call 0x4768f8
48121a: push 0xa
48121c: push 0x50
48121e: push 0x50
481220: push 0x69
481222: push 0x1
481224: push 0x2
481226: push 0xe
481228: push 0x0
48122a: xor eax,eax
48122c: mov al,bl
48122e: mov ecx,0x5
481233: mov edx,0x10
481238: call 0x4768f8
48123d: push 0xa
48123f: push 0x5
481241: push 0x32
481243: push 0x5f
481245: push 0x1
481247: push 0x0
481249: push 0x14
48124b: push 0x3
48124d: xor eax,eax
48124f: mov al,bl
481251: mov ecx,0x2
481256: mov edx,0x1a
48125b: call 0x4768f8
481260: push 0xa
481262: push 0x5
481264: push 0x32
481266: push 0x5f
481268: push 0x0
48126a: push 0x0
48126c: push 0x0
48126e: push 0x0
481270: xor eax,eax
481272: mov al,bl
481274: mov ecx,0x7
481279: mov edx,0x1a
48127e: call 0x4768f8
481283: push 0xa
481285: push 0x44
481287: push 0x64
481289: push 0x52
48128b: push 0x1
48128d: push 0x0
48128f: push 0x10
481291: push 0x4
481293: xor eax,eax
481295: mov al,bl
481297: mov ecx,0x5
48129c: mov edx,0x1b
4812a1: call 0x4768f8
4812a6: push 0x14
4812a8: push 0x50
4812aa: push 0x46
4812ac: push 0x6e
4812ae: push 0x1
4812b0: push 0x0
4812b2: push 0xc
4812b4: push 0x1
4812b6: xor eax,eax
4812b8: mov al,bl
4812ba: mov ecx,0x1
4812bf: mov edx,0x1c
4812c4: call 0x4768f8
4812c9: push 0xffffffba
4812cb: push 0x50
4812cd: push 0x5
4812cf: push 0x6e
4812d1: push 0x1
4812d3: push 0x0
4812d5: push 0xc
4812d7: push 0x1
4812d9: xor eax,eax
4812db: mov al,bl
4812dd: mov ecx,0x3
4812e2: mov edx,0x1c
4812e7: call 0x4768f8
4812ec: push 0x14
4812ee: push 0x50
4812f0: push 0x46
4812f2: push 0x6e
4812f4: push 0x1
4812f6: push 0x0
4812f8: push 0x8
4812fa: push 0x1
4812fc: xor eax,eax
4812fe: mov al,bl
481300: mov ecx,0x5
481305: mov edx,0x1c
48130a: call 0x4768f8
48130f: push 0xffffffba
481311: push 0x50
481313: push 0x5
481315: push 0x6e
481317: push 0x1
481319: push 0x0
48131b: push 0x8
48131d: push 0x1
48131f: xor eax,eax
481321: mov al,bl
481323: mov ecx,0x7
481328: mov edx,0x1c
48132d: call 0x4768f8
481332: push 0x0
481334: push 0x0
481336: push 0x0
481338: push 0x0
48133a: push 0x0
48133c: push 0x0
48133e: push 0x0
481340: push 0x0
481342: xor eax,eax
481344: mov al,bl
481346: mov ecx,0x9
48134b: mov edx,0x1c
481350: call 0x4768f8
481355: push 0x28
481357: push 0x2d
481359: push 0x46
48135b: push 0x82
481360: push 0x1
481362: push 0x0
481364: push 0x5
481366: push 0x0
481368: xor eax,eax
48136a: mov al,bl
48136c: mov ecx,0x1
481371: mov edx,0x1d
481376: call 0x4768f8
48137b: xor eax,eax
48137d: mov al,bl
48137f: imul eax,eax,0x16
481382: cmp BYTE PTR [esi+eax*8-0xa0],0x4
48138a: jne 0x4821bb
481390: xor eax,eax
481392: mov al,bl
481394: imul eax,eax,0x16
481397: cmp BYTE PTR [esi+eax*8-0x45],0x17
48139c: jne 0x4813bf
48139e: xor eax,eax
4813a0: mov al,bl
4813a2: imul eax,eax,0x16
4813a5: cmp WORD PTR [esi+eax*8-0x3c],0xd
4813ab: jge 0x4813bf
4813ad: xor eax,eax
4813af: mov al,bl
4813b1: imul eax,eax,0x16
4813b4: mov dl,BYTE PTR [esp+0x1]
4813b8: add dl,0x21
4813bb: mov BYTE PTR [esi+eax*8-0x44],dl
4813bf: xor eax,eax
4813c1: mov al,bl
4813c3: imul eax,eax,0x16
4813c6: cmp BYTE PTR [esi+eax*8-0x45],0x17
4813cb: jne 0x4813ee
4813cd: xor eax,eax
4813cf: mov al,bl
4813d1: imul eax,eax,0x16
4813d4: cmp WORD PTR [esi+eax*8-0x3c],0xd
4813da: jne 0x4813ee
4813dc: xor eax,eax
4813de: mov al,bl
4813e0: imul eax,eax,0x16
4813e3: mov dl,BYTE PTR [esp+0x1]
4813e7: add dl,0x22
4813ea: mov BYTE PTR [esi+eax*8-0x44],dl
4813ee: xor eax,eax
4813f0: mov al,bl
4813f2: imul eax,eax,0x16
4813f5: cmp BYTE PTR [esi+eax*8-0x45],0x18
4813fa: jne 0x48141d
4813fc: xor eax,eax
4813fe: mov al,bl
481400: imul eax,eax,0x16
481403: cmp WORD PTR [esi+eax*8-0x3c],0x0
481409: jne 0x48141d
48140b: xor eax,eax
48140d: mov al,bl
48140f: imul eax,eax,0x16
481412: mov dl,BYTE PTR [esp+0x1]
481416: add dl,0xc
481419: mov BYTE PTR [esi+eax*8-0x44],dl
48141d: xor eax,eax
48141f: mov al,bl
481421: imul eax,eax,0x16
481424: cmp BYTE PTR [esi+eax*8-0x45],0x18
481429: jne 0x48144c
48142b: xor eax,eax
48142d: mov al,bl
48142f: imul eax,eax,0x16
481432: cmp WORD PTR [esi+eax*8-0x3c],0x2
481438: jne 0x48144c
48143a: xor eax,eax
48143c: mov al,bl
48143e: imul eax,eax,0x16
481441: mov dl,BYTE PTR [esp+0x1]
481445: add dl,0x1e
481448: mov BYTE PTR [esi+eax*8-0x44],dl
48144c: xor eax,eax
48144e: mov al,bl
481450: imul eax,eax,0x16
481453: cmp BYTE PTR [esi+eax*8-0x45],0x19
481458: jne 0x481645
48145e: xor eax,eax
481460: mov al,bl
481462: imul eax,eax,0x16
481465: cmp WORD PTR [esi+eax*8-0x3c],0x0
48146b: jne 0x48147f
48146d: xor eax,eax
48146f: mov al,bl
481471: imul eax,eax,0x16
481474: mov dl,BYTE PTR [esp+0x1]
481478: add dl,0x23
48147b: mov BYTE PTR [esi+eax*8-0x44],dl
48147f: xor eax,eax
481481: mov al,bl
481483: imul eax,eax,0x16
481486: cmp WORD PTR [esi+eax*8-0x3c],0x5
48148c: jne 0x4814a0
48148e: xor eax,eax
481490: mov al,bl
481492: imul eax,eax,0x16
481495: mov dl,BYTE PTR [esp+0x1]
481499: add dl,0x24
48149c: mov BYTE PTR [esi+eax*8-0x44],dl
4814a0: xor eax,eax
4814a2: mov al,bl
4814a4: imul eax,eax,0x16
4814a7: cmp WORD PTR [esi+eax*8-0x3c],0xa
4814ad: jne 0x481645
4814b3: xor eax,eax
4814b5: mov al,bl
4814b7: imul eax,eax,0x16
4814ba: mov dl,BYTE PTR [esp+0x1]
4814be: add dl,0x25
4814c1: mov BYTE PTR [esi+eax*8-0x44],dl
4814c5: xor eax,eax
4814c7: mov al,bl
4814c9: imul eax,eax,0x16
4814cc: cmp BYTE PTR [esi+eax*8-0x43],0x1
4814d1: jne 0x481525
4814d3: xor eax,eax
4814d5: mov al,bl
4814d7: imul eax,eax,0x16
4814da: cmp BYTE PTR [esi+eax*8-0x41],0x1
4814df: jne 0x481525
4814e1: xor eax,eax
4814e3: mov al,bl
4814e5: imul eax,eax,0x16
4814e8: fld QWORD PTR [esi+eax*8-0xb0]
4814ef: fadd DWORD PTR ds:0x48dd10
4814f5: add esp,0xfffffff8
4814f8: fstp QWORD PTR [esp]
4814fb: fwait
4814fc: xor eax,eax
4814fe: mov al,bl
481500: imul eax,eax,0x16
481503: fld QWORD PTR [esi+eax*8-0xa8]
48150a: fsub DWORD PTR ds:0x48dcf4
481510: add esp,0xfffffff8
481513: fstp QWORD PTR [esp]
481516: fwait
481517: mov ecx,ebx
481519: mov edx,0x48dcd4
48151e: mov al,0xc
481520: call 0x476a04
481525: xor eax,eax
481527: mov al,bl
481529: imul eax,eax,0x16
48152c: cmp BYTE PTR [esi+eax*8-0x43],0x2
481531: jne 0x481585
481533: xor eax,eax
481535: mov al,bl
481537: imul eax,eax,0x16
48153a: cmp BYTE PTR [esi+eax*8-0x41],0x1
48153f: jne 0x481585
481541: xor eax,eax
481543: mov al,bl
481545: imul eax,eax,0x16
481548: fld QWORD PTR [esi+eax*8-0xb0]
48154f: fsub DWORD PTR ds:0x48dd10
481555: add esp,0xfffffff8
481558: fstp QWORD PTR [esp]
48155b: fwait
48155c: xor eax,eax
48155e: mov al,bl
481560: imul eax,eax,0x16
481563: fld QWORD PTR [esi+eax*8-0xa8]
48156a: fsub DWORD PTR ds:0x48dcf4
481570: add esp,0xfffffff8
481573: fstp QWORD PTR [esp]
481576: fwait
481577: mov ecx,ebx
481579: mov edx,0x48dcd4
48157e: mov al,0xc
481580: call 0x476a04
481585: xor eax,eax
481587: mov al,bl
481589: imul eax,eax,0x16
48158c: cmp BYTE PTR [esi+eax*8-0x43],0x1
481591: jne 0x4815e5
481593: xor eax,eax
481595: mov al,bl
481597: imul eax,eax,0x16
48159a: cmp BYTE PTR [esi+eax*8-0x41],0x2
48159f: jne 0x4815e5
4815a1: xor eax,eax
4815a3: mov al,bl
4815a5: imul eax,eax,0x16
4815a8: fld QWORD PTR [esi+eax*8-0xb0]
4815af: fadd DWORD PTR ds:0x48dd10
4815b5: add esp,0xfffffff8
4815b8: fstp QWORD PTR [esp]
4815bb: fwait
4815bc: xor eax,eax
4815be: mov al,bl
4815c0: imul eax,eax,0x16
4815c3: fld QWORD PTR [esi+eax*8-0xa8]
4815ca: fsub DWORD PTR ds:0x48dcf4
4815d0: add esp,0xfffffff8
4815d3: fstp QWORD PTR [esp]
4815d6: fwait
4815d7: mov ecx,ebx
4815d9: mov edx,0x48dce0
4815de: mov al,0xc
4815e0: call 0x476a04
4815e5: xor eax,eax
4815e7: mov al,bl
4815e9: imul eax,eax,0x16
4815ec: cmp BYTE PTR [esi+eax*8-0x43],0x2
4815f1: jne 0x481645
4815f3: xor eax,eax
4815f5: mov al,bl
4815f7: imul eax,eax,0x16
4815fa: cmp BYTE PTR [esi+eax*8-0x41],0x2
4815ff: jne 0x481645
481601: xor eax,eax
481603: mov al,bl
481605: imul eax,eax,0x16
481608: fld QWORD PTR [esi+eax*8-0xb0]
48160f: fsub DWORD PTR ds:0x48dd10
481615: add esp,0xfffffff8
481618: fstp QWORD PTR [esp]
48161b: fwait
48161c: xor eax,eax
48161e: mov al,bl
481620: imul eax,eax,0x16
481623: fld QWORD PTR [esi+eax*8-0xa8]
48162a: fsub DWORD PTR ds:0x48dcf4
481630: add esp,0xfffffff8
481633: fstp QWORD PTR [esp]
481636: fwait
481637: mov ecx,ebx
481639: mov edx,0x48dce0
48163e: mov al,0xc
481640: call 0x476a04
481645: xor eax,eax
481647: mov al,bl
481649: imul eax,eax,0x16
48164c: cmp BYTE PTR [esi+eax*8-0x45],0x1a
481651: jne 0x4817d0
481657: xor eax,eax
481659: mov al,bl
48165b: imul eax,eax,0x16
48165e: cmp WORD PTR [esi+eax*8-0x3c],0x0
481664: jne 0x481678
481666: xor eax,eax
481668: mov al,bl
48166a: imul eax,eax,0x16
48166d: mov dl,BYTE PTR [esp+0x1]
481671: add dl,0x23
481674: mov BYTE PTR [esi+eax*8-0x44],dl
481678: xor eax,eax
48167a: mov al,bl
48167c: imul eax,eax,0x16
48167f: cmp WORD PTR [esi+eax*8-0x3c],0x4
481685: jne 0x481699
481687: xor eax,eax
481689: mov al,bl
48168b: imul eax,eax,0x16
48168e: mov dl,BYTE PTR [esp+0x1]
481692: add dl,0x24
481695: mov BYTE PTR [esi+eax*8-0x44],dl
481699: xor eax,eax
48169b: mov al,bl
48169d: imul eax,eax,0x16
4816a0: cmp WORD PTR [esi+eax*8-0x3c],0x7
4816a6: jl 0x481766
4816ac: xor eax,eax
4816ae: mov al,bl
4816b0: imul eax,eax,0x16
4816b3: mov dl,BYTE PTR [esp+0x1]
4816b7: add dl,0x26
4816ba: mov BYTE PTR [esi+eax*8-0x44],dl
4816be: xor eax,eax
4816c0: mov al,bl
4816c2: imul eax,eax,0x16
4816c5: cmp BYTE PTR [esi+eax*8-0x43],0x1
4816ca: jne 0x4816e8
4816cc: xor eax,eax
4816ce: mov al,bl
4816d0: imul eax,eax,0x16
4816d3: cmp BYTE PTR [esi+eax*8-0x41],0x1
4816d8: jne 0x4816e8
4816da: push 0x403a0000
4816df: push 0x0
4816e1: mov eax,ebx
4816e3: call 0x47648c
4816e8: xor eax,eax
4816ea: mov al,bl
4816ec: imul eax,eax,0x16
4816ef: cmp BYTE PTR [esi+eax*8-0x43],0x2
4816f4: jne 0x481712
4816f6: xor eax,eax
4816f8: mov al,bl
4816fa: imul eax,eax,0x16
4816fd: cmp BYTE PTR [esi+eax*8-0x41],0x1
481702: jne 0x481712
481704: push 0xc03a0000
481709: push 0x0
48170b: mov eax,ebx
48170d: call 0x47648c
481712: xor eax,eax
481714: mov al,bl
481716: imul eax,eax,0x16
481719: cmp BYTE PTR [esi+eax*8-0x43],0x1
48171e: jne 0x48173c
481720: xor eax,eax
481722: mov al,bl
481724: imul eax,eax,0x16
481727: cmp BYTE PTR [esi+eax*8-0x41],0x2
48172c: jne 0x48173c
48172e: push 0x40390000
481733: push 0x0
481735: mov eax,ebx
481737: call 0x47648c
48173c: xor eax,eax
48173e: mov al,bl
481740: imul eax,eax,0x16
481743: cmp BYTE PTR [esi+eax*8-0x43],0x2
481748: jne 0x481766
48174a: xor eax,eax
48174c: mov al,bl
48174e: imul eax,eax,0x16
481751: cmp BYTE PTR [esi+eax*8-0x41],0x2
481756: jne 0x481766
481758: push 0xc0390000
48175d: push 0x0
48175f: mov eax,ebx
481761: call 0x47648c
481766: mov BYTE PTR [esp],0x3
48176a: mov eax,0x28
48176f: call 0x402a1c
481774: mov DWORD PTR [esp+0x4],eax
481778: fild DWORD PTR [esp+0x4]
48177c: xor eax,eax
48177e: mov al,bl
481780: imul eax,eax,0x16
481783: fld QWORD PTR [esi+eax*8-0xb0]
48178a: fsub DWORD PTR ds:0x48dce4
481790: faddp st(1),st
481792: add esp,0xfffffff8
481795: fstp QWORD PTR [esp]
481798: fwait
481799: mov eax,0xa
48179e: call 0x402a1c
4817a3: mov DWORD PTR [esp+0x10],eax
4817a7: fild DWORD PTR [esp+0x10]
4817ab: xor eax,eax
4817ad: mov al,bl
4817af: imul eax,eax,0x16
4817b2: fadd QWORD PTR [esi+eax*8-0xa8]
4817b9: add esp,0xfffffff8
4817bc: fstp QWORD PTR [esp]
4817bf: fwait
4817c0: xor ecx,ecx
4817c2: xor edx,edx
4817c4: mov al,0x2
4817c6: call 0x476a04
4817cb: dec BYTE PTR [esp]
4817ce: jne 0x48176a
4817d0: xor eax,eax
4817d2: mov al,bl
4817d4: imul eax,eax,0x16
4817d7: cmp BYTE PTR [esi+eax*8-0x45],0x1b
4817dc: jne 0x481929
4817e2: xor eax,eax
4817e4: mov al,bl
4817e6: imul eax,eax,0x16
4817e9: cmp WORD PTR [esi+eax*8-0x3c],0x0
4817ef: jne 0x481803
4817f1: xor eax,eax
4817f3: mov al,bl
4817f5: imul eax,eax,0x16
4817f8: mov dl,BYTE PTR [esp+0x1]
4817fc: add dl,0xc
4817ff: mov BYTE PTR [esi+eax*8-0x44],dl
481803: xor eax,eax
481805: mov al,bl
481807: imul eax,eax,0x16
48180a: cmp WORD PTR [esi+eax*8-0x3c],0x2
481810: jne 0x481824
481812: xor eax,eax
481814: mov al,bl
481816: imul eax,eax,0x16
481819: mov dl,BYTE PTR [esp+0x1]
48181d: add dl,0x27
481820: mov BYTE PTR [esi+eax*8-0x44],dl
481824: xor eax,eax
481826: mov al,bl
481828: imul eax,eax,0x16
48182b: cmp WORD PTR [esi+eax*8-0x3c],0x6
481831: jne 0x481845
481833: xor eax,eax
481835: mov al,bl
481837: imul eax,eax,0x16
48183a: mov dl,BYTE PTR [esp+0x1]
48183e: add dl,0x28
481841: mov BYTE PTR [esi+eax*8-0x44],dl
481845: xor eax,eax
481847: mov al,bl
481849: imul eax,eax,0x16
48184c: cmp WORD PTR [esi+eax*8-0x3c],0x9
481852: jne 0x481866
481854: xor eax,eax
481856: mov al,bl
481858: imul eax,eax,0x16
48185b: mov dl,BYTE PTR [esp+0x1]
48185f: add dl,0x29
481862: mov BYTE PTR [esi+eax*8-0x44],dl
481866: xor eax,eax
481868: mov al,bl
48186a: imul eax,eax,0x16
48186d: cmp BYTE PTR [esi+eax*8-0x43],0x1
481872: jne 0x481890
481874: xor eax,eax
481876: mov al,bl
481878: imul eax,eax,0x16
48187b: cmp BYTE PTR [esi+eax*8-0x41],0x1
481880: jne 0x481890
481882: push 0x40240000
481887: push 0x0
481889: mov eax,ebx
48188b: call 0x47648c
481890: xor eax,eax
481892: mov al,bl
481894: imul eax,eax,0x16
481897: cmp BYTE PTR [esi+eax*8-0x43],0x2
48189c: jne 0x4818ba
48189e: xor eax,eax
4818a0: mov al,bl
4818a2: imul eax,eax,0x16
4818a5: cmp BYTE PTR [esi+eax*8-0x41],0x1
4818aa: jne 0x4818ba
4818ac: push 0xc0240000
4818b1: push 0x0
4818b3: mov eax,ebx
4818b5: call 0x47648c
4818ba: xor eax,eax
4818bc: mov al,bl
4818be: imul eax,eax,0x16
4818c1: cmp BYTE PTR [esi+eax*8-0x43],0x1
4818c6: jne 0x4818e4
4818c8: xor eax,eax
4818ca: mov al,bl
4818cc: imul eax,eax,0x16
4818cf: cmp BYTE PTR [esi+eax*8-0x41],0x2
4818d4: jne 0x4818e4
4818d6: push 0x402a0000
4818db: push 0x0
4818dd: mov eax,ebx
4818df: call 0x47648c
4818e4: xor eax,eax
4818e6: mov al,bl
4818e8: imul eax,eax,0x16
4818eb: cmp BYTE PTR [esi+eax*8-0x43],0x2
4818f0: jne 0x48190e
4818f2: xor eax,eax
4818f4: mov al,bl
4818f6: imul eax,eax,0x16
4818f9: cmp BYTE PTR [esi+eax*8-0x41],0x2
4818fe: jne 0x48190e
481900: push 0xc02a0000
481905: push 0x0
481907: mov eax,ebx
481909: call 0x47648c
48190e: xor eax,eax
481910: mov al,bl
481912: imul eax,eax,0x16
481915: cmp WORD PTR [esi+eax*8-0x3c],0x6
48191b: jl 0x481929
48191d: xor eax,eax
48191f: mov al,bl
481921: imul eax,eax,0x16
481924: mov BYTE PTR [esi+eax*8-0x47],0x1
481929: xor eax,eax
48192b: mov al,bl
48192d: imul eax,eax,0x16
481930: cmp BYTE PTR [esi+eax*8-0x45],0x1c
481935: jne 0x481a8d
48193b: xor eax,eax
48193d: mov al,bl
48193f: imul eax,eax,0x16
481942: cmp WORD PTR [esi+eax*8-0x3c],0x0
481948: jne 0x48195c
48194a: xor eax,eax
48194c: mov al,bl
48194e: imul eax,eax,0x16
481951: mov dl,BYTE PTR [esp+0x1]
481955: add dl,0x2a
481958: mov BYTE PTR [esi+eax*8-0x44],dl
48195c: xor eax,eax
48195e: mov al,bl
481960: imul eax,eax,0x16
481963: cmp WORD PTR [esi+eax*8-0x3c],0x2
481969: jne 0x48197d
48196b: xor eax,eax
48196d: mov al,bl
48196f: imul eax,eax,0x16
481972: mov dl,BYTE PTR [esp+0x1]
481976: add dl,0x2b
481979: mov BYTE PTR [esi+eax*8-0x44],dl
48197d: xor eax,eax
48197f: mov al,bl
481981: imul eax,eax,0x16
481984: cmp WORD PTR [esi+eax*8-0x3c],0x4
48198a: jne 0x48199e
48198c: xor eax,eax
48198e: mov al,bl
481990: imul eax,eax,0x16
481993: mov dl,BYTE PTR [esp+0x1]
481997: add dl,0x2c
48199a: mov BYTE PTR [esi+eax*8-0x44],dl
48199e: xor eax,eax
4819a0: mov al,bl
4819a2: imul eax,eax,0x16
4819a5: cmp WORD PTR [esi+eax*8-0x3c],0x6
4819ab: jne 0x4819bf
4819ad: xor eax,eax
4819af: mov al,bl
4819b1: imul eax,eax,0x16
4819b4: mov dl,BYTE PTR [esp+0x1]
4819b8: add dl,0x2d
4819bb: mov BYTE PTR [esi+eax*8-0x44],dl
4819bf: xor eax,eax
4819c1: mov al,bl
4819c3: imul eax,eax,0x16
4819c6: cmp WORD PTR [esi+eax*8-0x3c],0x2
4819cc: jl 0x481a8d
4819d2: xor eax,eax
4819d4: mov al,bl
4819d6: imul eax,eax,0x16
4819d9: cmp WORD PTR [esi+eax*8-0x3c],0x6
4819df: jge 0x481a8d
4819e5: xor eax,eax
4819e7: mov al,bl
4819e9: imul eax,eax,0x16
4819ec: cmp BYTE PTR [esi+eax*8-0x43],0x1
4819f1: jne 0x481a0f
4819f3: xor eax,eax
4819f5: mov al,bl
4819f7: imul eax,eax,0x16
4819fa: cmp BYTE PTR [esi+eax*8-0x41],0x1
4819ff: jne 0x481a0f
481a01: push 0x40220000
481a06: push 0x0
481a08: mov eax,ebx
481a0a: call 0x47648c
481a0f: xor eax,eax
481a11: mov al,bl
481a13: imul eax,eax,0x16
481a16: cmp BYTE PTR [esi+eax*8-0x43],0x2
481a1b: jne 0x481a39
481a1d: xor eax,eax
481a1f: mov al,bl
481a21: imul eax,eax,0x16
481a24: cmp BYTE PTR [esi+eax*8-0x41],0x1
481a29: jne 0x481a39
481a2b: push 0xc0220000
481a30: push 0x0
481a32: mov eax,ebx
481a34: call 0x47648c
481a39: xor eax,eax
481a3b: mov al,bl
481a3d: imul eax,eax,0x16
481a40: cmp BYTE PTR [esi+eax*8-0x43],0x1
481a45: jne 0x481a63
481a47: xor eax,eax
481a49: mov al,bl
481a4b: imul eax,eax,0x16
481a4e: cmp BYTE PTR [esi+eax*8-0x41],0x2
481a53: jne 0x481a63
481a55: push 0x40320000
481a5a: push 0x0
481a5c: mov eax,ebx
481a5e: call 0x47648c
481a63: xor eax,eax
481a65: mov al,bl
481a67: imul eax,eax,0x16
481a6a: cmp BYTE PTR [esi+eax*8-0x43],0x2
481a6f: jne 0x481a8d
481a71: xor eax,eax
481a73: mov al,bl
481a75: imul eax,eax,0x16
481a78: cmp BYTE PTR [esi+eax*8-0x41],0x2
481a7d: jne 0x481a8d
481a7f: push 0xc0320000
481a84: push 0x0
481a86: mov eax,ebx
481a88: call 0x47648c
481a8d: xor eax,eax
481a8f: mov al,bl
481a91: imul eax,eax,0x16
481a94: cmp BYTE PTR [esi+eax*8-0x45],0x1d
481a99: jne 0x481c84
481a9f: xor eax,eax
481aa1: mov al,bl
481aa3: imul eax,eax,0x16
481aa6: cmp WORD PTR [esi+eax*8-0x3c],0x0
481aac: jne 0x481ac8
481aae: xor eax,eax
481ab0: mov al,bl
481ab2: imul eax,eax,0x16
481ab5: mov dl,BYTE PTR [esp+0x1]
481ab9: add dl,0xc
481abc: mov BYTE PTR [esi+eax*8-0x44],dl
481ac0: mov eax,ds:0x4b1098
481ac5: mov BYTE PTR [eax],0x1c
481ac8: xor eax,eax
481aca: mov al,bl
481acc: imul eax,eax,0x16
481acf: cmp WORD PTR [esi+eax*8-0x3c],0x1
481ad5: jne 0x481ae9
481ad7: xor eax,eax
481ad9: mov al,bl
481adb: imul eax,eax,0x16
481ade: mov dl,BYTE PTR [esp+0x1]
481ae2: add dl,0x27
481ae5: mov BYTE PTR [esi+eax*8-0x44],dl
481ae9: xor eax,eax
481aeb: mov al,bl
481aed: imul eax,eax,0x16
481af0: cmp WORD PTR [esi+eax*8-0x3c],0x5
481af6: jne 0x481b0a
481af8: xor eax,eax
481afa: mov al,bl
481afc: imul eax,eax,0x16
481aff: mov dl,BYTE PTR [esp+0x1]
481b03: add dl,0x28
481b06: mov BYTE PTR [esi+eax*8-0x44],dl
481b0a: xor eax,eax
481b0c: mov al,bl
481b0e: imul eax,eax,0x16
481b11: cmp WORD PTR [esi+eax*8-0x3c],0x9
481b17: jne 0x481b2b
481b19: xor eax,eax
481b1b: mov al,bl
481b1d: imul eax,eax,0x16
481b20: mov dl,BYTE PTR [esp+0x1]
481b24: add dl,0x29
481b27: mov BYTE PTR [esi+eax*8-0x44],dl
481b2b: xor eax,eax
481b2d: mov al,bl
481b2f: imul eax,eax,0x16
481b32: cmp BYTE PTR [esi+eax*8-0x43],0x1
481b37: jne 0x481b47
481b39: push 0x40310000
481b3e: push 0x0
481b40: mov eax,ebx
481b42: call 0x47648c
481b47: xor eax,eax
481b49: mov al,bl
481b4b: imul eax,eax,0x16
481b4e: cmp BYTE PTR [esi+eax*8-0x43],0x2
481b53: jne 0x481b63
481b55: push 0xc0310000
481b5a: push 0x0
481b5c: mov eax,ebx
481b5e: call 0x47648c
481b63: xor eax,eax
481b65: mov al,bl
481b67: imul eax,eax,0x16
481b6a: cmp WORD PTR [esi+eax*8-0x3c],0x1
481b70: jle 0x481c84
481b76: xor eax,eax
481b78: mov al,bl
481b7a: imul eax,eax,0x16
481b7d: cmp WORD PTR [esi+eax*8-0x3c],0xa
481b83: jge 0x481c84
481b89: mov BYTE PTR [esp],0x3
481b8d: xor eax,eax
481b8f: mov al,bl
481b91: imul eax,eax,0x16
481b94: cmp BYTE PTR [esi+eax*8-0x43],0x1
481b99: jne 0x481c04
481b9b: mov eax,0x1e
481ba0: call 0x402a1c
481ba5: mov DWORD PTR [esp+0x4],eax
481ba9: fild DWORD PTR [esp+0x4]
481bad: xor eax,eax
481baf: mov al,bl
481bb1: imul eax,eax,0x16
481bb4: fld QWORD PTR [esi+eax*8-0xb0]
481bbb: fadd DWORD PTR ds:0x48dce4
481bc1: faddp st(1),st
481bc3: add esp,0xfffffff8
481bc6: fstp QWORD PTR [esp]
481bc9: fwait
481bca: mov eax,0x28
481bcf: call 0x402a1c
481bd4: mov DWORD PTR [esp+0x10],eax
481bd8: fild DWORD PTR [esp+0x10]
481bdc: xor eax,eax
481bde: mov al,bl
481be0: imul eax,eax,0x16
481be3: fld QWORD PTR [esi+eax*8-0xa8]
481bea: fsub DWORD PTR ds:0x48dcf4
481bf0: faddp st(1),st
481bf2: add esp,0xfffffff8
481bf5: fstp QWORD PTR [esp]
481bf8: fwait
481bf9: xor ecx,ecx
481bfb: xor edx,edx
481bfd: mov al,0xb
481bff: call 0x476a04
481c04: xor eax,eax
481c06: mov al,bl
481c08: imul eax,eax,0x16
481c0b: cmp BYTE PTR [esi+eax*8-0x43],0x2
481c10: jne 0x481c7b
481c12: mov eax,0x1e
481c17: call 0x402a1c
481c1c: mov DWORD PTR [esp+0x4],eax
481c20: fild DWORD PTR [esp+0x4]
481c24: xor eax,eax
481c26: mov al,bl
481c28: imul eax,eax,0x16
481c2b: fld QWORD PTR [esi+eax*8-0xb0]
481c32: fsub DWORD PTR ds:0x48dce4
481c38: fsubrp st(1),st
481c3a: add esp,0xfffffff8
481c3d: fstp QWORD PTR [esp]
481c40: fwait
481c41: mov eax,0x28
481c46: call 0x402a1c
481c4b: mov DWORD PTR [esp+0x10],eax
481c4f: fild DWORD PTR [esp+0x10]
481c53: xor eax,eax
481c55: mov al,bl
481c57: imul eax,eax,0x16
481c5a: fld QWORD PTR [esi+eax*8-0xa8]
481c61: fsub DWORD PTR ds:0x48dcf4
481c67: faddp st(1),st
481c69: add esp,0xfffffff8
481c6c: fstp QWORD PTR [esp]
481c6f: fwait
481c70: xor ecx,ecx
481c72: xor edx,edx
481c74: mov al,0xb
481c76: call 0x476a04
481c7b: dec BYTE PTR [esp]
481c7e: jne 0x481b8d
481c84: push 0x14
481c86: push 0xe
481c88: push 0xa0
481c8d: xor edx,edx
481c8f: mov dl,BYTE PTR [esp+0xd]
481c93: inc edx
481c94: xor eax,eax
481c96: mov al,bl
481c98: mov ecx,0xffffffef
481c9d: call 0x476870
481ca2: push 0x14
481ca4: push 0xe
481ca6: push 0xa0
481cab: xor edx,edx
481cad: mov dl,BYTE PTR [esp+0xd]
481cb1: add edx,0x2
481cb4: xor eax,eax
481cb6: mov al,bl
481cb8: mov ecx,0xffffffef
481cbd: call 0x476870
481cc2: push 0x14
481cc4: push 0xe
481cc6: push 0xa0
481ccb: xor edx,edx
481ccd: mov dl,BYTE PTR [esp+0xd]
481cd1: add edx,0x3
481cd4: xor eax,eax
481cd6: mov al,bl
481cd8: mov ecx,0xffffffef
481cdd: call 0x476870
481ce2: push 0x14
481ce4: push 0xe
481ce6: push 0xa0
481ceb: xor edx,edx
481ced: mov dl,BYTE PTR [esp+0xd]
481cf1: add edx,0x4
481cf4: xor eax,eax
481cf6: mov al,bl
481cf8: mov ecx,0xffffffef
481cfd: call 0x476870
481d02: push 0x14
481d04: push 0xe
481d06: push 0xa0
481d0b: xor edx,edx
481d0d: mov dl,BYTE PTR [esp+0xd]
481d11: add edx,0x6
481d14: xor eax,eax
481d16: mov al,bl
481d18: mov ecx,0xffffffef
481d1d: call 0x476870
481d22: push 0x14
481d24: push 0xe
481d26: push 0xa0
481d2b: xor edx,edx
481d2d: mov dl,BYTE PTR [esp+0xd]
481d31: add edx,0x8
481d34: xor eax,eax
481d36: mov al,bl
481d38: mov ecx,0xffffffef
481d3d: call 0x476870
481d42: push 0x3c
481d44: push 0xe
481d46: push 0xa0
481d4b: xor edx,edx
481d4d: mov dl,BYTE PTR [esp+0xd]
481d51: add edx,0xa
481d54: xor eax,eax
481d56: mov al,bl
481d58: mov ecx,0xffffffef
481d5d: call 0x476870
481d62: push 0x41
481d64: push 0xe
481d66: push 0xa0
481d6b: xor edx,edx
481d6d: mov dl,BYTE PTR [esp+0xd]
481d71: add edx,0xc
481d74: xor eax,eax
481d76: mov al,bl
481d78: mov ecx,0xffffffef
481d7d: call 0x476870
481d82: push 0x41
481d84: push 0xe
481d86: push 0xa0
481d8b: xor edx,edx
481d8d: mov dl,BYTE PTR [esp+0xd]
481d91: add edx,0xd
481d94: xor eax,eax
481d96: mov al,bl
481d98: mov ecx,0xffffffef
481d9d: call 0x476870
481da2: push 0x41
481da4: push 0xe
481da6: push 0xa0
481dab: xor edx,edx
481dad: mov dl,BYTE PTR [esp+0xd]
481db1: add edx,0xf
481db4: xor eax,eax
481db6: mov al,bl
481db8: mov ecx,0xffffffef
481dbd: call 0x476870
481dc2: push 0x41
481dc4: push 0xe
481dc6: push 0xa0
481dcb: xor edx,edx
481dcd: mov dl,BYTE PTR [esp+0xd]
481dd1: add edx,0x11
481dd4: xor eax,eax
481dd6: mov al,bl
481dd8: mov ecx,0xffffffef
481ddd: call 0x476870
481de2: push 0x41
481de4: push 0xe
481de6: push 0xa0
481deb: xor edx,edx
481ded: mov dl,BYTE PTR [esp+0xd]
481df1: add edx,0x13
481df4: xor eax,eax
481df6: mov al,bl
481df8: mov ecx,0xffffffef
481dfd: call 0x476870
481e02: push 0x19
481e04: push 0xe
481e06: push 0x78
481e08: xor edx,edx
481e0a: mov dl,BYTE PTR [esp+0xd]
481e0e: add edx,0x15
481e11: xor eax,eax
481e13: mov al,bl
481e15: mov ecx,0xffffffef
481e1a: call 0x476870
481e1f: push 0x32
481e21: push 0x18
481e23: push 0x64
481e25: xor edx,edx
481e27: mov dl,BYTE PTR [esp+0xd]
481e2b: add edx,0x1c
481e2e: xor eax,eax
481e30: mov al,bl
481e32: mov ecx,0xffffffe5
481e37: call 0x476870
481e3c: push 0x6e
481e3e: push 0x18
481e40: push 0xa0
481e45: xor edx,edx
481e47: mov dl,BYTE PTR [esp+0xd]
481e4b: add edx,0x1d
481e4e: xor eax,eax
481e50: mov al,bl
481e52: mov ecx,0xffffffe5
481e57: call 0x476870
481e5c: push 0x14
481e5e: push 0xe
481e60: push 0xa0
481e65: xor edx,edx
481e67: mov dl,BYTE PTR [esp+0xd]
481e6b: add edx,0x1f
481e6e: xor eax,eax
481e70: mov al,bl
481e72: mov ecx,0xffffffef
481e77: call 0x476870
481e7c: push 0x41
481e7e: push 0xe
481e80: push 0xa0
481e85: xor edx,edx
481e87: mov dl,BYTE PTR [esp+0xd]
481e8b: add edx,0x20
481e8e: xor eax,eax
481e90: mov al,bl
481e92: mov ecx,0xffffffef
481e97: call 0x476870
481e9c: push 0x14
481e9e: push 0xe
481ea0: push 0xa0
481ea5: xor edx,edx
481ea7: mov dl,BYTE PTR [esp+0xd]
481eab: add edx,0x23
481eae: xor eax,eax
481eb0: mov al,bl
481eb2: mov ecx,0xffffffef
481eb7: call 0x476870
481ebc: push 0x28
481ebe: push 0x37
481ec0: push 0xa0
481ec5: xor edx,edx
481ec7: mov dl,BYTE PTR [esp+0xd]
481ecb: add edx,0x26
481ece: xor eax,eax
481ed0: mov al,bl
481ed2: mov ecx,0xfffffff6
481ed7: call 0x476870
481edc: push 0x32
481ede: push 0x19
481ee0: push 0x46
481ee2: xor edx,edx
481ee4: mov dl,BYTE PTR [esp+0xd]
481ee8: add edx,0x27
481eeb: xor eax,eax
481eed: mov al,bl
481eef: mov ecx,0xffffffd8
481ef4: call 0x476870
481ef9: push 0x14
481efb: push 0x14
481efd: push 0x96
481f02: xor edx,edx
481f04: mov dl,BYTE PTR [esp+0xd]
481f08: add edx,0x2b
481f0b: xor eax,eax
481f0d: mov al,bl
481f0f: mov ecx,0xfffffff4
481f14: call 0x476870
481f19: push 0x12
481f1b: push 0x23
481f1d: push 0x3c
481f1f: push 0x30
481f21: push 0x1
481f23: push 0x1
481f25: push 0x7
481f27: push 0x0
481f29: xor eax,eax
481f2b: mov al,bl
481f2d: mov ecx,0x2
481f32: mov edx,0x3
481f37: call 0x4768f8
481f3c: push 0x14
481f3e: push 0x32
481f40: push 0x50
481f42: push 0x50
481f44: push 0x1
481f46: push 0x1
481f48: push 0x7
481f4a: push 0x0
481f4c: xor eax,eax
481f4e: mov al,bl
481f50: mov ecx,0x2
481f55: mov edx,0x4
481f5a: call 0x4768f8
481f5f: push 0x14
481f61: push 0x23
481f63: push 0x46
481f65: push 0x2d
481f67: push 0x1
481f69: push 0x2
481f6b: push 0xe
481f6d: push 0x0
481f6f: xor eax,eax
481f71: mov al,bl
481f73: mov ecx,0x5
481f78: mov edx,0x5
481f7d: call 0x4768f8
481f82: push 0x14
481f84: push 0x6e
481f86: push 0x50
481f88: push 0x96
481f8d: push 0x1
481f8f: push 0x2
481f91: push 0xe
481f93: push 0x0
481f95: xor eax,eax
481f97: mov al,bl
481f99: mov ecx,0x5
481f9e: mov edx,0x6
481fa3: call 0x4768f8
481fa8: push 0xf
481faa: push 0x50
481fac: push 0x32
481fae: push 0x5a
481fb0: push 0x1
481fb2: push 0x1
481fb4: push 0x7
481fb6: push 0x0
481fb8: xor eax,eax
481fba: mov al,bl
481fbc: mov ecx,0x2
481fc1: mov edx,0x8
481fc6: call 0x4768f8
481fcb: push 0x14
481fcd: push 0x87
481fd2: push 0x4b
481fd4: push 0x96
481fd9: push 0x1
481fdb: push 0x1
481fdd: push 0x7
481fdf: push 0x0
481fe1: xor eax,eax
481fe3: mov al,bl
481fe5: mov ecx,0x2
481fea: mov edx,0x9
481fef: call 0x4768f8
481ff4: push 0xf
481ff6: push 0x50
481ff8: push 0x43
481ffa: push 0x5a
481ffc: push 0x1
481ffe: push 0x2
482000: push 0xe
482002: push 0x0
482004: xor eax,eax
482006: mov al,bl
482008: mov ecx,0x5
48200d: mov edx,0xa
482012: call 0x4768f8
482017: push 0xf
482019: push 0x6e
48201b: push 0x55
48201d: push 0x7d
48201f: push 0x1
482021: push 0x2
482023: push 0xe
482025: push 0x0
482027: xor eax,eax
482029: mov al,bl
48202b: mov ecx,0x5
482030: mov edx,0xb
482035: call 0x4768f8
48203a: push 0x14
48203c: push 0x41
48203e: push 0x32
482040: push 0x61
482042: push 0x1
482044: push 0x1
482046: push 0x7
482048: push 0x0
48204a: xor eax,eax
48204c: mov al,bl
48204e: mov ecx,0x2
482053: mov edx,0xd
482058: call 0x4768f8
48205d: push 0x14
48205f: push 0x5a
482061: push 0x4b
482063: push 0x73
482065: push 0x1
482067: push 0x1
482069: push 0x7
48206b: push 0x0
48206d: xor eax,eax
48206f: mov al,bl
482071: mov ecx,0x2
482076: mov edx,0xe
48207b: call 0x4768f8
482080: push 0x14
482082: push 0x41
482084: push 0x32
482086: push 0x61
482088: push 0x1
48208a: push 0x2
48208c: push 0xe
48208e: push 0x0
482090: xor eax,eax
482092: mov al,bl
482094: mov ecx,0x5
482099: mov edx,0xf
48209e: call 0x4768f8
4820a3: push 0x14
4820a5: push 0x5a
4820a7: push 0x4b
4820a9: push 0x73
4820ab: push 0x1
4820ad: push 0x2
4820af: push 0xe
4820b1: push 0x0
4820b3: xor eax,eax
4820b5: mov al,bl
4820b7: mov ecx,0x5
4820bc: mov edx,0x10
4820c1: call 0x4768f8
4820c6: push 0x1e
4820c8: push 0x37
4820ca: push 0x5a
4820cc: push 0x55
4820ce: push 0x1
4820d0: push 0x0
4820d2: push 0x14
4820d4: push 0x3
4820d6: xor eax,eax
4820d8: mov al,bl
4820da: mov ecx,0x3
4820df: mov edx,0x1a
4820e4: call 0x4768f8
4820e9: push 0x14
4820eb: push 0x1e
4820ed: push 0x4b
4820ef: push 0x46
4820f1: push 0x1
4820f3: push 0x0
4820f5: push 0x5
4820f7: push 0x1
4820f9: xor eax,eax
4820fb: mov al,bl
4820fd: mov ecx,0x4
482102: mov edx,0x1b
482107: call 0x4768f8
48210c: push 0xa
48210e: push 0x1e
482110: push 0x4b
482112: push 0x46
482114: push 0x1
482116: push 0x0
482118: push 0x9
48211a: push 0x1
48211c: xor eax,eax
48211e: mov al,bl
482120: mov ecx,0x5
482125: mov edx,0x1b
48212a: call 0x4768f8
48212f: push 0xa
482131: push 0x1e
482133: push 0x4b
482135: push 0x46
482137: push 0x1
482139: push 0x0
48213b: push 0x7
48213d: push 0x2
48213f: xor eax,eax
482141: mov al,bl
482143: mov ecx,0x6
482148: mov edx,0x1b
48214d: call 0x4768f8
482152: push 0x14
482154: push 0x0
482156: push 0x37
482158: push 0x5f
48215a: push 0x1
48215c: push 0x0
48215e: push 0x16
482160: push 0x3
482162: xor eax,eax
482164: mov al,bl
482166: mov ecx,0x2
48216b: mov edx,0x1c
482170: call 0x4768f8
482175: push 0x14
482177: push 0x0
482179: push 0x37
48217b: push 0x5f
48217d: push 0x0
48217f: push 0x0
482181: push 0x0
482183: push 0x0
482185: xor eax,eax
482187: mov al,bl
482189: mov ecx,0x7
48218e: mov edx,0x1c
482193: call 0x4768f8
482198: push 0xa
48219a: push 0x1e
48219c: push 0x4b
48219e: push 0x46
4821a0: push 0x1
4821a2: push 0x2
4821a4: push 0x28
4821a6: push 0x8
4821a8: xor eax,eax
4821aa: mov al,bl
4821ac: mov ecx,0x2
4821b1: mov edx,0x1d
4821b6: call 0x4768f8
4821bb: xor eax,eax
4821bd: mov al,bl
4821bf: imul eax,eax,0x16
4821c2: cmp BYTE PTR [esi+eax*8-0xa0],0x5
4821ca: jne 0x4833f4
4821d0: xor eax,eax
4821d2: mov al,bl
4821d4: imul eax,eax,0x16
4821d7: cmp BYTE PTR [esi+eax*8-0x45],0x17
4821dc: jne 0x4821ff
4821de: xor eax,eax
4821e0: mov al,bl
4821e2: imul eax,eax,0x16
4821e5: cmp WORD PTR [esi+eax*8-0x3c],0x5
4821eb: jge 0x4821ff
4821ed: xor eax,eax
4821ef: mov al,bl
4821f1: imul eax,eax,0x16
4821f4: mov dl,BYTE PTR [esp+0x1]
4821f8: add dl,0x21
4821fb: mov BYTE PTR [esi+eax*8-0x44],dl
4821ff: xor eax,eax
482201: mov al,bl
482203: imul eax,eax,0x16
482206: cmp BYTE PTR [esi+eax*8-0x45],0x17
48220b: jne 0x48222e
48220d: xor eax,eax
48220f: mov al,bl
482211: imul eax,eax,0x16
482214: cmp WORD PTR [esi+eax*8-0x3c],0x9
48221a: jne 0x48222e
48221c: xor eax,eax
48221e: mov al,bl
482220: imul eax,eax,0x16
482223: mov dl,BYTE PTR [esp+0x1]
482227: add dl,0x22
48222a: mov BYTE PTR [esi+eax*8-0x44],dl
48222e: xor eax,eax
482230: mov al,bl
482232: imul eax,eax,0x16
482235: cmp BYTE PTR [esi+eax*8-0x45],0x17
48223a: jne 0x48225d
48223c: xor eax,eax
48223e: mov al,bl
482240: imul eax,eax,0x16
482243: cmp WORD PTR [esi+eax*8-0x3c],0xd
482249: jne 0x48225d
48224b: xor eax,eax
48224d: mov al,bl
48224f: imul eax,eax,0x16
482252: mov dl,BYTE PTR [esp+0x1]
482256: add dl,0x21
482259: mov BYTE PTR [esi+eax*8-0x44],dl
48225d: xor eax,eax
48225f: mov al,bl
482261: imul eax,eax,0x16
482264: cmp BYTE PTR [esi+eax*8-0x45],0x17
482269: jne 0x48228c
48226b: xor eax,eax
48226d: mov al,bl
48226f: imul eax,eax,0x16
482272: cmp WORD PTR [esi+eax*8-0x3c],0x11
482278: jne 0x48228c
48227a: xor eax,eax
48227c: mov al,bl
48227e: imul eax,eax,0x16
482281: mov dl,BYTE PTR [esp+0x1]
482285: add dl,0x22
482288: mov BYTE PTR [esi+eax*8-0x44],dl
48228c: xor eax,eax
48228e: mov al,bl
482290: imul eax,eax,0x16
482293: cmp BYTE PTR [esi+eax*8-0x45],0x17
482298: jne 0x4822bb
48229a: xor eax,eax
48229c: mov al,bl
48229e: imul eax,eax,0x16
4822a1: cmp WORD PTR [esi+eax*8-0x3c],0x15
4822a7: jne 0x4822bb
4822a9: xor eax,eax
4822ab: mov al,bl
4822ad: imul eax,eax,0x16
4822b0: mov dl,BYTE PTR [esp+0x1]
4822b4: add dl,0x21
4822b7: mov BYTE PTR [esi+eax*8-0x44],dl
4822bb: xor eax,eax
4822bd: mov al,bl
4822bf: imul eax,eax,0x16
4822c2: cmp BYTE PTR [esi+eax*8-0x45],0x17
4822c7: jne 0x4822ea
4822c9: xor eax,eax
4822cb: mov al,bl
4822cd: imul eax,eax,0x16
4822d0: cmp WORD PTR [esi+eax*8-0x3c],0x19
4822d6: jne 0x4822ea
4822d8: xor eax,eax
4822da: mov al,bl
4822dc: imul eax,eax,0x16
4822df: mov dl,BYTE PTR [esp+0x1]
4822e3: add dl,0x22
4822e6: mov BYTE PTR [esi+eax*8-0x44],dl
4822ea: xor eax,eax
4822ec: mov al,bl
4822ee: imul eax,eax,0x16
4822f1: cmp BYTE PTR [esi+eax*8-0x45],0x17
4822f6: jne 0x482319
4822f8: xor eax,eax
4822fa: mov al,bl
4822fc: imul eax,eax,0x16
4822ff: cmp WORD PTR [esi+eax*8-0x3c],0x1d
482305: jne 0x482319
482307: xor eax,eax
482309: mov al,bl
48230b: imul eax,eax,0x16
48230e: mov dl,BYTE PTR [esp+0x1]
482312: add dl,0x21
482315: mov BYTE PTR [esi+eax*8-0x44],dl
482319: xor eax,eax
48231b: mov al,bl
48231d: imul eax,eax,0x16
482320: cmp BYTE PTR [esi+eax*8-0x45],0x17
482325: jne 0x482348
482327: xor eax,eax
482329: mov al,bl
48232b: imul eax,eax,0x16
48232e: cmp WORD PTR [esi+eax*8-0x3c],0x21
482334: jne 0x482348
482336: xor eax,eax
482338: mov al,bl
48233a: imul eax,eax,0x16
48233d: mov dl,BYTE PTR [esp+0x1]
482341: add dl,0x22
482344: mov BYTE PTR [esi+eax*8-0x44],dl
482348: xor eax,eax
48234a: mov al,bl
48234c: imul eax,eax,0x16
48234f: cmp BYTE PTR [esi+eax*8-0x45],0x17
482354: jne 0x482377
482356: xor eax,eax
482358: mov al,bl
48235a: imul eax,eax,0x16
48235d: cmp WORD PTR [esi+eax*8-0x3c],0x25
482363: jne 0x482377
482365: xor eax,eax
482367: mov al,bl
482369: imul eax,eax,0x16
48236c: mov dl,BYTE PTR [esp+0x1]
482370: add dl,0x21
482373: mov BYTE PTR [esi+eax*8-0x44],dl
482377: xor eax,eax
482379: mov al,bl
48237b: imul eax,eax,0x16
48237e: cmp BYTE PTR [esi+eax*8-0x45],0x17
482383: jne 0x4823a6
482385: xor eax,eax
482387: mov al,bl
482389: imul eax,eax,0x16
48238c: cmp WORD PTR [esi+eax*8-0x3c],0x29
482392: jne 0x4823a6
482394: xor eax,eax
482396: mov al,bl
482398: imul eax,eax,0x16
48239b: mov dl,BYTE PTR [esp+0x1]
48239f: add dl,0x23
4823a2: mov BYTE PTR [esi+eax*8-0x44],dl
4823a6: xor eax,eax
4823a8: mov al,bl
4823aa: imul eax,eax,0x16
4823ad: cmp BYTE PTR [esi+eax*8-0x45],0x18
4823b2: jne 0x4823d5
4823b4: xor eax,eax
4823b6: mov al,bl
4823b8: imul eax,eax,0x16
4823bb: cmp WORD PTR [esi+eax*8-0x3c],0x0
4823c1: jne 0x4823d5
4823c3: xor eax,eax
4823c5: mov al,bl
4823c7: imul eax,eax,0x16
4823ca: mov dl,BYTE PTR [esp+0x1]
4823ce: add dl,0xc
4823d1: mov BYTE PTR [esi+eax*8-0x44],dl
4823d5: xor eax,eax
4823d7: mov al,bl
4823d9: imul eax,eax,0x16
4823dc: cmp BYTE PTR [esi+eax*8-0x45],0x18
4823e1: jne 0x482404
4823e3: xor eax,eax
4823e5: mov al,bl
4823e7: imul eax,eax,0x16
4823ea: cmp WORD PTR [esi+eax*8-0x3c],0x2
4823f0: jne 0x482404
4823f2: xor eax,eax
4823f4: mov al,bl
4823f6: imul eax,eax,0x16
4823f9: mov dl,BYTE PTR [esp+0x1]
4823fd: add dl,0x1e
482400: mov BYTE PTR [esi+eax*8-0x44],dl
482404: xor eax,eax
482406: mov al,bl
482408: imul eax,eax,0x16
48240b: cmp BYTE PTR [esi+eax*8-0x45],0x19
482410: jne 0x4825fd
482416: xor eax,eax
482418: mov al,bl
48241a: imul eax,eax,0x16
48241d: cmp WORD PTR [esi+eax*8-0x3c],0x0
482423: jne 0x482437
482425: xor eax,eax
482427: mov al,bl
482429: imul eax,eax,0x16
48242c: mov dl,BYTE PTR [esp+0x1]
482430: add dl,0x24
482433: mov BYTE PTR [esi+eax*8-0x44],dl
482437: xor eax,eax
482439: mov al,bl
48243b: imul eax,eax,0x16
48243e: cmp WORD PTR [esi+eax*8-0x3c],0x5
482444: jne 0x482458
482446: xor eax,eax
482448: mov al,bl
48244a: imul eax,eax,0x16
48244d: mov dl,BYTE PTR [esp+0x1]
482451: add dl,0x25
482454: mov BYTE PTR [esi+eax*8-0x44],dl
482458: xor eax,eax
48245a: mov al,bl
48245c: imul eax,eax,0x16
48245f: cmp WORD PTR [esi+eax*8-0x3c],0xa
482465: jne 0x4825fd
48246b: xor eax,eax
48246d: mov al,bl
48246f: imul eax,eax,0x16
482472: mov dl,BYTE PTR [esp+0x1]
482476: add dl,0x26
482479: mov BYTE PTR [esi+eax*8-0x44],dl
48247d: xor eax,eax
48247f: mov al,bl
482481: imul eax,eax,0x16
482484: cmp BYTE PTR [esi+eax*8-0x43],0x1
482489: jne 0x4824dd
48248b: xor eax,eax
48248d: mov al,bl
48248f: imul eax,eax,0x16
482492: cmp BYTE PTR [esi+eax*8-0x41],0x1
482497: jne 0x4824dd
482499: xor eax,eax
48249b: mov al,bl
48249d: imul eax,eax,0x16
4824a0: fld QWORD PTR [esi+eax*8-0xb0]
4824a7: fadd DWORD PTR ds:0x48dd10
4824ad: add esp,0xfffffff8
4824b0: fstp QWORD PTR [esp]
4824b3: fwait
4824b4: xor eax,eax
4824b6: mov al,bl
4824b8: imul eax,eax,0x16
4824bb: fld QWORD PTR [esi+eax*8-0xa8]
4824c2: fsub DWORD PTR ds:0x48dd30
4824c8: add esp,0xfffffff8
4824cb: fstp QWORD PTR [esp]
4824ce: fwait
4824cf: mov ecx,ebx
4824d1: mov edx,0x48dcd4
4824d6: mov al,0xd
4824d8: call 0x476a04
4824dd: xor eax,eax
4824df: mov al,bl
4824e1: imul eax,eax,0x16
4824e4: cmp BYTE PTR [esi+eax*8-0x43],0x2
4824e9: jne 0x48253d
4824eb: xor eax,eax
4824ed: mov al,bl
4824ef: imul eax,eax,0x16
4824f2: cmp BYTE PTR [esi+eax*8-0x41],0x1
4824f7: jne 0x48253d
4824f9: xor eax,eax
4824fb: mov al,bl
4824fd: imul eax,eax,0x16
482500: fld QWORD PTR [esi+eax*8-0xb0]
482507: fsub DWORD PTR ds:0x48dd10
48250d: add esp,0xfffffff8
482510: fstp QWORD PTR [esp]
482513: fwait
482514: xor eax,eax
482516: mov al,bl
482518: imul eax,eax,0x16
48251b: fld QWORD PTR [esi+eax*8-0xa8]
482522: fsub DWORD PTR ds:0x48dd30
482528: add esp,0xfffffff8
48252b: fstp QWORD PTR [esp]
48252e: fwait
48252f: mov ecx,ebx
482531: mov edx,0x48dcd4
482536: mov al,0xd
482538: call 0x476a04
48253d: xor eax,eax
48253f: mov al,bl
482541: imul eax,eax,0x16
482544: cmp BYTE PTR [esi+eax*8-0x43],0x1
482549: jne 0x48259d
48254b: xor eax,eax
48254d: mov al,bl
48254f: imul eax,eax,0x16
482552: cmp BYTE PTR [esi+eax*8-0x41],0x2
482557: jne 0x48259d
482559: xor eax,eax
48255b: mov al,bl
48255d: imul eax,eax,0x16
482560: fld QWORD PTR [esi+eax*8-0xb0]
482567: fadd DWORD PTR ds:0x48dd10
48256d: add esp,0xfffffff8
482570: fstp QWORD PTR [esp]
482573: fwait
482574: xor eax,eax
482576: mov al,bl
482578: imul eax,eax,0x16
48257b: fld QWORD PTR [esi+eax*8-0xa8]
482582: fsub DWORD PTR ds:0x48dd30
482588: add esp,0xfffffff8
48258b: fstp QWORD PTR [esp]
48258e: fwait
48258f: mov ecx,ebx
482591: mov edx,0x48dce0
482596: mov al,0xd
482598: call 0x476a04
48259d: xor eax,eax
48259f: mov al,bl
4825a1: imul eax,eax,0x16
4825a4: cmp BYTE PTR [esi+eax*8-0x43],0x2
4825a9: jne 0x4825fd
4825ab: xor eax,eax
4825ad: mov al,bl
4825af: imul eax,eax,0x16
4825b2: cmp BYTE PTR [esi+eax*8-0x41],0x2
4825b7: jne 0x4825fd
4825b9: xor eax,eax
4825bb: mov al,bl
4825bd: imul eax,eax,0x16
4825c0: fld QWORD PTR [esi+eax*8-0xb0]
4825c7: fsub DWORD PTR ds:0x48dd10
4825cd: add esp,0xfffffff8
4825d0: fstp QWORD PTR [esp]
4825d3: fwait
4825d4: xor eax,eax
4825d6: mov al,bl
4825d8: imul eax,eax,0x16
4825db: fld QWORD PTR [esi+eax*8-0xa8]
4825e2: fsub DWORD PTR ds:0x48dd30
4825e8: add esp,0xfffffff8
4825eb: fstp QWORD PTR [esp]
4825ee: fwait
4825ef: mov ecx,ebx
4825f1: mov edx,0x48dce0
4825f6: mov al,0xd
4825f8: call 0x476a04
4825fd: xor eax,eax
4825ff: mov al,bl
482601: imul eax,eax,0x16
482604: cmp BYTE PTR [esi+eax*8-0x45],0x1a
482609: jne 0x48278a
48260f: xor eax,eax
482611: mov al,bl
482613: imul eax,eax,0x16
482616: cmp WORD PTR [esi+eax*8-0x3c],0x0
48261c: jne 0x482630
48261e: xor eax,eax
482620: mov al,bl
482622: imul eax,eax,0x16
482625: mov dl,BYTE PTR [esp+0x1]
482629: add dl,0x27
48262c: mov BYTE PTR [esi+eax*8-0x44],dl
482630: xor eax,eax
482632: mov al,bl
482634: imul eax,eax,0x16
482637: cmp WORD PTR [esi+eax*8-0x3c],0x5
48263d: jne 0x482651
48263f: xor eax,eax
482641: mov al,bl
482643: imul eax,eax,0x16
482646: mov dl,BYTE PTR [esp+0x1]
48264a: add dl,0x28
48264d: mov BYTE PTR [esi+eax*8-0x44],dl
482651: xor eax,eax
482653: mov al,bl
482655: imul eax,eax,0x16
482658: cmp WORD PTR [esi+eax*8-0x3c],0xa
48265e: jne 0x482672
482660: xor eax,eax
482662: mov al,bl
482664: imul eax,eax,0x16
482667: mov dl,BYTE PTR [esp+0x1]
48266b: add dl,0x29
48266e: mov BYTE PTR [esi+eax*8-0x44],dl
482672: xor eax,eax
482674: mov al,bl
482676: imul eax,eax,0x16
482679: cmp WORD PTR [esi+eax*8-0x3c],0xf
48267f: jne 0x482693
482681: xor eax,eax
482683: mov al,bl
482685: imul eax,eax,0x16
482688: mov dl,BYTE PTR [esp+0x1]
48268c: add dl,0x2a
48268f: mov BYTE PTR [esi+eax*8-0x44],dl
482693: xor eax,eax
482695: mov al,bl
482697: imul eax,eax,0x16
48269a: cmp WORD PTR [esi+eax*8-0x3c],0x14
4826a0: jne 0x4826b4
4826a2: xor eax,eax
4826a4: mov al,bl
4826a6: imul eax,eax,0x16
4826a9: mov dl,BYTE PTR [esp+0x1]
4826ad: add dl,0xc
4826b0: mov BYTE PTR [esi+eax*8-0x44],dl
4826b4: xor eax,eax
4826b6: mov al,bl
4826b8: imul eax,eax,0x16
4826bb: cmp WORD PTR [esi+eax*8-0x3c],0xd
4826c1: jge 0x48276f
4826c7: xor eax,eax
4826c9: mov al,bl
4826cb: imul eax,eax,0x16
4826ce: cmp BYTE PTR [esi+eax*8-0x41],0x1
4826d3: jne 0x4826f1
4826d5: xor eax,eax
4826d7: mov al,bl
4826d9: imul eax,eax,0x16
4826dc: cmp BYTE PTR [esi+eax*8-0x43],0x1
4826e1: jne 0x4826f1
4826e3: push 0x40180000
4826e8: push 0x0
4826ea: mov eax,ebx
4826ec: call 0x47648c
4826f1: xor eax,eax
4826f3: mov al,bl
4826f5: imul eax,eax,0x16
4826f8: cmp BYTE PTR [esi+eax*8-0x41],0x1
4826fd: jne 0x48271b
4826ff: xor eax,eax
482701: mov al,bl
482703: imul eax,eax,0x16
482706: cmp BYTE PTR [esi+eax*8-0x43],0x2
48270b: jne 0x48271b
48270d: push 0xc0180000
482712: push 0x0
482714: mov eax,ebx
482716: call 0x47648c
48271b: xor eax,eax
48271d: mov al,bl
48271f: imul eax,eax,0x16
482722: cmp BYTE PTR [esi+eax*8-0x41],0x2
482727: jne 0x482745
482729: xor eax,eax
48272b: mov al,bl
48272d: imul eax,eax,0x16
482730: cmp BYTE PTR [esi+eax*8-0x43],0x1
482735: jne 0x482745
482737: push 0x40240000
48273c: push 0x0
48273e: mov eax,ebx
482740: call 0x47648c
482745: xor eax,eax
482747: mov al,bl
482749: imul eax,eax,0x16
48274c: cmp BYTE PTR [esi+eax*8-0x41],0x2
482751: jne 0x48276f
482753: xor eax,eax
482755: mov al,bl
482757: imul eax,eax,0x16
48275a: cmp BYTE PTR [esi+eax*8-0x43],0x2
48275f: jne 0x48276f
482761: push 0xc0240000
482766: push 0x0
482768: mov eax,ebx
48276a: call 0x47648c
48276f: xor eax,eax
482771: mov al,bl
482773: imul eax,eax,0x16
482776: cmp WORD PTR [esi+eax*8-0x3c],0xf
48277c: jl 0x48278a
48277e: xor eax,eax
482780: mov al,bl
482782: imul eax,eax,0x16
482785: mov BYTE PTR [esi+eax*8-0x47],0x1
48278a: xor eax,eax
48278c: mov al,bl
48278e: imul eax,eax,0x16
482791: cmp BYTE PTR [esi+eax*8-0x45],0x1b
482796: jne 0x482989
48279c: xor eax,eax
48279e: mov al,bl
4827a0: imul eax,eax,0x16
4827a3: fild WORD PTR [esi+eax*8-0x3c]
4827a7: fdiv DWORD PTR ds:0x48dd34
4827ad: call 0x40287c
4827b2: xor eax,eax
4827b4: mov al,bl
4827b6: imul eax,eax,0x16
4827b9: fild WORD PTR [esi+eax*8-0x3c]
4827bd: fdiv DWORD PTR ds:0x48dd34
4827c3: fcompp
4827c5: fnstsw ax
4827c7: sahf
4827c8: jne 0x4827dc
4827ca: xor eax,eax
4827cc: mov al,bl
4827ce: imul eax,eax,0x16
4827d1: mov dl,BYTE PTR [esp+0x1]
4827d5: add dl,0x2b
4827d8: mov BYTE PTR [esi+eax*8-0x44],dl
4827dc: xor eax,eax
4827de: mov al,bl
4827e0: imul eax,eax,0x16
4827e3: fild WORD PTR [esi+eax*8-0x3c]
4827e7: fdiv DWORD PTR ds:0x48dd34
4827ed: call 0x40287c
4827f2: xor eax,eax
4827f4: mov al,bl
4827f6: imul eax,eax,0x16
4827f9: fild WORD PTR [esi+eax*8-0x3c]
4827fd: fdiv DWORD PTR ds:0x48dd34
482803: fcompp
482805: fnstsw ax
482807: sahf
482808: je 0x48281c
48280a: xor eax,eax
48280c: mov al,bl
48280e: imul eax,eax,0x16
482811: mov dl,BYTE PTR [esp+0x1]
482815: add dl,0x2c
482818: mov BYTE PTR [esi+eax*8-0x44],dl
48281c: xor eax,eax
48281e: mov al,bl
482820: imul eax,eax,0x16
482823: cmp WORD PTR [esi+eax*8-0x3c],0x0
482829: jne 0x48283d
48282b: xor eax,eax
48282d: mov al,bl
48282f: imul eax,eax,0x16
482832: mov dl,BYTE PTR [esp+0x1]
482836: add dl,0x27
482839: mov BYTE PTR [esi+eax*8-0x44],dl
48283d: xor eax,eax
48283f: mov al,bl
482841: imul eax,eax,0x16
482844: cmp WORD PTR [esi+eax*8-0x3c],0x2
48284a: jne 0x48285e
48284c: xor eax,eax
48284e: mov al,bl
482850: imul eax,eax,0x16
482853: mov dl,BYTE PTR [esp+0x1]
482857: add dl,0x28
48285a: mov BYTE PTR [esi+eax*8-0x44],dl
48285e: xor eax,eax
482860: mov al,bl
482862: imul eax,eax,0x16
482865: cmp WORD PTR [esi+eax*8-0x3c],0x23
48286b: jne 0x48287f
48286d: xor eax,eax
48286f: mov al,bl
482871: imul eax,eax,0x16
482874: mov dl,BYTE PTR [esp+0x1]
482878: add dl,0x28
48287b: mov BYTE PTR [esi+eax*8-0x44],dl
48287f: xor eax,eax
482881: mov al,bl
482883: imul eax,eax,0x16
482886: cmp WORD PTR [esi+eax*8-0x3c],0x26
48288c: jne 0x4828a0
48288e: xor eax,eax
482890: mov al,bl
482892: imul eax,eax,0x16
482895: mov dl,BYTE PTR [esp+0x1]
482899: add dl,0x27
48289c: mov BYTE PTR [esi+eax*8-0x44],dl
4828a0: xor eax,eax
4828a2: mov al,bl
4828a4: imul eax,eax,0x16
4828a7: cmp WORD PTR [esi+eax*8-0x3c],0x4
4828ad: jl 0x48296e
4828b3: xor eax,eax
4828b5: mov al,bl
4828b7: imul eax,eax,0x16
4828ba: cmp WORD PTR [esi+eax*8-0x3c],0x23
4828c0: jge 0x48296e
4828c6: xor eax,eax
4828c8: mov al,bl
4828ca: imul eax,eax,0x16
4828cd: cmp BYTE PTR [esi+eax*8-0x41],0x1
4828d2: jne 0x4828f0
4828d4: xor eax,eax
4828d6: mov al,bl
4828d8: imul eax,eax,0x16
4828db: cmp BYTE PTR [esi+eax*8-0x43],0x1
4828e0: jne 0x4828f0
4828e2: push 0x401c0000
4828e7: push 0x0
4828e9: mov eax,ebx
4828eb: call 0x47648c
4828f0: xor eax,eax
4828f2: mov al,bl
4828f4: imul eax,eax,0x16
4828f7: cmp BYTE PTR [esi+eax*8-0x41],0x1
4828fc: jne 0x48291a
4828fe: xor eax,eax
482900: mov al,bl
482902: imul eax,eax,0x16
482905: cmp BYTE PTR [esi+eax*8-0x43],0x2
48290a: jne 0x48291a
48290c: push 0xc01c0000
482911: push 0x0
482913: mov eax,ebx
482915: call 0x47648c
48291a: xor eax,eax
48291c: mov al,bl
48291e: imul eax,eax,0x16
482921: cmp BYTE PTR [esi+eax*8-0x41],0x2
482926: jne 0x482944
482928: xor eax,eax
48292a: mov al,bl
48292c: imul eax,eax,0x16
48292f: cmp BYTE PTR [esi+eax*8-0x43],0x1
482934: jne 0x482944
482936: push 0x40220000
48293b: push 0x0
48293d: mov eax,ebx
48293f: call 0x47648c
482944: xor eax,eax
482946: mov al,bl
482948: imul eax,eax,0x16
48294b: cmp BYTE PTR [esi+eax*8-0x41],0x2
482950: jne 0x48296e
482952: xor eax,eax
482954: mov al,bl
482956: imul eax,eax,0x16
482959: cmp BYTE PTR [esi+eax*8-0x43],0x2
48295e: jne 0x48296e
482960: push 0xc0220000
482965: push 0x0
482967: mov eax,ebx
482969: call 0x47648c
48296e: xor eax,eax
482970: mov al,bl
482972: imul eax,eax,0x16
482975: cmp WORD PTR [esi+eax*8-0x3c],0x1a
48297b: jl 0x482989
48297d: xor eax,eax
48297f: mov al,bl
482981: imul eax,eax,0x16
482984: mov BYTE PTR [esi+eax*8-0x47],0x1
482989: xor eax,eax
48298b: mov al,bl
48298d: imul eax,eax,0x16
482990: cmp BYTE PTR [esi+eax*8-0x45],0x1c
482995: jne 0x4829f1
482997: xor eax,eax
482999: mov al,bl
48299b: imul eax,eax,0x16
48299e: mov al,BYTE PTR [esi+eax*8-0x44]
4829a2: mov BYTE PTR [esp],al
4829a5: jmp 0x4829bd
4829a7: mov eax,0x3
4829ac: call 0x402a1c
4829b1: mov dl,BYTE PTR [esp+0x1]
4829b5: add dl,0x2d
4829b8: add al,dl
4829ba: mov BYTE PTR [esp],al
4829bd: xor eax,eax
4829bf: mov al,bl
4829c1: imul eax,eax,0x16
4829c4: mov al,BYTE PTR [esi+eax*8-0x44]
4829c8: cmp al,BYTE PTR [esp]
4829cb: je 0x4829a7
4829cd: xor eax,eax
4829cf: mov al,bl
4829d1: imul eax,eax,0x16
4829d4: mov dl,BYTE PTR [esp]
4829d7: mov BYTE PTR [esi+eax*8-0x44],dl
4829db: mov eax,0x5
4829e0: call 0x402a1c
4829e5: test eax,eax
4829e7: jne 0x4829f1
4829e9: mov eax,ds:0x4b1098
4829ee: mov BYTE PTR [eax],0x20
4829f1: xor eax,eax
4829f3: mov al,bl
4829f5: imul eax,eax,0x16
4829f8: cmp BYTE PTR [esi+eax*8-0x45],0x1d
4829fd: jne 0x482c61
482a03: xor eax,eax
482a05: mov al,bl
482a07: imul eax,eax,0x16
482a0a: cmp WORD PTR [esi+eax*8-0x3c],0x0
482a10: jne 0x482a24
482a12: xor eax,eax
482a14: mov al,bl
482a16: imul eax,eax,0x16
482a19: mov dl,BYTE PTR [esp+0x1]
482a1d: add dl,0x7
482a20: mov BYTE PTR [esi+eax*8-0x44],dl
482a24: xor eax,eax
482a26: mov al,bl
482a28: imul eax,eax,0x16
482a2b: cmp WORD PTR [esi+eax*8-0x3c],0x1
482a31: jne 0x482a45
482a33: xor eax,eax
482a35: mov al,bl
482a37: imul eax,eax,0x16
482a3a: mov dl,BYTE PTR [esp+0x1]
482a3e: add dl,0xa
482a41: mov BYTE PTR [esi+eax*8-0x44],dl
482a45: xor eax,eax
482a47: mov al,bl
482a49: imul eax,eax,0x16
482a4c: cmp WORD PTR [esi+eax*8-0x3c],0x2
482a52: jne 0x482a66
482a54: xor eax,eax
482a56: mov al,bl
482a58: imul eax,eax,0x16
482a5b: mov dl,BYTE PTR [esp+0x1]
482a5f: add dl,0xb
482a62: mov BYTE PTR [esi+eax*8-0x44],dl
482a66: xor eax,eax
482a68: mov al,bl
482a6a: imul eax,eax,0x16
482a6d: cmp WORD PTR [esi+eax*8-0x3c],0x3
482a73: jne 0x482a87
482a75: xor eax,eax
482a77: mov al,bl
482a79: imul eax,eax,0x16
482a7c: mov dl,BYTE PTR [esp+0x1]
482a80: add dl,0x6
482a83: mov BYTE PTR [esi+eax*8-0x44],dl
482a87: xor eax,eax
482a89: mov al,bl
482a8b: imul eax,eax,0x16
482a8e: cmp WORD PTR [esi+eax*8-0x3c],0x4
482a94: jne 0x482aa8
482a96: xor eax,eax
482a98: mov al,bl
482a9a: imul eax,eax,0x16
482a9d: mov dl,BYTE PTR [esp+0x1]
482aa1: add dl,0x7
482aa4: mov BYTE PTR [esi+eax*8-0x44],dl
482aa8: xor eax,eax
482aaa: mov al,bl
482aac: imul eax,eax,0x16
482aaf: cmp WORD PTR [esi+eax*8-0x3c],0x5
482ab5: jne 0x482ac9
482ab7: xor eax,eax
482ab9: mov al,bl
482abb: imul eax,eax,0x16
482abe: mov dl,BYTE PTR [esp+0x1]
482ac2: add dl,0xa
482ac5: mov BYTE PTR [esi+eax*8-0x44],dl
482ac9: xor eax,eax
482acb: mov al,bl
482acd: imul eax,eax,0x16
482ad0: cmp WORD PTR [esi+eax*8-0x3c],0x6
482ad6: jne 0x482aea
482ad8: xor eax,eax
482ada: mov al,bl
482adc: imul eax,eax,0x16
482adf: mov dl,BYTE PTR [esp+0x1]
482ae3: add dl,0xb
482ae6: mov BYTE PTR [esi+eax*8-0x44],dl
482aea: xor eax,eax
482aec: mov al,bl
482aee: imul eax,eax,0x16
482af1: cmp WORD PTR [esi+eax*8-0x3c],0x8
482af7: jl 0x482b26
482af9: xor eax,eax
482afb: mov al,bl
482afd: imul eax,eax,0x16
482b00: cmp WORD PTR [esi+eax*8-0x3c],0x1c
482b06: jge 0x482b26
482b08: mov eax,0x3
482b0d: call 0x402a1c
482b12: mov dl,BYTE PTR [esp+0x1]
482b16: add dl,0x2d
482b19: add al,dl
482b1b: xor edx,edx
482b1d: mov dl,bl
482b1f: imul edx,edx,0x16
482b22: mov BYTE PTR [esi+edx*8-0x44],al
482b26: xor eax,eax
482b28: mov al,bl
482b2a: imul eax,eax,0x16
482b2d: cmp WORD PTR [esi+eax*8-0x3c],0x1c
482b33: jne 0x482b47
482b35: xor eax,eax
482b37: mov al,bl
482b39: imul eax,eax,0x16
482b3c: mov dl,BYTE PTR [esp+0x1]
482b40: add dl,0x6
482b43: mov BYTE PTR [esi+eax*8-0x44],dl
482b47: xor eax,eax
482b49: mov al,bl
482b4b: imul eax,eax,0x16
482b4e: cmp WORD PTR [esi+eax*8-0x3c],0xf
482b54: jl 0x482b62
482b56: xor eax,eax
482b58: mov al,bl
482b5a: imul eax,eax,0x16
482b5d: mov BYTE PTR [esi+eax*8-0x47],0x1
482b62: xor eax,eax
482b64: mov al,bl
482b66: imul eax,eax,0x16
482b69: cmp WORD PTR [esi+eax*8-0x3c],0x1
482b6f: je 0x482b8f
482b71: xor eax,eax
482b73: mov al,bl
482b75: imul eax,eax,0x16
482b78: cmp WORD PTR [esi+eax*8-0x3c],0x8
482b7e: je 0x482b8f
482b80: xor eax,eax
482b82: mov al,bl
482b84: imul eax,eax,0x16
482b87: cmp WORD PTR [esi+eax*8-0x3c],0xc
482b8d: jne 0x482b97
482b8f: mov eax,ds:0x4b1098
482b94: mov BYTE PTR [eax],0x20
482b97: xor eax,eax
482b99: mov al,bl
482b9b: imul eax,eax,0x16
482b9e: cmp BYTE PTR [esi+eax*8-0x43],0x1
482ba3: jne 0x482bc2
482ba5: xor eax,eax
482ba7: mov al,bl
482ba9: imul eax,eax,0x16
482bac: cmp WORD PTR [esi+eax*8-0x3c],0x8
482bb2: jge 0x482bc2
482bb4: push 0x40140000
482bb9: push 0x0
482bbb: mov eax,ebx
482bbd: call 0x47648c
482bc2: xor eax,eax
482bc4: mov al,bl
482bc6: imul eax,eax,0x16
482bc9: cmp BYTE PTR [esi+eax*8-0x43],0x1
482bce: jne 0x482bfc
482bd0: xor eax,eax
482bd2: mov al,bl
482bd4: imul eax,eax,0x16
482bd7: cmp WORD PTR [esi+eax*8-0x3c],0x8
482bdd: jl 0x482bfc
482bdf: xor eax,eax
482be1: mov al,bl
482be3: imul eax,eax,0x16
482be6: cmp WORD PTR [esi+eax*8-0x3c],0x1c
482bec: jge 0x482bfc
482bee: push 0x40240000
482bf3: push 0x0
482bf5: mov eax,ebx
482bf7: call 0x47648c
482bfc: xor eax,eax
482bfe: mov al,bl
482c00: imul eax,eax,0x16
482c03: cmp BYTE PTR [esi+eax*8-0x43],0x2
482c08: jne 0x482c27
482c0a: xor eax,eax
482c0c: mov al,bl
482c0e: imul eax,eax,0x16
482c11: cmp WORD PTR [esi+eax*8-0x3c],0x8
482c17: jge 0x482c27
482c19: push 0xc0140000
482c1e: push 0x0
482c20: mov eax,ebx
482c22: call 0x47648c
482c27: xor eax,eax
482c29: mov al,bl
482c2b: imul eax,eax,0x16
482c2e: cmp BYTE PTR [esi+eax*8-0x43],0x2
482c33: jne 0x482c61
482c35: xor eax,eax
482c37: mov al,bl
482c39: imul eax,eax,0x16
482c3c: cmp WORD PTR [esi+eax*8-0x3c],0x8
482c42: jl 0x482c61
482c44: xor eax,eax
482c46: mov al,bl
482c48: imul eax,eax,0x16
482c4b: cmp WORD PTR [esi+eax*8-0x3c],0x1c
482c51: jge 0x482c61
482c53: push 0xc0240000
482c58: push 0x0
482c5a: mov eax,ebx
482c5c: call 0x47648c
482c61: push 0x14
482c63: push 0xe
482c65: push 0x96
482c6a: xor edx,edx
482c6c: mov dl,BYTE PTR [esp+0xd]
482c70: inc edx
482c71: xor eax,eax
482c73: mov al,bl
482c75: mov ecx,0xffffffef
482c7a: call 0x476870
482c7f: push 0x14
482c81: push 0xe
482c83: push 0x96
482c88: xor edx,edx
482c8a: mov dl,BYTE PTR [esp+0xd]
482c8e: add edx,0x2
482c91: xor eax,eax
482c93: mov al,bl
482c95: mov ecx,0xffffffef
482c9a: call 0x476870
482c9f: push 0x14
482ca1: push 0xe
482ca3: push 0x96
482ca8: xor edx,edx
482caa: mov dl,BYTE PTR [esp+0xd]
482cae: add edx,0x3
482cb1: xor eax,eax
482cb3: mov al,bl
482cb5: mov ecx,0xffffffef
482cba: call 0x476870
482cbf: push 0x14
482cc1: push 0xe
482cc3: push 0x96
482cc8: xor edx,edx
482cca: mov dl,BYTE PTR [esp+0xd]
482cce: add edx,0x4
482cd1: xor eax,eax
482cd3: mov al,bl
482cd5: mov ecx,0xffffffef
482cda: call 0x476870
482cdf: push 0x14
482ce1: push 0xe
482ce3: push 0x96
482ce8: xor edx,edx
482cea: mov dl,BYTE PTR [esp+0xd]
482cee: add edx,0x6
482cf1: xor eax,eax
482cf3: mov al,bl
482cf5: mov ecx,0xffffffef
482cfa: call 0x476870
482cff: push 0x14
482d01: push 0xe
482d03: push 0x96
482d08: xor edx,edx
482d0a: mov dl,BYTE PTR [esp+0xd]
482d0e: add edx,0x8
482d11: xor eax,eax
482d13: mov al,bl
482d15: mov ecx,0xffffffef
482d1a: call 0x476870
482d1f: push 0x14
482d21: push 0xe
482d23: push 0x96
482d28: xor edx,edx
482d2a: mov dl,BYTE PTR [esp+0xd]
482d2e: add edx,0xa
482d31: xor eax,eax
482d33: mov al,bl
482d35: mov ecx,0xffffffef
482d3a: call 0x476870
482d3f: push 0x41
482d41: push 0xe
482d43: push 0x96
482d48: xor edx,edx
482d4a: mov dl,BYTE PTR [esp+0xd]
482d4e: add edx,0xc
482d51: xor eax,eax
482d53: mov al,bl
482d55: mov ecx,0xffffffef
482d5a: call 0x476870
482d5f: push 0x41
482d61: push 0xe
482d63: push 0x96
482d68: xor edx,edx
482d6a: mov dl,BYTE PTR [esp+0xd]
482d6e: add edx,0xd
482d71: xor eax,eax
482d73: mov al,bl
482d75: mov ecx,0xffffffef
482d7a: call 0x476870
482d7f: push 0x41
482d81: push 0xe
482d83: push 0x96
482d88: xor edx,edx
482d8a: mov dl,BYTE PTR [esp+0xd]
482d8e: add edx,0xf
482d91: xor eax,eax
482d93: mov al,bl
482d95: mov ecx,0xffffffef
482d9a: call 0x476870
482d9f: push 0x41
482da1: push 0xe
482da3: push 0x96
482da8: xor edx,edx
482daa: mov dl,BYTE PTR [esp+0xd]
482dae: add edx,0x11
482db1: xor eax,eax
482db3: mov al,bl
482db5: mov ecx,0xffffffef
482dba: call 0x476870
482dbf: push 0x41
482dc1: push 0xe
482dc3: push 0x96
482dc8: xor edx,edx
482dca: mov dl,BYTE PTR [esp+0xd]
482dce: add edx,0x13
482dd1: xor eax,eax
482dd3: mov al,bl
482dd5: mov ecx,0xffffffef
482dda: call 0x476870
482ddf: push 0x19
482de1: push 0x18
482de3: push 0x78
482de5: xor edx,edx
482de7: mov dl,BYTE PTR [esp+0xd]
482deb: add edx,0x15
482dee: xor eax,eax
482df0: mov al,bl
482df2: mov ecx,0xfffffff9
482df7: call 0x476870
482dfc: push 0x3c
482dfe: push 0x18
482e00: push 0x6e
482e02: xor edx,edx
482e04: mov dl,BYTE PTR [esp+0xd]
482e08: add edx,0x1c
482e0b: xor eax,eax
482e0d: mov al,bl
482e0f: mov ecx,0xffffffe5
482e14: call 0x476870
482e19: push 0x69
482e1b: push 0x18
482e1d: push 0x8c
482e22: xor edx,edx
482e24: mov dl,BYTE PTR [esp+0xd]
482e28: add edx,0x1d
482e2b: xor eax,eax
482e2d: mov al,bl
482e2f: mov ecx,0xffffffe5
482e34: call 0x476870
482e39: push 0x14
482e3b: push 0xe
482e3d: push 0x96
482e42: xor edx,edx
482e44: mov dl,BYTE PTR [esp+0xd]
482e48: add edx,0x1f
482e4b: xor eax,eax
482e4d: mov al,bl
482e4f: mov ecx,0xffffffef
482e54: call 0x476870
482e59: push 0x41
482e5b: push 0xe
482e5d: push 0x96
482e62: xor edx,edx
482e64: mov dl,BYTE PTR [esp+0xd]
482e68: add edx,0x20
482e6b: xor eax,eax
482e6d: mov al,bl
482e6f: mov ecx,0xffffffef
482e74: call 0x476870
482e79: push 0x14
482e7b: push 0xe
482e7d: push 0x96
482e82: xor edx,edx
482e84: mov dl,BYTE PTR [esp+0xd]
482e88: add edx,0x24
482e8b: xor eax,eax
482e8d: mov al,bl
482e8f: mov ecx,0xffffffef
482e94: call 0x476870
482e99: push 0x46
482e9b: push 0xe
482e9d: push 0x96
482ea2: xor edx,edx
482ea4: mov dl,BYTE PTR [esp+0xd]
482ea8: add edx,0x2a
482eab: xor eax,eax
482ead: mov al,bl
482eaf: mov ecx,0xffffffef
482eb4: call 0x476870
482eb9: push 0x3c
482ebb: push 0xe
482ebd: push 0x8c
482ec2: xor edx,edx
482ec4: mov dl,BYTE PTR [esp+0xd]
482ec8: add edx,0x2b
482ecb: xor eax,eax
482ecd: mov al,bl
482ecf: mov ecx,0xffffffef
482ed4: call 0x476870
482ed9: push 0x14
482edb: push 0xe
482edd: push 0x96
482ee2: xor edx,edx
482ee4: mov dl,BYTE PTR [esp+0xd]
482ee8: add edx,0x2d
482eeb: xor eax,eax
482eed: mov al,bl
482eef: mov ecx,0xffffffef
482ef4: call 0x476870
482ef9: push 0x14
482efb: push 0x20
482efd: push 0x3a
482eff: push 0x2a
482f01: push 0x1
482f03: push 0x1
482f05: push 0x7
482f07: push 0x0
482f09: xor eax,eax
482f0b: mov al,bl
482f0d: mov ecx,0x2
482f12: mov edx,0x3
482f17: call 0x4768f8
482f1c: push 0x14
482f1e: push 0x5f
482f20: push 0x4b
482f22: push 0x76
482f24: push 0x1
482f26: push 0x1
482f28: push 0x7
482f2a: push 0x0
482f2c: xor eax,eax
482f2e: mov al,bl
482f30: mov ecx,0x2
482f35: mov edx,0x4
482f3a: call 0x4768f8
482f3f: push 0x14
482f41: push 0x1c
482f43: push 0x3f
482f45: push 0x28
482f47: push 0x1
482f49: push 0x2
482f4b: push 0xe
482f4d: push 0x0
482f4f: xor eax,eax
482f51: mov al,bl
482f53: mov ecx,0x5
482f58: mov edx,0x5
482f5d: call 0x4768f8
482f62: push 0x19
482f64: push 0x16
482f66: push 0x3f
482f68: push 0x3c
482f6a: push 0x1
482f6c: push 0x2
482f6e: push 0xe
482f70: push 0x0
482f72: xor eax,eax
482f74: mov al,bl
482f76: mov ecx,0x5
482f7b: mov edx,0x6
482f80: call 0x4768f8
482f85: push 0x14
482f87: push 0x52
482f89: push 0x3a
482f8b: push 0x5c
482f8d: push 0x1
482f8f: push 0x1
482f91: push 0x7
482f93: push 0x0
482f95: xor eax,eax
482f97: mov al,bl
482f99: mov ecx,0x2
482f9e: mov edx,0x8
482fa3: call 0x4768f8
482fa8: push 0x14
482faa: push 0x82
482faf: push 0x43
482fb1: push 0x8e
482fb6: push 0x1
482fb8: push 0x1
482fba: push 0x7
482fbc: push 0x0
482fbe: xor eax,eax
482fc0: mov al,bl
482fc2: mov ecx,0x2
482fc7: mov edx,0x9
482fcc: call 0x4768f8
482fd1: push 0x14
482fd3: push 0x4d
482fd5: push 0x3c
482fd7: push 0x57
482fd9: push 0x1
482fdb: push 0x2
482fdd: push 0xe
482fdf: push 0x0
482fe1: xor eax,eax
482fe3: mov al,bl
482fe5: mov ecx,0x5
482fea: mov edx,0xa
482fef: call 0x4768f8
482ff4: push 0x14
482ff6: push 0x73
482ff8: push 0x4d
482ffa: push 0x85
482fff: push 0x1
483001: push 0x2
483003: push 0xe
483005: push 0x0
483007: xor eax,eax
483009: mov al,bl
48300b: mov ecx,0x5
483010: mov edx,0xb
483015: call 0x4768f8
48301a: push 0x19
48301c: push 0x2d
48301e: push 0x43
483020: push 0x50
483022: push 0x1
483024: push 0x1
483026: push 0x7
483028: push 0x0
48302a: xor eax,eax
48302c: mov al,bl
48302e: mov ecx,0x2
483033: mov edx,0xd
483038: call 0x4768f8
48303d: push 0x19
48303f: push 0x60
483041: push 0x43
483043: push 0x71
483045: push 0x1
483047: push 0x1
483049: push 0x7
48304b: push 0x0
48304d: xor eax,eax
48304f: mov al,bl
483051: mov ecx,0x2
483056: mov edx,0xe
48305b: call 0x4768f8
483060: push 0x19
483062: push 0x2d
483064: push 0x43
483066: push 0x50
483068: push 0x1
48306a: push 0x2
48306c: push 0xe
48306e: push 0x0
483070: xor eax,eax
483072: mov al,bl
483074: mov ecx,0x5
483079: mov edx,0xf
48307e: call 0x4768f8
483083: push 0x19
483085: push 0x60
483087: push 0x43
483089: push 0x71
48308b: push 0x1
48308d: push 0x2
48308f: push 0xe
483091: push 0x0
483093: xor eax,eax
483095: mov al,bl
483097: mov ecx,0x5
48309c: mov edx,0x10
4830a1: call 0x4768f8
4830a6: push 0x14
4830a8: push 0x14
4830aa: push 0x46
4830ac: push 0x91
4830b1: push 0x1
4830b3: push 0x2
4830b5: push 0xa
4830b7: push 0x1
4830b9: xor eax,eax
4830bb: mov al,bl
4830bd: mov ecx,0xa
4830c2: mov edx,0x1a
4830c7: call 0x4768f8
4830cc: push 0x14
4830ce: push 0x78
4830d0: push 0x46
4830d2: push 0x91
4830d7: push 0x1
4830d9: push 0x2
4830db: push 0xf
4830dd: push 0x2
4830df: xor eax,eax
4830e1: mov al,bl
4830e3: mov ecx,0xf
4830e8: mov edx,0x1a
4830ed: call 0x4768f8
4830f2: push 0xffffffc4
4830f4: push 0x32
4830f6: push 0x46
4830f8: push 0x4b
4830fa: push 0x1
4830fc: push 0x0
4830fe: push 0x4
483100: push 0x1
483102: xor eax,eax
483104: mov al,bl
483106: mov ecx,0x3
48310b: mov edx,0x1b
483110: call 0x4768f8
483115: push 0xffffffc4
483117: push 0x32
483119: push 0x46
48311b: push 0x4b
48311d: push 0x1
48311f: push 0x0
483121: push 0x3
483123: push 0x1
483125: xor eax,eax
483127: mov al,bl
483129: mov ecx,0x7
48312e: mov edx,0x1b
483133: call 0x4768f8
483138: push 0xffffffc4
48313a: push 0x32
48313c: push 0x46
48313e: push 0x4b
483140: push 0x1
483142: push 0x0
483144: push 0x4
483146: push 0x0
483148: xor eax,eax
48314a: mov al,bl
48314c: mov ecx,0xb
483151: mov edx,0x1b
483156: call 0x4768f8
48315b: push 0xffffffc4
48315d: push 0x32
48315f: push 0x46
483161: push 0x4b
483163: push 0x1
483165: push 0x0
483167: push 0x3
483169: push 0x1
48316b: xor eax,eax
48316d: mov al,bl
48316f: mov ecx,0xf
483174: mov edx,0x1b
483179: call 0x4768f8
48317e: push 0xffffffc4
483180: push 0x32
483182: push 0x46
483184: push 0x4b
483186: push 0x1
483188: push 0x0
48318a: push 0x4
48318c: push 0x2
48318e: xor eax,eax
483190: mov al,bl
483192: mov ecx,0x13
483197: mov edx,0x1b
48319c: call 0x4768f8
4831a1: push 0xffffffc4
4831a3: push 0x32
4831a5: push 0x46
4831a7: push 0x4b
4831a9: push 0x1
4831ab: push 0x0
4831ad: push 0x3
4831af: push 0x2
4831b1: xor eax,eax
4831b3: mov al,bl
4831b5: mov ecx,0x17
4831ba: mov edx,0x1b
4831bf: call 0x4768f8
4831c4: push 0xffffffc4
4831c6: push 0x32
4831c8: push 0x46
4831ca: push 0x4b
4831cc: push 0x1
4831ce: push 0x0
4831d0: push 0x4
4831d2: push 0x2
4831d4: xor eax,eax
4831d6: mov al,bl
4831d8: mov ecx,0x1b
4831dd: mov edx,0x1b
4831e2: call 0x4768f8
4831e7: push 0x12
4831e9: push 0x1c
4831eb: push 0x46
4831ed: push 0x6e
4831ef: push 0x1
4831f1: push 0x0
4831f3: push 0x4
4831f5: push 0x1
4831f7: xor eax,eax
4831f9: mov al,bl
4831fb: mov ecx,0x1
483200: mov edx,0x1c
483205: call 0x4768f8
48320a: push 0x12
48320c: push 0x1c
48320e: push 0x46
483210: push 0x6e
483212: push 0x1
483214: push 0x0
483216: push 0x4
483218: push 0x1
48321a: xor eax,eax
48321c: mov al,bl
48321e: mov ecx,0x3
483223: mov edx,0x1c
483228: call 0x4768f8
48322d: push 0x12
48322f: push 0x1c
483231: push 0x46
483233: push 0x6e
483235: push 0x1
483237: push 0x0
483239: push 0x3
48323b: push 0x1
48323d: xor eax,eax
48323f: mov al,bl
483241: mov ecx,0x5
483246: mov edx,0x1c
48324b: call 0x4768f8
483250: push 0x12
483252: push 0x1c
483254: push 0x46
483256: push 0x6e
483258: push 0x1
48325a: push 0x0
48325c: push 0x4
48325e: push 0x1
483260: xor eax,eax
483262: mov al,bl
483264: mov ecx,0x7
483269: mov edx,0x1c
48326e: call 0x4768f8
483273: push 0x12
483275: push 0x1c
483277: push 0x46
483279: push 0x6e
48327b: push 0x1
48327d: push 0x0
48327f: push 0x3
483281: push 0x1
483283: xor eax,eax
483285: mov al,bl
483287: mov ecx,0x9
48328c: mov edx,0x1c
483291: call 0x4768f8
483296: push 0x12
483298: push 0x1c
48329a: push 0x46
48329c: push 0x6e
48329e: push 0x1
4832a0: push 0x0
4832a2: push 0x4
4832a4: push 0x1
4832a6: xor eax,eax
4832a8: mov al,bl
4832aa: mov ecx,0xb
4832af: mov edx,0x1c
4832b4: call 0x4768f8
4832b9: push 0x12
4832bb: push 0x1c
4832bd: push 0x46
4832bf: push 0x6e
4832c1: push 0x1
4832c3: push 0x0
4832c5: push 0x4
4832c7: push 0x1
4832c9: xor eax,eax
4832cb: mov al,bl
4832cd: mov ecx,0xd
4832d2: mov edx,0x1c
4832d7: call 0x4768f8
4832dc: push 0x12
4832de: push 0x1c
4832e0: push 0x46
4832e2: push 0x6e
4832e4: push 0x1
4832e6: push 0x2
4832e8: push 0x5
4832ea: push 0x1
4832ec: xor eax,eax
4832ee: mov al,bl
4832f0: mov ecx,0x1
4832f5: mov edx,0x1d
4832fa: call 0x4768f8
4832ff: push 0x12
483301: push 0x1c
483303: push 0x46
483305: push 0x6e
483307: push 0x1
483309: push 0x2
48330b: push 0x5
48330d: push 0x1
48330f: xor eax,eax
483311: mov al,bl
483313: mov ecx,0x3
483318: mov edx,0x1d
48331d: call 0x4768f8
483322: push 0x12
483324: push 0x1c
483326: push 0x46
483328: push 0x6e
48332a: push 0x1
48332c: push 0x2
48332e: push 0x5
483330: push 0x0
483332: xor eax,eax
483334: mov al,bl
483336: mov ecx,0x5
48333b: mov edx,0x1d
483340: call 0x4768f8
483345: push 0x12
483347: push 0x1c
483349: push 0x46
48334b: push 0x6e
48334d: push 0x1
48334f: push 0x2
483351: push 0x5
483353: push 0x1
483355: xor eax,eax
483357: mov al,bl
483359: mov ecx,0x7
48335e: mov edx,0x1d
483363: call 0x4768f8
483368: push 0x12
48336a: push 0x1c
48336c: push 0x46
48336e: push 0x6e
483370: push 0x1
483372: push 0x2
483374: push 0x5
483376: push 0x2
483378: xor eax,eax
48337a: mov al,bl
48337c: mov ecx,0x9
483381: mov edx,0x1d
483386: call 0x4768f8
48338b: push 0x12
48338d: push 0x1c
48338f: push 0x46
483391: push 0x6e
483393: push 0x1
483395: push 0x2
483397: push 0x5
483399: push 0x0
48339b: xor eax,eax
48339d: mov al,bl
48339f: mov ecx,0xb
4833a4: mov edx,0x1d
4833a9: call 0x4768f8
4833ae: push 0x12
4833b0: push 0x1c
4833b2: push 0x46
4833b4: push 0x6e
4833b6: push 0x1
4833b8: push 0x2
4833ba: push 0x5
4833bc: push 0x1
4833be: xor eax,eax
4833c0: mov al,bl
4833c2: mov ecx,0xd
4833c7: mov edx,0x1d
4833cc: call 0x4768f8
4833d1: push 0x12
4833d3: push 0x1c
4833d5: push 0x46
4833d7: push 0x6e
4833d9: push 0x1
4833db: push 0x2
4833dd: push 0xa
4833df: push 0x3
4833e1: xor eax,eax
4833e3: mov al,bl
4833e5: mov ecx,0xf
4833ea: mov edx,0x1d
4833ef: call 0x4768f8
4833f4: xor eax,eax
4833f6: mov al,bl
4833f8: imul eax,eax,0x16
4833fb: cmp BYTE PTR [esi+eax*8-0xa0],0x6
483403: jne 0x48467d
483409: xor eax,eax
48340b: mov al,bl
48340d: imul eax,eax,0x16
483410: cmp BYTE PTR [esi+eax*8-0x45],0x17
483415: jne 0x483484
483417: xor eax,eax
483419: mov al,bl
48341b: imul eax,eax,0x16
48341e: fild WORD PTR [esi+eax*8-0x3c]
483422: fdiv DWORD PTR ds:0x48dd24
483428: call 0x40287c
48342d: xor eax,eax
48342f: mov al,bl
483431: imul eax,eax,0x16
483434: fild WORD PTR [esi+eax*8-0x3c]
483438: fdiv DWORD PTR ds:0x48dd24
48343e: fcompp
483440: fnstsw ax
483442: sahf
483443: jne 0x483484
483445: xor eax,eax
483447: mov al,bl
483449: imul eax,eax,0x16
48344c: movzx eax,BYTE PTR [esi+eax*8-0x44]
483451: xor edx,edx
483453: mov dl,BYTE PTR [esp+0x1]
483457: add edx,0x21
48345a: cmp eax,edx
48345c: jne 0x483472
48345e: xor eax,eax
483460: mov al,bl
483462: imul eax,eax,0x16
483465: mov dl,BYTE PTR [esp+0x1]
483469: add dl,0x22
48346c: mov BYTE PTR [esi+eax*8-0x44],dl
483470: jmp 0x483484
483472: xor eax,eax
483474: mov al,bl
483476: imul eax,eax,0x16
483479: mov dl,BYTE PTR [esp+0x1]
48347d: add dl,0x21
483480: mov BYTE PTR [esi+eax*8-0x44],dl
483484: xor eax,eax
483486: mov al,bl
483488: imul eax,eax,0x16
48348b: cmp BYTE PTR [esi+eax*8-0x45],0x18
483490: jne 0x4834b3
483492: xor eax,eax
483494: mov al,bl
483496: imul eax,eax,0x16
483499: cmp WORD PTR [esi+eax*8-0x3c],0x0
48349f: jne 0x4834b3
4834a1: xor eax,eax
4834a3: mov al,bl
4834a5: imul eax,eax,0x16
4834a8: mov dl,BYTE PTR [esp+0x1]
4834ac: add dl,0xc
4834af: mov BYTE PTR [esi+eax*8-0x44],dl
4834b3: xor eax,eax
4834b5: mov al,bl
4834b7: imul eax,eax,0x16
4834ba: cmp BYTE PTR [esi+eax*8-0x45],0x18
4834bf: jne 0x4834e2
4834c1: xor eax,eax
4834c3: mov al,bl
4834c5: imul eax,eax,0x16
4834c8: cmp WORD PTR [esi+eax*8-0x3c],0x2
4834ce: jne 0x4834e2
4834d0: xor eax,eax
4834d2: mov al,bl
4834d4: imul eax,eax,0x16
4834d7: mov dl,BYTE PTR [esp+0x1]
4834db: add dl,0x1e
4834de: mov BYTE PTR [esi+eax*8-0x44],dl
4834e2: xor eax,eax
4834e4: mov al,bl
4834e6: imul eax,eax,0x16
4834e9: cmp BYTE PTR [esi+eax*8-0x45],0x19
4834ee: jne 0x4836db
4834f4: xor eax,eax
4834f6: mov al,bl
4834f8: imul eax,eax,0x16
4834fb: cmp WORD PTR [esi+eax*8-0x3c],0x0
483501: jne 0x483515
483503: xor eax,eax
483505: mov al,bl
483507: imul eax,eax,0x16
48350a: mov dl,BYTE PTR [esp+0x1]
48350e: add dl,0x23
483511: mov BYTE PTR [esi+eax*8-0x44],dl
483515: xor eax,eax
483517: mov al,bl
483519: imul eax,eax,0x16
48351c: cmp WORD PTR [esi+eax*8-0x3c],0x5
483522: jne 0x483536
483524: xor eax,eax
483526: mov al,bl
483528: imul eax,eax,0x16
48352b: mov dl,BYTE PTR [esp+0x1]
48352f: add dl,0x24
483532: mov BYTE PTR [esi+eax*8-0x44],dl
483536: xor eax,eax
483538: mov al,bl
48353a: imul eax,eax,0x16
48353d: cmp WORD PTR [esi+eax*8-0x3c],0xa
483543: jne 0x4836db
483549: xor eax,eax
48354b: mov al,bl
48354d: imul eax,eax,0x16
483550: mov dl,BYTE PTR [esp+0x1]
483554: add dl,0x25
483557: mov BYTE PTR [esi+eax*8-0x44],dl
48355b: xor eax,eax
48355d: mov al,bl
48355f: imul eax,eax,0x16
483562: cmp BYTE PTR [esi+eax*8-0x43],0x1
483567: jne 0x4835bb
483569: xor eax,eax
48356b: mov al,bl
48356d: imul eax,eax,0x16
483570: cmp BYTE PTR [esi+eax*8-0x41],0x1
483575: jne 0x4835bb
483577: xor eax,eax
483579: mov al,bl
48357b: imul eax,eax,0x16
48357e: fld QWORD PTR [esi+eax*8-0xb0]
483585: fadd DWORD PTR ds:0x48dd2c
48358b: add esp,0xfffffff8
48358e: fstp QWORD PTR [esp]
483591: fwait
483592: xor eax,eax
483594: mov al,bl
483596: imul eax,eax,0x16
483599: fld QWORD PTR [esi+eax*8-0xa8]
4835a0: fsub DWORD PTR ds:0x48dd1c
4835a6: add esp,0xfffffff8
4835a9: fstp QWORD PTR [esp]
4835ac: fwait
4835ad: mov ecx,ebx
4835af: mov edx,0x48dcd4
4835b4: mov al,0xf
4835b6: call 0x476a04
4835bb: xor eax,eax
4835bd: mov al,bl
4835bf: imul eax,eax,0x16
4835c2: cmp BYTE PTR [esi+eax*8-0x43],0x2
4835c7: jne 0x48361b
4835c9: xor eax,eax
4835cb: mov al,bl
4835cd: imul eax,eax,0x16
4835d0: cmp BYTE PTR [esi+eax*8-0x41],0x1
4835d5: jne 0x48361b
4835d7: xor eax,eax
4835d9: mov al,bl
4835db: imul eax,eax,0x16
4835de: fld QWORD PTR [esi+eax*8-0xb0]
4835e5: fsub DWORD PTR ds:0x48dd2c
4835eb: add esp,0xfffffff8
4835ee: fstp QWORD PTR [esp]
4835f1: fwait
4835f2: xor eax,eax
4835f4: mov al,bl
4835f6: imul eax,eax,0x16
4835f9: fld QWORD PTR [esi+eax*8-0xa8]
483600: fsub DWORD PTR ds:0x48dd1c
483606: add esp,0xfffffff8
483609: fstp QWORD PTR [esp]
48360c: fwait
48360d: mov ecx,ebx
48360f: mov edx,0x48dcd4
483614: mov al,0xf
483616: call 0x476a04
48361b: xor eax,eax
48361d: mov al,bl
48361f: imul eax,eax,0x16
483622: cmp BYTE PTR [esi+eax*8-0x43],0x1
483627: jne 0x48367b
483629: xor eax,eax
48362b: mov al,bl
48362d: imul eax,eax,0x16
483630: cmp BYTE PTR [esi+eax*8-0x41],0x2
483635: jne 0x48367b
483637: xor eax,eax
483639: mov al,bl
48363b: imul eax,eax,0x16
48363e: fld QWORD PTR [esi+eax*8-0xb0]
483645: fadd DWORD PTR ds:0x48dd2c
48364b: add esp,0xfffffff8
48364e: fstp QWORD PTR [esp]
483651: fwait
483652: xor eax,eax
483654: mov al,bl
483656: imul eax,eax,0x16
483659: fld QWORD PTR [esi+eax*8-0xa8]
483660: fsub DWORD PTR ds:0x48dd1c
483666: add esp,0xfffffff8
483669: fstp QWORD PTR [esp]
48366c: fwait
48366d: mov ecx,ebx
48366f: mov edx,0x48dce0
483674: mov al,0xf
483676: call 0x476a04
48367b: xor eax,eax
48367d: mov al,bl
48367f: imul eax,eax,0x16
483682: cmp BYTE PTR [esi+eax*8-0x43],0x2
483687: jne 0x4836db
483689: xor eax,eax
48368b: mov al,bl
48368d: imul eax,eax,0x16
483690: cmp BYTE PTR [esi+eax*8-0x41],0x2
483695: jne 0x4836db
483697: xor eax,eax
483699: mov al,bl
48369b: imul eax,eax,0x16
48369e: fld QWORD PTR [esi+eax*8-0xb0]
4836a5: fsub DWORD PTR ds:0x48dd2c
4836ab: add esp,0xfffffff8
4836ae: fstp QWORD PTR [esp]
4836b1: fwait
4836b2: xor eax,eax
4836b4: mov al,bl
4836b6: imul eax,eax,0x16
4836b9: fld QWORD PTR [esi+eax*8-0xa8]
4836c0: fsub DWORD PTR ds:0x48dd1c
4836c6: add esp,0xfffffff8
4836c9: fstp QWORD PTR [esp]
4836cc: fwait
4836cd: mov ecx,ebx
4836cf: mov edx,0x48dce0
4836d4: mov al,0xf
4836d6: call 0x476a04
4836db: xor eax,eax
4836dd: mov al,bl
4836df: imul eax,eax,0x16
4836e2: cmp BYTE PTR [esi+eax*8-0x45],0x1a
4836e7: jne 0x4838d4
4836ed: xor eax,eax
4836ef: mov al,bl
4836f1: imul eax,eax,0x16
4836f4: cmp WORD PTR [esi+eax*8-0x3c],0x0
4836fa: jne 0x48370e
4836fc: xor eax,eax
4836fe: mov al,bl
483700: imul eax,eax,0x16
483703: mov dl,BYTE PTR [esp+0x1]
483707: add dl,0x26
48370a: mov BYTE PTR [esi+eax*8-0x44],dl
48370e: xor eax,eax
483710: mov al,bl
483712: imul eax,eax,0x16
483715: cmp WORD PTR [esi+eax*8-0x3c],0x5
48371b: jne 0x48372f
48371d: xor eax,eax
48371f: mov al,bl
483721: imul eax,eax,0x16
483724: mov dl,BYTE PTR [esp+0x1]
483728: add dl,0x27
48372b: mov BYTE PTR [esi+eax*8-0x44],dl
48372f: xor eax,eax
483731: mov al,bl
483733: imul eax,eax,0x16
483736: cmp WORD PTR [esi+eax*8-0x3c],0xa
48373c: jne 0x4838d4
483742: xor eax,eax
483744: mov al,bl
483746: imul eax,eax,0x16
483749: mov dl,BYTE PTR [esp+0x1]
48374d: add dl,0x28
483750: mov BYTE PTR [esi+eax*8-0x44],dl
483754: xor eax,eax
483756: mov al,bl
483758: imul eax,eax,0x16
48375b: cmp BYTE PTR [esi+eax*8-0x43],0x1
483760: jne 0x4837b4
483762: xor eax,eax
483764: mov al,bl
483766: imul eax,eax,0x16
483769: cmp BYTE PTR [esi+eax*8-0x41],0x1
48376e: jne 0x4837b4
483770: xor eax,eax
483772: mov al,bl
483774: imul eax,eax,0x16
483777: fld QWORD PTR [esi+eax*8-0xb0]
48377e: fadd DWORD PTR ds:0x48dd2c
483784: add esp,0xfffffff8
483787: fstp QWORD PTR [esp]
48378a: fwait
48378b: xor eax,eax
48378d: mov al,bl
48378f: imul eax,eax,0x16
483792: fld QWORD PTR [esi+eax*8-0xa8]
483799: fsub DWORD PTR ds:0x48dd38
48379f: add esp,0xfffffff8
4837a2: fstp QWORD PTR [esp]
4837a5: fwait
4837a6: mov ecx,ebx
4837a8: mov edx,0x48dcd4
4837ad: mov al,0xf
4837af: call 0x476a04
4837b4: xor eax,eax
4837b6: mov al,bl
4837b8: imul eax,eax,0x16
4837bb: cmp BYTE PTR [esi+eax*8-0x43],0x2
4837c0: jne 0x483814
4837c2: xor eax,eax
4837c4: mov al,bl
4837c6: imul eax,eax,0x16
4837c9: cmp BYTE PTR [esi+eax*8-0x41],0x1
4837ce: jne 0x483814
4837d0: xor eax,eax
4837d2: mov al,bl
4837d4: imul eax,eax,0x16
4837d7: fld QWORD PTR [esi+eax*8-0xb0]
4837de: fsub DWORD PTR ds:0x48dd2c
4837e4: add esp,0xfffffff8
4837e7: fstp QWORD PTR [esp]
4837ea: fwait
4837eb: xor eax,eax
4837ed: mov al,bl
4837ef: imul eax,eax,0x16
4837f2: fld QWORD PTR [esi+eax*8-0xa8]
4837f9: fsub DWORD PTR ds:0x48dd38
4837ff: add esp,0xfffffff8
483802: fstp QWORD PTR [esp]
483805: fwait
483806: mov ecx,ebx
483808: mov edx,0x48dcd4
48380d: mov al,0xf
48380f: call 0x476a04
483814: xor eax,eax
483816: mov al,bl
483818: imul eax,eax,0x16
48381b: cmp BYTE PTR [esi+eax*8-0x43],0x1
483820: jne 0x483874
483822: xor eax,eax
483824: mov al,bl
483826: imul eax,eax,0x16
483829: cmp BYTE PTR [esi+eax*8-0x41],0x2
48382e: jne 0x483874
483830: xor eax,eax
483832: mov al,bl
483834: imul eax,eax,0x16
483837: fld QWORD PTR [esi+eax*8-0xb0]
48383e: fadd DWORD PTR ds:0x48dd2c
483844: add esp,0xfffffff8
483847: fstp QWORD PTR [esp]
48384a: fwait
48384b: xor eax,eax
48384d: mov al,bl
48384f: imul eax,eax,0x16
483852: fld QWORD PTR [esi+eax*8-0xa8]
483859: fsub DWORD PTR ds:0x48dd38
48385f: add esp,0xfffffff8
483862: fstp QWORD PTR [esp]
483865: fwait
483866: mov ecx,ebx
483868: mov edx,0x48dce0
48386d: mov al,0xf
48386f: call 0x476a04
483874: xor eax,eax
483876: mov al,bl
483878: imul eax,eax,0x16
48387b: cmp BYTE PTR [esi+eax*8-0x43],0x2
483880: jne 0x4838d4
483882: xor eax,eax
483884: mov al,bl
483886: imul eax,eax,0x16
483889: cmp BYTE PTR [esi+eax*8-0x41],0x2
48388e: jne 0x4838d4
483890: xor eax,eax
483892: mov al,bl
483894: imul eax,eax,0x16
483897: fld QWORD PTR [esi+eax*8-0xb0]
48389e: fsub DWORD PTR ds:0x48dd2c
4838a4: add esp,0xfffffff8
4838a7: fstp QWORD PTR [esp]
4838aa: fwait
4838ab: xor eax,eax
4838ad: mov al,bl
4838af: imul eax,eax,0x16
4838b2: fld QWORD PTR [esi+eax*8-0xa8]
4838b9: fsub DWORD PTR ds:0x48dd38
4838bf: add esp,0xfffffff8
4838c2: fstp QWORD PTR [esp]
4838c5: fwait
4838c6: mov ecx,ebx
4838c8: mov edx,0x48dce0
4838cd: mov al,0xf
4838cf: call 0x476a04
4838d4: xor eax,eax
4838d6: mov al,bl
4838d8: imul eax,eax,0x16
4838db: cmp BYTE PTR [esi+eax*8-0x45],0x1b
4838e0: jne 0x483ad4
4838e6: xor eax,eax
4838e8: mov al,bl
4838ea: imul eax,eax,0x16
4838ed: cmp WORD PTR [esi+eax*8-0x3c],0x0
4838f3: jne 0x483907
4838f5: xor eax,eax
4838f7: mov al,bl
4838f9: imul eax,eax,0x16
4838fc: mov dl,BYTE PTR [esp+0x1]
483900: add dl,0x29
483903: mov BYTE PTR [esi+eax*8-0x44],dl
483907: xor eax,eax
483909: mov al,bl
48390b: imul eax,eax,0x16
48390e: cmp WORD PTR [esi+eax*8-0x3c],0x3
483914: jne 0x483928
483916: xor eax,eax
483918: mov al,bl
48391a: imul eax,eax,0x16
48391d: mov dl,BYTE PTR [esp+0x1]
483921: add dl,0x2a
483924: mov BYTE PTR [esi+eax*8-0x44],dl
483928: xor eax,eax
48392a: mov al,bl
48392c: imul eax,eax,0x16
48392f: cmp WORD PTR [esi+eax*8-0x3c],0x9
483935: jne 0x483949
483937: xor eax,eax
483939: mov al,bl
48393b: imul eax,eax,0x16
48393e: mov dl,BYTE PTR [esp+0x1]
483942: add dl,0x2b
483945: mov BYTE PTR [esi+eax*8-0x44],dl
483949: xor eax,eax
48394b: mov al,bl
48394d: imul eax,eax,0x16
483950: cmp WORD PTR [esi+eax*8-0x3c],0x3
483956: jl 0x483a79
48395c: xor eax,eax
48395e: mov al,bl
483960: imul eax,eax,0x16
483963: cmp WORD PTR [esi+eax*8-0x3c],0xc
483969: jg 0x483a79
48396f: xor eax,eax
483971: mov al,bl
483973: imul eax,eax,0x16
483976: cmp BYTE PTR [esi+eax*8-0x41],0x1
48397b: jne 0x483999
48397d: xor eax,eax
48397f: mov al,bl
483981: imul eax,eax,0x16
483984: cmp BYTE PTR [esi+eax*8-0x43],0x1
483989: jne 0x483999
48398b: push 0x40180000
483990: push 0x0
483992: mov eax,ebx
483994: call 0x47648c
483999: xor eax,eax
48399b: mov al,bl
48399d: imul eax,eax,0x16
4839a0: cmp BYTE PTR [esi+eax*8-0x41],0x1
4839a5: jne 0x4839c3
4839a7: xor eax,eax
4839a9: mov al,bl
4839ab: imul eax,eax,0x16
4839ae: cmp BYTE PTR [esi+eax*8-0x43],0x2
4839b3: jne 0x4839c3
4839b5: push 0xc0180000
4839ba: push 0x0
4839bc: mov eax,ebx
4839be: call 0x47648c
4839c3: xor eax,eax
4839c5: mov al,bl
4839c7: imul eax,eax,0x16
4839ca: cmp BYTE PTR [esi+eax*8-0x41],0x2
4839cf: jne 0x4839ed
4839d1: xor eax,eax
4839d3: mov al,bl
4839d5: imul eax,eax,0x16
4839d8: cmp BYTE PTR [esi+eax*8-0x43],0x1
4839dd: jne 0x4839ed
4839df: push 0x40220000
4839e4: push 0x0
4839e6: mov eax,ebx
4839e8: call 0x47648c
4839ed: xor eax,eax
4839ef: mov al,bl
4839f1: imul eax,eax,0x16
4839f4: cmp BYTE PTR [esi+eax*8-0x41],0x2
4839f9: jne 0x483a17
4839fb: xor eax,eax
4839fd: mov al,bl
4839ff: imul eax,eax,0x16
483a02: cmp BYTE PTR [esi+eax*8-0x43],0x2
483a07: jne 0x483a17
483a09: push 0xc0220000
483a0e: push 0x0
483a10: mov eax,ebx
483a12: call 0x47648c
483a17: xor eax,eax
483a19: mov al,bl
483a1b: imul eax,eax,0x16
483a1e: cmp BYTE PTR [esi+eax*8-0x41],0x1
483a23: jne 0x483a48
483a25: xor eax,eax
483a27: mov al,bl
483a29: imul eax,eax,0x16
483a2c: fld QWORD PTR [esi+eax*8-0xa8]
483a33: fsub DWORD PTR ds:0x48dcc0
483a39: xor eax,eax
483a3b: mov al,bl
483a3d: imul eax,eax,0x16
483a40: fstp QWORD PTR [esi+eax*8-0xa8]
483a47: fwait
483a48: xor eax,eax
483a4a: mov al,bl
483a4c: imul eax,eax,0x16
483a4f: cmp BYTE PTR [esi+eax*8-0x41],0x2
483a54: jne 0x483a79
483a56: xor eax,eax
483a58: mov al,bl
483a5a: imul eax,eax,0x16
483a5d: fld QWORD PTR [esi+eax*8-0xa8]
483a64: fsub DWORD PTR ds:0x48dd08
483a6a: xor eax,eax
483a6c: mov al,bl
483a6e: imul eax,eax,0x16
483a71: fstp QWORD PTR [esi+eax*8-0xa8]
483a78: fwait
483a79: xor eax,eax
483a7b: mov al,bl
483a7d: imul eax,eax,0x16
483a80: cmp WORD PTR [esi+eax*8-0x3c],0xd
483a86: jne 0x483ac8
483a88: xor eax,eax
483a8a: mov al,bl
483a8c: imul eax,eax,0x16
483a8f: cmp BYTE PTR [esi+eax*8-0x41],0x1
483a94: jne 0x483aa2
483a96: xor eax,eax
483a98: mov al,bl
483a9a: imul eax,eax,0x16
483a9d: mov BYTE PTR [esi+eax*8-0x38],0xfd
483aa2: xor eax,eax
483aa4: mov al,bl
483aa6: imul eax,eax,0x16
483aa9: cmp BYTE PTR [esi+eax*8-0x41],0x2
483aae: jne 0x483abc
483ab0: xor eax,eax
483ab2: mov al,bl
483ab4: imul eax,eax,0x16
483ab7: mov BYTE PTR [esi+eax*8-0x38],0xfa
483abc: xor eax,eax
483abe: mov al,bl
483ac0: imul eax,eax,0x16
483ac3: mov BYTE PTR [esi+eax*8-0x46],0x1
483ac8: xor eax,eax
483aca: mov al,bl
483acc: imul eax,eax,0x16
483acf: mov BYTE PTR [esi+eax*8-0x47],0x1
483ad4: xor eax,eax
483ad6: mov al,bl
483ad8: imul eax,eax,0x16
483adb: cmp BYTE PTR [esi+eax*8-0x45],0x1c
483ae0: jne 0x483ca8
483ae6: xor eax,eax
483ae8: mov al,bl
483aea: imul eax,eax,0x16
483aed: cmp BYTE PTR [esi+eax*8-0x43],0x1
483af2: jne 0x483b02
483af4: push 0x40000000
483af9: push 0x0
483afb: mov eax,ebx
483afd: call 0x47648c
483b02: xor eax,eax
483b04: mov al,bl
483b06: imul eax,eax,0x16
483b09: cmp BYTE PTR [esi+eax*8-0x43],0x2
483b0e: jne 0x483b1e
483b10: push 0xc0000000
483b15: push 0x0
483b17: mov eax,ebx
483b19: call 0x47648c
483b1e: xor eax,eax
483b20: mov al,bl
483b22: imul eax,eax,0x16
483b25: cmp WORD PTR [esi+eax*8-0x3c],0x0
483b2b: jne 0x483b3f
483b2d: xor eax,eax
483b2f: mov al,bl
483b31: imul eax,eax,0x16
483b34: mov dl,BYTE PTR [esp+0x1]
483b38: add dl,0x29
483b3b: mov BYTE PTR [esi+eax*8-0x44],dl
483b3f: xor eax,eax
483b41: mov al,bl
483b43: imul eax,eax,0x16
483b46: cmp WORD PTR [esi+eax*8-0x3c],0x2
483b4c: jne 0x483b60
483b4e: xor eax,eax
483b50: mov al,bl
483b52: imul eax,eax,0x16
483b55: mov dl,BYTE PTR [esp+0x1]
483b59: add dl,0x2c
483b5c: mov BYTE PTR [esi+eax*8-0x44],dl
483b60: xor eax,eax
483b62: mov al,bl
483b64: imul eax,eax,0x16
483b67: cmp WORD PTR [esi+eax*8-0x3c],0x7
483b6d: jne 0x483b81
483b6f: xor eax,eax
483b71: mov al,bl
483b73: imul eax,eax,0x16
483b76: mov dl,BYTE PTR [esp+0x1]
483b7a: add dl,0x29
483b7d: mov BYTE PTR [esi+eax*8-0x44],dl
483b81: xor eax,eax
483b83: mov al,bl
483b85: imul eax,eax,0x16
483b88: cmp WORD PTR [esi+eax*8-0x3c],0x2
483b8e: jl 0x483c72
483b94: xor eax,eax
483b96: mov al,bl
483b98: imul eax,eax,0x16
483b9b: cmp WORD PTR [esi+eax*8-0x3c],0x5
483ba1: jg 0x483c72
483ba7: xor eax,eax
483ba9: mov al,bl
483bab: imul eax,eax,0x16
483bae: cmp BYTE PTR [esi+eax*8-0x41],0x1
483bb3: jne 0x483bd1
483bb5: xor eax,eax
483bb7: mov al,bl
483bb9: imul eax,eax,0x16
483bbc: cmp BYTE PTR [esi+eax*8-0x43],0x1
483bc1: jne 0x483bd1
483bc3: push 0x40340000
483bc8: push 0x0
483bca: mov eax,ebx
483bcc: call 0x47648c
483bd1: xor eax,eax
483bd3: mov al,bl
483bd5: imul eax,eax,0x16
483bd8: cmp BYTE PTR [esi+eax*8-0x41],0x1
483bdd: jne 0x483bfb
483bdf: xor eax,eax
483be1: mov al,bl
483be3: imul eax,eax,0x16
483be6: cmp BYTE PTR [esi+eax*8-0x43],0x2
483beb: jne 0x483bfb
483bed: push 0xc0340000
483bf2: push 0x0
483bf4: mov eax,ebx
483bf6: call 0x47648c
483bfb: xor eax,eax
483bfd: mov al,bl
483bff: imul eax,eax,0x16
483c02: cmp BYTE PTR [esi+eax*8-0x41],0x2
483c07: jne 0x483c25
483c09: xor eax,eax
483c0b: mov al,bl
483c0d: imul eax,eax,0x16
483c10: cmp BYTE PTR [esi+eax*8-0x43],0x1
483c15: jne 0x483c25
483c17: push 0x403b0000
483c1c: push 0x0
483c1e: mov eax,ebx
483c20: call 0x47648c
483c25: xor eax,eax
483c27: mov al,bl
483c29: imul eax,eax,0x16
483c2c: cmp BYTE PTR [esi+eax*8-0x41],0x2
483c31: jne 0x483c4f
483c33: xor eax,eax
483c35: mov al,bl
483c37: imul eax,eax,0x16
483c3a: cmp BYTE PTR [esi+eax*8-0x43],0x2
483c3f: jne 0x483c4f
483c41: push 0xc03b0000
483c46: push 0x0
483c48: mov eax,ebx
483c4a: call 0x47648c
483c4f: xor eax,eax
483c51: mov al,bl
483c53: imul eax,eax,0x16
483c56: fld QWORD PTR [esi+eax*8-0xa8]
483c5d: fsub DWORD PTR ds:0x48dd3c
483c63: xor eax,eax
483c65: mov al,bl
483c67: imul eax,eax,0x16
483c6a: fstp QWORD PTR [esi+eax*8-0xa8]
483c71: fwait
483c72: xor eax,eax
483c74: mov al,bl
483c76: imul eax,eax,0x16
483c79: cmp WORD PTR [esi+eax*8-0x3c],0x3
483c7f: jl 0x483c8d
483c81: xor eax,eax
483c83: mov al,bl
483c85: imul eax,eax,0x16
483c88: mov BYTE PTR [esi+eax*8-0x47],0x1
483c8d: xor eax,eax
483c8f: mov al,bl
483c91: imul eax,eax,0x16
483c94: cmp WORD PTR [esi+eax*8-0x3c],0x6
483c9a: jne 0x483ca8
483c9c: xor eax,eax
483c9e: mov al,bl
483ca0: imul eax,eax,0x16
483ca3: mov BYTE PTR [esi+eax*8-0x46],0x1
483ca8: xor eax,eax
483caa: mov al,bl
483cac: imul eax,eax,0x16
483caf: cmp BYTE PTR [esi+eax*8-0x45],0x1d
483cb4: jne 0x483f5d
483cba: xor eax,eax
483cbc: mov al,bl
483cbe: imul eax,eax,0x16
483cc1: cmp WORD PTR [esi+eax*8-0x3c],0x8
483cc7: jg 0x483d01
483cc9: xor eax,eax
483ccb: mov al,bl
483ccd: imul eax,eax,0x16
483cd0: cmp BYTE PTR [esi+eax*8-0x43],0x1
483cd5: jne 0x483ce5
483cd7: push 0x3ff00000
483cdc: push 0x0
483cde: mov eax,ebx
483ce0: call 0x47648c
483ce5: xor eax,eax
483ce7: mov al,bl
483ce9: imul eax,eax,0x16
483cec: cmp BYTE PTR [esi+eax*8-0x43],0x2
483cf1: jne 0x483d01
483cf3: push 0xbff00000
483cf8: push 0x0
483cfa: mov eax,ebx
483cfc: call 0x47648c
483d01: xor eax,eax
483d03: mov al,bl
483d05: imul eax,eax,0x16
483d08: cmp WORD PTR [esi+eax*8-0x3c],0x0
483d0e: jne 0x483d22
483d10: xor eax,eax
483d12: mov al,bl
483d14: imul eax,eax,0x16
483d17: mov dl,BYTE PTR [esp+0x1]
483d1b: add dl,0x29
483d1e: mov BYTE PTR [esi+eax*8-0x44],dl
483d22: xor eax,eax
483d24: mov al,bl
483d26: imul eax,eax,0x16
483d29: cmp WORD PTR [esi+eax*8-0x3c],0x3
483d2f: jne 0x483d43
483d31: xor eax,eax
483d33: mov al,bl
483d35: imul eax,eax,0x16
483d38: mov dl,BYTE PTR [esp+0x1]
483d3c: add dl,0x2c
483d3f: mov BYTE PTR [esi+eax*8-0x44],dl
483d43: xor eax,eax
483d45: mov al,bl
483d47: imul eax,eax,0x16
483d4a: cmp WORD PTR [esi+eax*8-0x3c],0x7
483d50: jne 0x483d64
483d52: xor eax,eax
483d54: mov al,bl
483d56: imul eax,eax,0x16
483d59: mov dl,BYTE PTR [esp+0x1]
483d5d: add dl,0x29
483d60: mov BYTE PTR [esi+eax*8-0x44],dl
483d64: xor eax,eax
483d66: mov al,bl
483d68: imul eax,eax,0x16
483d6b: cmp WORD PTR [esi+eax*8-0x3c],0x3
483d71: jl 0x483dba
483d73: xor eax,eax
483d75: mov al,bl
483d77: imul eax,eax,0x16
483d7a: cmp WORD PTR [esi+eax*8-0x3c],0x6
483d80: jg 0x483dba
483d82: xor eax,eax
483d84: mov al,bl
483d86: imul eax,eax,0x16
483d89: cmp BYTE PTR [esi+eax*8-0x43],0x1
483d8e: jne 0x483d9e
483d90: push 0x40350000
483d95: push 0x0
483d97: mov eax,ebx
483d99: call 0x47648c
483d9e: xor eax,eax
483da0: mov al,bl
483da2: imul eax,eax,0x16
483da5: cmp BYTE PTR [esi+eax*8-0x43],0x2
483daa: jne 0x483dba
483dac: push 0xc0350000
483db1: push 0x0
483db3: mov eax,ebx
483db5: call 0x47648c
483dba: xor eax,eax
483dbc: mov al,bl
483dbe: imul eax,eax,0x16
483dc1: cmp WORD PTR [esi+eax*8-0x3c],0x8
483dc7: jne 0x483deb
483dc9: xor eax,eax
483dcb: mov al,bl
483dcd: imul eax,eax,0x16
483dd0: mov BYTE PTR [esi+eax*8-0x46],0x0
483dd5: mov eax,ds:0x4b11f8
483dda: fild WORD PTR [eax]
483ddc: xor eax,eax
483dde: mov al,bl
483de0: imul eax,eax,0x16
483de3: fstp QWORD PTR [esi+eax*8-0xa8]
483dea: fwait
483deb: xor eax,eax
483ded: mov al,bl
483def: imul eax,eax,0x16
483df2: cmp WORD PTR [esi+eax*8-0x3c],0x8
483df8: jne 0x483e02
483dfa: mov eax,ds:0x4b1098
483dff: mov BYTE PTR [eax],0x22
483e02: xor eax,eax
483e04: mov al,bl
483e06: imul eax,eax,0x16
483e09: cmp WORD PTR [esi+eax*8-0x3c],0x8
483e0f: jne 0x483e23
483e11: xor eax,eax
483e13: mov al,bl
483e15: imul eax,eax,0x16
483e18: mov dl,BYTE PTR [esp+0x1]
483e1c: add dl,0x29
483e1f: mov BYTE PTR [esi+eax*8-0x44],dl
483e23: xor eax,eax
483e25: mov al,bl
483e27: imul eax,eax,0x16
483e2a: cmp WORD PTR [esi+eax*8-0x3c],0x9
483e30: jne 0x483e44
483e32: xor eax,eax
483e34: mov al,bl
483e36: imul eax,eax,0x16
483e39: mov dl,BYTE PTR [esp+0x1]
483e3d: add dl,0x2a
483e40: mov BYTE PTR [esi+eax*8-0x44],dl
483e44: xor eax,eax
483e46: mov al,bl
483e48: imul eax,eax,0x16
483e4b: cmp WORD PTR [esi+eax*8-0x3c],0x19
483e51: jne 0x483e65
483e53: xor eax,eax
483e55: mov al,bl
483e57: imul eax,eax,0x16
483e5a: mov dl,BYTE PTR [esp+0x1]
483e5e: add dl,0x2b
483e61: mov BYTE PTR [esi+eax*8-0x44],dl
483e65: xor eax,eax
483e67: mov al,bl
483e69: imul eax,eax,0x16
483e6c: cmp WORD PTR [esi+eax*8-0x3c],0x9
483e72: jl 0x483ede
483e74: xor eax,eax
483e76: mov al,bl
483e78: imul eax,eax,0x16
483e7b: cmp WORD PTR [esi+eax*8-0x3c],0x19
483e81: jg 0x483ede
483e83: xor eax,eax
483e85: mov al,bl
483e87: imul eax,eax,0x16
483e8a: cmp BYTE PTR [esi+eax*8-0x43],0x1
483e8f: jne 0x483e9f
483e91: push 0x40220000
483e96: push 0x0
483e98: mov eax,ebx
483e9a: call 0x47648c
483e9f: xor eax,eax
483ea1: mov al,bl
483ea3: imul eax,eax,0x16
483ea6: cmp BYTE PTR [esi+eax*8-0x43],0x2
483eab: jne 0x483ebb
483ead: push 0xc0220000
483eb2: push 0x0
483eb4: mov eax,ebx
483eb6: call 0x47648c
483ebb: xor eax,eax
483ebd: mov al,bl
483ebf: imul eax,eax,0x16
483ec2: fld QWORD PTR [esi+eax*8-0xa8]
483ec9: fsub DWORD PTR ds:0x48dcc0
483ecf: xor eax,eax
483ed1: mov al,bl
483ed3: imul eax,eax,0x16
483ed6: fstp QWORD PTR [esi+eax*8-0xa8]
483edd: fwait
483ede: xor eax,eax
483ee0: mov al,bl
483ee2: imul eax,eax,0x16
483ee5: cmp WORD PTR [esi+eax*8-0x3c],0x1a
483eeb: jne 0x483f05
483eed: xor eax,eax
483eef: mov al,bl
483ef1: imul eax,eax,0x16
483ef4: mov BYTE PTR [esi+eax*8-0x46],0x1
483ef9: xor eax,eax
483efb: mov al,bl
483efd: imul eax,eax,0x16
483f00: mov BYTE PTR [esi+eax*8-0x38],0xfb
483f05: xor eax,eax
483f07: mov al,bl
483f09: imul eax,eax,0x16
483f0c: cmp WORD PTR [esi+eax*8-0x3c],0x9
483f12: jl 0x483f5d
483f14: xor eax,eax
483f16: mov al,bl
483f18: mov edx,0x3
483f1d: sub edx,eax
483f1f: imul eax,edx,0x16
483f22: cmp BYTE PTR [esi+eax*8-0x45],0x11
483f27: je 0x483f3e
483f29: xor eax,eax
483f2b: mov al,bl
483f2d: mov edx,0x3
483f32: sub edx,eax
483f34: imul eax,edx,0x16
483f37: cmp BYTE PTR [esi+eax*8-0x45],0x13
483f3c: jne 0x483f5d
483f3e: xor eax,eax
483f40: mov al,bl
483f42: imul eax,eax,0x16
483f45: mov BYTE PTR [esi+eax*8-0x47],0x1
483f4a: xor eax,eax
483f4c: mov al,bl
483f4e: mov edx,0x3
483f53: sub edx,eax
483f55: imul eax,edx,0x16
483f58: mov BYTE PTR [esi+eax*8-0x1e],0x0
483f5d: push 0x28
483f5f: push 0x1e
483f61: push 0xc8
483f66: xor edx,edx
483f68: mov dl,BYTE PTR [esp+0xd]
483f6c: inc edx
483f6d: xor eax,eax
483f6f: mov al,bl
483f71: mov ecx,0xfffffffb
483f76: call 0x476870
483f7b: push 0x28
483f7d: push 0x1e
483f7f: push 0xc8
483f84: xor edx,edx
483f86: mov dl,BYTE PTR [esp+0xd]
483f8a: add edx,0x2
483f8d: xor eax,eax
483f8f: mov al,bl
483f91: mov ecx,0xfffffffb
483f96: call 0x476870
483f9b: push 0x28
483f9d: push 0x1e
483f9f: push 0xc8
483fa4: xor edx,edx
483fa6: mov dl,BYTE PTR [esp+0xd]
483faa: add edx,0x3
483fad: xor eax,eax
483faf: mov al,bl
483fb1: mov ecx,0xfffffffb
483fb6: call 0x476870
483fbb: push 0x28
483fbd: push 0x1e
483fbf: push 0xc8
483fc4: xor edx,edx
483fc6: mov dl,BYTE PTR [esp+0xd]
483fca: add edx,0x4
483fcd: xor eax,eax
483fcf: mov al,bl
483fd1: mov ecx,0xfffffffb
483fd6: call 0x476870
483fdb: push 0x28
483fdd: push 0x1e
483fdf: push 0xc8
483fe4: xor edx,edx
483fe6: mov dl,BYTE PTR [esp+0xd]
483fea: add edx,0x6
483fed: xor eax,eax
483fef: mov al,bl
483ff1: mov ecx,0xfffffffb
483ff6: call 0x476870
483ffb: push 0x28
483ffd: push 0x1e
483fff: push 0xc8
484004: xor edx,edx
484006: mov dl,BYTE PTR [esp+0xd]
48400a: add edx,0x8
48400d: xor eax,eax
48400f: mov al,bl
484011: mov ecx,0xfffffffb
484016: call 0x476870
48401b: push 0x28
48401d: push 0x1e
48401f: push 0xc8
484024: xor edx,edx
484026: mov dl,BYTE PTR [esp+0xd]
48402a: add edx,0xa
48402d: xor eax,eax
48402f: mov al,bl
484031: mov ecx,0xfffffffb
484036: call 0x476870
48403b: push 0x61
48403d: push 0x14
48403f: push 0xc8
484044: xor edx,edx
484046: mov dl,BYTE PTR [esp+0xd]
48404a: add edx,0xc
48404d: xor eax,eax
48404f: mov al,bl
484051: mov ecx,0xfffffff6
484056: call 0x476870
48405b: push 0x61
48405d: push 0x14
48405f: push 0xc8
484064: xor edx,edx
484066: mov dl,BYTE PTR [esp+0xd]
48406a: add edx,0xd
48406d: xor eax,eax
48406f: mov al,bl
484071: mov ecx,0xfffffff6
484076: call 0x476870
48407b: push 0x61
48407d: push 0x14
48407f: push 0xc8
484084: xor edx,edx
484086: mov dl,BYTE PTR [esp+0xd]
48408a: add edx,0xf
48408d: xor eax,eax
48408f: mov al,bl
484091: mov ecx,0xfffffff6
484096: call 0x476870
48409b: push 0x61
48409d: push 0x14
48409f: push 0xc8
4840a4: xor edx,edx
4840a6: mov dl,BYTE PTR [esp+0xd]
4840aa: add edx,0x11
4840ad: xor eax,eax
4840af: mov al,bl
4840b1: mov ecx,0xfffffff6
4840b6: call 0x476870
4840bb: push 0x61
4840bd: push 0x14
4840bf: push 0xc8
4840c4: xor edx,edx
4840c6: mov dl,BYTE PTR [esp+0xd]
4840ca: add edx,0x13
4840cd: xor eax,eax
4840cf: mov al,bl
4840d1: mov ecx,0xfffffff6
4840d6: call 0x476870
4840db: push 0x23
4840dd: push 0x12
4840df: push 0xa0
4840e4: xor edx,edx
4840e6: mov dl,BYTE PTR [esp+0xd]
4840ea: add edx,0x15
4840ed: xor eax,eax
4840ef: mov al,bl
4840f1: mov ecx,0xffffffee
4840f6: call 0x476870
4840fb: push 0x64
4840fd: push 0x23
4840ff: push 0x8c
484104: xor edx,edx
484106: mov dl,BYTE PTR [esp+0xd]
48410a: add edx,0x1c
48410d: xor eax,eax
48410f: mov al,bl
484111: mov ecx,0xffffffd8
484116: call 0x476870
48411b: push 0x91
484120: push 0x23
484122: push 0xb4
484127: xor edx,edx
484129: mov dl,BYTE PTR [esp+0xd]
48412d: add edx,0x1d
484130: xor eax,eax
484132: mov al,bl
484134: mov ecx,0xffffffd8
484139: call 0x476870
48413e: push 0x28
484140: push 0x23
484142: push 0xbe
484147: xor edx,edx
484149: mov dl,BYTE PTR [esp+0xd]
48414d: add edx,0x1f
484150: xor eax,eax
484152: mov al,bl
484154: mov ecx,0xfffffffb
484159: call 0x476870
48415e: push 0x61
484160: push 0xe
484162: push 0xbe
484167: xor edx,edx
484169: mov dl,BYTE PTR [esp+0xd]
48416d: add edx,0x20
484170: xor eax,eax
484172: mov al,bl
484174: mov ecx,0xffffffef
484179: call 0x476870
48417e: push 0x28
484180: push 0x14
484182: push 0xbe
484187: xor edx,edx
484189: mov dl,BYTE PTR [esp+0xd]
48418d: add edx,0x23
484190: xor eax,eax
484192: mov al,bl
484194: mov ecx,0xfffffff4
484199: call 0x476870
48419e: push 0x4e
4841a0: push 0xe
4841a2: push 0xbe
4841a7: xor edx,edx
4841a9: mov dl,BYTE PTR [esp+0xd]
4841ad: add edx,0x26
4841b0: xor eax,eax
4841b2: mov al,bl
4841b4: mov ecx,0xffffffef
4841b9: call 0x476870
4841be: push 0x4e
4841c0: push 0x2c
4841c2: push 0xbe
4841c7: xor edx,edx
4841c9: mov dl,BYTE PTR [esp+0xd]
4841cd: add edx,0x29
4841d0: xor eax,eax
4841d2: mov al,bl
4841d4: mov ecx,0xffffffef
4841d9: call 0x476870
4841de: push 0x28
4841e0: push 0x19
4841e2: push 0xb4
4841e7: xor edx,edx
4841e9: mov dl,BYTE PTR [esp+0xd]
4841ed: add edx,0x2a
4841f0: xor eax,eax
4841f2: mov al,bl
4841f4: mov ecx,0xfffffff1
4841f9: call 0x476870
4841fe: push 0x1e
484200: push 0x23
484202: push 0x96
484207: xor edx,edx
484209: mov dl,BYTE PTR [esp+0xd]
48420d: add edx,0x2c
484210: xor eax,eax
484212: mov al,bl
484214: mov ecx,0xfffffff6
484219: call 0x476870
48421e: push 0x14
484220: push 0x37
484222: push 0x44
484224: push 0x52
484226: push 0x1
484228: push 0x1
48422a: push 0x7
48422c: push 0x0
48422e: xor eax,eax
484230: mov al,bl
484232: mov ecx,0x2
484237: mov edx,0x3
48423c: call 0x4768f8
484241: push 0x14
484243: push 0x5f
484245: push 0x6c
484247: push 0x91
48424c: push 0x1
48424e: push 0x1
484250: push 0x7
484252: push 0x0
484254: xor eax,eax
484256: mov al,bl
484258: mov ecx,0x2
48425d: mov edx,0x4
484262: call 0x4768f8
484267: push 0x1e
484269: push 0x3a
48426b: push 0x4d
48426d: push 0x5a
48426f: push 0x1
484271: push 0x2
484273: push 0x4
484275: push 0x0
484277: xor eax,eax
484279: mov al,bl
48427b: mov ecx,0x4
484280: mov edx,0x5
484285: call 0x4768f8
48428a: push 0x28
48428c: push 0x17
48428e: push 0x49
484290: push 0x50
484292: push 0x1
484294: push 0x2
484296: push 0xa
484298: push 0x0
48429a: xor eax,eax
48429c: mov al,bl
48429e: mov ecx,0x6
4842a3: mov edx,0x5
4842a8: call 0x4768f8
4842ad: push 0x19
4842af: push 0x28
4842b1: push 0x69
4842b3: push 0x64
4842b5: push 0x1
4842b7: push 0x2
4842b9: push 0xe
4842bb: push 0x0
4842bd: xor eax,eax
4842bf: mov al,bl
4842c1: mov ecx,0x5
4842c6: mov edx,0x6
4842cb: call 0x4768f8
4842d0: push 0xf
4842d2: push 0x6e
4842d4: push 0x50
4842d6: push 0x7d
4842d8: push 0x1
4842da: push 0x1
4842dc: push 0x7
4842de: push 0x0
4842e0: xor eax,eax
4842e2: mov al,bl
4842e4: mov ecx,0x2
4842e9: mov edx,0x8
4842ee: call 0x4768f8
4842f3: push 0x12
4842f5: push 0xa0
4842fa: push 0x5d
4842fc: push 0xbe
484301: push 0x1
484303: push 0x1
484305: push 0x7
484307: push 0x0
484309: xor eax,eax
48430b: mov al,bl
48430d: mov ecx,0x2
484312: mov edx,0x9
484317: call 0x4768f8
48431c: push 0xf
48431e: push 0x66
484320: push 0x4a
484322: push 0x78
484324: push 0x1
484326: push 0x2
484328: push 0xe
48432a: push 0x0
48432c: xor eax,eax
48432e: mov al,bl
484330: mov ecx,0x5
484335: mov edx,0xa
48433a: call 0x4768f8
48433f: push 0xf
484341: push 0x87
484346: push 0x6e
484348: push 0x9b
48434d: push 0x1
48434f: push 0x2
484351: push 0xe
484353: push 0x0
484355: xor eax,eax
484357: mov al,bl
484359: mov ecx,0x5
48435e: mov edx,0xb
484363: call 0x4768f8
484368: push 0x26
48436a: push 0x64
48436c: push 0x55
48436e: push 0x8c
484373: push 0x1
484375: push 0x1
484377: push 0x7
484379: push 0x0
48437b: xor eax,eax
48437d: mov al,bl
48437f: mov ecx,0x2
484384: mov edx,0xd
484389: call 0x4768f8
48438e: push 0x12
484390: push 0x6e
484392: push 0x6c
484394: push 0x8f
484399: push 0x1
48439b: push 0x1
48439d: push 0x7
48439f: push 0x0
4843a1: xor eax,eax
4843a3: mov al,bl
4843a5: mov ecx,0x2
4843aa: mov edx,0xe
4843af: call 0x4768f8
4843b4: push 0x26
4843b6: push 0x64
4843b8: push 0x55
4843ba: push 0x8c
4843bf: push 0x1
4843c1: push 0x2
4843c3: push 0xe
4843c5: push 0x0
4843c7: xor eax,eax
4843c9: mov al,bl
4843cb: mov ecx,0x5
4843d0: mov edx,0xf
4843d5: call 0x4768f8
4843da: push 0x12
4843dc: push 0x6e
4843de: push 0x6c
4843e0: push 0x8f
4843e5: push 0x1
4843e7: push 0x2
4843e9: push 0xe
4843eb: push 0x0
4843ed: xor eax,eax
4843ef: mov al,bl
4843f1: mov ecx,0x5
4843f6: mov edx,0x10
4843fb: call 0x4768f8
484400: push 0x8
484402: push 0x0
484404: push 0x32
484406: push 0xaa
48440b: push 0x1
48440d: push 0x0
48440f: push 0x16
484411: push 0x2
484413: xor eax,eax
484415: mov al,bl
484417: mov ecx,0x2
48441c: mov edx,0x1b
484421: call 0x4768f8
484426: push 0x0
484428: push 0x0
48442a: push 0x0
48442c: push 0x0
48442e: push 0x0
484430: push 0x0
484432: push 0x0
484434: push 0x0
484436: xor eax,eax
484438: mov al,bl
48443a: mov ecx,0xd
48443f: mov edx,0x1b
484444: call 0x4768f8
484449: push 0x0
48444b: push 0x46
48444d: push 0x4b
48444f: push 0x82
484454: push 0x1
484456: push 0x0
484458: push 0x3
48445a: push 0x1
48445c: xor eax,eax
48445e: mov al,bl
484460: mov ecx,0x1
484465: mov edx,0x1c
48446a: call 0x4768f8
48446f: push 0x0
484471: push 0x46
484473: push 0x4b
484475: push 0x82
48447a: push 0x1
48447c: push 0x0
48447e: push 0x12
484480: push 0x1
484482: xor eax,eax
484484: mov al,bl
484486: mov ecx,0x3
48448b: mov edx,0x1c
484490: call 0x4768f8
484495: push 0x0
484497: push 0x0
484499: push 0x0
48449b: push 0x0
48449d: push 0x0
48449f: push 0x0
4844a1: push 0x0
4844a3: push 0x0
4844a5: xor eax,eax
4844a7: mov al,bl
4844a9: mov ecx,0x5
4844ae: mov edx,0x1c
4844b3: call 0x4768f8
4844b8: push 0x0
4844ba: push 0x46
4844bc: push 0x46
4844be: push 0x9b
4844c3: push 0x1
4844c5: push 0x2
4844c7: push 0x2
4844c9: push 0x1
4844cb: xor eax,eax
4844cd: mov al,bl
4844cf: mov ecx,0x1
4844d4: mov edx,0x1d
4844d9: call 0x4768f8
4844de: push 0x0
4844e0: push 0x46
4844e2: push 0x46
4844e4: push 0x9b
4844e9: push 0x1
4844eb: push 0x1
4844ed: push 0x1
4844ef: push 0x1
4844f1: xor eax,eax
4844f3: mov al,bl
4844f5: mov ecx,0x3
4844fa: mov edx,0x1d
4844ff: call 0x4768f8
484504: push 0x0
484506: push 0x46
484508: push 0x46
48450a: push 0x9b
48450f: push 0x1
484511: push 0x2
484513: push 0x2
484515: push 0x1
484517: xor eax,eax
484519: mov al,bl
48451b: mov ecx,0x6
484520: mov edx,0x1d
484525: call 0x4768f8
48452a: push 0x8
48452c: push 0x28
48452e: push 0x37
484530: push 0xa5
484535: push 0x1
484537: push 0x1
484539: push 0x3
48453b: push 0x2
48453d: xor eax,eax
48453f: mov al,bl
484541: mov ecx,0x8
484546: mov edx,0x1d
48454b: call 0x4768f8
484550: push 0x8
484552: push 0x28
484554: push 0x37
484556: push 0xa5
48455b: push 0x1
48455d: push 0x2
48455f: push 0x2
484561: push 0x1
484563: xor eax,eax
484565: mov al,bl
484567: mov ecx,0xa
48456c: mov edx,0x1d
484571: call 0x4768f8
484576: push 0x8
484578: push 0x28
48457a: push 0x37
48457c: push 0xa5
484581: push 0x1
484583: push 0x2
484585: push 0x4
484587: push 0x1
484589: xor eax,eax
48458b: mov al,bl
48458d: mov ecx,0xc
484592: mov edx,0x1d
484597: call 0x4768f8
48459c: push 0x8
48459e: push 0x28
4845a0: push 0x37
4845a2: push 0xa5
4845a7: push 0x1
4845a9: push 0x1
4845ab: push 0x3
4845ad: push 0x2
4845af: xor eax,eax
4845b1: mov al,bl
4845b3: mov ecx,0xe
4845b8: mov edx,0x1d
4845bd: call 0x4768f8
4845c2: push 0x8
4845c4: push 0x28
4845c6: push 0x37
4845c8: push 0xa5
4845cd: push 0x1
4845cf: push 0x2
4845d1: push 0x6
4845d3: push 0x1
4845d5: xor eax,eax
4845d7: mov al,bl
4845d9: mov ecx,0x10
4845de: mov edx,0x1d
4845e3: call 0x4768f8
4845e8: push 0x8
4845ea: push 0x28
4845ec: push 0x37
4845ee: push 0xa5
4845f3: push 0x1
4845f5: push 0x2
4845f7: push 0x5
4845f9: push 0x2
4845fb: xor eax,eax
4845fd: mov al,bl
4845ff: mov ecx,0x12
484604: mov edx,0x1d
484609: call 0x4768f8
48460e: push 0x8
484610: push 0x28
484612: push 0x37
484614: push 0xa5
484619: push 0x1
48461b: push 0x3
48461d: push 0x6
48461f: push 0x1
484621: xor eax,eax
484623: mov al,bl
484625: mov ecx,0x14
48462a: mov edx,0x1d
48462f: call 0x4768f8
484634: push 0x8
484636: push 0x28
484638: push 0x37
48463a: push 0xa5
48463f: push 0x1
484641: push 0x3
484643: push 0x9
484645: push 0x1
484647: xor eax,eax
484649: mov al,bl
48464b: mov ecx,0x16
484650: mov edx,0x1d
484655: call 0x4768f8
48465a: push 0x0
48465c: push 0x0
48465e: push 0x0
484660: push 0x0
484662: push 0x0
484664: push 0x0
484666: push 0x0
484668: push 0x0
48466a: xor eax,eax
48466c: mov al,bl
48466e: mov ecx,0x19
484673: mov edx,0x1d
484678: call 0x4768f8
48467d: xor eax,eax
48467f: mov al,bl
484681: imul eax,eax,0x16
484684: cmp BYTE PTR [esi+eax*8-0xa0],0x7
48468c: jne 0x4857e0
484692: xor eax,eax
484694: mov al,bl
484696: imul eax,eax,0x16
484699: cmp BYTE PTR [esi+eax*8-0x45],0x17
48469e: jne 0x4846e0
4846a0: xor eax,eax
4846a2: mov al,bl
4846a4: imul eax,eax,0x16
4846a7: fild WORD PTR [esi+eax*8-0x3c]
4846ab: fdiv DWORD PTR ds:0x48dd34
4846b1: call 0x40287c
4846b6: xor eax,eax
4846b8: mov al,bl
4846ba: imul eax,eax,0x16
4846bd: fild WORD PTR [esi+eax*8-0x3c]
4846c1: fdiv DWORD PTR ds:0x48dd34
4846c7: fcompp
4846c9: fnstsw ax
4846cb: sahf
4846cc: jne 0x4846e0
4846ce: xor eax,eax
4846d0: mov al,bl
4846d2: imul eax,eax,0x16
4846d5: mov dl,BYTE PTR [esp+0x1]
4846d9: add dl,0x21
4846dc: mov BYTE PTR [esi+eax*8-0x44],dl
4846e0: xor eax,eax
4846e2: mov al,bl
4846e4: imul eax,eax,0x16
4846e7: cmp BYTE PTR [esi+eax*8-0x45],0x17
4846ec: jne 0x48472e
4846ee: xor eax,eax
4846f0: mov al,bl
4846f2: imul eax,eax,0x16
4846f5: fild WORD PTR [esi+eax*8-0x3c]
4846f9: fdiv DWORD PTR ds:0x48dd34
4846ff: call 0x40287c
484704: xor eax,eax
484706: mov al,bl
484708: imul eax,eax,0x16
48470b: fild WORD PTR [esi+eax*8-0x3c]
48470f: fdiv DWORD PTR ds:0x48dd34
484715: fcompp
484717: fnstsw ax
484719: sahf
48471a: je 0x48472e
48471c: xor eax,eax
48471e: mov al,bl
484720: imul eax,eax,0x16
484723: mov dl,BYTE PTR [esp+0x1]
484727: add dl,0x22
48472a: mov BYTE PTR [esi+eax*8-0x44],dl
48472e: xor eax,eax
484730: mov al,bl
484732: imul eax,eax,0x16
484735: cmp BYTE PTR [esi+eax*8-0x45],0x18
48473a: jne 0x48475d
48473c: xor eax,eax
48473e: mov al,bl
484740: imul eax,eax,0x16
484743: cmp WORD PTR [esi+eax*8-0x3c],0x0
484749: jne 0x48475d
48474b: xor eax,eax
48474d: mov al,bl
48474f: imul eax,eax,0x16
484752: mov dl,BYTE PTR [esp+0x1]
484756: add dl,0xc
484759: mov BYTE PTR [esi+eax*8-0x44],dl
48475d: xor eax,eax
48475f: mov al,bl
484761: imul eax,eax,0x16
484764: cmp BYTE PTR [esi+eax*8-0x45],0x18
484769: jne 0x48478c
48476b: xor eax,eax
48476d: mov al,bl
48476f: imul eax,eax,0x16
484772: cmp WORD PTR [esi+eax*8-0x3c],0x2
484778: jne 0x48478c
48477a: xor eax,eax
48477c: mov al,bl
48477e: imul eax,eax,0x16
484781: mov dl,BYTE PTR [esp+0x1]
484785: add dl,0x1e
484788: mov BYTE PTR [esi+eax*8-0x44],dl
48478c: xor eax,eax
48478e: mov al,bl
484790: imul eax,eax,0x16
484793: cmp BYTE PTR [esi+eax*8-0x45],0x19
484798: jne 0x48496f
48479e: xor eax,eax
4847a0: mov al,bl
4847a2: imul eax,eax,0x16
4847a5: cmp WORD PTR [esi+eax*8-0x3c],0x0
4847ab: jne 0x4847bf
4847ad: xor eax,eax
4847af: mov al,bl
4847b1: imul eax,eax,0x16
4847b4: mov dl,BYTE PTR [esp+0x1]
4847b8: add dl,0x23
4847bb: mov BYTE PTR [esi+eax*8-0x44],dl
4847bf: xor eax,eax
4847c1: mov al,bl
4847c3: imul eax,eax,0x16
4847c6: cmp WORD PTR [esi+eax*8-0x3c],0x2
4847cc: jne 0x4847e0
4847ce: xor eax,eax
4847d0: mov al,bl
4847d2: imul eax,eax,0x16
4847d5: mov dl,BYTE PTR [esp+0x1]
4847d9: add dl,0x24
4847dc: mov BYTE PTR [esi+eax*8-0x44],dl
4847e0: xor eax,eax
4847e2: mov al,bl
4847e4: imul eax,eax,0x16
4847e7: cmp WORD PTR [esi+eax*8-0x3c],0x4
4847ed: jne 0x484801
4847ef: xor eax,eax
4847f1: mov al,bl
4847f3: imul eax,eax,0x16
4847f6: mov dl,BYTE PTR [esp+0x1]
4847fa: add dl,0x25
4847fd: mov BYTE PTR [esi+eax*8-0x44],dl
484801: xor eax,eax
484803: mov al,bl
484805: imul eax,eax,0x16
484808: cmp WORD PTR [esi+eax*8-0x3c],0x6
48480e: jne 0x484822
484810: xor eax,eax
484812: mov al,bl
484814: imul eax,eax,0x16
484817: mov dl,BYTE PTR [esp+0x1]
48481b: add dl,0x23
48481e: mov BYTE PTR [esi+eax*8-0x44],dl
484822: xor eax,eax
484824: mov al,bl
484826: imul eax,eax,0x16
484829: cmp WORD PTR [esi+eax*8-0x3c],0x8
48482f: jne 0x484843
484831: xor eax,eax
484833: mov al,bl
484835: imul eax,eax,0x16
484838: mov dl,BYTE PTR [esp+0x1]
48483c: add dl,0x24
48483f: mov BYTE PTR [esi+eax*8-0x44],dl
484843: xor eax,eax
484845: mov al,bl
484847: imul eax,eax,0x16
48484a: cmp WORD PTR [esi+eax*8-0x3c],0xa
484850: jne 0x484864
484852: xor eax,eax
484854: mov al,bl
484856: imul eax,eax,0x16
484859: mov dl,BYTE PTR [esp+0x1]
48485d: add dl,0x25
484860: mov BYTE PTR [esi+eax*8-0x44],dl
484864: xor eax,eax
484866: mov al,bl
484868: imul eax,eax,0x16
48486b: cmp WORD PTR [esi+eax*8-0x3c],0xc
484871: jne 0x484885
484873: xor eax,eax
484875: mov al,bl
484877: imul eax,eax,0x16
48487a: mov dl,BYTE PTR [esp+0x1]
48487e: add dl,0x23
484881: mov BYTE PTR [esi+eax*8-0x44],dl
484885: xor eax,eax
484887: mov al,bl
484889: imul eax,eax,0x16
48488c: cmp WORD PTR [esi+eax*8-0x3c],0xe
484892: jne 0x4848a6
484894: xor eax,eax
484896: mov al,bl
484898: imul eax,eax,0x16
48489b: mov dl,BYTE PTR [esp+0x1]
48489f: add dl,0x24
4848a2: mov BYTE PTR [esi+eax*8-0x44],dl
4848a6: xor eax,eax
4848a8: mov al,bl
4848aa: imul eax,eax,0x16
4848ad: cmp WORD PTR [esi+eax*8-0x3c],0x10
4848b3: jne 0x4848c7
4848b5: xor eax,eax
4848b7: mov al,bl
4848b9: imul eax,eax,0x16
4848bc: mov dl,BYTE PTR [esp+0x1]
4848c0: add dl,0x25
4848c3: mov BYTE PTR [esi+eax*8-0x44],dl
4848c7: xor eax,eax
4848c9: mov al,bl
4848cb: imul eax,eax,0x16
4848ce: cmp BYTE PTR [esi+eax*8-0x43],0x1
4848d3: jne 0x4848f1
4848d5: xor eax,eax
4848d7: mov al,bl
4848d9: imul eax,eax,0x16
4848dc: cmp BYTE PTR [esi+eax*8-0x41],0x1
4848e1: jne 0x4848f1
4848e3: push 0x40000000
4848e8: push 0x0
4848ea: mov eax,ebx
4848ec: call 0x47648c
4848f1: xor eax,eax
4848f3: mov al,bl
4848f5: imul eax,eax,0x16
4848f8: cmp BYTE PTR [esi+eax*8-0x43],0x2
4848fd: jne 0x48491b
4848ff: xor eax,eax
484901: mov al,bl
484903: imul eax,eax,0x16
484906: cmp BYTE PTR [esi+eax*8-0x41],0x1
48490b: jne 0x48491b
48490d: push 0xc0000000
484912: push 0x0
484914: mov eax,ebx
484916: call 0x47648c
48491b: xor eax,eax
48491d: mov al,bl
48491f: imul eax,eax,0x16
484922: cmp BYTE PTR [esi+eax*8-0x43],0x1
484927: jne 0x484945
484929: xor eax,eax
48492b: mov al,bl
48492d: imul eax,eax,0x16
484930: cmp BYTE PTR [esi+eax*8-0x41],0x2
484935: jne 0x484945
484937: push 0x40100000
48493c: push 0x0
48493e: mov eax,ebx
484940: call 0x47648c
484945: xor eax,eax
484947: mov al,bl
484949: imul eax,eax,0x16
48494c: cmp BYTE PTR [esi+eax*8-0x43],0x2
484951: jne 0x48496f
484953: xor eax,eax
484955: mov al,bl
484957: imul eax,eax,0x16
48495a: cmp BYTE PTR [esi+eax*8-0x41],0x2
48495f: jne 0x48496f
484961: push 0xc0100000
484966: push 0x0
484968: mov eax,ebx
48496a: call 0x47648c
48496f: xor eax,eax
484971: mov al,bl
484973: imul eax,eax,0x16
484976: cmp BYTE PTR [esi+eax*8-0x45],0x1a
48497b: jne 0x484a62
484981: xor eax,eax
484983: mov al,bl
484985: imul eax,eax,0x16
484988: cmp WORD PTR [esi+eax*8-0x3c],0x0
48498e: jne 0x4849a2
484990: xor eax,eax
484992: mov al,bl
484994: imul eax,eax,0x16
484997: mov dl,BYTE PTR [esp+0x1]
48499b: add dl,0x26
48499e: mov BYTE PTR [esi+eax*8-0x44],dl
4849a2: xor eax,eax
4849a4: mov al,bl
4849a6: imul eax,eax,0x16
4849a9: cmp WORD PTR [esi+eax*8-0x3c],0x2
4849af: jne 0x4849c3
4849b1: xor eax,eax
4849b3: mov al,bl
4849b5: imul eax,eax,0x16
4849b8: mov dl,BYTE PTR [esp+0x1]
4849bc: add dl,0x27
4849bf: mov BYTE PTR [esi+eax*8-0x44],dl
4849c3: xor eax,eax
4849c5: mov al,bl
4849c7: imul eax,eax,0x16
4849ca: cmp WORD PTR [esi+eax*8-0x3c],0x4
4849d0: jne 0x4849e4
4849d2: xor eax,eax
4849d4: mov al,bl
4849d6: imul eax,eax,0x16
4849d9: mov dl,BYTE PTR [esp+0x1]
4849dd: add dl,0x28
4849e0: mov BYTE PTR [esi+eax*8-0x44],dl
4849e4: xor eax,eax
4849e6: mov al,bl
4849e8: imul eax,eax,0x16
4849eb: cmp WORD PTR [esi+eax*8-0x3c],0x6
4849f1: jne 0x484a05
4849f3: xor eax,eax
4849f5: mov al,bl
4849f7: imul eax,eax,0x16
4849fa: mov dl,BYTE PTR [esp+0x1]
4849fe: add dl,0x29
484a01: mov BYTE PTR [esi+eax*8-0x44],dl
484a05: xor eax,eax
484a07: mov al,bl
484a09: imul eax,eax,0x16
484a0c: cmp WORD PTR [esi+eax*8-0x3c],0x8
484a12: jne 0x484a26
484a14: xor eax,eax
484a16: mov al,bl
484a18: imul eax,eax,0x16
484a1b: mov dl,BYTE PTR [esp+0x1]
484a1f: add dl,0x28
484a22: mov BYTE PTR [esi+eax*8-0x44],dl
484a26: xor eax,eax
484a28: mov al,bl
484a2a: imul eax,eax,0x16
484a2d: cmp WORD PTR [esi+eax*8-0x3c],0xa
484a33: jne 0x484a47
484a35: xor eax,eax
484a37: mov al,bl
484a39: imul eax,eax,0x16
484a3c: mov dl,BYTE PTR [esp+0x1]
484a40: add dl,0x27
484a43: mov BYTE PTR [esi+eax*8-0x44],dl
484a47: xor eax,eax
484a49: mov al,bl
484a4b: imul eax,eax,0x16
484a4e: cmp WORD PTR [esi+eax*8-0x3c],0x5
484a54: jl 0x484a62
484a56: xor eax,eax
484a58: mov al,bl
484a5a: imul eax,eax,0x16
484a5d: mov BYTE PTR [esi+eax*8-0x47],0x1
484a62: xor eax,eax
484a64: mov al,bl
484a66: imul eax,eax,0x16
484a69: cmp BYTE PTR [esi+eax*8-0x45],0x1b
484a6e: jne 0x484bc0
484a74: xor eax,eax
484a76: mov al,bl
484a78: imul eax,eax,0x16
484a7b: cmp WORD PTR [esi+eax*8-0x3c],0x0
484a81: jne 0x484a95
484a83: xor eax,eax
484a85: mov al,bl
484a87: imul eax,eax,0x16
484a8a: mov dl,BYTE PTR [esp+0x1]
484a8e: add dl,0x2a
484a91: mov BYTE PTR [esi+eax*8-0x44],dl
484a95: xor eax,eax
484a97: mov al,bl
484a99: imul eax,eax,0x16
484a9c: cmp WORD PTR [esi+eax*8-0x3c],0x2
484aa2: jne 0x484ab6
484aa4: xor eax,eax
484aa6: mov al,bl
484aa8: imul eax,eax,0x16
484aab: mov dl,BYTE PTR [esp+0x1]
484aaf: add dl,0x2b
484ab2: mov BYTE PTR [esi+eax*8-0x44],dl
484ab6: xor eax,eax
484ab8: mov al,bl
484aba: imul eax,eax,0x16
484abd: cmp WORD PTR [esi+eax*8-0x3c],0x4
484ac3: jne 0x484ad7
484ac5: xor eax,eax
484ac7: mov al,bl
484ac9: imul eax,eax,0x16
484acc: mov dl,BYTE PTR [esp+0x1]
484ad0: add dl,0x2c
484ad3: mov BYTE PTR [esi+eax*8-0x44],dl
484ad7: xor eax,eax
484ad9: mov al,bl
484adb: imul eax,eax,0x16
484ade: cmp WORD PTR [esi+eax*8-0x3c],0x0
484ae4: jle 0x484ba5
484aea: xor eax,eax
484aec: mov al,bl
484aee: imul eax,eax,0x16
484af1: cmp WORD PTR [esi+eax*8-0x3c],0x5
484af7: jge 0x484ba5
484afd: xor eax,eax
484aff: mov al,bl
484b01: imul eax,eax,0x16
484b04: cmp BYTE PTR [esi+eax*8-0x43],0x1
484b09: jne 0x484b27
484b0b: xor eax,eax
484b0d: mov al,bl
484b0f: imul eax,eax,0x16
484b12: cmp BYTE PTR [esi+eax*8-0x41],0x1
484b17: jne 0x484b27
484b19: push 0x401c0000
484b1e: push 0x0
484b20: mov eax,ebx
484b22: call 0x47648c
484b27: xor eax,eax
484b29: mov al,bl
484b2b: imul eax,eax,0x16
484b2e: cmp BYTE PTR [esi+eax*8-0x43],0x2
484b33: jne 0x484b51
484b35: xor eax,eax
484b37: mov al,bl
484b39: imul eax,eax,0x16
484b3c: cmp BYTE PTR [esi+eax*8-0x41],0x1
484b41: jne 0x484b51
484b43: push 0xc01c0000
484b48: push 0x0
484b4a: mov eax,ebx
484b4c: call 0x47648c
484b51: xor eax,eax
484b53: mov al,bl
484b55: imul eax,eax,0x16
484b58: cmp BYTE PTR [esi+eax*8-0x43],0x1
484b5d: jne 0x484b7b
484b5f: xor eax,eax
484b61: mov al,bl
484b63: imul eax,eax,0x16
484b66: cmp BYTE PTR [esi+eax*8-0x41],0x2
484b6b: jne 0x484b7b
484b6d: push 0x40280000
484b72: push 0x0
484b74: mov eax,ebx
484b76: call 0x47648c
484b7b: xor eax,eax
484b7d: mov al,bl
484b7f: imul eax,eax,0x16
484b82: cmp BYTE PTR [esi+eax*8-0x43],0x2
484b87: jne 0x484ba5
484b89: xor eax,eax
484b8b: mov al,bl
484b8d: imul eax,eax,0x16
484b90: cmp BYTE PTR [esi+eax*8-0x41],0x2
484b95: jne 0x484ba5
484b97: push 0xc0280000
484b9c: push 0x0
484b9e: mov eax,ebx
484ba0: call 0x47648c
484ba5: xor eax,eax
484ba7: mov al,bl
484ba9: imul eax,eax,0x16
484bac: cmp WORD PTR [esi+eax*8-0x3c],0x3
484bb2: jl 0x484bc0
484bb4: xor eax,eax
484bb6: mov al,bl
484bb8: imul eax,eax,0x16
484bbb: mov BYTE PTR [esi+eax*8-0x47],0x1
484bc0: xor eax,eax
484bc2: mov al,bl
484bc4: imul eax,eax,0x16
484bc7: cmp BYTE PTR [esi+eax*8-0x45],0x1c
484bcc: jne 0x484cc8
484bd2: xor eax,eax
484bd4: mov al,bl
484bd6: imul eax,eax,0x16
484bd9: cmp WORD PTR [esi+eax*8-0x3c],0x0
484bdf: jne 0x484bf3
484be1: xor eax,eax
484be3: mov al,bl
484be5: imul eax,eax,0x16
484be8: mov dl,BYTE PTR [esp+0x1]
484bec: add dl,0x2d
484bef: mov BYTE PTR [esi+eax*8-0x44],dl
484bf3: xor eax,eax
484bf5: mov al,bl
484bf7: imul eax,eax,0x16
484bfa: cmp WORD PTR [esi+eax*8-0x3c],0x2
484c00: jne 0x484c14
484c02: xor eax,eax
484c04: mov al,bl
484c06: imul eax,eax,0x16
484c09: mov dl,BYTE PTR [esp+0x1]
484c0d: add dl,0x2e
484c10: mov BYTE PTR [esi+eax*8-0x44],dl
484c14: xor eax,eax
484c16: mov al,bl
484c18: imul eax,eax,0x16
484c1b: cmp BYTE PTR [esi+eax*8-0x43],0x1
484c20: jne 0x484c3e
484c22: xor eax,eax
484c24: mov al,bl
484c26: imul eax,eax,0x16
484c29: cmp BYTE PTR [esi+eax*8-0x41],0x1
484c2e: jne 0x484c3e
484c30: push 0x40180000
484c35: push 0x0
484c37: mov eax,ebx
484c39: call 0x47648c
484c3e: xor eax,eax
484c40: mov al,bl
484c42: imul eax,eax,0x16
484c45: cmp BYTE PTR [esi+eax*8-0x43],0x2
484c4a: jne 0x484c68
484c4c: xor eax,eax
484c4e: mov al,bl
484c50: imul eax,eax,0x16
484c53: cmp BYTE PTR [esi+eax*8-0x41],0x1
484c58: jne 0x484c68
484c5a: push 0xc0180000
484c5f: push 0x0
484c61: mov eax,ebx
484c63: call 0x47648c
484c68: xor eax,eax
484c6a: mov al,bl
484c6c: imul eax,eax,0x16
484c6f: cmp BYTE PTR [esi+eax*8-0x43],0x1
484c74: jne 0x484c92
484c76: xor eax,eax
484c78: mov al,bl
484c7a: imul eax,eax,0x16
484c7d: cmp BYTE PTR [esi+eax*8-0x41],0x2
484c82: jne 0x484c92
484c84: push 0x40260000
484c89: push 0x0
484c8b: mov eax,ebx
484c8d: call 0x47648c
484c92: xor eax,eax
484c94: mov al,bl
484c96: imul eax,eax,0x16
484c99: cmp BYTE PTR [esi+eax*8-0x43],0x2
484c9e: jne 0x484cbc
484ca0: xor eax,eax
484ca2: mov al,bl
484ca4: imul eax,eax,0x16
484ca7: cmp BYTE PTR [esi+eax*8-0x41],0x2
484cac: jne 0x484cbc
484cae: push 0xc0260000
484cb3: push 0x0
484cb5: mov eax,ebx
484cb7: call 0x47648c
484cbc: xor eax,eax
484cbe: mov al,bl
484cc0: imul eax,eax,0x16
484cc3: mov BYTE PTR [esi+eax*8-0x47],0x1
484cc8: xor eax,eax
484cca: mov al,bl
484ccc: imul eax,eax,0x16
484ccf: cmp BYTE PTR [esi+eax*8-0x45],0x1d
484cd4: jne 0x484cf7
484cd6: xor eax,eax
484cd8: mov al,bl
484cda: imul eax,eax,0x16
484cdd: cmp WORD PTR [esi+eax*8-0x3c],0x0
484ce3: jne 0x484cf7
484ce5: xor eax,eax
484ce7: mov al,bl
484ce9: imul eax,eax,0x16
484cec: mov dl,BYTE PTR [esp+0x1]
484cf0: add dl,0x26
484cf3: mov BYTE PTR [esi+eax*8-0x44],dl
484cf7: xor eax,eax
484cf9: mov al,bl
484cfb: imul eax,eax,0x16
484cfe: cmp BYTE PTR [esi+eax*8-0x45],0x1d
484d03: jne 0x484dd0
484d09: xor eax,eax
484d0b: mov al,bl
484d0d: imul eax,eax,0x16
484d10: cmp WORD PTR [esi+eax*8-0x3c],0x2
484d16: jle 0x484dd0
484d1c: xor eax,eax
484d1e: mov al,bl
484d20: imul eax,eax,0x16
484d23: mov dl,BYTE PTR [esp+0x1]
484d27: add dl,0x26
484d2a: mov BYTE PTR [esi+eax*8-0x44],dl
484d2e: xor eax,eax
484d30: mov al,bl
484d32: imul eax,eax,0x16
484d35: cmp BYTE PTR [esi+eax*8-0x43],0x1
484d3a: jne 0x484d4a
484d3c: push 0x40390000
484d41: push 0x0
484d43: mov eax,ebx
484d45: call 0x47648c
484d4a: xor eax,eax
484d4c: mov al,bl
484d4e: imul eax,eax,0x16
484d51: cmp BYTE PTR [esi+eax*8-0x43],0x2
484d56: jne 0x484d66
484d58: push 0xc0390000
484d5d: push 0x0
484d5f: mov eax,ebx
484d61: call 0x47648c
484d66: mov BYTE PTR [esp],0x3
484d6a: mov eax,0x28
484d6f: call 0x402a1c
484d74: mov DWORD PTR [esp+0x4],eax
484d78: fild DWORD PTR [esp+0x4]
484d7c: xor eax,eax
484d7e: mov al,bl
484d80: imul eax,eax,0x16
484d83: fld QWORD PTR [esi+eax*8-0xb0]
484d8a: fsub DWORD PTR ds:0x48dce4
484d90: faddp st(1),st
484d92: add esp,0xfffffff8
484d95: fstp QWORD PTR [esp]
484d98: fwait
484d99: mov eax,0xa
484d9e: call 0x402a1c
484da3: mov DWORD PTR [esp+0x10],eax
484da7: fild DWORD PTR [esp+0x10]
484dab: xor eax,eax
484dad: mov al,bl
484daf: imul eax,eax,0x16
484db2: fadd QWORD PTR [esi+eax*8-0xa8]
484db9: add esp,0xfffffff8
484dbc: fstp QWORD PTR [esp]
484dbf: fwait
484dc0: xor ecx,ecx
484dc2: xor edx,edx
484dc4: mov al,0x2
484dc6: call 0x476a04
484dcb: dec BYTE PTR [esp]
484dce: jne 0x484d6a
484dd0: xor eax,eax
484dd2: mov al,bl
484dd4: imul eax,eax,0x16
484dd7: cmp BYTE PTR [esi+eax*8-0x45],0x1e
484ddc: jne 0x48522e
484de2: xor eax,eax
484de4: mov al,bl
484de6: imul eax,eax,0x16
484de9: mov BYTE PTR [esi+eax*8-0x3e],0x0
484dee: mov eax,0x2e
484df3: call 0x402a1c
484df8: inc eax
484df9: add al,BYTE PTR [esp+0x1]
484dfd: xor edx,edx
484dff: mov dl,bl
484e01: imul edx,edx,0x16
484e04: mov BYTE PTR [esi+edx*8-0x44],al
484e08: mov eax,ds:0x4b0d98
484e0d: cmp BYTE PTR [eax],0x1
484e10: jne 0x484e28
484e12: mov eax,0x5
484e17: call 0x402a1c
484e1c: test eax,eax
484e1e: jne 0x484e28
484e20: mov eax,ds:0x4b0fc8
484e25: mov BYTE PTR [eax],0x3
484e28: mov eax,0x3
484e2d: call 0x402a1c
484e32: test eax,eax
484e34: jne 0x484e4a
484e36: mov eax,0x3
484e3b: call 0x402a1c
484e40: add al,0x3
484e42: mov edx,DWORD PTR ds:0x4b0e84
484e48: mov BYTE PTR [edx],al
484e4a: xor eax,eax
484e4c: mov al,bl
484e4e: imul eax,eax,0x16
484e51: cmp BYTE PTR [esi+eax*8-0x43],0x1
484e56: jne 0x484e66
484e58: push 0x40080000
484e5d: push 0x0
484e5f: mov eax,ebx
484e61: call 0x47648c
484e66: xor eax,eax
484e68: mov al,bl
484e6a: imul eax,eax,0x16
484e6d: cmp BYTE PTR [esi+eax*8-0x43],0x2
484e72: jne 0x484e82
484e74: push 0xc0080000
484e79: push 0x0
484e7b: mov eax,ebx
484e7d: call 0x47648c
484e82: mov eax,0x2
484e87: call 0x402a1c
484e8c: add al,0x1a
484e8e: mov dl,0x32
484e90: sub dl,BYTE PTR [esp+0x1]
484e94: add al,dl
484e96: xor edx,edx
484e98: mov dl,bl
484e9a: mov ecx,0x3
484e9f: sub ecx,edx
484ea1: imul edx,ecx,0x16
484ea4: mov BYTE PTR [esi+edx*8-0x44],al
484ea8: xor eax,eax
484eaa: mov al,bl
484eac: mov edx,0x3
484eb1: sub edx,eax
484eb3: imul eax,edx,0x16
484eb6: mov WORD PTR [esi+eax*8-0x3c],0x0
484ebd: xor eax,eax
484ebf: mov al,bl
484ec1: mov edx,0x3
484ec6: sub edx,eax
484ec8: imul eax,edx,0x16
484ecb: mov WORD PTR [esi+eax*8-0x3a],0x5
484ed2: xor eax,eax
484ed4: mov al,bl
484ed6: mov edx,0x3
484edb: sub edx,eax
484edd: imul eax,edx,0x16
484ee0: mov BYTE PTR [esi+eax*8-0x38],0x0
484ee5: xor eax,eax
484ee7: mov al,bl
484ee9: mov edx,0x3
484eee: sub edx,eax
484ef0: imul eax,edx,0x16
484ef3: fld QWORD PTR [esi+eax*8-0xa8]
484efa: fadd DWORD PTR ds:0x48dcc0
484f00: xor eax,eax
484f02: mov al,bl
484f04: mov edx,0x3
484f09: sub edx,eax
484f0b: imul eax,edx,0x16
484f0e: fstp QWORD PTR [esi+eax*8-0xa8]
484f15: fwait
484f16: mov eax,ds:0x4b11f8
484f1b: fild WORD PTR [eax]
484f1d: xor eax,eax
484f1f: mov al,bl
484f21: mov edx,0x3
484f26: sub edx,eax
484f28: imul eax,edx,0x16
484f2b: fcomp QWORD PTR [esi+eax*8-0xa8]
484f32: fnstsw ax
484f34: sahf
484f35: jae 0x484f54
484f37: mov eax,ds:0x4b11f8
484f3c: fild WORD PTR [eax]
484f3e: xor eax,eax
484f40: mov al,bl
484f42: mov edx,0x3
484f47: sub edx,eax
484f49: imul eax,edx,0x16
484f4c: fstp QWORD PTR [esi+eax*8-0xa8]
484f53: fwait
484f54: xor eax,eax
484f56: mov al,bl
484f58: imul eax,eax,0x16
484f5b: cmp BYTE PTR [esi+eax*8-0x43],0x1
484f60: jne 0x484fa3
484f62: mov eax,0x2
484f67: call 0x402a1c
484f6c: shl eax,0x3
484f6f: mov DWORD PTR [esp+0x4],eax
484f73: fild DWORD PTR [esp+0x4]
484f77: xor eax,eax
484f79: mov al,bl
484f7b: imul eax,eax,0x16
484f7e: fld QWORD PTR [esi+eax*8-0xb0]
484f85: fadd DWORD PTR ds:0x48dd10
484f8b: faddp st(1),st
484f8d: xor eax,eax
484f8f: mov al,bl
484f91: mov edx,0x3
484f96: sub edx,eax
484f98: imul eax,edx,0x16
484f9b: fstp QWORD PTR [esi+eax*8-0xb0]
484fa2: fwait
484fa3: xor eax,eax
484fa5: mov al,bl
484fa7: imul eax,eax,0x16
484faa: cmp BYTE PTR [esi+eax*8-0x43],0x2
484faf: jne 0x484ff2
484fb1: mov eax,0x2
484fb6: call 0x402a1c
484fbb: shl eax,0x3
484fbe: mov DWORD PTR [esp+0x4],eax
484fc2: fild DWORD PTR [esp+0x4]
484fc6: xor eax,eax
484fc8: mov al,bl
484fca: imul eax,eax,0x16
484fcd: fld QWORD PTR [esi+eax*8-0xb0]
484fd4: fsub DWORD PTR ds:0x48dd10
484fda: fsubrp st(1),st
484fdc: xor eax,eax
484fde: mov al,bl
484fe0: mov edx,0x3
484fe5: sub edx,eax
484fe7: imul eax,edx,0x16
484fea: fstp QWORD PTR [esi+eax*8-0xb0]
484ff1: fwait
484ff2: xor eax,eax
484ff4: mov al,bl
484ff6: imul eax,eax,0x16
484ff9: inc BYTE PTR [esi+eax*8-0x1b]
484ffd: xor eax,eax
484fff: mov al,bl
485001: imul eax,eax,0x16
485004: mov BYTE PTR [esi+eax*8-0x1a],0x2b
485009: mov eax,0x4
48500e: call 0x402a1c
485013: test eax,eax
485015: jne 0x48501f
485017: mov eax,ds:0x4b1098
48501c: mov BYTE PTR [eax],0x7
48501f: mov eax,0x4
485024: call 0x402a1c
485029: test eax,eax
48502b: jne 0x485035
48502d: mov eax,ds:0x4b1098
485032: mov BYTE PTR [eax],0x8
485035: mov eax,0x4
48503a: call 0x402a1c
48503f: test eax,eax
485041: jne 0x48504b
485043: mov eax,ds:0x4b1098
485048: mov BYTE PTR [eax],0x9
48504b: mov eax,0x28
485050: call 0x402a1c
485055: mov DWORD PTR [esp+0x4],eax
485059: fild DWORD PTR [esp+0x4]
48505d: xor eax,eax
48505f: mov al,bl
485061: mov edx,0x3
485066: sub edx,eax
485068: imul eax,edx,0x16
48506b: fld QWORD PTR [esi+eax*8-0xb0]
485072: fsub DWORD PTR ds:0x48dce4
485078: faddp st(1),st
48507a: add esp,0xfffffff8
48507d: fstp QWORD PTR [esp]
485080: fwait
485081: mov eax,0x64
485086: call 0x402a1c
48508b: mov DWORD PTR [esp+0x10],eax
48508f: fild DWORD PTR [esp+0x10]
485093: xor eax,eax
485095: mov al,bl
485097: mov edx,0x3
48509c: sub edx,eax
48509e: imul eax,edx,0x16
4850a1: fld QWORD PTR [esi+eax*8-0xa8]
4850a8: fsub DWORD PTR ds:0x48dd18
4850ae: faddp st(1),st
4850b0: add esp,0xfffffff8
4850b3: fstp QWORD PTR [esp]
4850b6: fwait
4850b7: xor ecx,ecx
4850b9: xor edx,edx
4850bb: mov al,0x1
4850bd: call 0x476a04
4850c2: xor eax,eax
4850c4: mov al,bl
4850c6: imul eax,eax,0x16
4850c9: movsx eax,WORD PTR [esi+eax*8-0x3c]
4850ce: xor edx,edx
4850d0: mov dl,bl
4850d2: imul edx,edx,0x16
4850d5: movsx edx,WORD PTR [esi+edx*8-0x3a]
4850da: sub edx,0x2
4850dd: cmp eax,edx
4850df: jle 0x48522e
4850e5: xor eax,eax
4850e7: mov al,bl
4850e9: imul eax,eax,0x16
4850ec: mov BYTE PTR [esi+eax*8-0x40],0x24
4850f1: xor eax,eax
4850f3: mov al,bl
4850f5: imul eax,eax,0x16
4850f8: movzx eax,BYTE PTR [esi+eax*8-0x40]
4850fd: mov DWORD PTR [esp+0x4],eax
485101: fild DWORD PTR [esp+0x4]
485105: mov eax,ds:0x4b11f4
48510a: fmul QWORD PTR [eax]
48510c: xor eax,eax
48510e: mov al,bl
485110: mov edx,0x3
485115: sub edx,eax
485117: imul eax,edx,0x16
48511a: fsubr QWORD PTR [esi+eax*8-0x70]
48511e: xor eax,eax
485120: mov al,bl
485122: mov edx,0x3
485127: sub edx,eax
485129: imul eax,edx,0x16
48512c: fstp QWORD PTR [esi+eax*8-0x70]
485130: fwait
485131: xor eax,eax
485133: mov al,bl
485135: imul eax,eax,0x16
485138: mov BYTE PTR [esi+eax*8-0x45],0x1
48513d: xor eax,eax
48513f: mov al,bl
485141: imul eax,eax,0x16
485144: mov dl,BYTE PTR [esp+0x1]
485148: add dl,0xc
48514b: mov BYTE PTR [esi+eax*8-0x44],dl
48514f: xor eax,eax
485151: mov al,bl
485153: mov edx,0x3
485158: sub edx,eax
48515a: imul eax,edx,0x16
48515d: fld QWORD PTR [esi+eax*8-0x70]
485161: fcomp DWORD PTR ds:0x48dcc4
485167: fnstsw ax
485169: sahf
48516a: jbe 0x485174
48516c: mov eax,ds:0x4b0e84
485171: mov BYTE PTR [eax],0x5
485174: xor eax,eax
485176: mov al,bl
485178: imul eax,eax,0x16
48517b: mov WORD PTR [esi+eax*8-0x3c],0x0
485182: xor eax,eax
485184: mov al,bl
485186: imul eax,eax,0x16
485189: mov BYTE PTR [esi+eax*8-0x38],0xd0
48518e: xor eax,eax
485190: mov al,bl
485192: imul eax,eax,0x16
485195: mov BYTE PTR [esi+eax*8-0x46],0x1
48519a: mov dl,0x15
48519c: mov eax,ebx
48519e: call 0x4775fc
4851a3: mov al,0x3
4851a5: sub al,bl
4851a7: mov dl,0xa
4851a9: call 0x4775fc
4851ae: xor eax,eax
4851b0: mov al,bl
4851b2: mov edx,0x3
4851b7: sub edx,eax
4851b9: imul eax,edx,0x16
4851bc: mov BYTE PTR [esi+eax*8-0x3e],0x1e
4851c1: xor eax,eax
4851c3: mov al,bl
4851c5: mov edx,0x3
4851ca: sub edx,eax
4851cc: imul eax,edx,0x16
4851cf: mov BYTE PTR [esi+eax*8-0x38],0xdd
4851d4: xor eax,eax
4851d6: mov al,bl
4851d8: mov edx,0x3
4851dd: sub edx,eax
4851df: imul eax,edx,0x16
4851e2: cmp BYTE PTR [esi+eax*8-0x43],0x1
4851e7: jne 0x485201
4851e9: xor eax,eax
4851eb: mov al,bl
4851ed: mov edx,0x3
4851f2: sub edx,eax
4851f4: imul eax,edx,0x16
4851f7: mov WORD PTR [esi+eax*8-0x98],0xffe7
485201: xor eax,eax
485203: mov al,bl
485205: mov edx,0x3
48520a: sub edx,eax
48520c: imul eax,edx,0x16
48520f: cmp BYTE PTR [esi+eax*8-0x43],0x2
485214: jne 0x48522e
485216: xor eax,eax
485218: mov al,bl
48521a: mov edx,0x3
48521f: sub edx,eax
485221: imul eax,edx,0x16
485224: mov WORD PTR [esi+eax*8-0x98],0x19
48522e: push 0x23
485230: push 0x14
485232: push 0xaa
485237: xor edx,edx
485239: mov dl,BYTE PTR [esp+0xd]
48523d: inc edx
48523e: xor eax,eax
485240: mov al,bl
485242: mov ecx,0xfffffff4
485247: call 0x476870
48524c: push 0x23
48524e: push 0x14
485250: push 0xaa
485255: xor edx,edx
485257: mov dl,BYTE PTR [esp+0xd]
48525b: add edx,0x2
48525e: xor eax,eax
485260: mov al,bl
485262: mov ecx,0xfffffff4
485267: call 0x476870
48526c: push 0x23
48526e: push 0x14
485270: push 0xaa
485275: xor edx,edx
485277: mov dl,BYTE PTR [esp+0xd]
48527b: add edx,0x3
48527e: xor eax,eax
485280: mov al,bl
485282: mov ecx,0xfffffff4
485287: call 0x476870
48528c: push 0x23
48528e: push 0x14
485290: push 0xaa
485295: xor edx,edx
485297: mov dl,BYTE PTR [esp+0xd]
48529b: add edx,0x4
48529e: xor eax,eax
4852a0: mov al,bl
4852a2: mov ecx,0xfffffff4
4852a7: call 0x476870
4852ac: push 0x23
4852ae: push 0x14
4852b0: push 0xaa
4852b5: xor edx,edx
4852b7: mov dl,BYTE PTR [esp+0xd]
4852bb: add edx,0x6
4852be: xor eax,eax
4852c0: mov al,bl
4852c2: mov ecx,0xfffffff4
4852c7: call 0x476870
4852cc: push 0x23
4852ce: push 0x14
4852d0: push 0xaa
4852d5: xor edx,edx
4852d7: mov dl,BYTE PTR [esp+0xd]
4852db: add edx,0x8
4852de: xor eax,eax
4852e0: mov al,bl
4852e2: mov ecx,0xfffffff4
4852e7: call 0x476870
4852ec: push 0x23
4852ee: push 0x14
4852f0: push 0xaa
4852f5: xor edx,edx
4852f7: mov dl,BYTE PTR [esp+0xd]
4852fb: add edx,0xa
4852fe: xor eax,eax
485300: mov al,bl
485302: mov ecx,0xfffffff4
485307: call 0x476870
48530c: push 0x49
48530e: push 0x19
485310: push 0xaa
485315: xor edx,edx
485317: mov dl,BYTE PTR [esp+0xd]
48531b: add edx,0xc
48531e: xor eax,eax
485320: mov al,bl
485322: mov ecx,0xffffffee
485327: call 0x476870
48532c: push 0x49
48532e: push 0x19
485330: push 0xaa
485335: xor edx,edx
485337: mov dl,BYTE PTR [esp+0xd]
48533b: add edx,0xd
48533e: xor eax,eax
485340: mov al,bl
485342: mov ecx,0xffffffee
485347: call 0x476870
48534c: push 0x49
48534e: push 0x19
485350: push 0xaa
485355: xor edx,edx
485357: mov dl,BYTE PTR [esp+0xd]
48535b: add edx,0xf
48535e: xor eax,eax
485360: mov al,bl
485362: mov ecx,0xffffffee
485367: call 0x476870
48536c: push 0x49
48536e: push 0x19
485370: push 0xaa
485375: xor edx,edx
485377: mov dl,BYTE PTR [esp+0xd]
48537b: add edx,0x11
48537e: xor eax,eax
485380: mov al,bl
485382: mov ecx,0xffffffee
485387: call 0x476870
48538c: push 0x49
48538e: push 0x19
485390: push 0xaa
485395: xor edx,edx
485397: mov dl,BYTE PTR [esp+0xd]
48539b: add edx,0x13
48539e: xor eax,eax
4853a0: mov al,bl
4853a2: mov ecx,0xffffffee
4853a7: call 0x476870
4853ac: push 0x23
4853ae: push 0x19
4853b0: push 0x82
4853b5: xor edx,edx
4853b7: mov dl,BYTE PTR [esp+0xd]
4853bb: add edx,0x15
4853be: xor eax,eax
4853c0: mov al,bl
4853c2: mov ecx,0xffffffee
4853c7: call 0x476870
4853cc: push 0x50
4853ce: push 0x28
4853d0: push 0x78
4853d2: xor edx,edx
4853d4: mov dl,BYTE PTR [esp+0xd]
4853d8: add edx,0x1c
4853db: xor eax,eax
4853dd: mov al,bl
4853df: mov ecx,0xffffffe4
4853e4: call 0x476870
4853e9: push 0x78
4853eb: push 0x28
4853ed: push 0xa0
4853f2: xor edx,edx
4853f4: mov dl,BYTE PTR [esp+0xd]
4853f8: add edx,0x1d
4853fb: xor eax,eax
4853fd: mov al,bl
4853ff: mov ecx,0xffffffe4
485404: call 0x476870
485409: push 0x23
48540b: push 0x14
48540d: push 0xaa
485412: xor edx,edx
485414: mov dl,BYTE PTR [esp+0xd]
485418: add edx,0x1f
48541b: xor eax,eax
48541d: mov al,bl
48541f: mov ecx,0xfffffff4
485424: call 0x476870
485429: push 0x49
48542b: push 0x19
48542d: push 0xaa
485432: xor edx,edx
485434: mov dl,BYTE PTR [esp+0xd]
485438: add edx,0x20
48543b: xor eax,eax
48543d: mov al,bl
48543f: mov ecx,0xffffffee
485444: call 0x476870
485449: push 0x23
48544b: push 0x14
48544d: push 0xaa
485452: xor edx,edx
485454: mov dl,BYTE PTR [esp+0xd]
485458: add edx,0x26
48545b: xor eax,eax
48545d: mov al,bl
48545f: mov ecx,0xfffffff4
485464: call 0x476870
485469: push 0x14
48546b: push 0x2d
48546d: push 0x3c
48546f: push 0x3c
485471: push 0x1
485473: push 0x1
485475: push 0x7
485477: push 0x0
485479: xor eax,eax
48547b: mov al,bl
48547d: mov ecx,0x2
485482: mov edx,0x3
485487: call 0x4768f8
48548c: push 0x14
48548e: push 0x6e
485490: push 0x46
485492: push 0x8c
485497: push 0x1
485499: push 0x1
48549b: push 0x7
48549d: push 0x0
48549f: xor eax,eax
4854a1: mov al,bl
4854a3: mov ecx,0x2
4854a8: mov edx,0x4
4854ad: call 0x4768f8
4854b2: push 0x19
4854b4: push 0x3e
4854b6: push 0x48
4854b8: push 0x5f
4854ba: push 0x1
4854bc: push 0x2
4854be: push 0xe
4854c0: push 0x0
4854c2: xor eax,eax
4854c4: mov al,bl
4854c6: mov ecx,0x5
4854cb: mov edx,0x5
4854d0: call 0x4768f8
4854d5: push 0x14
4854d7: push 0x5a
4854d9: push 0x55
4854db: push 0x69
4854dd: push 0x1
4854df: push 0x2
4854e1: push 0xe
4854e3: push 0x0
4854e5: xor eax,eax
4854e7: mov al,bl
4854e9: mov ecx,0x5
4854ee: mov edx,0x6
4854f3: call 0x4768f8
4854f8: push 0x14
4854fa: push 0x50
4854fc: push 0x3c
4854fe: push 0x5f
485500: push 0x1
485502: push 0x1
485504: push 0x7
485506: push 0x0
485508: xor eax,eax
48550a: mov al,bl
48550c: mov ecx,0x2
485511: mov edx,0x8
485516: call 0x4768f8
48551b: push 0x1e
48551d: push 0x8e
485522: push 0x4a
485524: push 0xa0
485529: push 0x1
48552b: push 0x1
48552d: push 0x7
48552f: push 0x0
485531: xor eax,eax
485533: mov al,bl
485535: mov ecx,0x2
48553a: mov edx,0x9
48553f: call 0x4768f8
485544: push 0x19
485546: push 0x58
485548: push 0x48
48554a: push 0x78
48554c: push 0x1
48554e: push 0x2
485550: push 0xe
485552: push 0x0
485554: xor eax,eax
485556: mov al,bl
485558: mov ecx,0x5
48555d: mov edx,0xa
485562: call 0x4768f8
485567: push 0x19
485569: push 0x76
48556b: push 0x52
48556d: push 0x87
485572: push 0x1
485574: push 0x2
485576: push 0xe
485578: push 0x0
48557a: xor eax,eax
48557c: mov al,bl
48557e: mov ecx,0x5
485583: mov edx,0xb
485588: call 0x4768f8
48558d: push 0x1b
48558f: push 0x50
485591: push 0x46
485593: push 0x73
485595: push 0x1
485597: push 0x1
485599: push 0x7
48559b: push 0x0
48559d: xor eax,eax
48559f: mov al,bl
4855a1: mov ecx,0x2
4855a6: mov edx,0xd
4855ab: call 0x4768f8
4855b0: push 0x1e
4855b2: push 0x52
4855b4: push 0x53
4855b6: push 0x6c
4855b8: push 0x1
4855ba: push 0x1
4855bc: push 0x7
4855be: push 0x0
4855c0: xor eax,eax
4855c2: mov al,bl
4855c4: mov ecx,0x2
4855c9: mov edx,0xe
4855ce: call 0x4768f8
4855d3: push 0x1b
4855d5: push 0x50
4855d7: push 0x46
4855d9: push 0x73
4855db: push 0x1
4855dd: push 0x2
4855df: push 0xe
4855e1: push 0x0
4855e3: xor eax,eax
4855e5: mov al,bl
4855e7: mov ecx,0x5
4855ec: mov edx,0xf
4855f1: call 0x4768f8
4855f6: push 0x1e
4855f8: push 0x52
4855fa: push 0x53
4855fc: push 0x6c
4855fe: push 0x1
485600: push 0x2
485602: push 0xe
485604: push 0x0
485606: xor eax,eax
485608: mov al,bl
48560a: mov ecx,0x5
48560f: mov edx,0x10
485614: call 0x4768f8
485619: push 0xffffffe2
48561b: push 0xa
48561d: push 0x37
48561f: push 0x5f
485621: push 0x1
485623: push 0x0
485625: push 0x5
485627: push 0x2
485629: xor eax,eax
48562b: mov al,bl
48562d: mov ecx,0x2
485632: mov edx,0x19
485637: call 0x4768f8
48563c: push 0xffffffe2
48563e: push 0xa
485640: push 0x37
485642: push 0x5f
485644: push 0x1
485646: push 0x0
485648: push 0x5
48564a: push 0x2
48564c: xor eax,eax
48564e: mov al,bl
485650: mov ecx,0x5
485655: mov edx,0x19
48565a: call 0x4768f8
48565f: push 0xffffffe2
485661: push 0xa
485663: push 0x37
485665: push 0x5f
485667: push 0x1
485669: push 0x0
48566b: push 0x5
48566d: push 0x2
48566f: xor eax,eax
485671: mov al,bl
485673: mov ecx,0x8
485678: mov edx,0x19
48567d: call 0x4768f8
485682: push 0xffffffe2
485684: push 0xa
485686: push 0x37
485688: push 0x5f
48568a: push 0x1
48568c: push 0x0
48568e: push 0x5
485690: push 0x2
485692: xor eax,eax
485694: mov al,bl
485696: mov ecx,0xb
48569b: mov edx,0x19
4856a0: call 0x4768f8
4856a5: push 0xffffffe2
4856a7: push 0xa
4856a9: push 0x37
4856ab: push 0x5f
4856ad: push 0x1
4856af: push 0x0
4856b1: push 0x5
4856b3: push 0x2
4856b5: xor eax,eax
4856b7: mov al,bl
4856b9: mov ecx,0xe
4856be: mov edx,0x19
4856c3: call 0x4768f8
4856c8: push 0x14
4856ca: push 0x41
4856cc: push 0x5a
4856ce: push 0x5a
4856d0: push 0x1
4856d2: push 0x0
4856d4: push 0xc
4856d6: push 0x2
4856d8: xor eax,eax
4856da: mov al,bl
4856dc: mov ecx,0x3
4856e1: mov edx,0x1a
4856e6: call 0x4768f8
4856eb: push 0x14
4856ed: push 0x41
4856ef: push 0x7b
4856f1: push 0x5a
4856f3: push 0x1
4856f5: push 0x0
4856f7: push 0xc
4856f9: push 0x2
4856fb: xor eax,eax
4856fd: mov al,bl
4856ff: mov ecx,0x5
485704: mov edx,0x1a
485709: call 0x4768f8
48570e: push 0x14
485710: push 0x41
485712: push 0x78
485714: push 0x5a
485716: push 0x0
485718: push 0x0
48571a: push 0x0
48571c: push 0x0
48571e: xor eax,eax
485720: mov al,bl
485722: mov ecx,0x8
485727: mov edx,0x1a
48572c: call 0x4768f8
485731: push 0x5
485733: push 0x23
485735: push 0x50
485737: push 0x78
485739: push 0x1
48573b: push 0x0
48573d: push 0x8
48573f: push 0x2
485741: xor eax,eax
485743: mov al,bl
485745: mov ecx,0x1
48574a: mov edx,0x1b
48574f: call 0x4768f8
485754: push 0x5
485756: push 0x23
485758: push 0x50
48575a: push 0x78
48575c: push 0x1
48575e: push 0x0
485760: push 0xe
485762: push 0x2
485764: xor eax,eax
485766: mov al,bl
485768: mov ecx,0x3
48576d: mov edx,0x1b
485772: call 0x4768f8
485777: push 0x5
485779: push 0x23
48577b: push 0x50
48577d: push 0x78
48577f: push 0x0
485781: push 0x0
485783: push 0x0
485785: push 0x0
485787: xor eax,eax
485789: mov al,bl
48578b: mov ecx,0x6
485790: mov edx,0x1b
485795: call 0x4768f8
48579a: push 0x5
48579c: push 0x14
48579e: push 0x41
4857a0: push 0x78
4857a2: push 0x1
4857a4: push 0x0
4857a6: push 0x16
4857a8: push 0x3
4857aa: xor eax,eax
4857ac: mov al,bl
4857ae: mov ecx,0x1
4857b3: mov edx,0x1c
4857b8: call 0x4768f8
4857bd: push 0x14
4857bf: push 0x23
4857c1: push 0x41
4857c3: push 0x7d
4857c5: push 0x1
4857c7: push 0x0
4857c9: push 0x5
4857cb: push 0x2
4857cd: xor eax,eax
4857cf: mov al,bl
4857d1: mov ecx,0x2
4857d6: mov edx,0x1d
4857db: call 0x4768f8
4857e0: xor eax,eax
4857e2: mov al,bl
4857e4: imul eax,eax,0x16
4857e7: cmp BYTE PTR [esi+eax*8-0xa0],0x8
4857ef: jne 0x48690e
4857f5: xor eax,eax
4857f7: mov al,bl
4857f9: imul eax,eax,0x16
4857fc: cmp BYTE PTR [esi+eax*8-0x45],0x17
485801: jne 0x4858eb
485807: xor eax,eax
485809: mov al,bl
48580b: imul eax,eax,0x16
48580e: mov dl,BYTE PTR [esp+0x1]
485812: add dl,0x21
485815: mov BYTE PTR [esi+eax*8-0x44],dl
485819: xor eax,eax
48581b: mov al,bl
48581d: imul eax,eax,0x16
485820: fild WORD PTR [esi+eax*8-0x3c]
485824: fdiv DWORD PTR ds:0x48dd34
48582a: call 0x40287c
48582f: xor eax,eax
485831: mov al,bl
485833: imul eax,eax,0x16
485836: fild WORD PTR [esi+eax*8-0x3c]
48583a: fdiv DWORD PTR ds:0x48dd34
485840: fcompp
485842: fnstsw ax
485844: sahf
485845: jne 0x48586a
485847: xor eax,eax
485849: mov al,bl
48584b: imul eax,eax,0x16
48584e: fld QWORD PTR [esi+eax*8-0xa8]
485855: fsub DWORD PTR ds:0x48dd24
48585b: xor eax,eax
48585d: mov al,bl
48585f: imul eax,eax,0x16
485862: fstp QWORD PTR [esi+eax*8-0xa8]
485869: fwait
48586a: xor eax,eax
48586c: mov al,bl
48586e: imul eax,eax,0x16
485871: fild WORD PTR [esi+eax*8-0x3c]
485875: fdiv DWORD PTR ds:0x48dd34
48587b: call 0x40287c
485880: xor eax,eax
485882: mov al,bl
485884: imul eax,eax,0x16
485887: fild WORD PTR [esi+eax*8-0x3c]
48588b: fdiv DWORD PTR ds:0x48dd34
485891: fcompp
485893: fnstsw ax
485895: sahf
485896: je 0x4858bb
485898: xor eax,eax
48589a: mov al,bl
48589c: imul eax,eax,0x16
48589f: fld QWORD PTR [esi+eax*8-0xa8]
4858a6: fadd DWORD PTR ds:0x48dd24
4858ac: xor eax,eax
4858ae: mov al,bl
4858b0: imul eax,eax,0x16
4858b3: fstp QWORD PTR [esi+eax*8-0xa8]
4858ba: fwait
4858bb: mov eax,ds:0x4b11f8
4858c0: fild WORD PTR [eax]
4858c2: xor eax,eax
4858c4: mov al,bl
4858c6: imul eax,eax,0x16
4858c9: fcomp QWORD PTR [esi+eax*8-0xa8]
4858d0: fnstsw ax
4858d2: sahf
4858d3: jae 0x4858eb
4858d5: mov eax,ds:0x4b11f8
4858da: fild WORD PTR [eax]
4858dc: xor eax,eax
4858de: mov al,bl
4858e0: imul eax,eax,0x16
4858e3: fstp QWORD PTR [esi+eax*8-0xa8]
4858ea: fwait
4858eb: xor eax,eax
4858ed: mov al,bl
4858ef: imul eax,eax,0x16
4858f2: cmp BYTE PTR [esi+eax*8-0x45],0x18
4858f7: jne 0x48591a
4858f9: xor eax,eax
4858fb: mov al,bl
4858fd: imul eax,eax,0x16
485900: cmp WORD PTR [esi+eax*8-0x3c],0x0
485906: jne 0x48591a
485908: xor eax,eax
48590a: mov al,bl
48590c: imul eax,eax,0x16
48590f: mov dl,BYTE PTR [esp+0x1]
485913: add dl,0xc
485916: mov BYTE PTR [esi+eax*8-0x44],dl
48591a: xor eax,eax
48591c: mov al,bl
48591e: imul eax,eax,0x16
485921: cmp BYTE PTR [esi+eax*8-0x45],0x18
485926: jne 0x485949
485928: xor eax,eax
48592a: mov al,bl
48592c: imul eax,eax,0x16
48592f: cmp WORD PTR [esi+eax*8-0x3c],0x2
485935: jne 0x485949
485937: xor eax,eax
485939: mov al,bl
48593b: imul eax,eax,0x16
48593e: mov dl,BYTE PTR [esp+0x1]
485942: add dl,0x1e
485945: mov BYTE PTR [esi+eax*8-0x44],dl
485949: xor eax,eax
48594b: mov al,bl
48594d: imul eax,eax,0x16
485950: cmp BYTE PTR [esi+eax*8-0x45],0x19
485955: jne 0x485b42
48595b: xor eax,eax
48595d: mov al,bl
48595f: imul eax,eax,0x16
485962: cmp WORD PTR [esi+eax*8-0x3c],0x0
485968: jne 0x48597c
48596a: xor eax,eax
48596c: mov al,bl
48596e: imul eax,eax,0x16
485971: mov dl,BYTE PTR [esp+0x1]
485975: add dl,0x22
485978: mov BYTE PTR [esi+eax*8-0x44],dl
48597c: xor eax,eax
48597e: mov al,bl
485980: imul eax,eax,0x16
485983: cmp WORD PTR [esi+eax*8-0x3c],0x5
485989: jne 0x48599d
48598b: xor eax,eax
48598d: mov al,bl
48598f: imul eax,eax,0x16
485992: mov dl,BYTE PTR [esp+0x1]
485996: add dl,0x23
485999: mov BYTE PTR [esi+eax*8-0x44],dl
48599d: xor eax,eax
48599f: mov al,bl
4859a1: imul eax,eax,0x16
4859a4: cmp WORD PTR [esi+eax*8-0x3c],0xa
4859aa: jne 0x485b42
4859b0: xor eax,eax
4859b2: mov al,bl
4859b4: imul eax,eax,0x16
4859b7: mov dl,BYTE PTR [esp+0x1]
4859bb: add dl,0x24
4859be: mov BYTE PTR [esi+eax*8-0x44],dl
4859c2: xor eax,eax
4859c4: mov al,bl
4859c6: imul eax,eax,0x16
4859c9: cmp BYTE PTR [esi+eax*8-0x43],0x1
4859ce: jne 0x485a22
4859d0: xor eax,eax
4859d2: mov al,bl
4859d4: imul eax,eax,0x16
4859d7: cmp BYTE PTR [esi+eax*8-0x41],0x1
4859dc: jne 0x485a22
4859de: xor eax,eax
4859e0: mov al,bl
4859e2: imul eax,eax,0x16
4859e5: fld QWORD PTR [esi+eax*8-0xb0]
4859ec: fadd DWORD PTR ds:0x48dd10
4859f2: add esp,0xfffffff8
4859f5: fstp QWORD PTR [esp]
4859f8: fwait
4859f9: xor eax,eax
4859fb: mov al,bl
4859fd: imul eax,eax,0x16
485a00: fld QWORD PTR [esi+eax*8-0xa8]
485a07: fsub DWORD PTR ds:0x48dd40
485a0d: add esp,0xfffffff8
485a10: fstp QWORD PTR [esp]
485a13: fwait
485a14: mov ecx,ebx
485a16: mov edx,0x48dcd4
485a1b: mov al,0x12
485a1d: call 0x476a04
485a22: xor eax,eax
485a24: mov al,bl
485a26: imul eax,eax,0x16
485a29: cmp BYTE PTR [esi+eax*8-0x43],0x2
485a2e: jne 0x485a82
485a30: xor eax,eax
485a32: mov al,bl
485a34: imul eax,eax,0x16
485a37: cmp BYTE PTR [esi+eax*8-0x41],0x1
485a3c: jne 0x485a82
485a3e: xor eax,eax
485a40: mov al,bl
485a42: imul eax,eax,0x16
485a45: fld QWORD PTR [esi+eax*8-0xb0]
485a4c: fsub DWORD PTR ds:0x48dd10
485a52: add esp,0xfffffff8
485a55: fstp QWORD PTR [esp]
485a58: fwait
485a59: xor eax,eax
485a5b: mov al,bl
485a5d: imul eax,eax,0x16
485a60: fld QWORD PTR [esi+eax*8-0xa8]
485a67: fsub DWORD PTR ds:0x48dd40
485a6d: add esp,0xfffffff8
485a70: fstp QWORD PTR [esp]
485a73: fwait
485a74: mov ecx,ebx
485a76: mov edx,0x48dcd4
485a7b: mov al,0x12
485a7d: call 0x476a04
485a82: xor eax,eax
485a84: mov al,bl
485a86: imul eax,eax,0x16
485a89: cmp BYTE PTR [esi+eax*8-0x43],0x1
485a8e: jne 0x485ae2
485a90: xor eax,eax
485a92: mov al,bl
485a94: imul eax,eax,0x16
485a97: cmp BYTE PTR [esi+eax*8-0x41],0x2
485a9c: jne 0x485ae2
485a9e: xor eax,eax
485aa0: mov al,bl
485aa2: imul eax,eax,0x16
485aa5: fld QWORD PTR [esi+eax*8-0xb0]
485aac: fadd DWORD PTR ds:0x48dd10
485ab2: add esp,0xfffffff8
485ab5: fstp QWORD PTR [esp]
485ab8: fwait
485ab9: xor eax,eax
485abb: mov al,bl
485abd: imul eax,eax,0x16
485ac0: fld QWORD PTR [esi+eax*8-0xa8]
485ac7: fsub DWORD PTR ds:0x48dd40
485acd: add esp,0xfffffff8
485ad0: fstp QWORD PTR [esp]
485ad3: fwait
485ad4: mov ecx,ebx
485ad6: mov edx,0x48dce0
485adb: mov al,0x12
485add: call 0x476a04
485ae2: xor eax,eax
485ae4: mov al,bl
485ae6: imul eax,eax,0x16
485ae9: cmp BYTE PTR [esi+eax*8-0x43],0x2
485aee: jne 0x485b42
485af0: xor eax,eax
485af2: mov al,bl
485af4: imul eax,eax,0x16
485af7: cmp BYTE PTR [esi+eax*8-0x41],0x2
485afc: jne 0x485b42
485afe: xor eax,eax
485b00: mov al,bl
485b02: imul eax,eax,0x16
485b05: fld QWORD PTR [esi+eax*8-0xb0]
485b0c: fsub DWORD PTR ds:0x48dce8
485b12: add esp,0xfffffff8
485b15: fstp QWORD PTR [esp]
485b18: fwait
485b19: xor eax,eax
485b1b: mov al,bl
485b1d: imul eax,eax,0x16
485b20: fld QWORD PTR [esi+eax*8-0xa8]
485b27: fsub DWORD PTR ds:0x48dd40
485b2d: add esp,0xfffffff8
485b30: fstp QWORD PTR [esp]
485b33: fwait
485b34: mov ecx,ebx
485b36: mov edx,0x48dce0
485b3b: mov al,0x12
485b3d: call 0x476a04
485b42: xor eax,eax
485b44: mov al,bl
485b46: imul eax,eax,0x16
485b49: cmp BYTE PTR [esi+eax*8-0x45],0x1a
485b4e: jne 0x485d89
485b54: xor eax,eax
485b56: mov al,bl
485b58: imul eax,eax,0x16
485b5b: cmp WORD PTR [esi+eax*8-0x3c],0x0
485b61: jne 0x485b7b
485b63: xor eax,eax
485b65: mov al,bl
485b67: imul eax,eax,0x16
485b6a: mov BYTE PTR [esi+eax*8-0x38],0x0
485b6f: xor eax,eax
485b71: mov al,bl
485b73: imul eax,eax,0x16
485b76: mov BYTE PTR [esi+eax*8-0x46],0x0
485b7b: xor eax,eax
485b7d: mov al,bl
485b7f: imul eax,eax,0x16
485b82: cmp WORD PTR [esi+eax*8-0x3c],0x0
485b88: jne 0x485b9c
485b8a: xor eax,eax
485b8c: mov al,bl
485b8e: imul eax,eax,0x16
485b91: mov dl,BYTE PTR [esp+0x1]
485b95: add dl,0x22
485b98: mov BYTE PTR [esi+eax*8-0x44],dl
485b9c: xor eax,eax
485b9e: mov al,bl
485ba0: imul eax,eax,0x16
485ba3: cmp WORD PTR [esi+eax*8-0x3c],0x5
485ba9: jne 0x485bbd
485bab: xor eax,eax
485bad: mov al,bl
485baf: imul eax,eax,0x16
485bb2: mov dl,BYTE PTR [esp+0x1]
485bb6: add dl,0x25
485bb9: mov BYTE PTR [esi+eax*8-0x44],dl
485bbd: xor eax,eax
485bbf: mov al,bl
485bc1: imul eax,eax,0x16
485bc4: cmp WORD PTR [esi+eax*8-0x3c],0xa
485bca: jne 0x485d62
485bd0: xor eax,eax
485bd2: mov al,bl
485bd4: imul eax,eax,0x16
485bd7: mov dl,BYTE PTR [esp+0x1]
485bdb: add dl,0x26
485bde: mov BYTE PTR [esi+eax*8-0x44],dl
485be2: xor eax,eax
485be4: mov al,bl
485be6: imul eax,eax,0x16
485be9: cmp BYTE PTR [esi+eax*8-0x43],0x1
485bee: jne 0x485c42
485bf0: xor eax,eax
485bf2: mov al,bl
485bf4: imul eax,eax,0x16
485bf7: cmp BYTE PTR [esi+eax*8-0x41],0x1
485bfc: jne 0x485c42
485bfe: xor eax,eax
485c00: mov al,bl
485c02: imul eax,eax,0x16
485c05: fld QWORD PTR [esi+eax*8-0xb0]
485c0c: fadd DWORD PTR ds:0x48dd44
485c12: add esp,0xfffffff8
485c15: fstp QWORD PTR [esp]
485c18: fwait
485c19: xor eax,eax
485c1b: mov al,bl
485c1d: imul eax,eax,0x16
485c20: fld QWORD PTR [esi+eax*8-0xa8]
485c27: fsub DWORD PTR ds:0x48dd48
485c2d: add esp,0xfffffff8
485c30: fstp QWORD PTR [esp]
485c33: fwait
485c34: mov ecx,ebx
485c36: mov edx,0x48dcd4
485c3b: mov al,0x13
485c3d: call 0x476a04
485c42: xor eax,eax
485c44: mov al,bl
485c46: imul eax,eax,0x16
485c49: cmp BYTE PTR [esi+eax*8-0x43],0x2
485c4e: jne 0x485ca2
485c50: xor eax,eax
485c52: mov al,bl
485c54: imul eax,eax,0x16
485c57: cmp BYTE PTR [esi+eax*8-0x41],0x1
485c5c: jne 0x485ca2
485c5e: xor eax,eax
485c60: mov al,bl
485c62: imul eax,eax,0x16
485c65: fld QWORD PTR [esi+eax*8-0xb0]
485c6c: fsub DWORD PTR ds:0x48dd44
485c72: add esp,0xfffffff8
485c75: fstp QWORD PTR [esp]
485c78: fwait
485c79: xor eax,eax
485c7b: mov al,bl
485c7d: imul eax,eax,0x16
485c80: fld QWORD PTR [esi+eax*8-0xa8]
485c87: fsub DWORD PTR ds:0x48dd48
485c8d: add esp,0xfffffff8
485c90: fstp QWORD PTR [esp]
485c93: fwait
485c94: mov ecx,ebx
485c96: mov edx,0x48dcd4
485c9b: mov al,0x13
485c9d: call 0x476a04
485ca2: xor eax,eax
485ca4: mov al,bl
485ca6: imul eax,eax,0x16
485ca9: cmp BYTE PTR [esi+eax*8-0x43],0x1
485cae: jne 0x485d02
485cb0: xor eax,eax
485cb2: mov al,bl
485cb4: imul eax,eax,0x16
485cb7: cmp BYTE PTR [esi+eax*8-0x41],0x2
485cbc: jne 0x485d02
485cbe: xor eax,eax
485cc0: mov al,bl
485cc2: imul eax,eax,0x16
485cc5: fld QWORD PTR [esi+eax*8-0xb0]
485ccc: fadd DWORD PTR ds:0x48dd44
485cd2: add esp,0xfffffff8
485cd5: fstp QWORD PTR [esp]
485cd8: fwait
485cd9: xor eax,eax
485cdb: mov al,bl
485cdd: imul eax,eax,0x16
485ce0: fld QWORD PTR [esi+eax*8-0xa8]
485ce7: fsub DWORD PTR ds:0x48dd48
485ced: add esp,0xfffffff8
485cf0: fstp QWORD PTR [esp]
485cf3: fwait
485cf4: mov ecx,ebx
485cf6: mov edx,0x48dce0
485cfb: mov al,0x13
485cfd: call 0x476a04
485d02: xor eax,eax
485d04: mov al,bl
485d06: imul eax,eax,0x16
485d09: cmp BYTE PTR [esi+eax*8-0x43],0x2
485d0e: jne 0x485d62
485d10: xor eax,eax
485d12: mov al,bl
485d14: imul eax,eax,0x16
485d17: cmp BYTE PTR [esi+eax*8-0x41],0x2
485d1c: jne 0x485d62
485d1e: xor eax,eax
485d20: mov al,bl
485d22: imul eax,eax,0x16
485d25: fld QWORD PTR [esi+eax*8-0xb0]
485d2c: fsub DWORD PTR ds:0x48dd44
485d32: add esp,0xfffffff8
485d35: fstp QWORD PTR [esp]
485d38: fwait
485d39: xor eax,eax
485d3b: mov al,bl
485d3d: imul eax,eax,0x16
485d40: fld QWORD PTR [esi+eax*8-0xa8]
485d47: fsub DWORD PTR ds:0x48dd48
485d4d: add esp,0xfffffff8
485d50: fstp QWORD PTR [esp]
485d53: fwait
485d54: mov ecx,ebx
485d56: mov edx,0x48dce0
485d5b: mov al,0x13
485d5d: call 0x476a04
485d62: xor eax,eax
485d64: mov al,bl
485d66: imul eax,eax,0x16
485d69: cmp WORD PTR [esi+eax*8-0x3c],0x8
485d6f: jne 0x485d89
485d71: xor eax,eax
485d73: mov al,bl
485d75: imul eax,eax,0x16
485d78: mov BYTE PTR [esi+eax*8-0x38],0x0
485d7d: xor eax,eax
485d7f: mov al,bl
485d81: imul eax,eax,0x16
485d84: mov BYTE PTR [esi+eax*8-0x46],0x0
485d89: xor eax,eax
485d8b: mov al,bl
485d8d: imul eax,eax,0x16
485d90: cmp BYTE PTR [esi+eax*8-0x45],0x1b
485d95: jne 0x485fb4
485d9b: xor eax,eax
485d9d: mov al,bl
485d9f: imul eax,eax,0x16
485da2: cmp WORD PTR [esi+eax*8-0x3c],0x0
485da8: jne 0x485dbc
485daa: xor eax,eax
485dac: mov al,bl
485dae: imul eax,eax,0x16
485db1: mov dl,BYTE PTR [esp+0x1]
485db5: add dl,0x27
485db8: mov BYTE PTR [esi+eax*8-0x44],dl
485dbc: xor eax,eax
485dbe: mov al,bl
485dc0: imul eax,eax,0x16
485dc3: cmp WORD PTR [esi+eax*8-0x3c],0x2
485dc9: jne 0x485ddd
485dcb: xor eax,eax
485dcd: mov al,bl
485dcf: imul eax,eax,0x16
485dd2: mov dl,BYTE PTR [esp+0x1]
485dd6: add dl,0x28
485dd9: mov BYTE PTR [esi+eax*8-0x44],dl
485ddd: xor eax,eax
485ddf: mov al,bl
485de1: imul eax,eax,0x16
485de4: cmp WORD PTR [esi+eax*8-0x3c],0x4
485dea: jne 0x485dfe
485dec: xor eax,eax
485dee: mov al,bl
485df0: imul eax,eax,0x16
485df3: mov dl,BYTE PTR [esp+0x1]
485df7: add dl,0x29
485dfa: mov BYTE PTR [esi+eax*8-0x44],dl
485dfe: xor eax,eax
485e00: mov al,bl
485e02: imul eax,eax,0x16
485e05: cmp WORD PTR [esi+eax*8-0x3c],0x6
485e0b: jne 0x485e1f
485e0d: xor eax,eax
485e0f: mov al,bl
485e11: imul eax,eax,0x16
485e14: mov dl,BYTE PTR [esp+0x1]
485e18: add dl,0x28
485e1b: mov BYTE PTR [esi+eax*8-0x44],dl
485e1f: xor eax,eax
485e21: mov al,bl
485e23: imul eax,eax,0x16
485e26: cmp WORD PTR [esi+eax*8-0x3c],0x8
485e2c: jne 0x485e40
485e2e: xor eax,eax
485e30: mov al,bl
485e32: imul eax,eax,0x16
485e35: mov dl,BYTE PTR [esp+0x1]
485e39: add dl,0x29
485e3c: mov BYTE PTR [esi+eax*8-0x44],dl
485e40: xor eax,eax
485e42: mov al,bl
485e44: imul eax,eax,0x16
485e47: cmp WORD PTR [esi+eax*8-0x3c],0xa
485e4d: jne 0x485e61
485e4f: xor eax,eax
485e51: mov al,bl
485e53: imul eax,eax,0x16
485e56: mov dl,BYTE PTR [esp+0x1]
485e5a: add dl,0x28
485e5d: mov BYTE PTR [esi+eax*8-0x44],dl
485e61: xor eax,eax
485e63: mov al,bl
485e65: imul eax,eax,0x16
485e68: cmp WORD PTR [esi+eax*8-0x3c],0x2
485e6e: jne 0x485e8a
485e70: xor eax,eax
485e72: mov al,bl
485e74: imul eax,eax,0x16
485e77: cmp BYTE PTR [esi+eax*8-0x41],0x1
485e7c: jne 0x485e8a
485e7e: xor eax,eax
485e80: mov al,bl
485e82: imul eax,eax,0x16
485e85: mov BYTE PTR [esi+eax*8-0x38],0xe7
485e8a: xor eax,eax
485e8c: mov al,bl
485e8e: imul eax,eax,0x16
485e91: cmp WORD PTR [esi+eax*8-0x3c],0x2
485e97: jne 0x485eb3
485e99: xor eax,eax
485e9b: mov al,bl
485e9d: imul eax,eax,0x16
485ea0: cmp BYTE PTR [esi+eax*8-0x41],0x2
485ea5: jne 0x485eb3
485ea7: xor eax,eax
485ea9: mov al,bl
485eab: imul eax,eax,0x16
485eae: mov BYTE PTR [esi+eax*8-0x38],0xe0
485eb3: xor eax,eax
485eb5: mov al,bl
485eb7: imul eax,eax,0x16
485eba: cmp WORD PTR [esi+eax*8-0x3c],0x2
485ec0: jne 0x485eda
485ec2: xor eax,eax
485ec4: mov al,bl
485ec6: imul eax,eax,0x16
485ec9: mov BYTE PTR [esi+eax*8-0x42],0x0
485ece: xor eax,eax
485ed0: mov al,bl
485ed2: imul eax,eax,0x16
485ed5: mov BYTE PTR [esi+eax*8-0x46],0x1
485eda: xor eax,eax
485edc: mov al,bl
485ede: imul eax,eax,0x16
485ee1: cmp WORD PTR [esi+eax*8-0x3c],0x2
485ee7: jle 0x485fa8
485eed: xor eax,eax
485eef: mov al,bl
485ef1: imul eax,eax,0x16
485ef4: cmp WORD PTR [esi+eax*8-0x3c],0x8
485efa: jge 0x485fa8
485f00: xor eax,eax
485f02: mov al,bl
485f04: imul eax,eax,0x16
485f07: cmp BYTE PTR [esi+eax*8-0x41],0x1
485f0c: jne 0x485f2a
485f0e: xor eax,eax
485f10: mov al,bl
485f12: imul eax,eax,0x16
485f15: cmp BYTE PTR [esi+eax*8-0x43],0x1
485f1a: jne 0x485f2a
485f1c: push 0x40140000
485f21: push 0x0
485f23: mov eax,ebx
485f25: call 0x47648c
485f2a: xor eax,eax
485f2c: mov al,bl
485f2e: imul eax,eax,0x16
485f31: cmp BYTE PTR [esi+eax*8-0x41],0x1
485f36: jne 0x485f54
485f38: xor eax,eax
485f3a: mov al,bl
485f3c: imul eax,eax,0x16
485f3f: cmp BYTE PTR [esi+eax*8-0x43],0x2
485f44: jne 0x485f54
485f46: push 0xc0140000
485f4b: push 0x0
485f4d: mov eax,ebx
485f4f: call 0x47648c
485f54: xor eax,eax
485f56: mov al,bl
485f58: imul eax,eax,0x16
485f5b: cmp BYTE PTR [esi+eax*8-0x41],0x2
485f60: jne 0x485f7e
485f62: xor eax,eax
485f64: mov al,bl
485f66: imul eax,eax,0x16
485f69: cmp BYTE PTR [esi+eax*8-0x43],0x1
485f6e: jne 0x485f7e
485f70: push 0x40280000
485f75: push 0x0
485f77: mov eax,ebx
485f79: call 0x47648c
485f7e: xor eax,eax
485f80: mov al,bl
485f82: imul eax,eax,0x16
485f85: cmp BYTE PTR [esi+eax*8-0x41],0x2
485f8a: jne 0x485fa8
485f8c: xor eax,eax
485f8e: mov al,bl
485f90: imul eax,eax,0x16
485f93: cmp BYTE PTR [esi+eax*8-0x43],0x2
485f98: jne 0x485fa8
485f9a: push 0xc0280000
485f9f: push 0x0
485fa1: mov eax,ebx
485fa3: call 0x47648c
485fa8: xor eax,eax
485faa: mov al,bl
485fac: imul eax,eax,0x16
485faf: mov BYTE PTR [esi+eax*8-0x47],0x1
485fb4: xor eax,eax
485fb6: mov al,bl
485fb8: imul eax,eax,0x16
485fbb: cmp BYTE PTR [esi+eax*8-0x45],0x1c
485fc0: jne 0x486368
485fc6: xor eax,eax
485fc8: mov al,bl
485fca: imul eax,eax,0x16
485fcd: cmp WORD PTR [esi+eax*8-0x3c],0x0
485fd3: jne 0x486010
485fd5: xor eax,eax
485fd7: mov al,bl
485fd9: imul eax,eax,0x16
485fdc: push DWORD PTR [esi+eax*8-0xac]
485fe3: push DWORD PTR [esi+eax*8-0xb0]
485fea: xor eax,eax
485fec: mov al,bl
485fee: imul eax,eax,0x16
485ff1: fld QWORD PTR [esi+eax*8-0xa8]
485ff8: fsub DWORD PTR ds:0x48dd40
485ffe: add esp,0xfffffff8
486001: fstp QWORD PTR [esp]
486004: fwait
486005: mov ecx,ebx
486007: xor edx,edx
486009: mov al,0x11
48600b: call 0x476a04
486010: xor eax,eax
486012: mov al,bl
486014: imul eax,eax,0x16
486017: cmp WORD PTR [esi+eax*8-0x3c],0x0
48601d: jne 0x486037
48601f: xor eax,eax
486021: mov al,bl
486023: imul eax,eax,0x16
486026: mov BYTE PTR [esi+eax*8-0x38],0x0
48602b: xor eax,eax
48602d: mov al,bl
48602f: imul eax,eax,0x16
486032: mov BYTE PTR [esi+eax*8-0x46],0x0
486037: xor eax,eax
486039: mov al,bl
48603b: imul eax,eax,0x16
48603e: cmp WORD PTR [esi+eax*8-0x3c],0x1
486044: jne 0x486052
486046: xor eax,eax
486048: mov al,bl
48604a: imul eax,eax,0x16
48604d: mov BYTE PTR [esi+eax*8-0x1e],0x1
486052: xor eax,eax
486054: mov al,bl
486056: imul eax,eax,0x16
486059: cmp WORD PTR [esi+eax*8-0x3c],0x9
48605f: jne 0x48606d
486061: xor eax,eax
486063: mov al,bl
486065: imul eax,eax,0x16
486068: mov BYTE PTR [esi+eax*8-0x1e],0x0
48606d: xor eax,eax
48606f: mov al,bl
486071: imul eax,eax,0x16
486074: cmp WORD PTR [esi+eax*8-0x3c],0x8
48607a: jne 0x4861fc
486080: xor eax,eax
486082: mov al,bl
486084: imul eax,eax,0x16
486087: cmp BYTE PTR [esi+eax*8-0x43],0x1
48608c: jne 0x4860bf
48608e: xor eax,eax
486090: mov al,bl
486092: imul eax,eax,0x16
486095: cmp BYTE PTR [esi+eax*8-0x41],0x1
48609a: jne 0x4860bf
48609c: xor eax,eax
48609e: mov al,bl
4860a0: imul eax,eax,0x16
4860a3: fld QWORD PTR [esi+eax*8-0xb0]
4860aa: fadd DWORD PTR ds:0x48dd20
4860b0: xor eax,eax
4860b2: mov al,bl
4860b4: imul eax,eax,0x16
4860b7: fstp QWORD PTR [esi+eax*8-0xb0]
4860be: fwait
4860bf: xor eax,eax
4860c1: mov al,bl
4860c3: imul eax,eax,0x16
4860c6: cmp BYTE PTR [esi+eax*8-0x43],0x1
4860cb: jne 0x4860fe
4860cd: xor eax,eax
4860cf: mov al,bl
4860d1: imul eax,eax,0x16
4860d4: cmp BYTE PTR [esi+eax*8-0x41],0x2
4860d9: jne 0x4860fe
4860db: xor eax,eax
4860dd: mov al,bl
4860df: imul eax,eax,0x16
4860e2: fld QWORD PTR [esi+eax*8-0xb0]
4860e9: fadd DWORD PTR ds:0x48dd18
4860ef: xor eax,eax
4860f1: mov al,bl
4860f3: imul eax,eax,0x16
4860f6: fstp QWORD PTR [esi+eax*8-0xb0]
4860fd: fwait
4860fe: xor eax,eax
486100: mov al,bl
486102: imul eax,eax,0x16
486105: cmp BYTE PTR [esi+eax*8-0x43],0x2
48610a: jne 0x48613d
48610c: xor eax,eax
48610e: mov al,bl
486110: imul eax,eax,0x16
486113: cmp BYTE PTR [esi+eax*8-0x41],0x1
486118: jne 0x48613d
48611a: xor eax,eax
48611c: mov al,bl
48611e: imul eax,eax,0x16
486121: fld QWORD PTR [esi+eax*8-0xb0]
486128: fsub DWORD PTR ds:0x48dd20
48612e: xor eax,eax
486130: mov al,bl
486132: imul eax,eax,0x16
486135: fstp QWORD PTR [esi+eax*8-0xb0]
48613c: fwait
48613d: xor eax,eax
48613f: mov al,bl
486141: imul eax,eax,0x16
486144: cmp BYTE PTR [esi+eax*8-0x43],0x2
486149: jne 0x48617c
48614b: xor eax,eax
48614d: mov al,bl
48614f: imul eax,eax,0x16
486152: cmp BYTE PTR [esi+eax*8-0x41],0x2
486157: jne 0x48617c
486159: xor eax,eax
48615b: mov al,bl
48615d: imul eax,eax,0x16
486160: fld QWORD PTR [esi+eax*8-0xb0]
486167: fsub DWORD PTR ds:0x48dd18
48616d: xor eax,eax
48616f: mov al,bl
486171: imul eax,eax,0x16
486174: fstp QWORD PTR [esi+eax*8-0xb0]
48617b: fwait
48617c: xor eax,eax
48617e: mov al,bl
486180: imul eax,eax,0x16
486183: xor edx,edx
486185: mov DWORD PTR [esi+eax*8-0xa8],edx
48618c: mov DWORD PTR [esi+eax*8-0xa4],0x40490000
486197: xor eax,eax
486199: mov al,bl
48619b: imul eax,eax,0x16
48619e: mov BYTE PTR [esi+eax*8-0x38],0x0
4861a3: xor eax,eax
4861a5: mov al,bl
4861a7: imul eax,eax,0x16
4861aa: mov BYTE PTR [esi+eax*8-0x42],0x0
4861af: xor eax,eax
4861b1: mov al,bl
4861b3: imul eax,eax,0x16
4861b6: mov BYTE PTR [esi+eax*8-0x46],0x1
4861bb: xor eax,eax
4861bd: mov al,bl
4861bf: imul eax,eax,0x16
4861c2: fld QWORD PTR [esi+eax*8-0xb0]
4861c9: fsub DWORD PTR ds:0x48dd4c
4861cf: add esp,0xfffffff8
4861d2: fstp QWORD PTR [esp]
4861d5: fwait
4861d6: xor eax,eax
4861d8: mov al,bl
4861da: imul eax,eax,0x16
4861dd: fld QWORD PTR [esi+eax*8-0xa8]
4861e4: fsub DWORD PTR ds:0x48dd20
4861ea: add esp,0xfffffff8
4861ed: fstp QWORD PTR [esp]
4861f0: fwait
4861f1: mov ecx,ebx
4861f3: xor edx,edx
4861f5: mov al,0x18
4861f7: call 0x476a04
4861fc: xor eax,eax
4861fe: mov al,bl
486200: imul eax,eax,0x16
486203: cmp WORD PTR [esi+eax*8-0x3c],0x9
486209: jne 0x48621d
48620b: xor eax,eax
48620d: mov al,bl
48620f: imul eax,eax,0x16
486212: mov dl,BYTE PTR [esp+0x1]
486216: add dl,0x2a
486219: mov BYTE PTR [esi+eax*8-0x44],dl
48621d: xor eax,eax
48621f: mov al,bl
486221: imul eax,eax,0x16
486224: cmp WORD PTR [esi+eax*8-0x3c],0xb
48622a: jne 0x48623e
48622c: xor eax,eax
48622e: mov al,bl
486230: imul eax,eax,0x16
486233: mov dl,BYTE PTR [esp+0x1]
486237: add dl,0x2b
48623a: mov BYTE PTR [esi+eax*8-0x44],dl
48623e: xor eax,eax
486240: mov al,bl
486242: imul eax,eax,0x16
486245: cmp WORD PTR [esi+eax*8-0x3c],0xd
48624b: jne 0x48625f
48624d: xor eax,eax
48624f: mov al,bl
486251: imul eax,eax,0x16
486254: mov dl,BYTE PTR [esp+0x1]
486258: add dl,0x2a
48625b: mov BYTE PTR [esi+eax*8-0x44],dl
48625f: xor eax,eax
486261: mov al,bl
486263: imul eax,eax,0x16
486266: cmp WORD PTR [esi+eax*8-0x3c],0xf
48626c: jne 0x486280
48626e: xor eax,eax
486270: mov al,bl
486272: imul eax,eax,0x16
486275: mov dl,BYTE PTR [esp+0x1]
486279: add dl,0x2b
48627c: mov BYTE PTR [esi+eax*8-0x44],dl
486280: xor eax,eax
486282: mov al,bl
486284: imul eax,eax,0x16
486287: cmp WORD PTR [esi+eax*8-0x3c],0x11
48628d: jne 0x4862a1
48628f: xor eax,eax
486291: mov al,bl
486293: imul eax,eax,0x16
486296: mov dl,BYTE PTR [esp+0x1]
48629a: add dl,0x2a
48629d: mov BYTE PTR [esi+eax*8-0x44],dl
4862a1: xor eax,eax
4862a3: mov al,bl
4862a5: imul eax,eax,0x16
4862a8: cmp WORD PTR [esi+eax*8-0x3c],0x8
4862ae: jl 0x48635c
4862b4: xor eax,eax
4862b6: mov al,bl
4862b8: imul eax,eax,0x16
4862bb: cmp BYTE PTR [esi+eax*8-0x43],0x1
4862c0: jne 0x4862de
4862c2: xor eax,eax
4862c4: mov al,bl
4862c6: imul eax,eax,0x16
4862c9: cmp BYTE PTR [esi+eax*8-0x41],0x1
4862ce: jne 0x4862de
4862d0: push 0x40140000
4862d5: push 0x0
4862d7: mov eax,ebx
4862d9: call 0x47648c
4862de: xor eax,eax
4862e0: mov al,bl
4862e2: imul eax,eax,0x16
4862e5: cmp BYTE PTR [esi+eax*8-0x43],0x1
4862ea: jne 0x486308
4862ec: xor eax,eax
4862ee: mov al,bl
4862f0: imul eax,eax,0x16
4862f3: cmp BYTE PTR [esi+eax*8-0x41],0x2
4862f8: jne 0x486308
4862fa: push 0x40200000
4862ff: push 0x0
486301: mov eax,ebx
486303: call 0x47648c
486308: xor eax,eax
48630a: mov al,bl
48630c: imul eax,eax,0x16
48630f: cmp BYTE PTR [esi+eax*8-0x43],0x2
486314: jne 0x486332
486316: xor eax,eax
486318: mov al,bl
48631a: imul eax,eax,0x16
48631d: cmp BYTE PTR [esi+eax*8-0x41],0x1
486322: jne 0x486332
486324: push 0xc0140000
486329: push 0x0
48632b: mov eax,ebx
48632d: call 0x47648c
486332: xor eax,eax
486334: mov al,bl
486336: imul eax,eax,0x16
486339: cmp BYTE PTR [esi+eax*8-0x43],0x2
48633e: jne 0x48635c
486340: xor eax,eax
486342: mov al,bl
486344: imul eax,eax,0x16
486347: cmp BYTE PTR [esi+eax*8-0x41],0x2
48634c: jne 0x48635c
48634e: push 0xc0200000
486353: push 0x0
486355: mov eax,ebx
486357: call 0x47648c
48635c: xor eax,eax
48635e: mov al,bl
486360: imul eax,eax,0x16
486363: mov BYTE PTR [esi+eax*8-0x47],0x1
486368: xor eax,eax
48636a: mov al,bl
48636c: imul eax,eax,0x16
48636f: cmp BYTE PTR [esi+eax*8-0x45],0x1d
486374: jne 0x4864ae
48637a: xor eax,eax
48637c: mov al,bl
48637e: imul eax,eax,0x16
486381: cmp WORD PTR [esi+eax*8-0x3c],0x0
486387: jne 0x486391
486389: mov eax,ds:0x4b1098
48638e: mov BYTE PTR [eax],0x2a
486391: xor eax,eax
486393: mov al,bl
486395: imul eax,eax,0x16
486398: cmp WORD PTR [esi+eax*8-0x3c],0x0
48639e: jne 0x4863b2
4863a0: xor eax,eax
4863a2: mov al,bl
4863a4: imul eax,eax,0x16
4863a7: mov dl,BYTE PTR [esp+0x1]
4863ab: add dl,0x21
4863ae: mov BYTE PTR [esi+eax*8-0x44],dl
4863b2: xor eax,eax
4863b4: mov al,bl
4863b6: imul eax,eax,0x16
4863b9: fild WORD PTR [esi+eax*8-0x3c]
4863bd: fdiv DWORD PTR ds:0x48dd34
4863c3: call 0x40287c
4863c8: xor eax,eax
4863ca: mov al,bl
4863cc: imul eax,eax,0x16
4863cf: fild WORD PTR [esi+eax*8-0x3c]
4863d3: fdiv DWORD PTR ds:0x48dd34
4863d9: fcompp
4863db: fnstsw ax
4863dd: sahf
4863de: jne 0x48649b
4863e4: xor eax,eax
4863e6: mov al,bl
4863e8: imul eax,eax,0x16
4863eb: cmp WORD PTR [esi+eax*8-0x3c],0xf
4863f1: jge 0x48649b
4863f7: xor eax,eax
4863f9: mov al,bl
4863fb: imul eax,eax,0x16
4863fe: cmp BYTE PTR [esi+eax*8-0x43],0x1
486403: jne 0x486449
486405: xor eax,eax
486407: mov al,bl
486409: imul eax,eax,0x16
48640c: fld QWORD PTR [esi+eax*8-0xb0]
486413: fadd DWORD PTR ds:0x48dce4
486419: add esp,0xfffffff8
48641c: fstp QWORD PTR [esp]
48641f: fwait
486420: xor eax,eax
486422: mov al,bl
486424: imul eax,eax,0x16
486427: fld QWORD PTR [esi+eax*8-0xa8]
48642e: fsub DWORD PTR ds:0x48dd40
486434: add esp,0xfffffff8
486437: fstp QWORD PTR [esp]
48643a: fwait
48643b: mov ecx,ebx
48643d: mov edx,0x48dcd4
486442: mov al,0x14
486444: call 0x476a04
486449: xor eax,eax
48644b: mov al,bl
48644d: imul eax,eax,0x16
486450: cmp BYTE PTR [esi+eax*8-0x43],0x2
486455: jne 0x48649b
486457: xor eax,eax
486459: mov al,bl
48645b: imul eax,eax,0x16
48645e: fld QWORD PTR [esi+eax*8-0xb0]
486465: fsub DWORD PTR ds:0x48dce4
48646b: add esp,0xfffffff8
48646e: fstp QWORD PTR [esp]
486471: fwait
486472: xor eax,eax
486474: mov al,bl
486476: imul eax,eax,0x16
486479: fld QWORD PTR [esi+eax*8-0xa8]
486480: fsub DWORD PTR ds:0x48dd40
486486: add esp,0xfffffff8
486489: fstp QWORD PTR [esp]
48648c: fwait
48648d: mov ecx,ebx
48648f: mov edx,0x48dcd4
486494: mov al,0x14
486496: call 0x476a04
48649b: xor eax,eax
48649d: mov al,bl
48649f: mov edx,0x3
4864a4: sub edx,eax
4864a6: imul eax,edx,0x16
4864a9: mov BYTE PTR [esi+eax*8-0x1e],0x0
4864ae: push 0x1e
4864b0: push 0xe
4864b2: push 0xaa
4864b7: xor edx,edx
4864b9: mov dl,BYTE PTR [esp+0xd]
4864bd: inc edx
4864be: xor eax,eax
4864c0: mov al,bl
4864c2: mov ecx,0xffffffef
4864c7: call 0x476870
4864cc: push 0x1e
4864ce: push 0xe
4864d0: push 0xaa
4864d5: xor edx,edx
4864d7: mov dl,BYTE PTR [esp+0xd]
4864db: add edx,0x2
4864de: xor eax,eax
4864e0: mov al,bl
4864e2: mov ecx,0xffffffef
4864e7: call 0x476870
4864ec: push 0x1e
4864ee: push 0xe
4864f0: push 0xaa
4864f5: xor edx,edx
4864f7: mov dl,BYTE PTR [esp+0xd]
4864fb: add edx,0x3
4864fe: xor eax,eax
486500: mov al,bl
486502: mov ecx,0xffffffef
486507: call 0x476870
48650c: push 0x1e
48650e: push 0xe
486510: push 0xaa
486515: xor edx,edx
486517: mov dl,BYTE PTR [esp+0xd]
48651b: add edx,0x4
48651e: xor eax,eax
486520: mov al,bl
486522: mov ecx,0xffffffef
486527: call 0x476870
48652c: push 0x1e
48652e: push 0xe
486530: push 0xaa
486535: xor edx,edx
486537: mov dl,BYTE PTR [esp+0xd]
48653b: add edx,0x6
48653e: xor eax,eax
486540: mov al,bl
486542: mov ecx,0xffffffef
486547: call 0x476870
48654c: push 0x1e
48654e: push 0xe
486550: push 0xaa
486555: xor edx,edx
486557: mov dl,BYTE PTR [esp+0xd]
48655b: add edx,0x8
48655e: xor eax,eax
486560: mov al,bl
486562: mov ecx,0xffffffef
486567: call 0x476870
48656c: push 0x1e
48656e: push 0xe
486570: push 0xaa
486575: xor edx,edx
486577: mov dl,BYTE PTR [esp+0xd]
48657b: add edx,0xa
48657e: xor eax,eax
486580: mov al,bl
486582: mov ecx,0xffffffef
486587: call 0x476870
48658c: push 0x43
48658e: push 0x14
486590: push 0xaa
486595: xor edx,edx
486597: mov dl,BYTE PTR [esp+0xd]
48659b: add edx,0xc
48659e: xor eax,eax
4865a0: mov al,bl
4865a2: mov ecx,0xffffffef
4865a7: call 0x476870
4865ac: push 0x43
4865ae: push 0x14
4865b0: push 0xaa
4865b5: xor edx,edx
4865b7: mov dl,BYTE PTR [esp+0xd]
4865bb: add edx,0xd
4865be: xor eax,eax
4865c0: mov al,bl
4865c2: mov ecx,0xffffffef
4865c7: call 0x476870
4865cc: push 0x43
4865ce: push 0x14
4865d0: push 0xaa
4865d5: xor edx,edx
4865d7: mov dl,BYTE PTR [esp+0xd]
4865db: add edx,0xf
4865de: xor eax,eax
4865e0: mov al,bl
4865e2: mov ecx,0xffffffef
4865e7: call 0x476870
4865ec: push 0x43
4865ee: push 0x14
4865f0: push 0xaa
4865f5: xor edx,edx
4865f7: mov dl,BYTE PTR [esp+0xd]
4865fb: add edx,0x11
4865fe: xor eax,eax
486600: mov al,bl
486602: mov ecx,0xffffffef
486607: call 0x476870
48660c: push 0x43
48660e: push 0x14
486610: push 0xaa
486615: xor edx,edx
486617: mov dl,BYTE PTR [esp+0xd]
48661b: add edx,0x13
48661e: xor eax,eax
486620: mov al,bl
486622: mov ecx,0xffffffef
486627: call 0x476870
48662c: push 0x1e
48662e: push 0xe
486630: push 0x8c
486635: xor edx,edx
486637: mov dl,BYTE PTR [esp+0xd]
48663b: add edx,0x15
48663e: xor eax,eax
486640: mov al,bl
486642: mov ecx,0xffffffef
486647: call 0x476870
48664c: push 0x50
48664e: push 0x22
486650: push 0x6e
486652: xor edx,edx
486654: mov dl,BYTE PTR [esp+0xd]
486658: add edx,0x1c
48665b: xor eax,eax
48665d: mov al,bl
48665f: mov ecx,0xffffffe5
486664: call 0x476870
486669: push 0x78
48666b: push 0x22
48666d: push 0x8c
486672: xor edx,edx
486674: mov dl,BYTE PTR [esp+0xd]
486678: add edx,0x1d
48667b: xor eax,eax
48667d: mov al,bl
48667f: mov ecx,0xffffffe5
486684: call 0x476870
486689: push 0x1e
48668b: push 0xe
48668d: push 0xaa
486692: xor edx,edx
486694: mov dl,BYTE PTR [esp+0xd]
486698: add edx,0x1f
48669b: xor eax,eax
48669d: mov al,bl
48669f: mov ecx,0xffffffef
4866a4: call 0x476870
4866a9: push 0x43
4866ab: push 0xe
4866ad: push 0xaa
4866b2: xor edx,edx
4866b4: mov dl,BYTE PTR [esp+0xd]
4866b8: add edx,0x20
4866bb: xor eax,eax
4866bd: mov al,bl
4866bf: mov ecx,0xffffffef
4866c4: call 0x476870
4866c9: push 0x1e
4866cb: push 0xe
4866cd: push 0xaa
4866d2: xor edx,edx
4866d4: mov dl,BYTE PTR [esp+0xd]
4866d8: add edx,0x22
4866db: xor eax,eax
4866dd: mov al,bl
4866df: mov ecx,0xffffffef
4866e4: call 0x476870
4866e9: push 0x14
4866eb: push 0x30
4866ed: push 0x3e
4866ef: push 0x4a
4866f1: push 0x1
4866f3: push 0x1
4866f5: push 0x7
4866f7: push 0x0
4866f9: xor eax,eax
4866fb: mov al,bl
4866fd: mov ecx,0x2
486702: mov edx,0x3
486707: call 0x4768f8
48670c: push 0x14
48670e: push 0x6c
486710: push 0x2d
486712: push 0x90
486717: push 0x1
486719: push 0x1
48671b: push 0x7
48671d: push 0x0
48671f: xor eax,eax
486721: mov al,bl
486723: mov ecx,0x2
486728: mov edx,0x4
48672d: call 0x4768f8
486732: push 0x14
486734: push 0x30
486736: push 0x41
486738: push 0x4a
48673a: push 0x1
48673c: push 0x2
48673e: push 0xe
486740: push 0x0
486742: xor eax,eax
486744: mov al,bl
486746: mov ecx,0x5
48674b: mov edx,0x5
486750: call 0x4768f8
486755: push 0x14
486757: push 0x6c
486759: push 0x3c
48675b: push 0x90
486760: push 0x1
486762: push 0x2
486764: push 0xe
486766: push 0x0
486768: xor eax,eax
48676a: mov al,bl
48676c: mov ecx,0x5
486771: mov edx,0x6
486776: call 0x4768f8
48677b: push 0x14
48677d: push 0x49
48677f: push 0x3e
486781: push 0x63
486783: push 0x1
486785: push 0x1
486787: push 0x7
486789: push 0x0
48678b: xor eax,eax
48678d: mov al,bl
48678f: mov ecx,0x2
486794: mov edx,0x8
486799: call 0x4768f8
48679e: push 0x1e
4867a0: push 0x67
4867a2: push 0x3e
4867a4: push 0x96
4867a9: push 0x1
4867ab: push 0x1
4867ad: push 0x7
4867af: push 0x0
4867b1: xor eax,eax
4867b3: mov al,bl
4867b5: mov ecx,0x2
4867ba: mov edx,0x9
4867bf: call 0x4768f8
4867c4: push 0x14
4867c6: push 0x49
4867c8: push 0x46
4867ca: push 0x63
4867cc: push 0x1
4867ce: push 0x2
4867d0: push 0xe
4867d2: push 0x0
4867d4: xor eax,eax
4867d6: mov al,bl
4867d8: mov ecx,0x5
4867dd: mov edx,0xa
4867e2: call 0x4768f8
4867e7: push 0x28
4867e9: push 0x67
4867eb: push 0x4e
4867ed: push 0x96
4867f2: push 0x1
4867f4: push 0x2
4867f6: push 0xe
4867f8: push 0x0
4867fa: xor eax,eax
4867fc: mov al,bl
4867fe: mov ecx,0x5
486803: mov edx,0xb
486808: call 0x4768f8
48680d: push 0x1e
48680f: push 0x49
486811: push 0x44
486813: push 0x78
486815: push 0x1
486817: push 0x1
486819: push 0x7
48681b: push 0x0
48681d: xor eax,eax
48681f: mov al,bl
486821: mov ecx,0x2
486826: mov edx,0xd
48682b: call 0x4768f8
486830: push 0x1e
486832: push 0x71
486834: push 0x44
486836: push 0xa0
48683b: push 0x1
48683d: push 0x1
48683f: push 0x7
486841: push 0x0
486843: xor eax,eax
486845: mov al,bl
486847: mov ecx,0x2
48684c: mov edx,0xe
486851: call 0x4768f8
486856: push 0x1e
486858: push 0x49
48685a: push 0x44
48685c: push 0x78
48685e: push 0x1
486860: push 0x2
486862: push 0xe
486864: push 0x0
486866: xor eax,eax
486868: mov al,bl
48686a: mov ecx,0x5
48686f: mov edx,0xf
486874: call 0x4768f8
486879: push 0x1e
48687b: push 0x71
48687d: push 0x44
48687f: push 0xa0
486884: push 0x1
486886: push 0x2
486888: push 0xe
48688a: push 0x0
48688c: xor eax,eax
48688e: mov al,bl
486890: mov ecx,0x5
486895: mov edx,0x10
48689a: call 0x4768f8
48689f: push 0xffffffe2
4868a1: push 0xa
4868a3: push 0x2d
4868a5: push 0x96
4868aa: push 0x1
4868ac: push 0x0
4868ae: push 0x12
4868b0: push 0x3
4868b2: xor eax,eax
4868b4: mov al,bl
4868b6: mov ecx,0x2
4868bb: mov edx,0x1b
4868c0: call 0x4768f8
4868c5: push 0x0
4868c7: push 0x0
4868c9: push 0x0
4868cb: push 0x0
4868cd: push 0x0
4868cf: push 0x0
4868d1: push 0x0
4868d3: push 0x0
4868d5: xor eax,eax
4868d7: mov al,bl
4868d9: mov ecx,0x7
4868de: mov edx,0x1b
4868e3: call 0x4768f8
4868e8: push 0xfffffff6
4868ea: push 0x3c
4868ec: push 0x2d
4868ee: push 0xa0
4868f3: push 0x1
4868f5: push 0x0
4868f7: push 0x12
4868f9: push 0x3
4868fb: xor eax,eax
4868fd: mov al,bl
4868ff: mov ecx,0x9
486904: mov edx,0x1c
486909: call 0x4768f8
48690e: xor eax,eax
486910: mov al,bl
486912: imul eax,eax,0x16
486915: cmp BYTE PTR [esi+eax*8-0xa0],0x9
48691d: jne 0x487af5
486923: xor eax,eax
486925: mov al,bl
486927: imul eax,eax,0x16
48692a: cmp BYTE PTR [esi+eax*8-0x45],0x17
48692f: jne 0x48699e
486931: xor eax,eax
486933: mov al,bl
486935: imul eax,eax,0x16
486938: fild WORD PTR [esi+eax*8-0x3c]
48693c: fdiv DWORD PTR ds:0x48dcf0
486942: call 0x40287c
486947: xor eax,eax
486949: mov al,bl
48694b: imul eax,eax,0x16
48694e: fild WORD PTR [esi+eax*8-0x3c]
486952: fdiv DWORD PTR ds:0x48dcf0
486958: fcompp
48695a: fnstsw ax
48695c: sahf
48695d: jne 0x48699e
48695f: xor eax,eax
486961: mov al,bl
486963: imul eax,eax,0x16
486966: movzx eax,BYTE PTR [esi+eax*8-0x44]
48696b: xor edx,edx
48696d: mov dl,BYTE PTR [esp+0x1]
486971: add edx,0x21
486974: cmp eax,edx
486976: jne 0x48698c
486978: xor eax,eax
48697a: mov al,bl
48697c: imul eax,eax,0x16
48697f: mov dl,BYTE PTR [esp+0x1]
486983: add dl,0x22
486986: mov BYTE PTR [esi+eax*8-0x44],dl
48698a: jmp 0x48699e
48698c: xor eax,eax
48698e: mov al,bl
486990: imul eax,eax,0x16
486993: mov dl,BYTE PTR [esp+0x1]
486997: add dl,0x21
48699a: mov BYTE PTR [esi+eax*8-0x44],dl
48699e: xor eax,eax
4869a0: mov al,bl
4869a2: imul eax,eax,0x16
4869a5: cmp BYTE PTR [esi+eax*8-0x45],0x18
4869aa: jne 0x4869cd
4869ac: xor eax,eax
4869ae: mov al,bl
4869b0: imul eax,eax,0x16
4869b3: cmp WORD PTR [esi+eax*8-0x3c],0x0
4869b9: jne 0x4869cd
4869bb: xor eax,eax
4869bd: mov al,bl
4869bf: imul eax,eax,0x16
4869c2: mov dl,BYTE PTR [esp+0x1]
4869c6: add dl,0xc
4869c9: mov BYTE PTR [esi+eax*8-0x44],dl
4869cd: xor eax,eax
4869cf: mov al,bl
4869d1: imul eax,eax,0x16
4869d4: cmp BYTE PTR [esi+eax*8-0x45],0x18
4869d9: jne 0x4869fc
4869db: xor eax,eax
4869dd: mov al,bl
4869df: imul eax,eax,0x16
4869e2: cmp WORD PTR [esi+eax*8-0x3c],0x2
4869e8: jne 0x4869fc
4869ea: xor eax,eax
4869ec: mov al,bl
4869ee: imul eax,eax,0x16
4869f1: mov dl,BYTE PTR [esp+0x1]
4869f5: add dl,0x1e
4869f8: mov BYTE PTR [esi+eax*8-0x44],dl
4869fc: xor eax,eax
4869fe: mov al,bl
486a00: imul eax,eax,0x16
486a03: cmp BYTE PTR [esi+eax*8-0x45],0x19
486a08: jne 0x486b97
486a0e: xor eax,eax
486a10: mov al,bl
486a12: imul eax,eax,0x16
486a15: fild WORD PTR [esi+eax*8-0x3c]
486a19: fdiv DWORD PTR ds:0x48dd34
486a1f: call 0x40287c
486a24: xor eax,eax
486a26: mov al,bl
486a28: imul eax,eax,0x16
486a2b: fild WORD PTR [esi+eax*8-0x3c]
486a2f: fdiv DWORD PTR ds:0x48dd34
486a35: fcompp
486a37: fnstsw ax
486a39: sahf
486a3a: jne 0x486a50
486a3c: xor eax,eax
486a3e: mov al,bl
486a40: imul eax,eax,0x16
486a43: mov dl,BYTE PTR [esp+0x1]
486a47: add dl,0x23
486a4a: mov BYTE PTR [esi+eax*8-0x44],dl
486a4e: jmp 0x486a62
486a50: xor eax,eax
486a52: mov al,bl
486a54: imul eax,eax,0x16
486a57: mov dl,BYTE PTR [esp+0x1]
486a5b: add dl,0x24
486a5e: mov BYTE PTR [esi+eax*8-0x44],dl
486a62: xor eax,eax
486a64: mov al,bl
486a66: imul eax,eax,0x16
486a69: cmp WORD PTR [esi+eax*8-0x3c],0x2
486a6f: jge 0x486a83
486a71: xor eax,eax
486a73: mov al,bl
486a75: imul eax,eax,0x16
486a78: mov dl,BYTE PTR [esp+0x1]
486a7c: add dl,0x13
486a7f: mov BYTE PTR [esi+eax*8-0x44],dl
486a83: xor eax,eax
486a85: mov al,bl
486a87: imul eax,eax,0x16
486a8a: cmp WORD PTR [esi+eax*8-0x3c],0xa
486a90: jl 0x486ab2
486a92: xor eax,eax
486a94: mov al,bl
486a96: imul eax,eax,0x16
486a99: cmp BYTE PTR [esi+eax*8-0x41],0x1
486a9e: jne 0x486ab2
486aa0: xor eax,eax
486aa2: mov al,bl
486aa4: imul eax,eax,0x16
486aa7: mov dl,BYTE PTR [esp+0x1]
486aab: add dl,0xc
486aae: mov BYTE PTR [esi+eax*8-0x44],dl
486ab2: xor eax,eax
486ab4: mov al,bl
486ab6: imul eax,eax,0x16
486ab9: cmp WORD PTR [esi+eax*8-0x3c],0x12
486abf: jl 0x486ae1
486ac1: xor eax,eax
486ac3: mov al,bl
486ac5: imul eax,eax,0x16
486ac8: cmp BYTE PTR [esi+eax*8-0x41],0x2
486acd: jne 0x486ae1
486acf: xor eax,eax
486ad1: mov al,bl
486ad3: imul eax,eax,0x16
486ad6: mov dl,BYTE PTR [esp+0x1]
486ada: add dl,0xc
486add: mov BYTE PTR [esi+eax*8-0x44],dl
486ae1: xor eax,eax
486ae3: mov al,bl
486ae5: imul eax,eax,0x16
486ae8: cmp WORD PTR [esi+eax*8-0x3c],0xa
486aee: jge 0x486b36
486af0: xor eax,eax
486af2: mov al,bl
486af4: imul eax,eax,0x16
486af7: cmp BYTE PTR [esi+eax*8-0x41],0x1
486afc: jne 0x486b36
486afe: xor eax,eax
486b00: mov al,bl
486b02: imul eax,eax,0x16
486b05: cmp BYTE PTR [esi+eax*8-0x43],0x1
486b0a: jne 0x486b1a
486b0c: push 0x402c0000
486b11: push 0x0
486b13: mov eax,ebx
486b15: call 0x47648c
486b1a: xor eax,eax
486b1c: mov al,bl
486b1e: imul eax,eax,0x16
486b21: cmp BYTE PTR [esi+eax*8-0x43],0x2
486b26: jne 0x486b36
486b28: push 0xc02c0000
486b2d: push 0x0
486b2f: mov eax,ebx
486b31: call 0x47648c
486b36: xor eax,eax
486b38: mov al,bl
486b3a: imul eax,eax,0x16
486b3d: cmp WORD PTR [esi+eax*8-0x3c],0x12
486b43: jge 0x486b8b
486b45: xor eax,eax
486b47: mov al,bl
486b49: imul eax,eax,0x16
486b4c: cmp BYTE PTR [esi+eax*8-0x41],0x2
486b51: jne 0x486b8b
486b53: xor eax,eax
486b55: mov al,bl
486b57: imul eax,eax,0x16
486b5a: cmp BYTE PTR [esi+eax*8-0x43],0x1
486b5f: jne 0x486b6f
486b61: push 0x402a0000
486b66: push 0x0
486b68: mov eax,ebx
486b6a: call 0x47648c
486b6f: xor eax,eax
486b71: mov al,bl
486b73: imul eax,eax,0x16
486b76: cmp BYTE PTR [esi+eax*8-0x43],0x2
486b7b: jne 0x486b8b
486b7d: push 0xc02a0000
486b82: push 0x0
486b84: mov eax,ebx
486b86: call 0x47648c
486b8b: xor eax,eax
486b8d: mov al,bl
486b8f: imul eax,eax,0x16
486b92: mov BYTE PTR [esi+eax*8-0x47],0x1
486b97: xor eax,eax
486b99: mov al,bl
486b9b: imul eax,eax,0x16
486b9e: cmp BYTE PTR [esi+eax*8-0x45],0x1a
486ba3: jne 0x486d68
486ba9: xor eax,eax
486bab: mov al,bl
486bad: imul eax,eax,0x16
486bb0: mov BYTE PTR [esi+eax*8-0x42],0x0
486bb5: xor eax,eax
486bb7: mov al,bl
486bb9: imul eax,eax,0x16
486bbc: cmp WORD PTR [esi+eax*8-0x3c],0x0
486bc2: jne 0x486bd6
486bc4: xor eax,eax
486bc6: mov al,bl
486bc8: imul eax,eax,0x16
486bcb: mov dl,BYTE PTR [esp+0x1]
486bcf: add dl,0x25
486bd2: mov BYTE PTR [esi+eax*8-0x44],dl
486bd6: xor eax,eax
486bd8: mov al,bl
486bda: imul eax,eax,0x16
486bdd: cmp WORD PTR [esi+eax*8-0x3c],0x4
486be3: jne 0x486bf7
486be5: xor eax,eax
486be7: mov al,bl
486be9: imul eax,eax,0x16
486bec: mov dl,BYTE PTR [esp+0x1]
486bf0: add dl,0x26
486bf3: mov BYTE PTR [esi+eax*8-0x44],dl
486bf7: xor eax,eax
486bf9: mov al,bl
486bfb: imul eax,eax,0x16
486bfe: cmp WORD PTR [esi+eax*8-0x3c],0x8
486c04: jne 0x486c18
486c06: xor eax,eax
486c08: mov al,bl
486c0a: imul eax,eax,0x16
486c0d: mov dl,BYTE PTR [esp+0x1]
486c11: add dl,0x27
486c14: mov BYTE PTR [esi+eax*8-0x44],dl
486c18: xor eax,eax
486c1a: mov al,bl
486c1c: imul eax,eax,0x16
486c1f: cmp WORD PTR [esi+eax*8-0x3c],0x8
486c25: jne 0x486c3f
486c27: xor eax,eax
486c29: mov al,bl
486c2b: imul eax,eax,0x16
486c2e: mov BYTE PTR [esi+eax*8-0x38],0xf6
486c33: xor eax,eax
486c35: mov al,bl
486c37: imul eax,eax,0x16
486c3a: mov BYTE PTR [esi+eax*8-0x46],0x1
486c3f: xor eax,eax
486c41: mov al,bl
486c43: imul eax,eax,0x16
486c46: cmp WORD PTR [esi+eax*8-0x3c],0x8
486c4c: jge 0x486d5c
486c52: xor eax,eax
486c54: mov al,bl
486c56: imul eax,eax,0x16
486c59: cmp BYTE PTR [esi+eax*8-0x43],0x1
486c5e: jne 0x486c7c
486c60: xor eax,eax
486c62: mov al,bl
486c64: imul eax,eax,0x16
486c67: cmp BYTE PTR [esi+eax*8-0x41],0x1
486c6c: jne 0x486c7c
486c6e: push 0x40180000
486c73: push 0x0
486c75: mov eax,ebx
486c77: call 0x47648c
486c7c: xor eax,eax
486c7e: mov al,bl
486c80: imul eax,eax,0x16
486c83: cmp BYTE PTR [esi+eax*8-0x43],0x2
486c88: jne 0x486ca6
486c8a: xor eax,eax
486c8c: mov al,bl
486c8e: imul eax,eax,0x16
486c91: cmp BYTE PTR [esi+eax*8-0x41],0x1
486c96: jne 0x486ca6
486c98: push 0xc0180000
486c9d: push 0x0
486c9f: mov eax,ebx
486ca1: call 0x47648c
486ca6: xor eax,eax
486ca8: mov al,bl
486caa: imul eax,eax,0x16
486cad: cmp BYTE PTR [esi+eax*8-0x43],0x1
486cb2: jne 0x486cd0
486cb4: xor eax,eax
486cb6: mov al,bl
486cb8: imul eax,eax,0x16
486cbb: cmp BYTE PTR [esi+eax*8-0x41],0x2
486cc0: jne 0x486cd0
486cc2: push 0x40280000
486cc7: push 0x0
486cc9: mov eax,ebx
486ccb: call 0x47648c
486cd0: xor eax,eax
486cd2: mov al,bl
486cd4: imul eax,eax,0x16
486cd7: cmp BYTE PTR [esi+eax*8-0x43],0x2
486cdc: jne 0x486cfa
486cde: xor eax,eax
486ce0: mov al,bl
486ce2: imul eax,eax,0x16
486ce5: cmp BYTE PTR [esi+eax*8-0x41],0x2
486cea: jne 0x486cfa
486cec: push 0xc0280000
486cf1: push 0x0
486cf3: mov eax,ebx
486cf5: call 0x47648c
486cfa: xor eax,eax
486cfc: mov al,bl
486cfe: imul eax,eax,0x16
486d01: cmp BYTE PTR [esi+eax*8-0x41],0x1
486d06: jne 0x486d2b
486d08: xor eax,eax
486d0a: mov al,bl
486d0c: imul eax,eax,0x16
486d0f: fld QWORD PTR [esi+eax*8-0xa8]
486d16: fsub DWORD PTR ds:0x48dd50
486d1c: xor eax,eax
486d1e: mov al,bl
486d20: imul eax,eax,0x16
486d23: fstp QWORD PTR [esi+eax*8-0xa8]
486d2a: fwait
486d2b: xor eax,eax
486d2d: mov al,bl
486d2f: imul eax,eax,0x16
486d32: cmp BYTE PTR [esi+eax*8-0x41],0x2
486d37: jne 0x486d5c
486d39: xor eax,eax
486d3b: mov al,bl
486d3d: imul eax,eax,0x16
486d40: fld QWORD PTR [esi+eax*8-0xa8]
486d47: fsub DWORD PTR ds:0x48dd3c
486d4d: xor eax,eax
486d4f: mov al,bl
486d51: imul eax,eax,0x16
486d54: fstp QWORD PTR [esi+eax*8-0xa8]
486d5b: fwait
486d5c: xor eax,eax
486d5e: mov al,bl
486d60: imul eax,eax,0x16
486d63: mov BYTE PTR [esi+eax*8-0x47],0x1
486d68: xor eax,eax
486d6a: mov al,bl
486d6c: imul eax,eax,0x16
486d6f: cmp BYTE PTR [esi+eax*8-0x45],0x1b
486d74: jne 0x486ee2
486d7a: xor eax,eax
486d7c: mov al,bl
486d7e: imul eax,eax,0x16
486d81: cmp WORD PTR [esi+eax*8-0x3c],0x0
486d87: jne 0x486d9b
486d89: xor eax,eax
486d8b: mov al,bl
486d8d: imul eax,eax,0x16
486d90: mov dl,BYTE PTR [esp+0x1]
486d94: add dl,0x28
486d97: mov BYTE PTR [esi+eax*8-0x44],dl
486d9b: xor eax,eax
486d9d: mov al,bl
486d9f: imul eax,eax,0x16
486da2: cmp WORD PTR [esi+eax*8-0x3c],0x3
486da8: jne 0x486dbc
486daa: xor eax,eax
486dac: mov al,bl
486dae: imul eax,eax,0x16
486db1: mov dl,BYTE PTR [esp+0x1]
486db5: add dl,0x29
486db8: mov BYTE PTR [esi+eax*8-0x44],dl
486dbc: xor eax,eax
486dbe: mov al,bl
486dc0: imul eax,eax,0x16
486dc3: cmp WORD PTR [esi+eax*8-0x3c],0x5
486dc9: jne 0x486ddd
486dcb: xor eax,eax
486dcd: mov al,bl
486dcf: imul eax,eax,0x16
486dd2: mov dl,BYTE PTR [esp+0x1]
486dd6: add dl,0x2a
486dd9: mov BYTE PTR [esi+eax*8-0x44],dl
486ddd: xor eax,eax
486ddf: mov al,bl
486de1: imul eax,eax,0x16
486de4: cmp WORD PTR [esi+eax*8-0x3c],0x7
486dea: jne 0x486dfe
486dec: xor eax,eax
486dee: mov al,bl
486df0: imul eax,eax,0x16
486df3: mov dl,BYTE PTR [esp+0x1]
486df7: add dl,0x2b
486dfa: mov BYTE PTR [esi+eax*8-0x44],dl
486dfe: xor eax,eax
486e00: mov al,bl
486e02: imul eax,eax,0x16
486e05: cmp WORD PTR [esi+eax*8-0x3c],0x3
486e0b: jge 0x486eb9
486e11: xor eax,eax
486e13: mov al,bl
486e15: imul eax,eax,0x16
486e18: cmp BYTE PTR [esi+eax*8-0x43],0x1
486e1d: jne 0x486e3b
486e1f: xor eax,eax
486e21: mov al,bl
486e23: imul eax,eax,0x16
486e26: cmp BYTE PTR [esi+eax*8-0x41],0x1
486e2b: jne 0x486e3b
486e2d: push 0x40340000
486e32: push 0x0
486e34: mov eax,ebx
486e36: call 0x47648c
486e3b: xor eax,eax
486e3d: mov al,bl
486e3f: imul eax,eax,0x16
486e42: cmp BYTE PTR [esi+eax*8-0x43],0x1
486e47: jne 0x486e65
486e49: xor eax,eax
486e4b: mov al,bl
486e4d: imul eax,eax,0x16
486e50: cmp BYTE PTR [esi+eax*8-0x41],0x2
486e55: jne 0x486e65
486e57: push 0x40390000
486e5c: push 0x0
486e5e: mov eax,ebx
486e60: call 0x47648c
486e65: xor eax,eax
486e67: mov al,bl
486e69: imul eax,eax,0x16
486e6c: cmp BYTE PTR [esi+eax*8-0x43],0x2
486e71: jne 0x486e8f
486e73: xor eax,eax
486e75: mov al,bl
486e77: imul eax,eax,0x16
486e7a: cmp BYTE PTR [esi+eax*8-0x41],0x1
486e7f: jne 0x486e8f
486e81: push 0xc0340000
486e86: push 0x0
486e88: mov eax,ebx
486e8a: call 0x47648c
486e8f: xor eax,eax
486e91: mov al,bl
486e93: imul eax,eax,0x16
486e96: cmp BYTE PTR [esi+eax*8-0x43],0x2
486e9b: jne 0x486eb9
486e9d: xor eax,eax
486e9f: mov al,bl
486ea1: imul eax,eax,0x16
486ea4: cmp BYTE PTR [esi+eax*8-0x41],0x2
486ea9: jne 0x486eb9
486eab: push 0xc0390000
486eb0: push 0x0
486eb2: mov eax,ebx
486eb4: call 0x47648c
486eb9: xor eax,eax
486ebb: mov al,bl
486ebd: imul eax,eax,0x16
486ec0: cmp WORD PTR [esi+eax*8-0x3c],0x6
486ec6: jl 0x486ee2
486ec8: xor eax,eax
486eca: mov al,bl
486ecc: imul eax,eax,0x16
486ecf: cmp BYTE PTR [esi+eax*8-0x41],0x2
486ed4: jne 0x486ee2
486ed6: xor eax,eax
486ed8: mov al,bl
486eda: imul eax,eax,0x16
486edd: mov BYTE PTR [esi+eax*8-0x47],0x1
486ee2: xor eax,eax
486ee4: mov al,bl
486ee6: imul eax,eax,0x16
486ee9: cmp BYTE PTR [esi+eax*8-0x45],0x1c
486eee: jne 0x487091
486ef4: xor eax,eax
486ef6: mov al,bl
486ef8: imul eax,eax,0x16
486efb: cmp WORD PTR [esi+eax*8-0x3c],0x0
486f01: jne 0x486f15
486f03: xor eax,eax
486f05: mov al,bl
486f07: imul eax,eax,0x16
486f0a: mov dl,BYTE PTR [esp+0x1]
486f0e: add dl,0x18
486f11: mov BYTE PTR [esi+eax*8-0x44],dl
486f15: xor eax,eax
486f17: mov al,bl
486f19: imul eax,eax,0x16
486f1c: cmp WORD PTR [esi+eax*8-0x3c],0x0
486f22: jne 0x486f30
486f24: xor eax,eax
486f26: mov al,bl
486f28: imul eax,eax,0x16
486f2b: mov BYTE PTR [esi+eax*8-0x38],0x0
486f30: xor eax,eax
486f32: mov al,bl
486f34: imul eax,eax,0x16
486f37: cmp WORD PTR [esi+eax*8-0x3c],0x3
486f3d: jne 0x486f51
486f3f: xor eax,eax
486f41: mov al,bl
486f43: imul eax,eax,0x16
486f46: mov dl,BYTE PTR [esp+0x1]
486f4a: add dl,0x2c
486f4d: mov BYTE PTR [esi+eax*8-0x44],dl
486f51: xor eax,eax
486f53: mov al,bl
486f55: imul eax,eax,0x16
486f58: cmp WORD PTR [esi+eax*8-0x3c],0x3
486f5e: jl 0x487085
486f64: xor eax,eax
486f66: mov al,bl
486f68: imul eax,eax,0x16
486f6b: cmp BYTE PTR [esi+eax*8-0x43],0x1
486f70: jne 0x486f8e
486f72: xor eax,eax
486f74: mov al,bl
486f76: imul eax,eax,0x16
486f79: cmp BYTE PTR [esi+eax*8-0x41],0x1
486f7e: jne 0x486f8e
486f80: push 0x40100000
486f85: push 0x0
486f87: mov eax,ebx
486f89: call 0x47648c
486f8e: xor eax,eax
486f90: mov al,bl
486f92: imul eax,eax,0x16
486f95: cmp BYTE PTR [esi+eax*8-0x43],0x2
486f9a: jne 0x486fb8
486f9c: xor eax,eax
486f9e: mov al,bl
486fa0: imul eax,eax,0x16
486fa3: cmp BYTE PTR [esi+eax*8-0x41],0x1
486fa8: jne 0x486fb8
486faa: push 0xc0100000
486faf: push 0x0
486fb1: mov eax,ebx
486fb3: call 0x47648c
486fb8: xor eax,eax
486fba: mov al,bl
486fbc: imul eax,eax,0x16
486fbf: cmp BYTE PTR [esi+eax*8-0x43],0x1
486fc4: jne 0x486fe2
486fc6: xor eax,eax
486fc8: mov al,bl
486fca: imul eax,eax,0x16
486fcd: cmp BYTE PTR [esi+eax*8-0x41],0x2
486fd2: jne 0x486fe2
486fd4: push 0x40280000
486fd9: push 0x0
486fdb: mov eax,ebx
486fdd: call 0x47648c
486fe2: xor eax,eax
486fe4: mov al,bl
486fe6: imul eax,eax,0x16
486fe9: cmp BYTE PTR [esi+eax*8-0x43],0x2
486fee: jne 0x48700c
486ff0: xor eax,eax
486ff2: mov al,bl
486ff4: imul eax,eax,0x16
486ff7: cmp BYTE PTR [esi+eax*8-0x41],0x2
486ffc: jne 0x48700c
486ffe: push 0xc0280000
487003: push 0x0
487005: mov eax,ebx
487007: call 0x47648c
48700c: xor eax,eax
48700e: mov al,bl
487010: imul eax,eax,0x16
487013: fld QWORD PTR [esi+eax*8-0xa8]
48701a: fadd DWORD PTR ds:0x48dd3c
487020: xor eax,eax
487022: mov al,bl
487024: imul eax,eax,0x16
487027: fstp QWORD PTR [esi+eax*8-0xa8]
48702e: fwait
48702f: mov eax,ds:0x4b11f8
487034: fild WORD PTR [eax]
487036: xor eax,eax
487038: mov al,bl
48703a: imul eax,eax,0x16
48703d: fcomp QWORD PTR [esi+eax*8-0xa8]
487044: fnstsw ax
487046: sahf
487047: ja 0x487085
487049: xor eax,eax
48704b: mov al,bl
48704d: imul eax,eax,0x16
487050: mov BYTE PTR [esi+eax*8-0x45],0x1
487055: xor eax,eax
487057: mov al,bl
487059: imul eax,eax,0x16
48705c: mov WORD PTR [esi+eax*8-0x3c],0x0
487063: xor eax,eax
487065: mov al,bl
487067: imul eax,eax,0x16
48706a: mov BYTE PTR [esi+eax*8-0x48],0x0
48706f: mov eax,ds:0x4b11f8
487074: fild WORD PTR [eax]
487076: xor eax,eax
487078: mov al,bl
48707a: imul eax,eax,0x16
48707d: fstp QWORD PTR [esi+eax*8-0xa8]
487084: fwait
487085: xor eax,eax
487087: mov al,bl
487089: imul eax,eax,0x16
48708c: mov BYTE PTR [esi+eax*8-0x47],0x1
487091: xor eax,eax
487093: mov al,bl
487095: imul eax,eax,0x16
487098: cmp BYTE PTR [esi+eax*8-0x45],0x1d
48709d: jne 0x487380
4870a3: xor eax,eax
4870a5: mov al,bl
4870a7: imul eax,eax,0x16
4870aa: cmp WORD PTR [esi+eax*8-0x3c],0x0
4870b0: jne 0x4870c4
4870b2: xor eax,eax
4870b4: mov al,bl
4870b6: imul eax,eax,0x16
4870b9: mov dl,BYTE PTR [esp+0x1]
4870bd: add dl,0x23
4870c0: mov BYTE PTR [esi+eax*8-0x44],dl
4870c4: xor eax,eax
4870c6: mov al,bl
4870c8: imul eax,eax,0x16
4870cb: cmp WORD PTR [esi+eax*8-0x3c],0x0
4870d1: jne 0x4870db
4870d3: mov eax,ds:0x4b1098
4870d8: mov BYTE PTR [eax],0x2e
4870db: xor eax,eax
4870dd: mov al,bl
4870df: imul eax,eax,0x16
4870e2: cmp WORD PTR [esi+eax*8-0x3c],0x1
4870e8: jne 0x4870fc
4870ea: xor eax,eax
4870ec: mov al,bl
4870ee: imul eax,eax,0x16
4870f1: mov dl,BYTE PTR [esp+0x1]
4870f5: add dl,0x24
4870f8: mov BYTE PTR [esi+eax*8-0x44],dl
4870fc: xor eax,eax
4870fe: mov al,bl
487100: imul eax,eax,0x16
487103: cmp WORD PTR [esi+eax*8-0x3c],0x2
487109: jne 0x48711d
48710b: xor eax,eax
48710d: mov al,bl
48710f: imul eax,eax,0x16
487112: mov dl,BYTE PTR [esp+0x1]
487116: add dl,0x23
487119: mov BYTE PTR [esi+eax*8-0x44],dl
48711d: xor eax,eax
48711f: mov al,bl
487121: imul eax,eax,0x16
487124: cmp WORD PTR [esi+eax*8-0x3c],0x3
48712a: jne 0x48713e
48712c: xor eax,eax
48712e: mov al,bl
487130: imul eax,eax,0x16
487133: mov dl,BYTE PTR [esp+0x1]
487137: add dl,0x24
48713a: mov BYTE PTR [esi+eax*8-0x44],dl
48713e: xor eax,eax
487140: mov al,bl
487142: imul eax,eax,0x16
487145: cmp WORD PTR [esi+eax*8-0x3c],0x4
48714b: jne 0x48715f
48714d: xor eax,eax
48714f: mov al,bl
487151: imul eax,eax,0x16
487154: mov dl,BYTE PTR [esp+0x1]
487158: add dl,0x23
48715b: mov BYTE PTR [esi+eax*8-0x44],dl
48715f: xor eax,eax
487161: mov al,bl
487163: imul eax,eax,0x16
487166: cmp WORD PTR [esi+eax*8-0x3c],0x5
48716c: jne 0x487180
48716e: xor eax,eax
487170: mov al,bl
487172: imul eax,eax,0x16
487175: mov dl,BYTE PTR [esp+0x1]
487179: add dl,0x24
48717c: mov BYTE PTR [esi+eax*8-0x44],dl
487180: xor eax,eax
487182: mov al,bl
487184: imul eax,eax,0x16
487187: cmp WORD PTR [esi+eax*8-0x3c],0x6
48718d: jne 0x4871a1
48718f: xor eax,eax
487191: mov al,bl
487193: imul eax,eax,0x16
487196: mov dl,BYTE PTR [esp+0x1]
48719a: add dl,0x23
48719d: mov BYTE PTR [esi+eax*8-0x44],dl
4871a1: xor eax,eax
4871a3: mov al,bl
4871a5: imul eax,eax,0x16
4871a8: cmp WORD PTR [esi+eax*8-0x3c],0x7
4871ae: jne 0x4871c2
4871b0: xor eax,eax
4871b2: mov al,bl
4871b4: imul eax,eax,0x16
4871b7: mov dl,BYTE PTR [esp+0x1]
4871bb: add dl,0x24
4871be: mov BYTE PTR [esi+eax*8-0x44],dl
4871c2: xor eax,eax
4871c4: mov al,bl
4871c6: imul eax,eax,0x16
4871c9: cmp WORD PTR [esi+eax*8-0x3c],0x8
4871cf: jne 0x4871e3
4871d1: xor eax,eax
4871d3: mov al,bl
4871d5: imul eax,eax,0x16
4871d8: mov dl,BYTE PTR [esp+0x1]
4871dc: add dl,0x23
4871df: mov BYTE PTR [esi+eax*8-0x44],dl
4871e3: xor eax,eax
4871e5: mov al,bl
4871e7: imul eax,eax,0x16
4871ea: cmp WORD PTR [esi+eax*8-0x3c],0x9
4871f0: jne 0x487204
4871f2: xor eax,eax
4871f4: mov al,bl
4871f6: imul eax,eax,0x16
4871f9: mov dl,BYTE PTR [esp+0x1]
4871fd: add dl,0x24
487200: mov BYTE PTR [esi+eax*8-0x44],dl
487204: xor eax,eax
487206: mov al,bl
487208: imul eax,eax,0x16
48720b: cmp WORD PTR [esi+eax*8-0x3c],0x0
487211: jl 0x48725a
487213: xor eax,eax
487215: mov al,bl
487217: imul eax,eax,0x16
48721a: cmp WORD PTR [esi+eax*8-0x3c],0xa
487220: jg 0x48725a
487222: xor eax,eax
487224: mov al,bl
487226: imul eax,eax,0x16
487229: cmp BYTE PTR [esi+eax*8-0x43],0x1
48722e: jne 0x48723e
487230: push 0x40280000
487235: push 0x0
487237: mov eax,ebx
487239: call 0x47648c
48723e: xor eax,eax
487240: mov al,bl
487242: imul eax,eax,0x16
487245: cmp BYTE PTR [esi+eax*8-0x43],0x2
48724a: jne 0x48725a
48724c: push 0xc0280000
487251: push 0x0
487253: mov eax,ebx
487255: call 0x47648c
48725a: xor eax,eax
48725c: mov al,bl
48725e: imul eax,eax,0x16
487261: cmp WORD PTR [esi+eax*8-0x3c],0xb
487267: jne 0x48727b
487269: xor eax,eax
48726b: mov al,bl
48726d: imul eax,eax,0x16
487270: mov dl,BYTE PTR [esp+0x1]
487274: add dl,0x25
487277: mov BYTE PTR [esi+eax*8-0x44],dl
48727b: xor eax,eax
48727d: mov al,bl
48727f: imul eax,eax,0x16
487282: cmp WORD PTR [esi+eax*8-0x3c],0xc
487288: jne 0x48729c
48728a: xor eax,eax
48728c: mov al,bl
48728e: imul eax,eax,0x16
487291: mov dl,BYTE PTR [esp+0x1]
487295: add dl,0x26
487298: mov BYTE PTR [esi+eax*8-0x44],dl
48729c: xor eax,eax
48729e: mov al,bl
4872a0: imul eax,eax,0x16
4872a3: cmp WORD PTR [esi+eax*8-0x3c],0xc
4872a9: jl 0x487338
4872af: xor eax,eax
4872b1: mov al,bl
4872b3: imul eax,eax,0x16
4872b6: cmp WORD PTR [esi+eax*8-0x3c],0x12
4872bc: jg 0x487338
4872be: xor eax,eax
4872c0: mov al,bl
4872c2: imul eax,eax,0x16
4872c5: cmp BYTE PTR [esi+eax*8-0x43],0x1
4872ca: jne 0x4872da
4872cc: push 0x402e0000
4872d1: push 0x0
4872d3: mov eax,ebx
4872d5: call 0x47648c
4872da: xor eax,eax
4872dc: mov al,bl
4872de: imul eax,eax,0x16
4872e1: cmp BYTE PTR [esi+eax*8-0x43],0x2
4872e6: jne 0x4872f6
4872e8: push 0xc02e0000
4872ed: push 0x0
4872ef: mov eax,ebx
4872f1: call 0x47648c
4872f6: xor eax,eax
4872f8: mov al,bl
4872fa: imul eax,eax,0x16
4872fd: fld QWORD PTR [esi+eax*8-0xa8]
487304: fsub DWORD PTR ds:0x48dd54
48730a: xor eax,eax
48730c: mov al,bl
48730e: imul eax,eax,0x16
487311: fstp QWORD PTR [esi+eax*8-0xa8]
487318: fwait
487319: xor eax,eax
48731b: mov al,bl
48731d: imul eax,eax,0x16
487320: mov BYTE PTR [esi+eax*8-0x47],0x1
487325: xor eax,eax
487327: mov al,bl
487329: mov edx,0x3
48732e: sub edx,eax
487330: imul eax,edx,0x16
487333: mov BYTE PTR [esi+eax*8-0x1e],0x0
487338: xor eax,eax
48733a: mov al,bl
48733c: imul eax,eax,0x16
48733f: cmp WORD PTR [esi+eax*8-0x3c],0x16
487345: jne 0x487359
487347: xor eax,eax
487349: mov al,bl
48734b: imul eax,eax,0x16
48734e: mov dl,BYTE PTR [esp+0x1]
487352: add dl,0x27
487355: mov BYTE PTR [esi+eax*8-0x44],dl
487359: xor eax,eax
48735b: mov al,bl
48735d: imul eax,eax,0x16
487360: cmp WORD PTR [esi+eax*8-0x3c],0x16
487366: jne 0x487380
487368: xor eax,eax
48736a: mov al,bl
48736c: imul eax,eax,0x16
48736f: mov BYTE PTR [esi+eax*8-0x38],0xf2
487374: xor eax,eax
487376: mov al,bl
487378: imul eax,eax,0x16
48737b: mov BYTE PTR [esi+eax*8-0x46],0x1
487380: push 0x1e
487382: push 0xe
487384: push 0xa0
487389: xor edx,edx
48738b: mov dl,BYTE PTR [esp+0xd]
48738f: inc edx
487390: xor eax,eax
487392: mov al,bl
487394: mov ecx,0xffffffef
487399: call 0x476870
48739e: push 0x1e
4873a0: push 0xe
4873a2: push 0xa0
4873a7: xor edx,edx
4873a9: mov dl,BYTE PTR [esp+0xd]
4873ad: add edx,0x2
4873b0: xor eax,eax
4873b2: mov al,bl
4873b4: mov ecx,0xffffffef
4873b9: call 0x476870
4873be: push 0x1e
4873c0: push 0xe
4873c2: push 0xa0
4873c7: xor edx,edx
4873c9: mov dl,BYTE PTR [esp+0xd]
4873cd: add edx,0x3
4873d0: xor eax,eax
4873d2: mov al,bl
4873d4: mov ecx,0xffffffef
4873d9: call 0x476870
4873de: push 0x1e
4873e0: push 0xe
4873e2: push 0xa0
4873e7: xor edx,edx
4873e9: mov dl,BYTE PTR [esp+0xd]
4873ed: add edx,0x4
4873f0: xor eax,eax
4873f2: mov al,bl
4873f4: mov ecx,0xffffffef
4873f9: call 0x476870
4873fe: push 0x1e
487400: push 0xe
487402: push 0xa0
487407: xor edx,edx
487409: mov dl,BYTE PTR [esp+0xd]
48740d: add edx,0x6
487410: xor eax,eax
487412: mov al,bl
487414: mov ecx,0xffffffef
487419: call 0x476870
48741e: push 0x1e
487420: push 0xe
487422: push 0xa0
487427: xor edx,edx
487429: mov dl,BYTE PTR [esp+0xd]
48742d: add edx,0x8
487430: xor eax,eax
487432: mov al,bl
487434: mov ecx,0xffffffef
487439: call 0x476870
48743e: push 0x46
487440: push 0xe
487442: push 0xa0
487447: xor edx,edx
487449: mov dl,BYTE PTR [esp+0xd]
48744d: add edx,0xa
487450: xor eax,eax
487452: mov al,bl
487454: mov ecx,0xffffffef
487459: call 0x476870
48745e: push 0x46
487460: push 0x14
487462: push 0xa0
487467: xor edx,edx
487469: mov dl,BYTE PTR [esp+0xd]
48746d: add edx,0xc
487470: xor eax,eax
487472: mov al,bl
487474: mov ecx,0xffffffef
487479: call 0x476870
48747e: push 0x46
487480: push 0x14
487482: push 0xa0
487487: xor edx,edx
487489: mov dl,BYTE PTR [esp+0xd]
48748d: add edx,0xd
487490: xor eax,eax
487492: mov al,bl
487494: mov ecx,0xffffffef
487499: call 0x476870
48749e: push 0x46
4874a0: push 0x14
4874a2: push 0xa0
4874a7: xor edx,edx
4874a9: mov dl,BYTE PTR [esp+0xd]
4874ad: add edx,0xf
4874b0: xor eax,eax
4874b2: mov al,bl
4874b4: mov ecx,0xffffffef
4874b9: call 0x476870
4874be: push 0x46
4874c0: push 0x14
4874c2: push 0xa0
4874c7: xor edx,edx
4874c9: mov dl,BYTE PTR [esp+0xd]
4874cd: add edx,0x11
4874d0: xor eax,eax
4874d2: mov al,bl
4874d4: mov ecx,0xffffffef
4874d9: call 0x476870
4874de: push 0x55
4874e0: push 0x14
4874e2: push 0xa0
4874e7: xor edx,edx
4874e9: mov dl,BYTE PTR [esp+0xd]
4874ed: add edx,0x13
4874f0: xor eax,eax
4874f2: mov al,bl
4874f4: mov ecx,0xffffffef
4874f9: call 0x476870
4874fe: push 0x1e
487500: push 0xe
487502: push 0x82
487507: xor edx,edx
487509: mov dl,BYTE PTR [esp+0xd]
48750d: add edx,0x15
487510: xor eax,eax
487512: mov al,bl
487514: mov ecx,0xffffffef
487519: call 0x476870
48751e: push 0x50
487520: push 0x22
487522: push 0x6e
487524: xor edx,edx
487526: mov dl,BYTE PTR [esp+0xd]
48752a: add edx,0x1c
48752d: xor eax,eax
48752f: mov al,bl
487531: mov ecx,0xffffffe5
487536: call 0x476870
48753b: push 0x78
48753d: push 0x22
48753f: push 0x8c
487544: xor edx,edx
487546: mov dl,BYTE PTR [esp+0xd]
48754a: add edx,0x1d
48754d: xor eax,eax
48754f: mov al,bl
487551: mov ecx,0xffffffe5
487556: call 0x476870
48755b: push 0x1e
48755d: push 0xe
48755f: push 0xa0
487564: xor edx,edx
487566: mov dl,BYTE PTR [esp+0xd]
48756a: add edx,0x1f
48756d: xor eax,eax
48756f: mov al,bl
487571: mov ecx,0xffffffef
487576: call 0x476870
48757b: push 0x41
48757d: push 0xe
48757f: push 0xa0
487584: xor edx,edx
487586: mov dl,BYTE PTR [esp+0xd]
48758a: add edx,0x20
48758d: xor eax,eax
48758f: mov al,bl
487591: mov ecx,0xffffffef
487596: call 0x476870
48759b: push 0x6e
48759d: push 0x28
48759f: push 0x8c
4875a4: xor edx,edx
4875a6: mov dl,BYTE PTR [esp+0xd]
4875aa: add edx,0x23
4875ad: xor eax,eax
4875af: mov al,bl
4875b1: mov ecx,0xffffffe5
4875b6: call 0x476870
4875bb: push 0xa
4875bd: push 0xe
4875bf: push 0x82
4875c4: xor edx,edx
4875c6: mov dl,BYTE PTR [esp+0xd]
4875ca: add edx,0x25
4875cd: xor eax,eax
4875cf: mov al,bl
4875d1: mov ecx,0xffffffef
4875d6: call 0x476870
4875db: push 0x1e
4875dd: push 0xe
4875df: push 0x78
4875e1: xor edx,edx
4875e3: mov dl,BYTE PTR [esp+0xd]
4875e7: add edx,0x28
4875ea: xor eax,eax
4875ec: mov al,bl
4875ee: mov ecx,0xffffffef
4875f3: call 0x476870
4875f8: push 0x1e
4875fa: push 0xe
4875fc: push 0xa0
487601: xor edx,edx
487603: mov dl,BYTE PTR [esp+0xd]
487607: add edx,0x2a
48760a: xor eax,eax
48760c: mov al,bl
48760e: mov ecx,0xffffffef
487613: call 0x476870
487618: push 0x1e
48761a: push 0x28
48761c: push 0xa0
487621: xor edx,edx
487623: mov dl,BYTE PTR [esp+0xd]
487627: add edx,0x2c
48762a: xor eax,eax
48762c: mov al,bl
48762e: mov ecx,0xa
487633: call 0x476870
487638: push 0xa
48763a: push 0x37
48763c: push 0x32
48763e: push 0x41
487640: push 0x1
487642: push 0x1
487644: push 0x7
487646: push 0x0
487648: xor eax,eax
48764a: mov al,bl
48764c: mov ecx,0x2
487651: mov edx,0x3
487656: call 0x4768f8
48765b: push 0x1e
48765d: push 0x30
48765f: push 0x3c
487661: push 0x55
487663: push 0x1
487665: push 0x1
487667: push 0x7
487669: push 0x0
48766b: xor eax,eax
48766d: mov al,bl
48766f: mov ecx,0x2
487674: mov edx,0x4
487679: call 0x4768f8
48767e: push 0xa
487680: push 0x32
487682: push 0x37
487684: push 0x3c
487686: push 0x1
487688: push 0x2
48768a: push 0xe
48768c: push 0x0
48768e: xor eax,eax
487690: mov al,bl
487692: mov ecx,0x5
487697: mov edx,0x5
48769c: call 0x4768f8
4876a1: push 0x14
4876a3: push 0x30
4876a5: push 0x46
4876a7: push 0x5a
4876a9: push 0x1
4876ab: push 0x2
4876ad: push 0xe
4876af: push 0x0
4876b1: xor eax,eax
4876b3: mov al,bl
4876b5: mov ecx,0x5
4876ba: mov edx,0x6
4876bf: call 0x4768f8
4876c4: push 0xa
4876c6: push 0x58
4876c8: push 0x2d
4876ca: push 0x62
4876cc: push 0x1
4876ce: push 0x1
4876d0: push 0x7
4876d2: push 0x0
4876d4: xor eax,eax
4876d6: mov al,bl
4876d8: mov ecx,0x2
4876dd: mov edx,0x8
4876e2: call 0x4768f8
4876e7: push 0x14
4876e9: push 0x87
4876ee: push 0x32
4876f0: push 0x96
4876f5: push 0x1
4876f7: push 0x1
4876f9: push 0x7
4876fb: push 0x0
4876fd: xor eax,eax
4876ff: mov al,bl
487701: mov ecx,0x2
487706: mov edx,0x9
48770b: call 0x4768f8
487710: push 0xa
487712: push 0x58
487714: push 0x2d
487716: push 0x62
487718: push 0x1
48771a: push 0x2
48771c: push 0xe
48771e: push 0x0
487720: xor eax,eax
487722: mov al,bl
487724: mov ecx,0x5
487729: mov edx,0xa
48772e: call 0x4768f8
487733: push 0x14
487735: push 0x73
487737: push 0x43
487739: push 0x87
48773e: push 0x1
487740: push 0x2
487742: push 0xe
487744: push 0x0
487746: xor eax,eax
487748: mov al,bl
48774a: mov ecx,0x5
48774f: mov edx,0xb
487754: call 0x4768f8
487759: push 0x14
48775b: push 0x50
48775d: push 0x43
48775f: push 0x64
487761: push 0x1
487763: push 0x1
487765: push 0x7
487767: push 0x0
487769: xor eax,eax
48776b: mov al,bl
48776d: mov ecx,0x2
487772: mov edx,0xd
487777: call 0x4768f8
48777c: push 0x14
48777e: push 0x5a
487780: push 0x45
487782: push 0x6e
487784: push 0x1
487786: push 0x1
487788: push 0x7
48778a: push 0x0
48778c: xor eax,eax
48778e: mov al,bl
487790: mov ecx,0x2
487795: mov edx,0xe
48779a: call 0x4768f8
48779f: push 0x14
4877a1: push 0x50
4877a3: push 0x43
4877a5: push 0x64
4877a7: push 0x1
4877a9: push 0x2
4877ab: push 0xe
4877ad: push 0x0
4877af: xor eax,eax
4877b1: mov al,bl
4877b3: mov ecx,0x5
4877b8: mov edx,0xf
4877bd: call 0x4768f8
4877c2: push 0x14
4877c4: push 0x5a
4877c6: push 0x45
4877c8: push 0x6e
4877ca: push 0x1
4877cc: push 0x2
4877ce: push 0xe
4877d0: push 0x0
4877d2: xor eax,eax
4877d4: mov al,bl
4877d6: mov ecx,0x5
4877db: mov edx,0x10
4877e0: call 0x4768f8
4877e5: push 0x14
4877e7: push 0x6e
4877e9: push 0x55
4877eb: push 0x82
4877f0: push 0x1
4877f2: push 0x0
4877f4: push 0x12
4877f6: push 0x3
4877f8: xor eax,eax
4877fa: mov al,bl
4877fc: mov ecx,0x2
487801: mov edx,0x19
487806: call 0x4768f8
48780b: xor eax,eax
48780d: mov al,bl
48780f: imul eax,eax,0x16
487812: cmp BYTE PTR [esi+eax*8-0x41],0x1
487817: jne 0x48783c
487819: push 0x0
48781b: push 0x0
48781d: push 0x0
48781f: push 0x0
487821: push 0x0
487823: push 0x0
487825: push 0x0
487827: push 0x0
487829: xor eax,eax
48782b: mov al,bl
48782d: mov ecx,0xa
487832: mov edx,0x19
487837: call 0x4768f8
48783c: xor eax,eax
48783e: mov al,bl
487840: imul eax,eax,0x16
487843: cmp BYTE PTR [esi+eax*8-0x41],0x2
487848: jne 0x48786d
48784a: push 0x0
48784c: push 0x0
48784e: push 0x0
487850: push 0x0
487852: push 0x0
487854: push 0x0
487856: push 0x0
487858: push 0x0
48785a: xor eax,eax
48785c: mov al,bl
48785e: mov ecx,0xf
487863: mov edx,0x19
487868: call 0x4768f8
48786d: push 0xa
48786f: push 0xffffffe2
487871: push 0x26
487873: push 0x78
487875: push 0x1
487877: push 0x0
487879: push 0x12
48787b: push 0x3
48787d: xor eax,eax
48787f: mov al,bl
487881: mov ecx,0x2
487886: mov edx,0x1a
48788b: call 0x4768f8
487890: push 0x0
487892: push 0x0
487894: push 0x0
487896: push 0x0
487898: push 0x0
48789a: push 0x0
48789c: push 0x0
48789e: push 0x0
4878a0: xor eax,eax
4878a2: mov al,bl
4878a4: mov ecx,0x6
4878a9: mov edx,0x1a
4878ae: call 0x4768f8
4878b3: push 0xa
4878b5: push 0x3c
4878b7: push 0x26
4878b9: push 0x50
4878bb: push 0x1
4878bd: push 0x0
4878bf: push 0xa
4878c1: push 0x2
4878c3: xor eax,eax
4878c5: mov al,bl
4878c7: mov ecx,0x4
4878cc: mov edx,0x1b
4878d1: call 0x4768f8
4878d6: push 0xa
4878d8: push 0x3c
4878da: push 0x46
4878dc: push 0x50
4878de: push 0x1
4878e0: push 0x0
4878e2: push 0x8
4878e4: push 0x2
4878e6: xor eax,eax
4878e8: mov al,bl
4878ea: mov ecx,0x6
4878ef: mov edx,0x1b
4878f4: call 0x4768f8
4878f9: push 0x14
4878fb: push 0x6e
4878fd: push 0x4b
4878ff: push 0xa2
487904: push 0x1
487906: push 0x0
487908: push 0x10
48790a: push 0x2
48790c: xor eax,eax
48790e: mov al,bl
487910: mov ecx,0x3
487915: mov edx,0x1c
48791a: call 0x4768f8
48791f: push 0x14
487921: push 0x6e
487923: push 0x55
487925: push 0x82
48792a: push 0x1
48792c: push 0x0
48792e: push 0x3
487930: push 0x1
487932: xor eax,eax
487934: mov al,bl
487936: mov ecx,0x1
48793b: mov edx,0x1d
487940: call 0x4768f8
487945: push 0x14
487947: push 0x6e
487949: push 0x55
48794b: push 0x82
487950: push 0x1
487952: push 0x2
487954: push 0x5
487956: push 0x0
487958: xor eax,eax
48795a: mov al,bl
48795c: mov ecx,0x3
487961: mov edx,0x1d
487966: call 0x4768f8
48796b: push 0x14
48796d: push 0x6e
48796f: push 0x55
487971: push 0x82
487976: push 0x1
487978: push 0x2
48797a: push 0x5
48797c: push 0x1
48797e: xor eax,eax
487980: mov al,bl
487982: mov ecx,0x5
487987: mov edx,0x1d
48798c: call 0x4768f8
487991: push 0x14
487993: push 0x6e
487995: push 0x55
487997: push 0x82
48799c: push 0x1
48799e: push 0x2
4879a0: push 0x3
4879a2: push 0x1
4879a4: xor eax,eax
4879a6: mov al,bl
4879a8: mov ecx,0x7
4879ad: mov edx,0x1d
4879b2: call 0x4768f8
4879b7: push 0x14
4879b9: push 0x6e
4879bb: push 0x55
4879bd: push 0x82
4879c2: push 0x1
4879c4: push 0x2
4879c6: push 0x5
4879c8: push 0x0
4879ca: xor eax,eax
4879cc: mov al,bl
4879ce: mov ecx,0x9
4879d3: mov edx,0x1d
4879d8: call 0x4768f8
4879dd: push 0xa
4879df: push 0xffffffe2
4879e1: push 0x32
4879e3: push 0x78
4879e5: push 0x1
4879e7: push 0x2
4879e9: push 0x3
4879eb: push 0x1
4879ed: xor eax,eax
4879ef: mov al,bl
4879f1: mov ecx,0xa
4879f6: mov edx,0x1d
4879fb: call 0x4768f8
487a00: push 0xa
487a02: push 0xffffffe2
487a04: push 0x32
487a06: push 0x78
487a08: push 0x1
487a0a: push 0x2
487a0c: push 0x4
487a0e: push 0x1
487a10: xor eax,eax
487a12: mov al,bl
487a14: mov ecx,0xb
487a19: mov edx,0x1d
487a1e: call 0x4768f8
487a23: push 0xa
487a25: push 0xffffffe2
487a27: push 0x32
487a29: push 0x78
487a2b: push 0x1
487a2d: push 0x2
487a2f: push 0x3
487a31: push 0x0
487a33: xor eax,eax
487a35: mov al,bl
487a37: mov ecx,0xc
487a3c: mov edx,0x1d
487a41: call 0x4768f8
487a46: push 0xa
487a48: push 0xffffffe2
487a4a: push 0x32
487a4c: push 0x78
487a4e: push 0x1
487a50: push 0x2
487a52: push 0x4
487a54: push 0x1
487a56: xor eax,eax
487a58: mov al,bl
487a5a: mov ecx,0xd
487a5f: mov edx,0x1d
487a64: call 0x4768f8
487a69: push 0xa
487a6b: push 0xffffffe2
487a6d: push 0x32
487a6f: push 0x78
487a71: push 0x1
487a73: push 0x2
487a75: push 0x3
487a77: push 0x1
487a79: xor eax,eax
487a7b: mov al,bl
487a7d: mov ecx,0xe
487a82: mov edx,0x1d
487a87: call 0x4768f8
487a8c: push 0xa
487a8e: push 0xffffffe2
487a90: push 0x32
487a92: push 0x78
487a94: push 0x1
487a96: push 0x2
487a98: push 0x4
487a9a: push 0x0
487a9c: xor eax,eax
487a9e: mov al,bl
487aa0: mov ecx,0xf
487aa5: mov edx,0x1d
487aaa: call 0x4768f8
487aaf: push 0xa
487ab1: push 0xffffffe2
487ab3: push 0x32
487ab5: push 0x78
487ab7: push 0x1
487ab9: push 0x2
487abb: push 0x2
487abd: push 0x1
487abf: xor eax,eax
487ac1: mov al,bl
487ac3: mov ecx,0x10
487ac8: mov edx,0x1d
487acd: call 0x4768f8
487ad2: push 0xa
487ad4: push 0xffffffe2
487ad6: push 0x32
487ad8: push 0x78
487ada: push 0x0
487adc: push 0x0
487ade: push 0x0
487ae0: push 0x0
487ae2: xor eax,eax
487ae4: mov al,bl
487ae6: mov ecx,0x11
487aeb: mov edx,0x1d
487af0: call 0x4768f8
487af5: xor eax,eax
487af7: mov al,bl
487af9: imul eax,eax,0x16
487afc: cmp BYTE PTR [esi+eax*8-0xa0],0xa
487b04: jne 0x488a4c
487b0a: xor eax,eax
487b0c: mov al,bl
487b0e: imul eax,eax,0x16
487b11: cmp BYTE PTR [esi+eax*8-0x45],0x17
487b16: jne 0x487b39
487b18: xor eax,eax
487b1a: mov al,bl
487b1c: imul eax,eax,0x16
487b1f: cmp WORD PTR [esi+eax*8-0x3c],0xc
487b25: jge 0x487b39
487b27: xor eax,eax
487b29: mov al,bl
487b2b: imul eax,eax,0x16
487b2e: mov dl,BYTE PTR [esp+0x1]
487b32: add dl,0x21
487b35: mov BYTE PTR [esi+eax*8-0x44],dl
487b39: xor eax,eax
487b3b: mov al,bl
487b3d: imul eax,eax,0x16
487b40: cmp BYTE PTR [esi+eax*8-0x45],0x17
487b45: jne 0x487b68
487b47: xor eax,eax
487b49: mov al,bl
487b4b: imul eax,eax,0x16
487b4e: cmp WORD PTR [esi+eax*8-0x3c],0xc
487b54: jne 0x487b68
487b56: xor eax,eax
487b58: mov al,bl
487b5a: imul eax,eax,0x16
487b5d: mov dl,BYTE PTR [esp+0x1]
487b61: add dl,0x22
487b64: mov BYTE PTR [esi+eax*8-0x44],dl
487b68: xor eax,eax
487b6a: mov al,bl
487b6c: imul eax,eax,0x16
487b6f: cmp BYTE PTR [esi+eax*8-0x45],0x18
487b74: jne 0x487b97
487b76: xor eax,eax
487b78: mov al,bl
487b7a: imul eax,eax,0x16
487b7d: cmp WORD PTR [esi+eax*8-0x3c],0x0
487b83: jne 0x487b97
487b85: xor eax,eax
487b87: mov al,bl
487b89: imul eax,eax,0x16
487b8c: mov dl,BYTE PTR [esp+0x1]
487b90: add dl,0xc
487b93: mov BYTE PTR [esi+eax*8-0x44],dl
487b97: xor eax,eax
487b99: mov al,bl
487b9b: imul eax,eax,0x16
487b9e: cmp BYTE PTR [esi+eax*8-0x45],0x18
487ba3: jne 0x487bc6
487ba5: xor eax,eax
487ba7: mov al,bl
487ba9: imul eax,eax,0x16
487bac: cmp WORD PTR [esi+eax*8-0x3c],0x2
487bb2: jne 0x487bc6
487bb4: xor eax,eax
487bb6: mov al,bl
487bb8: imul eax,eax,0x16
487bbb: mov dl,BYTE PTR [esp+0x1]
487bbf: add dl,0x1e
487bc2: mov BYTE PTR [esi+eax*8-0x44],dl
487bc6: xor eax,eax
487bc8: mov al,bl
487bca: imul eax,eax,0x16
487bcd: cmp BYTE PTR [esi+eax*8-0x45],0x19
487bd2: jne 0x487cda
487bd8: xor eax,eax
487bda: mov al,bl
487bdc: imul eax,eax,0x16
487bdf: mov al,BYTE PTR [esi+eax*8-0x44]
487be3: mov BYTE PTR [esp],al
487be6: jmp 0x487bfe
487be8: mov eax,0x3
487bed: call 0x402a1c
487bf2: mov dl,BYTE PTR [esp+0x1]
487bf6: add dl,0x23
487bf9: add al,dl
487bfb: mov BYTE PTR [esp],al
487bfe: xor eax,eax
487c00: mov al,bl
487c02: imul eax,eax,0x16
487c05: mov al,BYTE PTR [esi+eax*8-0x44]
487c09: cmp al,BYTE PTR [esp]
487c0c: je 0x487be8
487c0e: xor eax,eax
487c10: mov al,bl
487c12: imul eax,eax,0x16
487c15: mov dl,BYTE PTR [esp]
487c18: mov BYTE PTR [esi+eax*8-0x44],dl
487c1c: xor eax,eax
487c1e: mov al,bl
487c20: imul eax,eax,0x16
487c23: cmp BYTE PTR [esi+eax*8-0x43],0x1
487c28: jne 0x487c46
487c2a: xor eax,eax
487c2c: mov al,bl
487c2e: imul eax,eax,0x16
487c31: cmp BYTE PTR [esi+eax*8-0x41],0x1
487c36: jne 0x487c46
487c38: push 0x40000000
487c3d: push 0x0
487c3f: mov eax,ebx
487c41: call 0x47648c
487c46: xor eax,eax
487c48: mov al,bl
487c4a: imul eax,eax,0x16
487c4d: cmp BYTE PTR [esi+eax*8-0x43],0x2
487c52: jne 0x487c70
487c54: xor eax,eax
487c56: mov al,bl
487c58: imul eax,eax,0x16
487c5b: cmp BYTE PTR [esi+eax*8-0x41],0x1
487c60: jne 0x487c70
487c62: push 0xc0000000
487c67: push 0x0
487c69: mov eax,ebx
487c6b: call 0x47648c
487c70: xor eax,eax
487c72: mov al,bl
487c74: imul eax,eax,0x16
487c77: cmp BYTE PTR [esi+eax*8-0x43],0x1
487c7c: jne 0x487c9a
487c7e: xor eax,eax
487c80: mov al,bl
487c82: imul eax,eax,0x16
487c85: cmp BYTE PTR [esi+eax*8-0x41],0x2
487c8a: jne 0x487c9a
487c8c: push 0x40080000
487c91: push 0x0
487c93: mov eax,ebx
487c95: call 0x47648c
487c9a: xor eax,eax
487c9c: mov al,bl
487c9e: imul eax,eax,0x16
487ca1: cmp BYTE PTR [esi+eax*8-0x43],0x2
487ca6: jne 0x487cc4
487ca8: xor eax,eax
487caa: mov al,bl
487cac: imul eax,eax,0x16
487caf: cmp BYTE PTR [esi+eax*8-0x41],0x2
487cb4: jne 0x487cc4
487cb6: push 0xc0080000
487cbb: push 0x0
487cbd: mov eax,ebx
487cbf: call 0x47648c
487cc4: mov eax,0x5
487cc9: call 0x402a1c
487cce: test eax,eax
487cd0: jne 0x487cda
487cd2: mov eax,ds:0x4b1098
487cd7: mov BYTE PTR [eax],0x2f
487cda: xor eax,eax
487cdc: mov al,bl
487cde: imul eax,eax,0x16
487ce1: cmp BYTE PTR [esi+eax*8-0x45],0x1a
487ce6: jne 0x487eeb
487cec: xor eax,eax
487cee: mov al,bl
487cf0: imul eax,eax,0x16
487cf3: cmp WORD PTR [esi+eax*8-0x3c],0x0
487cf9: jne 0x487d0d
487cfb: xor eax,eax
487cfd: mov al,bl
487cff: imul eax,eax,0x16
487d02: mov dl,BYTE PTR [esp+0x1]
487d06: add dl,0x26
487d09: mov BYTE PTR [esi+eax*8-0x44],dl
487d0d: xor eax,eax
487d0f: mov al,bl
487d11: imul eax,eax,0x16
487d14: cmp WORD PTR [esi+eax*8-0x3c],0x2
487d1a: jne 0x487d2e
487d1c: xor eax,eax
487d1e: mov al,bl
487d20: imul eax,eax,0x16
487d23: mov dl,BYTE PTR [esp+0x1]
487d27: add dl,0x27
487d2a: mov BYTE PTR [esi+eax*8-0x44],dl
487d2e: xor eax,eax
487d30: mov al,bl
487d32: imul eax,eax,0x16
487d35: cmp WORD PTR [esi+eax*8-0x3c],0x4
487d3b: jne 0x487d4f
487d3d: xor eax,eax
487d3f: mov al,bl
487d41: imul eax,eax,0x16
487d44: mov dl,BYTE PTR [esp+0x1]
487d48: add dl,0x28
487d4b: mov BYTE PTR [esi+eax*8-0x44],dl
487d4f: xor eax,eax
487d51: mov al,bl
487d53: imul eax,eax,0x16
487d56: cmp WORD PTR [esi+eax*8-0x3c],0xa
487d5c: jne 0x487d7e
487d5e: xor eax,eax
487d60: mov al,bl
487d62: imul eax,eax,0x16
487d65: cmp BYTE PTR [esi+eax*8-0x41],0x1
487d6a: jne 0x487d7e
487d6c: xor eax,eax
487d6e: mov al,bl
487d70: imul eax,eax,0x16
487d73: mov dl,BYTE PTR [esp+0x1]
487d77: add dl,0xc
487d7a: mov BYTE PTR [esi+eax*8-0x44],dl
487d7e: xor eax,eax
487d80: mov al,bl
487d82: imul eax,eax,0x16
487d85: cmp WORD PTR [esi+eax*8-0x3c],0x10
487d8b: jne 0x487dad
487d8d: xor eax,eax
487d8f: mov al,bl
487d91: imul eax,eax,0x16
487d94: cmp BYTE PTR [esi+eax*8-0x41],0x2
487d99: jne 0x487dad
487d9b: xor eax,eax
487d9d: mov al,bl
487d9f: imul eax,eax,0x16
487da2: mov dl,BYTE PTR [esp+0x1]
487da6: add dl,0xc
487da9: mov BYTE PTR [esi+eax*8-0x44],dl
487dad: xor eax,eax
487daf: mov al,bl
487db1: imul eax,eax,0x16
487db4: cmp WORD PTR [esi+eax*8-0x3c],0x4
487dba: jl 0x487e02
487dbc: xor eax,eax
487dbe: mov al,bl
487dc0: imul eax,eax,0x16
487dc3: cmp BYTE PTR [esi+eax*8-0x41],0x1
487dc8: jne 0x487e02
487dca: xor eax,eax
487dcc: mov al,bl
487dce: imul eax,eax,0x16
487dd1: cmp BYTE PTR [esi+eax*8-0x43],0x1
487dd6: jne 0x487de6
487dd8: push 0x40330000
487ddd: push 0x0
487ddf: mov eax,ebx
487de1: call 0x47648c
487de6: xor eax,eax
487de8: mov al,bl
487dea: imul eax,eax,0x16
487ded: cmp BYTE PTR [esi+eax*8-0x43],0x2
487df2: jne 0x487e02
487df4: push 0xc0330000
487df9: push 0x0
487dfb: mov eax,ebx
487dfd: call 0x47648c
487e02: xor eax,eax
487e04: mov al,bl
487e06: imul eax,eax,0x16
487e09: cmp WORD PTR [esi+eax*8-0x3c],0x4
487e0f: jl 0x487e66
487e11: xor eax,eax
487e13: mov al,bl
487e15: imul eax,eax,0x16
487e18: cmp WORD PTR [esi+eax*8-0x3c],0x10
487e1e: jge 0x487e66
487e20: xor eax,eax
487e22: mov al,bl
487e24: imul eax,eax,0x16
487e27: cmp BYTE PTR [esi+eax*8-0x41],0x2
487e2c: jne 0x487e66
487e2e: xor eax,eax
487e30: mov al,bl
487e32: imul eax,eax,0x16
487e35: cmp BYTE PTR [esi+eax*8-0x43],0x1
487e3a: jne 0x487e4a
487e3c: push 0x40310000
487e41: push 0x0
487e43: mov eax,ebx
487e45: call 0x47648c
487e4a: xor eax,eax
487e4c: mov al,bl
487e4e: imul eax,eax,0x16
487e51: cmp BYTE PTR [esi+eax*8-0x43],0x2
487e56: jne 0x487e66
487e58: push 0xc0310000
487e5d: push 0x0
487e5f: mov eax,ebx
487e61: call 0x47648c
487e66: xor eax,eax
487e68: mov al,bl
487e6a: imul eax,eax,0x16
487e6d: cmp WORD PTR [esi+eax*8-0x3c],0x2
487e73: jne 0x487edf
487e75: mov BYTE PTR [esp],0x3
487e79: mov eax,0x28
487e7e: call 0x402a1c
487e83: mov DWORD PTR [esp+0x4],eax
487e87: fild DWORD PTR [esp+0x4]
487e8b: xor eax,eax
487e8d: mov al,bl
487e8f: imul eax,eax,0x16
487e92: fld QWORD PTR [esi+eax*8-0xb0]
487e99: fsub DWORD PTR ds:0x48dce4
487e9f: faddp st(1),st
487ea1: add esp,0xfffffff8
487ea4: fstp QWORD PTR [esp]
487ea7: fwait
487ea8: mov eax,0xa
487ead: call 0x402a1c
487eb2: mov DWORD PTR [esp+0x10],eax
487eb6: fild DWORD PTR [esp+0x10]
487eba: xor eax,eax
487ebc: mov al,bl
487ebe: imul eax,eax,0x16
487ec1: fadd QWORD PTR [esi+eax*8-0xa8]
487ec8: add esp,0xfffffff8
487ecb: fstp QWORD PTR [esp]
487ece: fwait
487ecf: xor ecx,ecx
487ed1: xor edx,edx
487ed3: mov al,0x2
487ed5: call 0x476a04
487eda: dec BYTE PTR [esp]
487edd: jne 0x487e79
487edf: xor eax,eax
487ee1: mov al,bl
487ee3: imul eax,eax,0x16
487ee6: mov BYTE PTR [esi+eax*8-0x47],0x1
487eeb: xor eax,eax
487eed: mov al,bl
487eef: imul eax,eax,0x16
487ef2: cmp BYTE PTR [esi+eax*8-0x45],0x1b
487ef7: jne 0x488021
487efd: xor eax,eax
487eff: mov al,bl
487f01: imul eax,eax,0x16
487f04: mov BYTE PTR [esi+eax*8-0x42],0x0
487f09: xor eax,eax
487f0b: mov al,bl
487f0d: imul eax,eax,0x16
487f10: cmp WORD PTR [esi+eax*8-0x3c],0x0
487f16: jne 0x487f2a
487f18: xor eax,eax
487f1a: mov al,bl
487f1c: imul eax,eax,0x16
487f1f: mov dl,BYTE PTR [esp+0x1]
487f23: add dl,0x29
487f26: mov BYTE PTR [esi+eax*8-0x44],dl
487f2a: xor eax,eax
487f2c: mov al,bl
487f2e: imul eax,eax,0x16
487f31: cmp WORD PTR [esi+eax*8-0x3c],0x4
487f37: jne 0x487f4b
487f39: xor eax,eax
487f3b: mov al,bl
487f3d: imul eax,eax,0x16
487f40: mov dl,BYTE PTR [esp+0x1]
487f44: add dl,0x2a
487f47: mov BYTE PTR [esi+eax*8-0x44],dl
487f4b: xor eax,eax
487f4d: mov al,bl
487f4f: imul eax,eax,0x16
487f52: cmp WORD PTR [esi+eax*8-0x3c],0x4
487f58: jg 0x488006
487f5e: xor eax,eax
487f60: mov al,bl
487f62: imul eax,eax,0x16
487f65: cmp BYTE PTR [esi+eax*8-0x43],0x1
487f6a: jne 0x487f88
487f6c: xor eax,eax
487f6e: mov al,bl
487f70: imul eax,eax,0x16
487f73: cmp BYTE PTR [esi+eax*8-0x41],0x1
487f78: jne 0x487f88
487f7a: push 0x40300000
487f7f: push 0x0
487f81: mov eax,ebx
487f83: call 0x47648c
487f88: xor eax,eax
487f8a: mov al,bl
487f8c: imul eax,eax,0x16
487f8f: cmp BYTE PTR [esi+eax*8-0x43],0x2
487f94: jne 0x487fb2
487f96: xor eax,eax
487f98: mov al,bl
487f9a: imul eax,eax,0x16
487f9d: cmp BYTE PTR [esi+eax*8-0x41],0x1
487fa2: jne 0x487fb2
487fa4: push 0xc0300000
487fa9: push 0x0
487fab: mov eax,ebx
487fad: call 0x47648c
487fb2: xor eax,eax
487fb4: mov al,bl
487fb6: imul eax,eax,0x16
487fb9: cmp BYTE PTR [esi+eax*8-0x43],0x1
487fbe: jne 0x487fdc
487fc0: xor eax,eax
487fc2: mov al,bl
487fc4: imul eax,eax,0x16
487fc7: cmp BYTE PTR [esi+eax*8-0x41],0x2
487fcc: jne 0x487fdc
487fce: push 0x40340000
487fd3: push 0x0
487fd5: mov eax,ebx
487fd7: call 0x47648c
487fdc: xor eax,eax
487fde: mov al,bl
487fe0: imul eax,eax,0x16
487fe3: cmp BYTE PTR [esi+eax*8-0x43],0x2
487fe8: jne 0x488006
487fea: xor eax,eax
487fec: mov al,bl
487fee: imul eax,eax,0x16
487ff1: cmp BYTE PTR [esi+eax*8-0x41],0x2
487ff6: jne 0x488006
487ff8: push 0xc0340000
487ffd: push 0x0
487fff: mov eax,ebx
488001: call 0x47648c
488006: xor eax,eax
488008: mov al,bl
48800a: imul eax,eax,0x16
48800d: cmp WORD PTR [esi+eax*8-0x3c],0x5
488013: jl 0x488021
488015: xor eax,eax
488017: mov al,bl
488019: imul eax,eax,0x16
48801c: mov BYTE PTR [esi+eax*8-0x47],0x1
488021: xor eax,eax
488023: mov al,bl
488025: imul eax,eax,0x16
488028: cmp BYTE PTR [esi+eax*8-0x45],0x1c
48802d: jne 0x4881a6
488033: xor eax,eax
488035: mov al,bl
488037: imul eax,eax,0x16
48803a: cmp WORD PTR [esi+eax*8-0x3c],0x0
488040: jne 0x488054
488042: xor eax,eax
488044: mov al,bl
488046: imul eax,eax,0x16
488049: mov dl,BYTE PTR [esp+0x1]
48804d: add dl,0x2b
488050: mov BYTE PTR [esi+eax*8-0x44],dl
488054: xor eax,eax
488056: mov al,bl
488058: imul eax,eax,0x16
48805b: cmp WORD PTR [esi+eax*8-0x3c],0x6
488061: jne 0x488075
488063: xor eax,eax
488065: mov al,bl
488067: imul eax,eax,0x16
48806a: mov dl,BYTE PTR [esp+0x1]
48806e: add dl,0x2c
488071: mov BYTE PTR [esi+eax*8-0x44],dl
488075: xor eax,eax
488077: mov al,bl
488079: imul eax,eax,0x16
48807c: cmp WORD PTR [esi+eax*8-0x3c],0x6
488082: jl 0x48819a
488088: xor eax,eax
48808a: mov al,bl
48808c: imul eax,eax,0x16
48808f: cmp BYTE PTR [esi+eax*8-0x43],0x1
488094: jne 0x4880b2
488096: xor eax,eax
488098: mov al,bl
48809a: imul eax,eax,0x16
48809d: cmp BYTE PTR [esi+eax*8-0x41],0x1
4880a2: jne 0x4880b2
4880a4: push 0x40300000
4880a9: push 0x0
4880ab: mov eax,ebx
4880ad: call 0x47648c
4880b2: xor eax,eax
4880b4: mov al,bl
4880b6: imul eax,eax,0x16
4880b9: cmp BYTE PTR [esi+eax*8-0x43],0x2
4880be: jne 0x4880dc
4880c0: xor eax,eax
4880c2: mov al,bl
4880c4: imul eax,eax,0x16
4880c7: cmp BYTE PTR [esi+eax*8-0x41],0x1
4880cc: jne 0x4880dc
4880ce: push 0xc0300000
4880d3: push 0x0
4880d5: mov eax,ebx
4880d7: call 0x47648c
4880dc: xor eax,eax
4880de: mov al,bl
4880e0: imul eax,eax,0x16
4880e3: cmp BYTE PTR [esi+eax*8-0x43],0x1
4880e8: jne 0x488106
4880ea: xor eax,eax
4880ec: mov al,bl
4880ee: imul eax,eax,0x16
4880f1: cmp BYTE PTR [esi+eax*8-0x41],0x2
4880f6: jne 0x488106
4880f8: push 0x40340000
4880fd: push 0x0
4880ff: mov eax,ebx
488101: call 0x47648c
488106: xor eax,eax
488108: mov al,bl
48810a: imul eax,eax,0x16
48810d: cmp BYTE PTR [esi+eax*8-0x43],0x2
488112: jne 0x488130
488114: xor eax,eax
488116: mov al,bl
488118: imul eax,eax,0x16
48811b: cmp BYTE PTR [esi+eax*8-0x41],0x2
488120: jne 0x488130
488122: push 0xc0340000
488127: push 0x0
488129: mov eax,ebx
48812b: call 0x47648c
488130: mov BYTE PTR [esp],0x3
488134: mov eax,0x28
488139: call 0x402a1c
48813e: mov DWORD PTR [esp+0x4],eax
488142: fild DWORD PTR [esp+0x4]
488146: xor eax,eax
488148: mov al,bl
48814a: imul eax,eax,0x16
48814d: fld QWORD PTR [esi+eax*8-0xb0]
488154: fsub DWORD PTR ds:0x48dce4
48815a: faddp st(1),st
48815c: add esp,0xfffffff8
48815f: fstp QWORD PTR [esp]
488162: fwait
488163: mov eax,0xa
488168: call 0x402a1c
48816d: mov DWORD PTR [esp+0x10],eax
488171: fild DWORD PTR [esp+0x10]
488175: xor eax,eax
488177: mov al,bl
488179: imul eax,eax,0x16
48817c: fadd QWORD PTR [esi+eax*8-0xa8]
488183: add esp,0xfffffff8
488186: fstp QWORD PTR [esp]
488189: fwait
48818a: xor ecx,ecx
48818c: xor edx,edx
48818e: mov al,0x2
488190: call 0x476a04
488195: dec BYTE PTR [esp]
488198: jne 0x488134
48819a: xor eax,eax
48819c: mov al,bl
48819e: imul eax,eax,0x16
4881a1: mov BYTE PTR [esi+eax*8-0x47],0x1
4881a6: xor eax,eax
4881a8: mov al,bl
4881aa: imul eax,eax,0x16
4881ad: cmp BYTE PTR [esi+eax*8-0x45],0x1d
4881b2: jne 0x488379
4881b8: xor eax,eax
4881ba: mov al,bl
4881bc: imul eax,eax,0x16
4881bf: cmp WORD PTR [esi+eax*8-0x3c],0x0
4881c5: jne 0x4881d9
4881c7: xor eax,eax
4881c9: mov al,bl
4881cb: imul eax,eax,0x16
4881ce: mov dl,BYTE PTR [esp+0x1]
4881d2: add dl,0x26
4881d5: mov BYTE PTR [esi+eax*8-0x44],dl
4881d9: xor eax,eax
4881db: mov al,bl
4881dd: imul eax,eax,0x16
4881e0: cmp WORD PTR [esi+eax*8-0x3c],0x2
4881e6: jne 0x4881fa
4881e8: xor eax,eax
4881ea: mov al,bl
4881ec: imul eax,eax,0x16
4881ef: mov dl,BYTE PTR [esp+0x1]
4881f3: add dl,0x27
4881f6: mov BYTE PTR [esi+eax*8-0x44],dl
4881fa: xor eax,eax
4881fc: mov al,bl
4881fe: imul eax,eax,0x16
488201: cmp WORD PTR [esi+eax*8-0x3c],0x4
488207: jne 0x48821b
488209: xor eax,eax
48820b: mov al,bl
48820d: imul eax,eax,0x16
488210: mov dl,BYTE PTR [esp+0x1]
488214: add dl,0x28
488217: mov BYTE PTR [esi+eax*8-0x44],dl
48821b: xor eax,eax
48821d: mov al,bl
48821f: imul eax,eax,0x16
488222: cmp WORD PTR [esi+eax*8-0x3c],0xf
488228: jne 0x48823c
48822a: xor eax,eax
48822c: mov al,bl
48822e: imul eax,eax,0x16
488231: mov dl,BYTE PTR [esp+0x1]
488235: add dl,0x29
488238: mov BYTE PTR [esi+eax*8-0x44],dl
48823c: xor eax,eax
48823e: mov al,bl
488240: imul eax,eax,0x16
488243: cmp WORD PTR [esi+eax*8-0x3c],0xf
488249: jne 0x488263
48824b: xor eax,eax
48824d: mov al,bl
48824f: imul eax,eax,0x16
488252: mov BYTE PTR [esi+eax*8-0x38],0xdd
488257: xor eax,eax
488259: mov al,bl
48825b: imul eax,eax,0x16
48825e: mov BYTE PTR [esi+eax*8-0x46],0x1
488263: xor eax,eax
488265: mov al,bl
488267: imul eax,eax,0x16
48826a: cmp WORD PTR [esi+eax*8-0x3c],0x14
488270: jne 0x488290
488272: xor eax,eax
488274: mov al,bl
488276: imul eax,eax,0x16
488279: mov dl,BYTE PTR [esp+0x1]
48827d: add dl,0x2a
488280: mov BYTE PTR [esi+eax*8-0x44],dl
488284: xor eax,eax
488286: mov al,bl
488288: imul eax,eax,0x16
48828b: mov BYTE PTR [esi+eax*8-0x38],0xa
488290: xor eax,eax
488292: mov al,bl
488294: imul eax,eax,0x16
488297: cmp WORD PTR [esi+eax*8-0x3c],0x3
48829d: jl 0x4882e6
48829f: xor eax,eax
4882a1: mov al,bl
4882a3: imul eax,eax,0x16
4882a6: cmp WORD PTR [esi+eax*8-0x3c],0xf
4882ac: jge 0x4882e6
4882ae: xor eax,eax
4882b0: mov al,bl
4882b2: imul eax,eax,0x16
4882b5: cmp BYTE PTR [esi+eax*8-0x43],0x1
4882ba: jne 0x4882ca
4882bc: push 0x402a0000
4882c1: push 0x0
4882c3: mov eax,ebx
4882c5: call 0x47648c
4882ca: xor eax,eax
4882cc: mov al,bl
4882ce: imul eax,eax,0x16
4882d1: cmp BYTE PTR [esi+eax*8-0x43],0x2
4882d6: jne 0x4882e6
4882d8: push 0xc02a0000
4882dd: push 0x0
4882df: mov eax,ebx
4882e1: call 0x47648c
4882e6: xor eax,eax
4882e8: mov al,bl
4882ea: imul eax,eax,0x16
4882ed: cmp WORD PTR [esi+eax*8-0x3c],0xf
4882f3: jl 0x48833c
4882f5: xor eax,eax
4882f7: mov al,bl
4882f9: imul eax,eax,0x16
4882fc: cmp WORD PTR [esi+eax*8-0x3c],0x14
488302: jge 0x48833c
488304: xor eax,eax
488306: mov al,bl
488308: imul eax,eax,0x16
48830b: cmp BYTE PTR [esi+eax*8-0x43],0x1
488310: jne 0x488320
488312: push 0x40370000
488317: push 0x0
488319: mov eax,ebx
48831b: call 0x47648c
488320: xor eax,eax
488322: mov al,bl
488324: imul eax,eax,0x16
488327: cmp BYTE PTR [esi+eax*8-0x43],0x2
48832c: jne 0x48833c
48832e: push 0xc0370000
488333: push 0x0
488335: mov eax,ebx
488337: call 0x47648c
48833c: xor eax,eax
48833e: mov al,bl
488340: imul eax,eax,0x16
488343: cmp WORD PTR [esi+eax*8-0x3c],0xe
488349: jne 0x488357
48834b: xor eax,eax
48834d: mov al,bl
48834f: imul eax,eax,0x16
488352: mov BYTE PTR [esi+eax*8-0x47],0x1
488357: xor eax,eax
488359: mov al,bl
48835b: imul eax,eax,0x16
48835e: cmp WORD PTR [esi+eax*8-0x3c],0xe
488364: jle 0x488379
488366: xor eax,eax
488368: mov al,bl
48836a: mov edx,0x3
48836f: sub edx,eax
488371: imul eax,edx,0x16
488374: mov BYTE PTR [esi+eax*8-0x1e],0x0
488379: push 0x1e
48837b: push 0x13
48837d: push 0xaa
488382: xor edx,edx
488384: mov dl,BYTE PTR [esp+0xd]
488388: inc edx
488389: xor eax,eax
48838b: mov al,bl
48838d: mov ecx,0xfffffff2
488392: call 0x476870
488397: push 0x1e
488399: push 0x13
48839b: push 0xaa
4883a0: xor edx,edx
4883a2: mov dl,BYTE PTR [esp+0xd]
4883a6: add edx,0x2
4883a9: xor eax,eax
4883ab: mov al,bl
4883ad: mov ecx,0xfffffff2
4883b2: call 0x476870
4883b7: push 0x1e
4883b9: push 0x13
4883bb: push 0xaa
4883c0: xor edx,edx
4883c2: mov dl,BYTE PTR [esp+0xd]
4883c6: add edx,0x3
4883c9: xor eax,eax
4883cb: mov al,bl
4883cd: mov ecx,0xfffffff2
4883d2: call 0x476870
4883d7: push 0x1e
4883d9: push 0x13
4883db: push 0xaa
4883e0: xor edx,edx
4883e2: mov dl,BYTE PTR [esp+0xd]
4883e6: add edx,0x4
4883e9: xor eax,eax
4883eb: mov al,bl
4883ed: mov ecx,0xfffffff2
4883f2: call 0x476870
4883f7: push 0x1e
4883f9: push 0x13
4883fb: push 0xaa
488400: xor edx,edx
488402: mov dl,BYTE PTR [esp+0xd]
488406: add edx,0x6
488409: xor eax,eax
48840b: mov al,bl
48840d: mov ecx,0xfffffff2
488412: call 0x476870
488417: push 0x1e
488419: push 0x13
48841b: push 0xaa
488420: xor edx,edx
488422: mov dl,BYTE PTR [esp+0xd]
488426: add edx,0x8
488429: xor eax,eax
48842b: mov al,bl
48842d: mov ecx,0xfffffff2
488432: call 0x476870
488437: push 0x1e
488439: push 0x13
48843b: push 0xaa
488440: xor edx,edx
488442: mov dl,BYTE PTR [esp+0xd]
488446: add edx,0xa
488449: xor eax,eax
48844b: mov al,bl
48844d: mov ecx,0xfffffff2
488452: call 0x476870
488457: push 0x41
488459: push 0x14
48845b: push 0xaa
488460: xor edx,edx
488462: mov dl,BYTE PTR [esp+0xd]
488466: add edx,0xc
488469: xor eax,eax
48846b: mov al,bl
48846d: mov ecx,0xffffffec
488472: call 0x476870
488477: push 0x41
488479: push 0x14
48847b: push 0xaa
488480: xor edx,edx
488482: mov dl,BYTE PTR [esp+0xd]
488486: add edx,0xd
488489: xor eax,eax
48848b: mov al,bl
48848d: mov ecx,0xffffffec
488492: call 0x476870
488497: push 0x41
488499: push 0x14
48849b: push 0xaa
4884a0: xor edx,edx
4884a2: mov dl,BYTE PTR [esp+0xd]
4884a6: add edx,0xf
4884a9: xor eax,eax
4884ab: mov al,bl
4884ad: mov ecx,0xffffffec
4884b2: call 0x476870
4884b7: push 0x41
4884b9: push 0x14
4884bb: push 0xaa
4884c0: xor edx,edx
4884c2: mov dl,BYTE PTR [esp+0xd]
4884c6: add edx,0x11
4884c9: xor eax,eax
4884cb: mov al,bl
4884cd: mov ecx,0xffffffec
4884d2: call 0x476870
4884d7: push 0x41
4884d9: push 0x14
4884db: push 0xaa
4884e0: xor edx,edx
4884e2: mov dl,BYTE PTR [esp+0xd]
4884e6: add edx,0x13
4884e9: xor eax,eax
4884eb: mov al,bl
4884ed: mov ecx,0xffffffec
4884f2: call 0x476870
4884f7: push 0x1c
4884f9: push 0x13
4884fb: push 0x8c
488500: xor edx,edx
488502: mov dl,BYTE PTR [esp+0xd]
488506: add edx,0x15
488509: xor eax,eax
48850b: mov al,bl
48850d: mov ecx,0xffffffec
488512: call 0x476870
488517: push 0x44
488519: push 0x24
48851b: push 0x70
48851d: xor edx,edx
48851f: mov dl,BYTE PTR [esp+0xd]
488523: add edx,0x1c
488526: xor eax,eax
488528: mov al,bl
48852a: mov ecx,0xffffffe4
48852f: call 0x476870
488534: push 0x76
488536: push 0x24
488538: push 0x98
48853d: xor edx,edx
48853f: mov dl,BYTE PTR [esp+0xd]
488543: add edx,0x1d
488546: xor eax,eax
488548: mov al,bl
48854a: mov ecx,0xffffffe4
48854f: call 0x476870
488554: push 0x1e
488556: push 0x13
488558: push 0xaa
48855d: xor edx,edx
48855f: mov dl,BYTE PTR [esp+0xd]
488563: add edx,0x1f
488566: xor eax,eax
488568: mov al,bl
48856a: mov ecx,0xfffffff2
48856f: call 0x476870
488574: push 0x41
488576: push 0x14
488578: push 0xaa
48857d: xor edx,edx
48857f: mov dl,BYTE PTR [esp+0xd]
488583: add edx,0x20
488586: xor eax,eax
488588: mov al,bl
48858a: mov ecx,0xffffffec
48858f: call 0x476870
488594: push 0x55
488596: push 0x28
488598: push 0x78
48859a: xor edx,edx
48859c: mov dl,BYTE PTR [esp+0xd]
4885a0: add edx,0x28
4885a3: xor eax,eax
4885a5: mov al,bl
4885a7: mov ecx,0xffffffe2
4885ac: call 0x476870
4885b1: push 0xa
4885b3: push 0x34
4885b5: push 0x37
4885b7: push 0x44
4885b9: push 0x1
4885bb: push 0x1
4885bd: push 0x7
4885bf: push 0x0
4885c1: xor eax,eax
4885c3: mov al,bl
4885c5: mov ecx,0x2
4885ca: mov edx,0x3
4885cf: call 0x4768f8
4885d4: push 0x14
4885d6: push 0x7a
4885d8: push 0x37
4885da: push 0x91
4885df: push 0x1
4885e1: push 0x1
4885e3: push 0x7
4885e5: push 0x0
4885e7: xor eax,eax
4885e9: mov al,bl
4885eb: mov ecx,0x2
4885f0: mov edx,0x4
4885f5: call 0x4768f8
4885fa: push 0x14
4885fc: push 0x34
4885fe: push 0x3c
488600: push 0x44
488602: push 0x1
488604: push 0x2
488606: push 0xe
488608: push 0x0
48860a: xor eax,eax
48860c: mov al,bl
48860e: mov ecx,0x5
488613: mov edx,0x5
488618: call 0x4768f8
48861d: push 0x1e
48861f: push 0x3c
488621: push 0x55
488623: push 0x55
488625: push 0x1
488627: push 0x2
488629: push 0xe
48862b: push 0x0
48862d: xor eax,eax
48862f: mov al,bl
488631: mov ecx,0x5
488636: mov edx,0x6
48863b: call 0x4768f8
488640: push 0xa
488642: push 0x58
488644: push 0x37
488646: push 0x68
488648: push 0x1
48864a: push 0x1
48864c: push 0x7
48864e: push 0x0
488650: xor eax,eax
488652: mov al,bl
488654: mov ecx,0x2
488659: mov edx,0x8
48865e: call 0x4768f8
488663: push 0xa
488665: push 0x8c
48866a: push 0x3f
48866c: push 0x9a
488671: push 0x1
488673: push 0x1
488675: push 0x7
488677: push 0x0
488679: xor eax,eax
48867b: mov al,bl
48867d: mov ecx,0x2
488682: mov edx,0x9
488687: call 0x4768f8
48868c: push 0xa
48868e: push 0x58
488690: push 0x41
488692: push 0x68
488694: push 0x1
488696: push 0x2
488698: push 0xe
48869a: push 0x0
48869c: xor eax,eax
48869e: mov al,bl
4886a0: mov ecx,0x5
4886a5: mov edx,0xa
4886aa: call 0x4768f8
4886af: push 0xa
4886b1: push 0x87
4886b6: push 0x4a
4886b8: push 0x99
4886bd: push 0x1
4886bf: push 0x2
4886c1: push 0xe
4886c3: push 0x0
4886c5: xor eax,eax
4886c7: mov al,bl
4886c9: mov ecx,0x5
4886ce: mov edx,0xb
4886d3: call 0x4768f8
4886d8: push 0x14
4886da: push 0x3c
4886dc: push 0x50
4886de: push 0x66
4886e0: push 0x1
4886e2: push 0x1
4886e4: push 0x7
4886e6: push 0x0
4886e8: xor eax,eax
4886ea: mov al,bl
4886ec: mov ecx,0x2
4886f1: mov edx,0xd
4886f6: call 0x4768f8
4886fb: push 0xa
4886fd: push 0x41
4886ff: push 0x4b
488701: push 0x6e
488703: push 0x1
488705: push 0x1
488707: push 0x7
488709: push 0x0
48870b: xor eax,eax
48870d: mov al,bl
48870f: mov ecx,0x2
488714: mov edx,0xe
488719: call 0x4768f8
48871e: push 0x14
488720: push 0x3c
488722: push 0x50
488724: push 0x66
488726: push 0x1
488728: push 0x2
48872a: push 0xe
48872c: push 0x0
48872e: xor eax,eax
488730: mov al,bl
488732: mov ecx,0x5
488737: mov edx,0xf
48873c: call 0x4768f8
488741: push 0xa
488743: push 0x41
488745: push 0x4b
488747: push 0x6e
488749: push 0x1
48874b: push 0x2
48874d: push 0xe
48874f: push 0x0
488751: xor eax,eax
488753: mov al,bl
488755: mov ecx,0x5
48875a: mov edx,0x10
48875f: call 0x4768f8
488764: push 0xa
488766: push 0x2d
488768: push 0x46
48876a: push 0x69
48876c: push 0x1
48876e: push 0x0
488770: push 0x4
488772: push 0x1
488774: xor eax,eax
488776: mov al,bl
488778: mov ecx,0x1
48877d: mov edx,0x19
488782: call 0x4768f8
488787: push 0xa
488789: push 0x2d
48878b: push 0x46
48878d: push 0x69
48878f: push 0x1
488791: push 0x0
488793: push 0x4
488795: push 0x1
488797: xor eax,eax
488799: mov al,bl
48879b: mov ecx,0x3
4887a0: mov edx,0x19
4887a5: call 0x4768f8
4887aa: push 0xa
4887ac: push 0x2d
4887ae: push 0x46
4887b0: push 0x69
4887b2: push 0x1
4887b4: push 0x0
4887b6: push 0x3
4887b8: push 0x1
4887ba: xor eax,eax
4887bc: mov al,bl
4887be: mov ecx,0x5
4887c3: mov edx,0x19
4887c8: call 0x4768f8
4887cd: push 0xa
4887cf: push 0x2d
4887d1: push 0x46
4887d3: push 0x69
4887d5: push 0x1
4887d7: push 0x0
4887d9: push 0x4
4887db: push 0x1
4887dd: xor eax,eax
4887df: mov al,bl
4887e1: mov ecx,0x7
4887e6: mov edx,0x19
4887eb: call 0x4768f8
4887f0: push 0xa
4887f2: push 0x2d
4887f4: push 0x46
4887f6: push 0x69
4887f8: push 0x1
4887fa: push 0x0
4887fc: push 0x4
4887fe: push 0x1
488800: xor eax,eax
488802: mov al,bl
488804: mov ecx,0x9
488809: mov edx,0x19
48880e: call 0x4768f8
488813: push 0x0
488815: push 0x0
488817: push 0x0
488819: push 0x0
48881b: push 0x0
48881d: push 0x0
48881f: push 0x4
488821: push 0x1
488823: xor eax,eax
488825: mov al,bl
488827: mov ecx,0xc
48882c: mov edx,0x19
488831: call 0x4768f8
488836: push 0x28
488838: push 0x55
48883a: push 0x4b
48883c: push 0x73
48883e: push 0x1
488840: push 0x0
488842: push 0x12
488844: push 0x3
488846: xor eax,eax
488848: mov al,bl
48884a: mov ecx,0x3
48884f: mov edx,0x1a
488854: call 0x4768f8
488859: push 0x0
48885b: push 0x0
48885d: push 0x0
48885f: push 0x0
488861: push 0x0
488863: push 0x0
488865: push 0x0
488867: push 0x0
488869: xor eax,eax
48886b: mov al,bl
48886d: mov ecx,0xf
488872: mov edx,0x1a
488877: call 0x4768f8
48887c: push 0xffffffe2
48887e: push 0x1e
488880: push 0x32
488882: push 0x6e
488884: push 0x1
488886: push 0x0
488888: push 0x5
48888a: push 0x2
48888c: xor eax,eax
48888e: mov al,bl
488890: mov ecx,0x1
488895: mov edx,0x1b
48889a: call 0x4768f8
48889f: push 0xffffffe2
4888a1: push 0x64
4888a3: push 0x32
4888a5: push 0x8c
4888aa: push 0x1
4888ac: push 0x0
4888ae: push 0x12
4888b0: push 0x3
4888b2: xor eax,eax
4888b4: mov al,bl
4888b6: mov ecx,0x5
4888bb: mov edx,0x1b
4888c0: call 0x4768f8
4888c5: push 0x14
4888c7: push 0x23
4888c9: push 0x2d
4888cb: push 0x84
4888d0: push 0x1
4888d2: push 0x0
4888d4: push 0x12
4888d6: push 0x3
4888d8: xor eax,eax
4888da: mov al,bl
4888dc: mov ecx,0x6
4888e1: mov edx,0x1c
4888e6: call 0x4768f8
4888eb: push 0x28
4888ed: push 0x55
4888ef: push 0x4b
4888f1: push 0x73
4888f3: push 0x1
4888f5: push 0x0
4888f7: push 0x4
4888f9: push 0x3
4888fb: xor eax,eax
4888fd: mov al,bl
4888ff: mov ecx,0x3
488904: mov edx,0x1d
488909: call 0x4768f8
48890e: push 0x28
488910: push 0x55
488912: push 0x4b
488914: push 0x73
488916: push 0x1
488918: push 0x2
48891a: push 0x6
48891c: push 0x2
48891e: xor eax,eax
488920: mov al,bl
488922: mov ecx,0x5
488927: mov edx,0x1d
48892c: call 0x4768f8
488931: push 0x28
488933: push 0x55
488935: push 0x4b
488937: push 0x73
488939: push 0x1
48893b: push 0x2
48893d: push 0x8
48893f: push 0x2
488941: xor eax,eax
488943: mov al,bl
488945: mov ecx,0x7
48894a: mov edx,0x1d
48894f: call 0x4768f8
488954: push 0x28
488956: push 0x55
488958: push 0x4b
48895a: push 0x73
48895c: push 0x1
48895e: push 0x2
488960: push 0x6
488962: push 0x2
488964: xor eax,eax
488966: mov al,bl
488968: mov ecx,0x9
48896d: mov edx,0x1d
488972: call 0x4768f8
488977: push 0x28
488979: push 0x55
48897b: push 0x4b
48897d: push 0x73
48897f: push 0x1
488981: push 0x2
488983: push 0x8
488985: push 0x1
488987: xor eax,eax
488989: mov al,bl
48898b: mov ecx,0xb
488990: mov edx,0x1d
488995: call 0x4768f8
48899a: push 0x28
48899c: push 0x55
48899e: push 0x4b
4889a0: push 0x73
4889a2: push 0x1
4889a4: push 0x2
4889a6: push 0x4
4889a8: push 0x2
4889aa: xor eax,eax
4889ac: mov al,bl
4889ae: mov ecx,0xd
4889b3: mov edx,0x1d
4889b8: call 0x4768f8
4889bd: push 0x28
4889bf: push 0x55
4889c1: push 0x4b
4889c3: push 0x73
4889c5: push 0x1
4889c7: push 0x2
4889c9: push 0x6
4889cb: push 0x1
4889cd: xor eax,eax
4889cf: mov al,bl
4889d1: mov ecx,0xf
4889d6: mov edx,0x1d
4889db: call 0x4768f8
4889e0: push 0x28
4889e2: push 0x55
4889e4: push 0x4b
4889e6: push 0x73
4889e8: push 0x1
4889ea: push 0x2
4889ec: push 0x4
4889ee: push 0x2
4889f0: xor eax,eax
4889f2: mov al,bl
4889f4: mov ecx,0x11
4889f9: mov edx,0x1d
4889fe: call 0x4768f8
488a03: push 0x28
488a05: push 0x55
488a07: push 0x4b
488a09: push 0x73
488a0b: push 0x1
488a0d: push 0x2
488a0f: push 0x6
488a11: push 0x1
488a13: xor eax,eax
488a15: mov al,bl
488a17: mov ecx,0x13
488a1c: mov edx,0x1d
488a21: call 0x4768f8
488a26: push 0xffffffda
488a28: push 0x64
488a2a: push 0x3a
488a2c: push 0x8a
488a31: push 0x1
488a33: push 0x2
488a35: push 0x3
488a37: push 0x3
488a39: xor eax,eax
488a3b: mov al,bl
488a3d: mov ecx,0x17
488a42: mov edx,0x1d
488a47: call 0x4768f8
488a4c: xor eax,eax
488a4e: mov al,bl
488a50: imul eax,eax,0x16
488a53: cmp BYTE PTR [esi+eax*8-0xa0],0xb
488a5b: jne 0x489d14
488a61: xor eax,eax
488a63: mov al,bl
488a65: imul eax,eax,0x16
488a68: cmp BYTE PTR [esi+eax*8-0x45],0x17
488a6d: jne 0x488a81
488a6f: xor eax,eax
488a71: mov al,bl
488a73: imul eax,eax,0x16
488a76: mov dl,BYTE PTR [esp+0x1]
488a7a: add dl,0x21
488a7d: mov BYTE PTR [esi+eax*8-0x44],dl
488a81: xor eax,eax
488a83: mov al,bl
488a85: imul eax,eax,0x16
488a88: cmp BYTE PTR [esi+eax*8-0x45],0x18
488a8d: jne 0x488ab0
488a8f: xor eax,eax
488a91: mov al,bl
488a93: imul eax,eax,0x16
488a96: cmp WORD PTR [esi+eax*8-0x3c],0x0
488a9c: jne 0x488ab0
488a9e: xor eax,eax
488aa0: mov al,bl
488aa2: imul eax,eax,0x16
488aa5: mov dl,BYTE PTR [esp+0x1]
488aa9: add dl,0xc
488aac: mov BYTE PTR [esi+eax*8-0x44],dl
488ab0: xor eax,eax
488ab2: mov al,bl
488ab4: imul eax,eax,0x16
488ab7: cmp BYTE PTR [esi+eax*8-0x45],0x18
488abc: jne 0x488adf
488abe: xor eax,eax
488ac0: mov al,bl
488ac2: imul eax,eax,0x16
488ac5: cmp WORD PTR [esi+eax*8-0x3c],0x2
488acb: jne 0x488adf
488acd: xor eax,eax
488acf: mov al,bl
488ad1: imul eax,eax,0x16
488ad4: mov dl,BYTE PTR [esp+0x1]
488ad8: add dl,0x1e
488adb: mov BYTE PTR [esi+eax*8-0x44],dl
488adf: xor eax,eax
488ae1: mov al,bl
488ae3: imul eax,eax,0x16
488ae6: cmp BYTE PTR [esi+eax*8-0x45],0x19
488aeb: jne 0x488ce0
488af1: xor eax,eax
488af3: mov al,bl
488af5: imul eax,eax,0x16
488af8: cmp WORD PTR [esi+eax*8-0x3c],0x0
488afe: jne 0x488b12
488b00: xor eax,eax
488b02: mov al,bl
488b04: imul eax,eax,0x16
488b07: mov dl,BYTE PTR [esp+0x1]
488b0b: add dl,0x22
488b0e: mov BYTE PTR [esi+eax*8-0x44],dl
488b12: xor eax,eax
488b14: mov al,bl
488b16: imul eax,eax,0x16
488b19: cmp WORD PTR [esi+eax*8-0x3c],0x5
488b1f: jne 0x488b33
488b21: xor eax,eax
488b23: mov al,bl
488b25: imul eax,eax,0x16
488b28: mov dl,BYTE PTR [esp+0x1]
488b2c: add dl,0x23
488b2f: mov BYTE PTR [esi+eax*8-0x44],dl
488b33: xor eax,eax
488b35: mov al,bl
488b37: imul eax,eax,0x16
488b3a: cmp WORD PTR [esi+eax*8-0x3c],0xa
488b40: jne 0x488ce0
488b46: xor eax,eax
488b48: mov al,bl
488b4a: imul eax,eax,0x16
488b4d: mov dl,BYTE PTR [esp+0x1]
488b51: add dl,0x24
488b54: mov BYTE PTR [esi+eax*8-0x44],dl
488b58: xor eax,eax
488b5a: mov al,bl
488b5c: imul eax,eax,0x16
488b5f: cmp BYTE PTR [esi+eax*8-0x43],0x1
488b64: jne 0x488bb8
488b66: xor eax,eax
488b68: mov al,bl
488b6a: imul eax,eax,0x16
488b6d: cmp BYTE PTR [esi+eax*8-0x41],0x1
488b72: jne 0x488bb8
488b74: xor eax,eax
488b76: mov al,bl
488b78: imul eax,eax,0x16
488b7b: fld QWORD PTR [esi+eax*8-0xb0]
488b82: fadd DWORD PTR ds:0x48dd14
488b88: add esp,0xfffffff8
488b8b: fstp QWORD PTR [esp]
488b8e: fwait
488b8f: xor eax,eax
488b91: mov al,bl
488b93: imul eax,eax,0x16
488b96: fld QWORD PTR [esi+eax*8-0xa8]
488b9d: fsub DWORD PTR ds:0x48dcfc
488ba3: add esp,0xfffffff8
488ba6: fstp QWORD PTR [esp]
488ba9: fwait
488baa: mov ecx,ebx
488bac: mov edx,0x48dcd4
488bb1: mov al,0x16
488bb3: call 0x476a04
488bb8: xor eax,eax
488bba: mov al,bl
488bbc: imul eax,eax,0x16
488bbf: cmp BYTE PTR [esi+eax*8-0x43],0x2
488bc4: jne 0x488c18
488bc6: xor eax,eax
488bc8: mov al,bl
488bca: imul eax,eax,0x16
488bcd: cmp BYTE PTR [esi+eax*8-0x41],0x1
488bd2: jne 0x488c18
488bd4: xor eax,eax
488bd6: mov al,bl
488bd8: imul eax,eax,0x16
488bdb: fld QWORD PTR [esi+eax*8-0xb0]
488be2: fsub DWORD PTR ds:0x48dd14
488be8: add esp,0xfffffff8
488beb: fstp QWORD PTR [esp]
488bee: fwait
488bef: xor eax,eax
488bf1: mov al,bl
488bf3: imul eax,eax,0x16
488bf6: fld QWORD PTR [esi+eax*8-0xa8]
488bfd: fsub DWORD PTR ds:0x48dcfc
488c03: add esp,0xfffffff8
488c06: fstp QWORD PTR [esp]
488c09: fwait
488c0a: mov ecx,ebx
488c0c: mov edx,0x48dcd4
488c11: mov al,0x16
488c13: call 0x476a04
488c18: xor eax,eax
488c1a: mov al,bl
488c1c: imul eax,eax,0x16
488c1f: cmp BYTE PTR [esi+eax*8-0x43],0x1
488c24: jne 0x488c78
488c26: xor eax,eax
488c28: mov al,bl
488c2a: imul eax,eax,0x16
488c2d: cmp BYTE PTR [esi+eax*8-0x41],0x2
488c32: jne 0x488c78
488c34: xor eax,eax
488c36: mov al,bl
488c38: imul eax,eax,0x16
488c3b: fld QWORD PTR [esi+eax*8-0xb0]
488c42: fadd DWORD PTR ds:0x48dd14
488c48: add esp,0xfffffff8
488c4b: fstp QWORD PTR [esp]
488c4e: fwait
488c4f: xor eax,eax
488c51: mov al,bl
488c53: imul eax,eax,0x16
488c56: fld QWORD PTR [esi+eax*8-0xa8]
488c5d: fsub DWORD PTR ds:0x48dcfc
488c63: add esp,0xfffffff8
488c66: fstp QWORD PTR [esp]
488c69: fwait
488c6a: mov ecx,ebx
488c6c: mov edx,0x48dce0
488c71: mov al,0x16
488c73: call 0x476a04
488c78: xor eax,eax
488c7a: mov al,bl
488c7c: imul eax,eax,0x16
488c7f: cmp BYTE PTR [esi+eax*8-0x43],0x2
488c84: jne 0x488cd8
488c86: xor eax,eax
488c88: mov al,bl
488c8a: imul eax,eax,0x16
488c8d: cmp BYTE PTR [esi+eax*8-0x41],0x2
488c92: jne 0x488cd8
488c94: xor eax,eax
488c96: mov al,bl
488c98: imul eax,eax,0x16
488c9b: fld QWORD PTR [esi+eax*8-0xb0]
488ca2: fsub DWORD PTR ds:0x48dd14
488ca8: add esp,0xfffffff8
488cab: fstp QWORD PTR [esp]
488cae: fwait
488caf: xor eax,eax
488cb1: mov al,bl
488cb3: imul eax,eax,0x16
488cb6: fld QWORD PTR [esi+eax*8-0xa8]
488cbd: fsub DWORD PTR ds:0x48dcfc
488cc3: add esp,0xfffffff8
488cc6: fstp QWORD PTR [esp]
488cc9: fwait
488cca: mov ecx,ebx
488ccc: mov edx,0x48dce0
488cd1: mov al,0x16
488cd3: call 0x476a04
488cd8: mov eax,ds:0x4b1098
488cdd: mov BYTE PTR [eax],0x32
488ce0: xor eax,eax
488ce2: mov al,bl
488ce4: imul eax,eax,0x16
488ce7: cmp BYTE PTR [esi+eax*8-0x45],0x1a
488cec: jne 0x488ea8
488cf2: xor eax,eax
488cf4: mov al,bl
488cf6: imul eax,eax,0x16
488cf9: cmp WORD PTR [esi+eax*8-0x3c],0x0
488cff: jne 0x488d13
488d01: xor eax,eax
488d03: mov al,bl
488d05: imul eax,eax,0x16
488d08: mov dl,BYTE PTR [esp+0x1]
488d0c: add dl,0x25
488d0f: mov BYTE PTR [esi+eax*8-0x44],dl
488d13: xor eax,eax
488d15: mov al,bl
488d17: imul eax,eax,0x16
488d1a: cmp WORD PTR [esi+eax*8-0x3c],0x4
488d20: jne 0x488ea8
488d26: xor eax,eax
488d28: mov al,bl
488d2a: imul eax,eax,0x16
488d2d: mov dl,BYTE PTR [esp+0x1]
488d31: add dl,0x26
488d34: mov BYTE PTR [esi+eax*8-0x44],dl
488d38: xor eax,eax
488d3a: mov al,bl
488d3c: imul eax,eax,0x16
488d3f: cmp BYTE PTR [esi+eax*8-0x43],0x1
488d44: jne 0x488d92
488d46: xor eax,eax
488d48: mov al,bl
488d4a: imul eax,eax,0x16
488d4d: cmp BYTE PTR [esi+eax*8-0x41],0x1
488d52: jne 0x488d92
488d54: xor eax,eax
488d56: mov al,bl
488d58: imul eax,eax,0x16
488d5b: fld QWORD PTR [esi+eax*8-0xb0]
488d62: fadd DWORD PTR ds:0x48dd2c
488d68: add esp,0xfffffff8
488d6b: fstp QWORD PTR [esp]
488d6e: fwait
488d6f: xor eax,eax
488d71: mov al,bl
488d73: imul eax,eax,0x16
488d76: push DWORD PTR [esi+eax*8-0xa4]
488d7d: push DWORD PTR [esi+eax*8-0xa8]
488d84: mov ecx,ebx
488d86: mov edx,0x48dcd4
488d8b: mov al,0x17
488d8d: call 0x476a04
488d92: xor eax,eax
488d94: mov al,bl
488d96: imul eax,eax,0x16
488d99: cmp BYTE PTR [esi+eax*8-0x43],0x2
488d9e: jne 0x488dec
488da0: xor eax,eax
488da2: mov al,bl
488da4: imul eax,eax,0x16
488da7: cmp BYTE PTR [esi+eax*8-0x41],0x1
488dac: jne 0x488dec
488dae: xor eax,eax
488db0: mov al,bl
488db2: imul eax,eax,0x16
488db5: fld QWORD PTR [esi+eax*8-0xb0]
488dbc: fsub DWORD PTR ds:0x48dd2c
488dc2: add esp,0xfffffff8
488dc5: fstp QWORD PTR [esp]
488dc8: fwait
488dc9: xor eax,eax
488dcb: mov al,bl
488dcd: imul eax,eax,0x16
488dd0: push DWORD PTR [esi+eax*8-0xa4]
488dd7: push DWORD PTR [esi+eax*8-0xa8]
488dde: mov ecx,ebx
488de0: mov edx,0x48dcd4
488de5: mov al,0x17
488de7: call 0x476a04
488dec: xor eax,eax
488dee: mov al,bl
488df0: imul eax,eax,0x16
488df3: cmp BYTE PTR [esi+eax*8-0x43],0x1
488df8: jne 0x488e46
488dfa: xor eax,eax
488dfc: mov al,bl
488dfe: imul eax,eax,0x16
488e01: cmp BYTE PTR [esi+eax*8-0x41],0x2
488e06: jne 0x488e46
488e08: xor eax,eax
488e0a: mov al,bl
488e0c: imul eax,eax,0x16
488e0f: fld QWORD PTR [esi+eax*8-0xb0]
488e16: fadd DWORD PTR ds:0x48dd2c
488e1c: add esp,0xfffffff8
488e1f: fstp QWORD PTR [esp]
488e22: fwait
488e23: xor eax,eax
488e25: mov al,bl
488e27: imul eax,eax,0x16
488e2a: push DWORD PTR [esi+eax*8-0xa4]
488e31: push DWORD PTR [esi+eax*8-0xa8]
488e38: mov ecx,ebx
488e3a: mov edx,0x48dce0
488e3f: mov al,0x17
488e41: call 0x476a04
488e46: xor eax,eax
488e48: mov al,bl
488e4a: imul eax,eax,0x16
488e4d: cmp BYTE PTR [esi+eax*8-0x43],0x2
488e52: jne 0x488ea0
488e54: xor eax,eax
488e56: mov al,bl
488e58: imul eax,eax,0x16
488e5b: cmp BYTE PTR [esi+eax*8-0x41],0x2
488e60: jne 0x488ea0
488e62: xor eax,eax
488e64: mov al,bl
488e66: imul eax,eax,0x16
488e69: fld QWORD PTR [esi+eax*8-0xb0]
488e70: fsub DWORD PTR ds:0x48dd2c
488e76: add esp,0xfffffff8
488e79: fstp QWORD PTR [esp]
488e7c: fwait
488e7d: xor eax,eax
488e7f: mov al,bl
488e81: imul eax,eax,0x16
488e84: push DWORD PTR [esi+eax*8-0xa4]
488e8b: push DWORD PTR [esi+eax*8-0xa8]
488e92: mov ecx,ebx
488e94: mov edx,0x48dce0
488e99: mov al,0x17
488e9b: call 0x476a04
488ea0: mov eax,ds:0x4b1098
488ea5: mov BYTE PTR [eax],0x33
488ea8: xor eax,eax
488eaa: mov al,bl
488eac: imul eax,eax,0x16
488eaf: cmp BYTE PTR [esi+eax*8-0x45],0x1b
488eb4: jne 0x4890e6
488eba: xor eax,eax
488ebc: mov al,bl
488ebe: imul eax,eax,0x16
488ec1: cmp BYTE PTR [esi+eax*8-0x41],0x1
488ec6: jne 0x488ee9
488ec8: xor eax,eax
488eca: mov al,bl
488ecc: imul eax,eax,0x16
488ecf: cmp WORD PTR [esi+eax*8-0x3c],0x1
488ed5: jge 0x488ee9
488ed7: xor eax,eax
488ed9: mov al,bl
488edb: imul eax,eax,0x16
488ede: mov dl,BYTE PTR [esp+0x1]
488ee2: add dl,0xf
488ee5: mov BYTE PTR [esi+eax*8-0x44],dl
488ee9: xor eax,eax
488eeb: mov al,bl
488eed: imul eax,eax,0x16
488ef0: cmp BYTE PTR [esi+eax*8-0x41],0x2
488ef5: jne 0x488f18
488ef7: xor eax,eax
488ef9: mov al,bl
488efb: imul eax,eax,0x16
488efe: cmp WORD PTR [esi+eax*8-0x3c],0x1
488f04: jge 0x488f18
488f06: xor eax,eax
488f08: mov al,bl
488f0a: imul eax,eax,0x16
488f0d: mov dl,BYTE PTR [esp+0x1]
488f11: add dl,0x6
488f14: mov BYTE PTR [esi+eax*8-0x44],dl
488f18: xor eax,eax
488f1a: mov al,bl
488f1c: imul eax,eax,0x16
488f1f: cmp BYTE PTR [esi+eax*8-0x41],0x1
488f24: jne 0x488f47
488f26: xor eax,eax
488f28: mov al,bl
488f2a: imul eax,eax,0x16
488f2d: cmp WORD PTR [esi+eax*8-0x3c],0x1
488f33: jl 0x488f47
488f35: xor eax,eax
488f37: mov al,bl
488f39: imul eax,eax,0x16
488f3c: mov dl,BYTE PTR [esp+0x1]
488f40: add dl,0x27
488f43: mov BYTE PTR [esi+eax*8-0x44],dl
488f47: xor eax,eax
488f49: mov al,bl
488f4b: imul eax,eax,0x16
488f4e: cmp BYTE PTR [esi+eax*8-0x41],0x2
488f53: jne 0x488f76
488f55: xor eax,eax
488f57: mov al,bl
488f59: imul eax,eax,0x16
488f5c: cmp WORD PTR [esi+eax*8-0x3c],0x1
488f62: jl 0x488f76
488f64: xor eax,eax
488f66: mov al,bl
488f68: imul eax,eax,0x16
488f6b: mov dl,BYTE PTR [esp+0x1]
488f6f: add dl,0x28
488f72: mov BYTE PTR [esi+eax*8-0x44],dl
488f76: xor eax,eax
488f78: mov al,bl
488f7a: imul eax,eax,0x16
488f7d: cmp WORD PTR [esi+eax*8-0x3c],0x1
488f83: jne 0x488f8d
488f85: mov eax,ds:0x4b1098
488f8a: mov BYTE PTR [eax],0x34
488f8d: xor eax,eax
488f8f: mov al,bl
488f91: imul eax,eax,0x16
488f94: cmp WORD PTR [esi+eax*8-0x3c],0x1
488f9a: jl 0x4890b2
488fa0: xor eax,eax
488fa2: mov al,bl
488fa4: imul eax,eax,0x16
488fa7: cmp BYTE PTR [esi+eax*8-0x43],0x1
488fac: jne 0x488fca
488fae: xor eax,eax
488fb0: mov al,bl
488fb2: imul eax,eax,0x16
488fb5: cmp BYTE PTR [esi+eax*8-0x41],0x1
488fba: jne 0x488fca
488fbc: push 0x40330000
488fc1: push 0x0
488fc3: mov eax,ebx
488fc5: call 0x47648c
488fca: xor eax,eax
488fcc: mov al,bl
488fce: imul eax,eax,0x16
488fd1: cmp BYTE PTR [esi+eax*8-0x43],0x2
488fd6: jne 0x488ff4
488fd8: xor eax,eax
488fda: mov al,bl
488fdc: imul eax,eax,0x16
488fdf: cmp BYTE PTR [esi+eax*8-0x41],0x1
488fe4: jne 0x488ff4
488fe6: push 0xc0330000
488feb: push 0x0
488fed: mov eax,ebx
488fef: call 0x47648c
488ff4: xor eax,eax
488ff6: mov al,bl
488ff8: imul eax,eax,0x16
488ffb: cmp BYTE PTR [esi+eax*8-0x43],0x1
489000: jne 0x48901e
489002: xor eax,eax
489004: mov al,bl
489006: imul eax,eax,0x16
489009: cmp BYTE PTR [esi+eax*8-0x41],0x2
48900e: jne 0x48901e
489010: push 0x40300000
489015: push 0x0
489017: mov eax,ebx
489019: call 0x47648c
48901e: xor eax,eax
489020: mov al,bl
489022: imul eax,eax,0x16
489025: cmp BYTE PTR [esi+eax*8-0x43],0x2
48902a: jne 0x489048
48902c: xor eax,eax
48902e: mov al,bl
489030: imul eax,eax,0x16
489033: cmp BYTE PTR [esi+eax*8-0x41],0x2
489038: jne 0x489048
48903a: push 0xc0300000
48903f: push 0x0
489041: mov eax,ebx
489043: call 0x47648c
489048: mov BYTE PTR [esp],0x8
48904c: mov eax,0x28
489051: call 0x402a1c
489056: mov DWORD PTR [esp+0x4],eax
48905a: fild DWORD PTR [esp+0x4]
48905e: xor eax,eax
489060: mov al,bl
489062: imul eax,eax,0x16
489065: fld QWORD PTR [esi+eax*8-0xb0]
48906c: fsub DWORD PTR ds:0x48dce4
489072: faddp st(1),st
489074: add esp,0xfffffff8
489077: fstp QWORD PTR [esp]
48907a: fwait
48907b: mov eax,0xa
489080: call 0x402a1c
489085: mov DWORD PTR [esp+0x10],eax
489089: fild DWORD PTR [esp+0x10]
48908d: xor eax,eax
48908f: mov al,bl
489091: imul eax,eax,0x16
489094: fadd QWORD PTR [esi+eax*8-0xa8]
48909b: add esp,0xfffffff8
48909e: fstp QWORD PTR [esp]
4890a1: fwait
4890a2: xor ecx,ecx
4890a4: xor edx,edx
4890a6: mov al,0x2
4890a8: call 0x476a04
4890ad: dec BYTE PTR [esp]
4890b0: jne 0x48904c
4890b2: xor eax,eax
4890b4: mov al,bl
4890b6: imul eax,eax,0x16
4890b9: cmp BYTE PTR [esi+eax*8-0x41],0x1
4890be: jne 0x4890cc
4890c0: xor eax,eax
4890c2: mov al,bl
4890c4: imul eax,eax,0x16
4890c7: mov BYTE PTR [esi+eax*8-0x47],0x0
4890cc: xor eax,eax
4890ce: mov al,bl
4890d0: imul eax,eax,0x16
4890d3: cmp BYTE PTR [esi+eax*8-0x41],0x2
4890d8: jne 0x4890e6
4890da: xor eax,eax
4890dc: mov al,bl
4890de: imul eax,eax,0x16
4890e1: mov BYTE PTR [esi+eax*8-0x47],0x1
4890e6: xor eax,eax
4890e8: mov al,bl
4890ea: imul eax,eax,0x16
4890ed: cmp BYTE PTR [esi+eax*8-0x45],0x1c
4890f2: jne 0x489375
4890f8: xor eax,eax
4890fa: mov al,bl
4890fc: imul eax,eax,0x16
4890ff: cmp WORD PTR [esi+eax*8-0x3c],0x0
489105: jne 0x489119
489107: xor eax,eax
489109: mov al,bl
48910b: imul eax,eax,0x16
48910e: mov dl,BYTE PTR [esp+0x1]
489112: add dl,0x29
489115: mov BYTE PTR [esi+eax*8-0x44],dl
489119: xor eax,eax
48911b: mov al,bl
48911d: imul eax,eax,0x16
489120: cmp WORD PTR [esi+eax*8-0x3c],0x2
489126: jne 0x48913a
489128: xor eax,eax
48912a: mov al,bl
48912c: imul eax,eax,0x16
48912f: mov dl,BYTE PTR [esp+0x1]
489133: add dl,0x2a
489136: mov BYTE PTR [esi+eax*8-0x44],dl
48913a: xor eax,eax
48913c: mov al,bl
48913e: imul eax,eax,0x16
489141: cmp WORD PTR [esi+eax*8-0x3c],0x4
489147: jne 0x48915b
489149: xor eax,eax
48914b: mov al,bl
48914d: imul eax,eax,0x16
489150: mov dl,BYTE PTR [esp+0x1]
489154: add dl,0x29
489157: mov BYTE PTR [esi+eax*8-0x44],dl
48915b: xor eax,eax
48915d: mov al,bl
48915f: imul eax,eax,0x16
489162: cmp WORD PTR [esi+eax*8-0x3c],0x6
489168: jne 0x48917c
48916a: xor eax,eax
48916c: mov al,bl
48916e: imul eax,eax,0x16
489171: mov dl,BYTE PTR [esp+0x1]
489175: add dl,0x2a
489178: mov BYTE PTR [esi+eax*8-0x44],dl
48917c: xor eax,eax
48917e: mov al,bl
489180: imul eax,eax,0x16
489183: cmp WORD PTR [esi+eax*8-0x3c],0x8
489189: jne 0x48919d
48918b: xor eax,eax
48918d: mov al,bl
48918f: imul eax,eax,0x16
489192: mov dl,BYTE PTR [esp+0x1]
489196: add dl,0x29
489199: mov BYTE PTR [esi+eax*8-0x44],dl
48919d: xor eax,eax
48919f: mov al,bl
4891a1: imul eax,eax,0x16
4891a4: cmp WORD PTR [esi+eax*8-0x3c],0xa
4891aa: jne 0x4891be
4891ac: xor eax,eax
4891ae: mov al,bl
4891b0: imul eax,eax,0x16
4891b3: mov dl,BYTE PTR [esp+0x1]
4891b7: add dl,0x2a
4891ba: mov BYTE PTR [esi+eax*8-0x44],dl
4891be: xor eax,eax
4891c0: mov al,bl
4891c2: imul eax,eax,0x16
4891c5: cmp WORD PTR [esi+eax*8-0x3c],0xc
4891cb: jne 0x4891df
4891cd: xor eax,eax
4891cf: mov al,bl
4891d1: imul eax,eax,0x16
4891d4: mov dl,BYTE PTR [esp+0x1]
4891d8: add dl,0x29
4891db: mov BYTE PTR [esi+eax*8-0x44],dl
4891df: xor eax,eax
4891e1: mov al,bl
4891e3: imul eax,eax,0x16
4891e6: cmp BYTE PTR [esi+eax*8-0x43],0x1
4891eb: jne 0x489209
4891ed: xor eax,eax
4891ef: mov al,bl
4891f1: imul eax,eax,0x16
4891f4: cmp BYTE PTR [esi+eax*8-0x41],0x1
4891f9: jne 0x489209
4891fb: push 0x401c0000
489200: push 0x0
489202: mov eax,ebx
489204: call 0x47648c
489209: xor eax,eax
48920b: mov al,bl
48920d: imul eax,eax,0x16
489210: cmp BYTE PTR [esi+eax*8-0x43],0x2
489215: jne 0x489233
489217: xor eax,eax
489219: mov al,bl
48921b: imul eax,eax,0x16
48921e: cmp BYTE PTR [esi+eax*8-0x41],0x1
489223: jne 0x489233
489225: push 0xc01c0000
48922a: push 0x0
48922c: mov eax,ebx
48922e: call 0x47648c
489233: xor eax,eax
489235: mov al,bl
489237: imul eax,eax,0x16
48923a: cmp BYTE PTR [esi+eax*8-0x43],0x1
48923f: jne 0x48925d
489241: xor eax,eax
489243: mov al,bl
489245: imul eax,eax,0x16
489248: cmp BYTE PTR [esi+eax*8-0x41],0x2
48924d: jne 0x48925d
48924f: push 0x40280000
489254: push 0x0
489256: mov eax,ebx
489258: call 0x47648c
48925d: xor eax,eax
48925f: mov al,bl
489261: imul eax,eax,0x16
489264: cmp BYTE PTR [esi+eax*8-0x43],0x2
489269: jne 0x489287
48926b: xor eax,eax
48926d: mov al,bl
48926f: imul eax,eax,0x16
489272: cmp BYTE PTR [esi+eax*8-0x41],0x2
489277: jne 0x489287
489279: push 0xc0280000
48927e: push 0x0
489280: mov eax,ebx
489282: call 0x47648c
489287: xor eax,eax
489289: mov al,bl
48928b: imul eax,eax,0x16
48928e: cmp BYTE PTR [esi+eax*8-0x41],0x1
489293: jne 0x4892b8
489295: xor eax,eax
489297: mov al,bl
489299: imul eax,eax,0x16
48929c: fld QWORD PTR [esi+eax*8-0xa8]
4892a3: fsub DWORD PTR ds:0x48dd58
4892a9: xor eax,eax
4892ab: mov al,bl
4892ad: imul eax,eax,0x16
4892b0: fstp QWORD PTR [esi+eax*8-0xa8]
4892b7: fwait
4892b8: xor eax,eax
4892ba: mov al,bl
4892bc: imul eax,eax,0x16
4892bf: cmp BYTE PTR [esi+eax*8-0x41],0x2
4892c4: jne 0x4892e9
4892c6: xor eax,eax
4892c8: mov al,bl
4892ca: imul eax,eax,0x16
4892cd: fld QWORD PTR [esi+eax*8-0xa8]
4892d4: fsub DWORD PTR ds:0x48dd5c
4892da: xor eax,eax
4892dc: mov al,bl
4892de: imul eax,eax,0x16
4892e1: fstp QWORD PTR [esi+eax*8-0xa8]
4892e8: fwait
4892e9: xor eax,eax
4892eb: mov al,bl
4892ed: imul eax,eax,0x16
4892f0: mov BYTE PTR [esi+eax*8-0x47],0x1
4892f5: xor eax,eax
4892f7: mov al,bl
4892f9: imul eax,eax,0x16
4892fc: cmp BYTE PTR [esi+eax*8-0x1b],0x1
489301: jb 0x48935a
489303: xor eax,eax
489305: mov al,bl
489307: mov edx,0x3
48930c: sub edx,eax
48930e: imul eax,edx,0x16
489311: cmp BYTE PTR [esi+eax*8-0x45],0x13
489316: jne 0x48935a
489318: xor eax,eax
48931a: mov al,bl
48931c: imul eax,eax,0x16
48931f: cmp BYTE PTR [esi+eax*8-0x1a],0x13
489324: jbe 0x489339
489326: xor eax,eax
489328: mov al,bl
48932a: mov edx,0x3
48932f: sub edx,eax
489331: imul eax,edx,0x16
489334: mov BYTE PTR [esi+eax*8-0x1e],0x0
489339: xor eax,eax
48933b: mov al,bl
48933d: imul eax,eax,0x16
489340: cmp BYTE PTR [esi+eax*8-0x1a],0x11
489345: jae 0x48935a
489347: xor eax,eax
489349: mov al,bl
48934b: mov edx,0x3
489350: sub edx,eax
489352: imul eax,edx,0x16
489355: mov BYTE PTR [esi+eax*8-0x1e],0x1
48935a: xor eax,eax
48935c: mov al,bl
48935e: imul eax,eax,0x16
489361: cmp WORD PTR [esi+eax*8-0x3c],0xb
489367: jne 0x489375
489369: xor eax,eax
48936b: mov al,bl
48936d: imul eax,eax,0x16
489370: mov BYTE PTR [esi+eax*8-0x38],0xf6
489375: xor eax,eax
489377: mov al,bl
489379: imul eax,eax,0x16
48937c: cmp BYTE PTR [esi+eax*8-0x45],0x1d
489381: jne 0x48964e
489387: xor eax,eax
489389: mov al,bl
48938b: imul eax,eax,0x16
48938e: cmp WORD PTR [esi+eax*8-0x3c],0x0
489394: jne 0x4893a8
489396: xor eax,eax
489398: mov al,bl
48939a: imul eax,eax,0x16
48939d: mov dl,BYTE PTR [esp+0x1]
4893a1: add dl,0x7
4893a4: mov BYTE PTR [esi+eax*8-0x44],dl
4893a8: xor eax,eax
4893aa: mov al,bl
4893ac: imul eax,eax,0x16
4893af: cmp WORD PTR [esi+eax*8-0x3c],0x2
4893b5: jne 0x4893c9
4893b7: xor eax,eax
4893b9: mov al,bl
4893bb: imul eax,eax,0x16
4893be: mov dl,BYTE PTR [esp+0x1]
4893c2: add dl,0x9
4893c5: mov BYTE PTR [esi+eax*8-0x44],dl
4893c9: xor eax,eax
4893cb: mov al,bl
4893cd: imul eax,eax,0x16
4893d0: cmp WORD PTR [esi+eax*8-0x3c],0x4
4893d6: jne 0x4893ea
4893d8: xor eax,eax
4893da: mov al,bl
4893dc: imul eax,eax,0x16
4893df: mov dl,BYTE PTR [esp+0x1]
4893e3: add dl,0x7
4893e6: mov BYTE PTR [esi+eax*8-0x44],dl
4893ea: xor eax,eax
4893ec: mov al,bl
4893ee: imul eax,eax,0x16
4893f1: cmp WORD PTR [esi+eax*8-0x3c],0x6
4893f7: jne 0x48940b
4893f9: xor eax,eax
4893fb: mov al,bl
4893fd: imul eax,eax,0x16
489400: mov dl,BYTE PTR [esp+0x1]
489404: add dl,0x5
489407: mov BYTE PTR [esi+eax*8-0x44],dl
48940b: xor eax,eax
48940d: mov al,bl
48940f: imul eax,eax,0x16
489412: cmp WORD PTR [esi+eax*8-0x3c],0x8
489418: jne 0x48942c
48941a: xor eax,eax
48941c: mov al,bl
48941e: imul eax,eax,0x16
489421: mov dl,BYTE PTR [esp+0x1]
489425: add dl,0x9
489428: mov BYTE PTR [esi+eax*8-0x44],dl
48942c: xor eax,eax
48942e: mov al,bl
489430: imul eax,eax,0x16
489433: cmp WORD PTR [esi+eax*8-0x3c],0xa
489439: jne 0x48944d
48943b: xor eax,eax
48943d: mov al,bl
48943f: imul eax,eax,0x16
489442: mov dl,BYTE PTR [esp+0x1]
489446: add dl,0x5
489449: mov BYTE PTR [esi+eax*8-0x44],dl
48944d: xor eax,eax
48944f: mov al,bl
489451: imul eax,eax,0x16
489454: cmp WORD PTR [esi+eax*8-0x3c],0xc
48945a: jne 0x48946e
48945c: xor eax,eax
48945e: mov al,bl
489460: imul eax,eax,0x16
489463: mov dl,BYTE PTR [esp+0x1]
489467: add dl,0x9
48946a: mov BYTE PTR [esi+eax*8-0x44],dl
48946e: xor eax,eax
489470: mov al,bl
489472: imul eax,eax,0x16
489475: cmp WORD PTR [esi+eax*8-0x3c],0xe
48947b: jne 0x48948f
48947d: xor eax,eax
48947f: mov al,bl
489481: imul eax,eax,0x16
489484: mov dl,BYTE PTR [esp+0x1]
489488: add dl,0x5
48948b: mov BYTE PTR [esi+eax*8-0x44],dl
48948f: xor eax,eax
489491: mov al,bl
489493: imul eax,eax,0x16
489496: cmp WORD PTR [esi+eax*8-0x3c],0x10
48949c: jne 0x4894b0
48949e: xor eax,eax
4894a0: mov al,bl
4894a2: imul eax,eax,0x16
4894a5: mov dl,BYTE PTR [esp+0x1]
4894a9: add dl,0x9
4894ac: mov BYTE PTR [esi+eax*8-0x44],dl
4894b0: xor eax,eax
4894b2: mov al,bl
4894b4: imul eax,eax,0x16
4894b7: cmp WORD PTR [esi+eax*8-0x3c],0x12
4894bd: jne 0x4894d1
4894bf: xor eax,eax
4894c1: mov al,bl
4894c3: imul eax,eax,0x16
4894c6: mov dl,BYTE PTR [esp+0x1]
4894ca: add dl,0x7
4894cd: mov BYTE PTR [esi+eax*8-0x44],dl
4894d1: xor eax,eax
4894d3: mov al,bl
4894d5: imul eax,eax,0x16
4894d8: cmp WORD PTR [esi+eax*8-0x3c],0x14
4894de: jne 0x4894f2
4894e0: xor eax,eax
4894e2: mov al,bl
4894e4: imul eax,eax,0x16
4894e7: mov dl,BYTE PTR [esp+0x1]
4894eb: add dl,0x9
4894ee: mov BYTE PTR [esi+eax*8-0x44],dl
4894f2: xor eax,eax
4894f4: mov al,bl
4894f6: imul eax,eax,0x16
4894f9: cmp WORD PTR [esi+eax*8-0x3c],0x16
4894ff: jne 0x489513
489501: xor eax,eax
489503: mov al,bl
489505: imul eax,eax,0x16
489508: mov dl,BYTE PTR [esp+0x1]
48950c: add dl,0x7
48950f: mov BYTE PTR [esi+eax*8-0x44],dl
489513: xor eax,eax
489515: mov al,bl
489517: imul eax,eax,0x16
48951a: cmp WORD PTR [esi+eax*8-0x3c],0x18
489520: jne 0x489534
489522: xor eax,eax
489524: mov al,bl
489526: imul eax,eax,0x16
489529: mov dl,BYTE PTR [esp+0x1]
48952d: add dl,0x5
489530: mov BYTE PTR [esi+eax*8-0x44],dl
489534: xor eax,eax
489536: mov al,bl
489538: imul eax,eax,0x16
48953b: cmp WORD PTR [esi+eax*8-0x3c],0x1a
489541: jne 0x489555
489543: xor eax,eax
489545: mov al,bl
489547: imul eax,eax,0x16
48954a: mov dl,BYTE PTR [esp+0x1]
48954e: add dl,0x9
489551: mov BYTE PTR [esi+eax*8-0x44],dl
489555: xor eax,eax
489557: mov al,bl
489559: imul eax,eax,0x16
48955c: cmp WORD PTR [esi+eax*8-0x3c],0x1c
489562: jne 0x489576
489564: xor eax,eax
489566: mov al,bl
489568: imul eax,eax,0x16
48956b: mov dl,BYTE PTR [esp+0x1]
48956f: add dl,0xb
489572: mov BYTE PTR [esi+eax*8-0x44],dl
489576: xor eax,eax
489578: mov al,bl
48957a: imul eax,eax,0x16
48957d: cmp WORD PTR [esi+eax*8-0x3c],0x1b
489583: jge 0x4895bd
489585: xor eax,eax
489587: mov al,bl
489589: imul eax,eax,0x16
48958c: cmp BYTE PTR [esi+eax*8-0x43],0x1
489591: jne 0x4895a1
489593: push 0x401c0000
489598: push 0x0
48959a: mov eax,ebx
48959c: call 0x47648c
4895a1: xor eax,eax
4895a3: mov al,bl
4895a5: imul eax,eax,0x16
4895a8: cmp BYTE PTR [esi+eax*8-0x43],0x2
4895ad: jne 0x4895bd
4895af: push 0xc01c0000
4895b4: push 0x0
4895b6: mov eax,ebx
4895b8: call 0x47648c
4895bd: xor eax,eax
4895bf: mov al,bl
4895c1: imul eax,eax,0x16
4895c4: cmp WORD PTR [esi+eax*8-0x3c],0x1b
4895ca: jl 0x489604
4895cc: xor eax,eax
4895ce: mov al,bl
4895d0: imul eax,eax,0x16
4895d3: cmp BYTE PTR [esi+eax*8-0x43],0x1
4895d8: jne 0x4895e8
4895da: push 0x40280000
4895df: push 0x0
4895e1: mov eax,ebx
4895e3: call 0x47648c
4895e8: xor eax,eax
4895ea: mov al,bl
4895ec: imul eax,eax,0x16
4895ef: cmp BYTE PTR [esi+eax*8-0x43],0x2
4895f4: jne 0x489604
4895f6: push 0xc0280000
4895fb: push 0x0
4895fd: mov eax,ebx
4895ff: call 0x47648c
489604: xor eax,eax
489606: mov al,bl
489608: imul eax,eax,0x16
48960b: cmp BYTE PTR [esi+eax*8-0x1b],0x3
489610: jb 0x489633
489612: xor eax,eax
489614: mov al,bl
489616: imul eax,eax,0x16
489619: cmp BYTE PTR [esi+eax*8-0x1a],0x12
48961e: jb 0x489633
489620: xor eax,eax
489622: mov al,bl
489624: mov edx,0x3
489629: sub edx,eax
48962b: imul eax,edx,0x16
48962e: mov BYTE PTR [esi+eax*8-0x1e],0x0
489633: xor eax,eax
489635: mov al,bl
489637: imul eax,eax,0x16
48963a: cmp WORD PTR [esi+eax*8-0x3c],0x1c
489640: jl 0x48964e
489642: xor eax,eax
489644: mov al,bl
489646: imul eax,eax,0x16
489649: mov BYTE PTR [esi+eax*8-0x47],0x1
48964e: push 0x1e
489650: push 0x13
489652: push 0xaa
489657: xor edx,edx
489659: mov dl,BYTE PTR [esp+0xd]
48965d: inc edx
48965e: xor eax,eax
489660: mov al,bl
489662: mov ecx,0xfffffff2
489667: call 0x476870
48966c: push 0x1e
48966e: push 0x13
489670: push 0xaa
489675: xor edx,edx
489677: mov dl,BYTE PTR [esp+0xd]
48967b: add edx,0x2
48967e: xor eax,eax
489680: mov al,bl
489682: mov ecx,0xfffffff2
489687: call 0x476870
48968c: push 0x1e
48968e: push 0x13
489690: push 0xaa
489695: xor edx,edx
489697: mov dl,BYTE PTR [esp+0xd]
48969b: add edx,0x3
48969e: xor eax,eax
4896a0: mov al,bl
4896a2: mov ecx,0xfffffff2
4896a7: call 0x476870
4896ac: push 0x1e
4896ae: push 0x13
4896b0: push 0xaa
4896b5: xor edx,edx
4896b7: mov dl,BYTE PTR [esp+0xd]
4896bb: add edx,0x4
4896be: xor eax,eax
4896c0: mov al,bl
4896c2: mov ecx,0xfffffff2
4896c7: call 0x476870
4896cc: push 0x1e
4896ce: push 0x13
4896d0: push 0xaa
4896d5: xor edx,edx
4896d7: mov dl,BYTE PTR [esp+0xd]
4896db: add edx,0x6
4896de: xor eax,eax
4896e0: mov al,bl
4896e2: mov ecx,0xfffffff2
4896e7: call 0x476870
4896ec: push 0x1e
4896ee: push 0x13
4896f0: push 0xaa
4896f5: xor edx,edx
4896f7: mov dl,BYTE PTR [esp+0xd]
4896fb: add edx,0x8
4896fe: xor eax,eax
489700: mov al,bl
489702: mov ecx,0xfffffff2
489707: call 0x476870
48970c: push 0x1e
48970e: push 0x13
489710: push 0xaa
489715: xor edx,edx
489717: mov dl,BYTE PTR [esp+0xd]
48971b: add edx,0xa
48971e: xor eax,eax
489720: mov al,bl
489722: mov ecx,0xfffffff2
489727: call 0x476870
48972c: push 0x44
48972e: push 0x18
489730: push 0xaa
489735: xor edx,edx
489737: mov dl,BYTE PTR [esp+0xd]
48973b: add edx,0xc
48973e: xor eax,eax
489740: mov al,bl
489742: mov ecx,0xfffffff7
489747: call 0x476870
48974c: push 0x1c
48974e: push 0x13
489750: push 0x8c
489755: xor edx,edx
489757: mov dl,BYTE PTR [esp+0xd]
48975b: add edx,0x15
48975e: xor eax,eax
489760: mov al,bl
489762: mov ecx,0xfffffff1
489767: call 0x476870
48976c: push 0x4e
48976e: push 0x24
489770: push 0x70
489772: xor edx,edx
489774: mov dl,BYTE PTR [esp+0xd]
489778: add edx,0x1c
48977b: xor eax,eax
48977d: mov al,bl
48977f: mov ecx,0xffffffe4
489784: call 0x476870
489789: push 0x76
48978b: push 0x24
48978d: push 0x98
489792: xor edx,edx
489794: mov dl,BYTE PTR [esp+0xd]
489798: add edx,0x1d
48979b: xor eax,eax
48979d: mov al,bl
48979f: mov ecx,0xffffffe4
4897a4: call 0x476870
4897a9: push 0x1e
4897ab: push 0x13
4897ad: push 0xaa
4897b2: xor edx,edx
4897b4: mov dl,BYTE PTR [esp+0xd]
4897b8: add edx,0x1f
4897bb: xor eax,eax
4897bd: mov al,bl
4897bf: mov ecx,0xfffffff2
4897c4: call 0x476870
4897c9: push 0x44
4897cb: push 0x18
4897cd: push 0xaa
4897d2: xor edx,edx
4897d4: mov dl,BYTE PTR [esp+0xd]
4897d8: add edx,0x20
4897db: xor eax,eax
4897dd: mov al,bl
4897df: mov ecx,0xfffffff7
4897e4: call 0x476870
4897e9: push 0x1e
4897eb: push 0x13
4897ed: push 0xaa
4897f2: xor edx,edx
4897f4: mov dl,BYTE PTR [esp+0xd]
4897f8: add edx,0x22
4897fb: xor eax,eax
4897fd: mov al,bl
4897ff: mov ecx,0xfffffff2
489804: call 0x476870
489809: push 0x4b
48980b: push 0x19
48980d: push 0xaa
489812: xor edx,edx
489814: mov dl,BYTE PTR [esp+0xd]
489818: add edx,0x27
48981b: xor eax,eax
48981d: mov al,bl
48981f: mov ecx,0xfffffff2
489824: call 0x476870
489829: push 0xa
48982b: push 0x13
48982d: push 0x96
489832: xor edx,edx
489834: mov dl,BYTE PTR [esp+0xd]
489838: add edx,0x29
48983b: xor eax,eax
48983d: mov al,bl
48983f: mov ecx,0xfffffff2
489844: call 0x476870
489849: push 0xa
48984b: push 0x3a
48984d: push 0x37
48984f: push 0x44
489851: push 0x1
489853: push 0x1
489855: push 0x7
489857: push 0x0
489859: xor eax,eax
48985b: mov al,bl
48985d: mov ecx,0x2
489862: mov edx,0x3
489867: call 0x4768f8
48986c: push 0x14
48986e: push 0x3c
489870: push 0x44
489872: push 0x55
489874: push 0x1
489876: push 0x1
489878: push 0x7
48987a: push 0x0
48987c: xor eax,eax
48987e: mov al,bl
489880: mov ecx,0x2
489885: mov edx,0x4
48988a: call 0x4768f8
48988f: push 0x14
489891: push 0x3a
489893: push 0x49
489895: push 0x46
489897: push 0x1
489899: push 0x2
48989b: push 0xe
48989d: push 0x0
48989f: xor eax,eax
4898a1: mov al,bl
4898a3: mov ecx,0x5
4898a8: mov edx,0x5
4898ad: call 0x4768f8
4898b2: push 0x14
4898b4: push 0x30
4898b6: push 0x55
4898b8: push 0x55
4898ba: push 0x1
4898bc: push 0x2
4898be: push 0xe
4898c0: push 0x0
4898c2: xor eax,eax
4898c4: mov al,bl
4898c6: mov ecx,0x5
4898cb: mov edx,0x6
4898d0: call 0x4768f8
4898d5: push 0xa
4898d7: push 0x58
4898d9: push 0x3a
4898db: push 0x66
4898dd: push 0x1
4898df: push 0x1
4898e1: push 0x7
4898e3: push 0x0
4898e5: xor eax,eax
4898e7: mov al,bl
4898e9: mov ecx,0x2
4898ee: mov edx,0x8
4898f3: call 0x4768f8
4898f8: push 0xa
4898fa: push 0x87
4898ff: push 0x41
489901: push 0x9c
489906: push 0x1
489908: push 0x1
48990a: push 0x7
48990c: push 0x0
48990e: xor eax,eax
489910: mov al,bl
489912: mov ecx,0x2
489917: mov edx,0x9
48991c: call 0x4768f8
489921: push 0xa
489923: push 0x59
489925: push 0x44
489927: push 0x66
489929: push 0x1
48992b: push 0x2
48992d: push 0xe
48992f: push 0x0
489931: xor eax,eax
489933: mov al,bl
489935: mov ecx,0x5
48993a: mov edx,0xa
48993f: call 0x4768f8
489944: push 0xa
489946: push 0x7e
489948: push 0x49
48994a: push 0x93
48994f: push 0x1
489951: push 0x2
489953: push 0xe
489955: push 0x0
489957: xor eax,eax
489959: mov al,bl
48995b: mov ecx,0x5
489960: mov edx,0xb
489965: call 0x4768f8
48996a: push 0x14
48996c: push 0x46
48996e: push 0x32
489970: push 0x73
489972: push 0x1
489974: push 0x1
489976: push 0x7
489978: push 0x0
48997a: xor eax,eax
48997c: mov al,bl
48997e: mov ecx,0x2
489983: mov edx,0xd
489988: call 0x4768f8
48998d: push 0xa
48998f: push 0x55
489991: push 0x44
489993: push 0x67
489995: push 0x1
489997: push 0x1
489999: push 0x7
48999b: push 0x0
48999d: xor eax,eax
48999f: mov al,bl
4899a1: mov ecx,0x2
4899a6: mov edx,0xe
4899ab: call 0x4768f8
4899b0: push 0x14
4899b2: push 0x46
4899b4: push 0x32
4899b6: push 0x73
4899b8: push 0x1
4899ba: push 0x2
4899bc: push 0xe
4899be: push 0x0
4899c0: xor eax,eax
4899c2: mov al,bl
4899c4: mov ecx,0x5
4899c9: mov edx,0xf
4899ce: call 0x4768f8
4899d3: push 0xa
4899d5: push 0x55
4899d7: push 0x44
4899d9: push 0x67
4899db: push 0x1
4899dd: push 0x2
4899df: push 0xe
4899e1: push 0x0
4899e3: xor eax,eax
4899e5: mov al,bl
4899e7: mov ecx,0x5
4899ec: mov edx,0x10
4899f1: call 0x4768f8
4899f6: xor eax,eax
4899f8: mov al,bl
4899fa: imul eax,eax,0x16
4899fd: cmp BYTE PTR [esi+eax*8-0x41],0x1
489a02: jne 0x489a2d
489a04: push 0xa
489a06: push 0x82
489a0b: push 0x52
489a0d: push 0x9e
489a12: push 0x1
489a14: push 0x0
489a16: push 0x12
489a18: push 0x3
489a1a: xor eax,eax
489a1c: mov al,bl
489a1e: mov ecx,0x1
489a23: mov edx,0x1b
489a28: call 0x4768f8
489a2d: xor eax,eax
489a2f: mov al,bl
489a31: imul eax,eax,0x16
489a34: cmp BYTE PTR [esi+eax*8-0x41],0x2
489a39: jne 0x489a5e
489a3b: push 0xa
489a3d: push 0x19
489a3f: push 0x46
489a41: push 0x37
489a43: push 0x1
489a45: push 0x0
489a47: push 0x12
489a49: push 0x3
489a4b: xor eax,eax
489a4d: mov al,bl
489a4f: mov ecx,0x1
489a54: mov edx,0x1b
489a59: call 0x4768f8
489a5e: push 0xa
489a60: push 0x41
489a62: push 0x4b
489a64: push 0x53
489a66: push 0x1
489a68: push 0x0
489a6a: push 0x8
489a6c: push 0x2
489a6e: xor eax,eax
489a70: mov al,bl
489a72: xor ecx,ecx
489a74: mov edx,0x1c
489a79: call 0x4768f8
489a7e: push 0xffffffc4
489a80: push 0x41
489a82: push 0xfffffff6
489a84: push 0x53
489a86: push 0x1
489a88: push 0x0
489a8a: push 0x8
489a8c: push 0x2
489a8e: xor eax,eax
489a90: mov al,bl
489a92: mov ecx,0x2
489a97: mov edx,0x1c
489a9c: call 0x4768f8
489aa1: push 0xa
489aa3: push 0x41
489aa5: push 0x4b
489aa7: push 0x53
489aa9: push 0x1
489aab: push 0x0
489aad: push 0x8
489aaf: push 0x2
489ab1: xor eax,eax
489ab3: mov al,bl
489ab5: mov ecx,0x4
489aba: mov edx,0x1c
489abf: call 0x4768f8
489ac4: push 0xffffffc4
489ac6: push 0x41
489ac8: push 0xfffffff6
489aca: push 0x53
489acc: push 0x1
489ace: push 0x0
489ad0: push 0x8
489ad2: push 0x2
489ad4: xor eax,eax
489ad6: mov al,bl
489ad8: mov ecx,0x6
489add: mov edx,0x1c
489ae2: call 0x4768f8
489ae7: push 0xa
489ae9: push 0x41
489aeb: push 0x4b
489aed: push 0x53
489aef: push 0x1
489af1: push 0x0
489af3: push 0x8
489af5: push 0x2
489af7: xor eax,eax
489af9: mov al,bl
489afb: mov ecx,0x8
489b00: mov edx,0x1c
489b05: call 0x4768f8
489b0a: push 0xa
489b0c: push 0x28
489b0e: push 0x46
489b10: push 0x5a
489b12: push 0x1
489b14: push 0x2
489b16: push 0x2
489b18: push 0x2
489b1a: xor eax,eax
489b1c: mov al,bl
489b1e: xor ecx,ecx
489b20: mov edx,0x1d
489b25: call 0x4768f8
489b2a: push 0xa
489b2c: push 0x28
489b2e: push 0x46
489b30: push 0x5a
489b32: push 0x1
489b34: push 0x2
489b36: push 0x1
489b38: push 0x1
489b3a: xor eax,eax
489b3c: mov al,bl
489b3e: mov ecx,0x2
489b43: mov edx,0x1d
489b48: call 0x4768f8
489b4d: push 0xa
489b4f: push 0x28
489b51: push 0x46
489b53: push 0x5a
489b55: push 0x1
489b57: push 0x1
489b59: push 0x1
489b5b: push 0x0
489b5d: xor eax,eax
489b5f: mov al,bl
489b61: mov ecx,0x4
489b66: mov edx,0x1d
489b6b: call 0x4768f8
489b70: push 0xa
489b72: push 0x28
489b74: push 0x46
489b76: push 0x5a
489b78: push 0x1
489b7a: push 0x2
489b7c: push 0x1
489b7e: push 0x1
489b80: xor eax,eax
489b82: mov al,bl
489b84: mov ecx,0x6
489b89: mov edx,0x1d
489b8e: call 0x4768f8
489b93: push 0xa
489b95: push 0x28
489b97: push 0x46
489b99: push 0x5a
489b9b: push 0x1
489b9d: push 0x1
489b9f: push 0x1
489ba1: push 0x0
489ba3: xor eax,eax
489ba5: mov al,bl
489ba7: mov ecx,0x8
489bac: mov edx,0x1d
489bb1: call 0x4768f8
489bb6: push 0xa
489bb8: push 0x28
489bba: push 0x46
489bbc: push 0x5a
489bbe: push 0x1
489bc0: push 0x1
489bc2: push 0x2
489bc4: push 0x1
489bc6: xor eax,eax
489bc8: mov al,bl
489bca: mov ecx,0xa
489bcf: mov edx,0x1d
489bd4: call 0x4768f8
489bd9: push 0xa
489bdb: push 0x28
489bdd: push 0x46
489bdf: push 0x5a
489be1: push 0x1
489be3: push 0x2
489be5: push 0x4
489be7: push 0x2
489be9: xor eax,eax
489beb: mov al,bl
489bed: mov ecx,0xc
489bf2: mov edx,0x1d
489bf7: call 0x4768f8
489bfc: push 0xa
489bfe: push 0x28
489c00: push 0x46
489c02: push 0x5a
489c04: push 0x1
489c06: push 0x2
489c08: push 0x3
489c0a: push 0x1
489c0c: xor eax,eax
489c0e: mov al,bl
489c10: mov ecx,0xe
489c15: mov edx,0x1d
489c1a: call 0x4768f8
489c1f: push 0xa
489c21: push 0x28
489c23: push 0x46
489c25: push 0x5a
489c27: push 0x1
489c29: push 0x1
489c2b: push 0x3
489c2d: push 0x1
489c2f: xor eax,eax
489c31: mov al,bl
489c33: mov ecx,0x10
489c38: mov edx,0x1d
489c3d: call 0x4768f8
489c42: push 0xa
489c44: push 0x28
489c46: push 0x46
489c48: push 0x5a
489c4a: push 0x1
489c4c: push 0x1
489c4e: push 0x6
489c50: push 0x0
489c52: xor eax,eax
489c54: mov al,bl
489c56: mov ecx,0x12
489c5b: mov edx,0x1d
489c60: call 0x4768f8
489c65: push 0xa
489c67: push 0x28
489c69: push 0x46
489c6b: push 0x5a
489c6d: push 0x1
489c6f: push 0x2
489c71: push 0x3
489c73: push 0x1
489c75: xor eax,eax
489c77: mov al,bl
489c79: mov ecx,0x14
489c7e: mov edx,0x1d
489c83: call 0x4768f8
489c88: push 0xa
489c8a: push 0x28
489c8c: push 0x46
489c8e: push 0x5a
489c90: push 0x1
489c92: push 0x1
489c94: push 0x4
489c96: push 0x0
489c98: xor eax,eax
489c9a: mov al,bl
489c9c: mov ecx,0x16
489ca1: mov edx,0x1d
489ca6: call 0x4768f8
489cab: push 0xa
489cad: push 0x28
489caf: push 0x46
489cb1: push 0x5a
489cb3: push 0x1
489cb5: push 0x2
489cb7: push 0x3
489cb9: push 0x1
489cbb: xor eax,eax
489cbd: mov al,bl
489cbf: mov ecx,0x18
489cc4: mov edx,0x1d
489cc9: call 0x4768f8
489cce: push 0xa
489cd0: push 0x28
489cd2: push 0x46
489cd4: push 0x5a
489cd6: push 0x1
489cd8: push 0x1
489cda: push 0x5
489cdc: push 0x1
489cde: xor eax,eax
489ce0: mov al,bl
489ce2: mov ecx,0x1a
489ce7: mov edx,0x1d
489cec: call 0x4768f8
489cf1: push 0xa
489cf3: push 0x28
489cf5: push 0x46
489cf7: push 0x5a
489cf9: push 0x1
489cfb: push 0x2
489cfd: push 0x6
489cff: push 0x2
489d01: xor eax,eax
489d03: mov al,bl
489d05: mov ecx,0x1c
489d0a: mov edx,0x1d
489d0f: call 0x4768f8
489d14: xor eax,eax
489d16: mov al,bl
489d18: imul eax,eax,0x16
489d1b: cmp BYTE PTR [esi+eax*8-0xa0],0xc
489d23: jne 0x48aebf
489d29: xor eax,eax
489d2b: mov al,bl
489d2d: imul eax,eax,0x16
489d30: cmp BYTE PTR [esi+eax*8-0x45],0x17
489d35: jne 0x489f25
489d3b: xor eax,eax
489d3d: mov al,bl
489d3f: imul eax,eax,0x16
489d42: fild WORD PTR [esi+eax*8-0x3c]
489d46: fdiv DWORD PTR ds:0x48dd34
489d4c: call 0x40287c
489d51: xor eax,eax
489d53: mov al,bl
489d55: imul eax,eax,0x16
489d58: fild WORD PTR [esi+eax*8-0x3c]
489d5c: fdiv DWORD PTR ds:0x48dd34
489d62: fcompp
489d64: fnstsw ax
489d66: sahf
489d67: jne 0x489d7d
489d69: xor eax,eax
489d6b: mov al,bl
489d6d: imul eax,eax,0x16
489d70: mov dl,BYTE PTR [esp+0x1]
489d74: add dl,0x21
489d77: mov BYTE PTR [esi+eax*8-0x44],dl
489d7b: jmp 0x489d8f
489d7d: xor eax,eax
489d7f: mov al,bl
489d81: imul eax,eax,0x16
489d84: mov dl,BYTE PTR [esp+0x1]
489d88: add dl,0x22
489d8b: mov BYTE PTR [esi+eax*8-0x44],dl
489d8f: xor eax,eax
489d91: mov al,bl
489d93: imul eax,eax,0x16
489d96: cmp BYTE PTR [esi+eax*8-0x43],0x1
489d9b: jne 0x489dc0
489d9d: xor eax,eax
489d9f: mov al,bl
489da1: imul eax,eax,0x16
489da4: fld QWORD PTR [esi+eax*8-0xb0]
489dab: fadd DWORD PTR ds:0x48dd04
489db1: xor eax,eax
489db3: mov al,bl
489db5: imul eax,eax,0x16
489db8: fstp QWORD PTR [esi+eax*8-0xb0]
489dbf: fwait
489dc0: xor eax,eax
489dc2: mov al,bl
489dc4: imul eax,eax,0x16
489dc7: cmp BYTE PTR [esi+eax*8-0x43],0x2
489dcc: jne 0x489df1
489dce: xor eax,eax
489dd0: mov al,bl
489dd2: imul eax,eax,0x16
489dd5: fld QWORD PTR [esi+eax*8-0xb0]
489ddc: fsub DWORD PTR ds:0x48dd04
489de2: xor eax,eax
489de4: mov al,bl
489de6: imul eax,eax,0x16
489de9: fstp QWORD PTR [esi+eax*8-0xb0]
489df0: fwait
489df1: mov eax,ds:0x4b11b4
489df6: fild DWORD PTR [eax]
489df8: xor eax,eax
489dfa: mov al,bl
489dfc: imul eax,eax,0x16
489dff: fsubr QWORD PTR [esi+eax*8-0xb0]
489e06: fcomp DWORD PTR ds:0x48dcfc
489e0c: fnstsw ax
489e0e: sahf
489e0f: ja 0x489e1d
489e11: xor eax,eax
489e13: mov al,bl
489e15: imul eax,eax,0x16
489e18: mov BYTE PTR [esi+eax*8-0x43],0x1
489e1d: mov eax,ds:0x4b11b4
489e22: fild DWORD PTR [eax]
489e24: xor eax,eax
489e26: mov al,bl
489e28: imul eax,eax,0x16
489e2b: fsubr QWORD PTR [esi+eax*8-0xb0]
489e32: fcomp DWORD PTR ds:0x48dd60
489e38: fnstsw ax
489e3a: sahf
489e3b: jb 0x489e49
489e3d: xor eax,eax
489e3f: mov al,bl
489e41: imul eax,eax,0x16
489e44: mov BYTE PTR [esi+eax*8-0x43],0x2
489e49: xor eax,eax
489e4b: mov al,bl
489e4d: imul eax,eax,0x16
489e50: fild WORD PTR [esi+eax*8-0x3c]
489e54: fdiv DWORD PTR ds:0x48dd5c
489e5a: call 0x40287c
489e5f: xor eax,eax
489e61: mov al,bl
489e63: imul eax,eax,0x16
489e66: fild WORD PTR [esi+eax*8-0x3c]
489e6a: fdiv DWORD PTR ds:0x48dd5c
489e70: fcompp
489e72: fnstsw ax
489e74: sahf
489e75: jne 0x489ebb
489e77: mov eax,0x2
489e7c: call 0x402a1c
489e81: test eax,eax
489e83: jne 0x489ebb
489e85: xor eax,eax
489e87: mov al,bl
489e89: imul eax,eax,0x16
489e8c: cmp BYTE PTR [esi+eax*8-0x43],0x1
489e91: jne 0x489ea1
489e93: xor eax,eax
489e95: mov al,bl
489e97: imul eax,eax,0x16
489e9a: mov BYTE PTR [esi+eax*8-0x43],0x2
489e9f: jmp 0x489ebb
489ea1: xor eax,eax
489ea3: mov al,bl
489ea5: imul eax,eax,0x16
489ea8: cmp BYTE PTR [esi+eax*8-0x43],0x2
489ead: jne 0x489ebb
489eaf: xor eax,eax
489eb1: mov al,bl
489eb3: imul eax,eax,0x16
489eb6: mov BYTE PTR [esi+eax*8-0x43],0x1
489ebb: mov BYTE PTR [esp],0x5
489ebf: mov eax,0x28
489ec4: call 0x402a1c
489ec9: mov DWORD PTR [esp+0x4],eax
489ecd: fild DWORD PTR [esp+0x4]
489ed1: xor eax,eax
489ed3: mov al,bl
489ed5: imul eax,eax,0x16
489ed8: fld QWORD PTR [esi+eax*8-0xb0]
489edf: fsub DWORD PTR ds:0x48dd14
489ee5: faddp st(1),st
489ee7: add esp,0xfffffff8
489eea: fstp QWORD PTR [esp]
489eed: fwait
489eee: mov eax,0xa
489ef3: call 0x402a1c
489ef8: mov DWORD PTR [esp+0x10],eax
489efc: fild DWORD PTR [esp+0x10]
489f00: xor eax,eax
489f02: mov al,bl
489f04: imul eax,eax,0x16
489f07: fadd QWORD PTR [esi+eax*8-0xa8]
489f0e: add esp,0xfffffff8
489f11: fstp QWORD PTR [esp]
489f14: fwait
489f15: xor ecx,ecx
489f17: xor edx,edx
489f19: mov al,0x2
489f1b: call 0x476a04
489f20: dec BYTE PTR [esp]
489f23: jne 0x489ebf
489f25: xor eax,eax
489f27: mov al,bl
489f29: imul eax,eax,0x16
489f2c: cmp BYTE PTR [esi+eax*8-0x45],0x18
489f31: jne 0x489f54
489f33: xor eax,eax
489f35: mov al,bl
489f37: imul eax,eax,0x16
489f3a: cmp WORD PTR [esi+eax*8-0x3c],0x0
489f40: jne 0x489f54
489f42: xor eax,eax
489f44: mov al,bl
489f46: imul eax,eax,0x16
489f49: mov dl,BYTE PTR [esp+0x1]
489f4d: add dl,0xc
489f50: mov BYTE PTR [esi+eax*8-0x44],dl
489f54: xor eax,eax
489f56: mov al,bl
489f58: imul eax,eax,0x16
489f5b: cmp BYTE PTR [esi+eax*8-0x45],0x18
489f60: jne 0x489f83
489f62: xor eax,eax
489f64: mov al,bl
489f66: imul eax,eax,0x16
489f69: cmp WORD PTR [esi+eax*8-0x3c],0x2
489f6f: jne 0x489f83
489f71: xor eax,eax
489f73: mov al,bl
489f75: imul eax,eax,0x16
489f78: mov dl,BYTE PTR [esp+0x1]
489f7c: add dl,0x1e
489f7f: mov BYTE PTR [esi+eax*8-0x44],dl
489f83: xor eax,eax
489f85: mov al,bl
489f87: imul eax,eax,0x16
489f8a: cmp BYTE PTR [esi+eax*8-0x45],0x19
489f8f: jne 0x48a184
489f95: xor eax,eax
489f97: mov al,bl
489f99: imul eax,eax,0x16
489f9c: cmp WORD PTR [esi+eax*8-0x3c],0x0
489fa2: jne 0x489fb6
489fa4: xor eax,eax
489fa6: mov al,bl
489fa8: imul eax,eax,0x16
489fab: mov dl,BYTE PTR [esp+0x1]
489faf: add dl,0x23
489fb2: mov BYTE PTR [esi+eax*8-0x44],dl
489fb6: xor eax,eax
489fb8: mov al,bl
489fba: imul eax,eax,0x16
489fbd: cmp WORD PTR [esi+eax*8-0x3c],0x5
489fc3: jne 0x489fd7
489fc5: xor eax,eax
489fc7: mov al,bl
489fc9: imul eax,eax,0x16
489fcc: mov dl,BYTE PTR [esp+0x1]
489fd0: add dl,0x24
489fd3: mov BYTE PTR [esi+eax*8-0x44],dl
489fd7: xor eax,eax
489fd9: mov al,bl
489fdb: imul eax,eax,0x16
489fde: cmp WORD PTR [esi+eax*8-0x3c],0xa
489fe4: jne 0x48a184
489fea: xor eax,eax
489fec: mov al,bl
489fee: imul eax,eax,0x16
489ff1: mov dl,BYTE PTR [esp+0x1]
489ff5: add dl,0x25
489ff8: mov BYTE PTR [esi+eax*8-0x44],dl
489ffc: xor eax,eax
489ffe: mov al,bl
48a000: imul eax,eax,0x16
48a003: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a008: jne 0x48a05c
48a00a: xor eax,eax
48a00c: mov al,bl
48a00e: imul eax,eax,0x16
48a011: cmp BYTE PTR [esi+eax*8-0x41],0x1
48a016: jne 0x48a05c
48a018: xor eax,eax
48a01a: mov al,bl
48a01c: imul eax,eax,0x16
48a01f: fld QWORD PTR [esi+eax*8-0xb0]
48a026: fadd DWORD PTR ds:0x48dd44
48a02c: add esp,0xfffffff8
48a02f: fstp QWORD PTR [esp]
48a032: fwait
48a033: xor eax,eax
48a035: mov al,bl
48a037: imul eax,eax,0x16
48a03a: fld QWORD PTR [esi+eax*8-0xa8]
48a041: fsub DWORD PTR ds:0x48dd64
48a047: add esp,0xfffffff8
48a04a: fstp QWORD PTR [esp]
48a04d: fwait
48a04e: mov ecx,ebx
48a050: mov edx,0x48dcd4
48a055: mov al,0x9
48a057: call 0x476a04
48a05c: xor eax,eax
48a05e: mov al,bl
48a060: imul eax,eax,0x16
48a063: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a068: jne 0x48a0bc
48a06a: xor eax,eax
48a06c: mov al,bl
48a06e: imul eax,eax,0x16
48a071: cmp BYTE PTR [esi+eax*8-0x41],0x1
48a076: jne 0x48a0bc
48a078: xor eax,eax
48a07a: mov al,bl
48a07c: imul eax,eax,0x16
48a07f: fld QWORD PTR [esi+eax*8-0xb0]
48a086: fsub DWORD PTR ds:0x48dd44
48a08c: add esp,0xfffffff8
48a08f: fstp QWORD PTR [esp]
48a092: fwait
48a093: xor eax,eax
48a095: mov al,bl
48a097: imul eax,eax,0x16
48a09a: fld QWORD PTR [esi+eax*8-0xa8]
48a0a1: fsub DWORD PTR ds:0x48dd64
48a0a7: add esp,0xfffffff8
48a0aa: fstp QWORD PTR [esp]
48a0ad: fwait
48a0ae: mov ecx,ebx
48a0b0: mov edx,0x48dcd4
48a0b5: mov al,0x9
48a0b7: call 0x476a04
48a0bc: xor eax,eax
48a0be: mov al,bl
48a0c0: imul eax,eax,0x16
48a0c3: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a0c8: jne 0x48a11c
48a0ca: xor eax,eax
48a0cc: mov al,bl
48a0ce: imul eax,eax,0x16
48a0d1: cmp BYTE PTR [esi+eax*8-0x41],0x2
48a0d6: jne 0x48a11c
48a0d8: xor eax,eax
48a0da: mov al,bl
48a0dc: imul eax,eax,0x16
48a0df: fld QWORD PTR [esi+eax*8-0xb0]
48a0e6: fadd DWORD PTR ds:0x48dd44
48a0ec: add esp,0xfffffff8
48a0ef: fstp QWORD PTR [esp]
48a0f2: fwait
48a0f3: xor eax,eax
48a0f5: mov al,bl
48a0f7: imul eax,eax,0x16
48a0fa: fld QWORD PTR [esi+eax*8-0xa8]
48a101: fsub DWORD PTR ds:0x48dd64
48a107: add esp,0xfffffff8
48a10a: fstp QWORD PTR [esp]
48a10d: fwait
48a10e: mov ecx,ebx
48a110: mov edx,0x48dce0
48a115: mov al,0x9
48a117: call 0x476a04
48a11c: xor eax,eax
48a11e: mov al,bl
48a120: imul eax,eax,0x16
48a123: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a128: jne 0x48a17c
48a12a: xor eax,eax
48a12c: mov al,bl
48a12e: imul eax,eax,0x16
48a131: cmp BYTE PTR [esi+eax*8-0x41],0x2
48a136: jne 0x48a17c
48a138: xor eax,eax
48a13a: mov al,bl
48a13c: imul eax,eax,0x16
48a13f: fld QWORD PTR [esi+eax*8-0xb0]
48a146: fsub DWORD PTR ds:0x48dd44
48a14c: add esp,0xfffffff8
48a14f: fstp QWORD PTR [esp]
48a152: fwait
48a153: xor eax,eax
48a155: mov al,bl
48a157: imul eax,eax,0x16
48a15a: fld QWORD PTR [esi+eax*8-0xa8]
48a161: fsub DWORD PTR ds:0x48dd64
48a167: add esp,0xfffffff8
48a16a: fstp QWORD PTR [esp]
48a16d: fwait
48a16e: mov ecx,ebx
48a170: mov edx,0x48dce0
48a175: mov al,0x9
48a177: call 0x476a04
48a17c: mov eax,ds:0x4b1098
48a181: mov BYTE PTR [eax],0x35
48a184: xor eax,eax
48a186: mov al,bl
48a188: imul eax,eax,0x16
48a18b: cmp BYTE PTR [esi+eax*8-0x45],0x1a
48a190: jne 0x48a364
48a196: xor eax,eax
48a198: mov al,bl
48a19a: imul eax,eax,0x16
48a19d: cmp WORD PTR [esi+eax*8-0x3c],0x0
48a1a3: jne 0x48a1bf
48a1a5: xor eax,eax
48a1a7: mov al,bl
48a1a9: imul eax,eax,0x16
48a1ac: mov dl,BYTE PTR [esp+0x1]
48a1b0: add dl,0x26
48a1b3: mov BYTE PTR [esi+eax*8-0x44],dl
48a1b7: mov eax,ds:0x4b1098
48a1bc: mov BYTE PTR [eax],0x36
48a1bf: xor eax,eax
48a1c1: mov al,bl
48a1c3: imul eax,eax,0x16
48a1c6: cmp WORD PTR [esi+eax*8-0x3c],0x3
48a1cc: jne 0x48a1e0
48a1ce: xor eax,eax
48a1d0: mov al,bl
48a1d2: imul eax,eax,0x16
48a1d5: mov dl,BYTE PTR [esp+0x1]
48a1d9: add dl,0x27
48a1dc: mov BYTE PTR [esi+eax*8-0x44],dl
48a1e0: xor eax,eax
48a1e2: mov al,bl
48a1e4: imul eax,eax,0x16
48a1e7: cmp WORD PTR [esi+eax*8-0x3c],0x8
48a1ed: jne 0x48a1fd
48a1ef: xor eax,eax
48a1f1: mov al,bl
48a1f3: imul eax,eax,0x16
48a1f6: cmp BYTE PTR [esi+eax*8-0x41],0x1
48a1fb: je 0x48a21a
48a1fd: xor eax,eax
48a1ff: mov al,bl
48a201: imul eax,eax,0x16
48a204: cmp WORD PTR [esi+eax*8-0x3c],0xa
48a20a: jne 0x48a244
48a20c: xor eax,eax
48a20e: mov al,bl
48a210: imul eax,eax,0x16
48a213: cmp BYTE PTR [esi+eax*8-0x41],0x2
48a218: jne 0x48a244
48a21a: xor eax,eax
48a21c: mov al,bl
48a21e: imul eax,eax,0x16
48a221: mov dl,BYTE PTR [esp+0x1]
48a225: add dl,0x28
48a228: mov BYTE PTR [esi+eax*8-0x44],dl
48a22c: xor eax,eax
48a22e: mov al,bl
48a230: imul eax,eax,0x16
48a233: mov BYTE PTR [esi+eax*8-0x46],0x1
48a238: xor eax,eax
48a23a: mov al,bl
48a23c: imul eax,eax,0x16
48a23f: mov BYTE PTR [esi+eax*8-0x38],0xfa
48a244: xor eax,eax
48a246: mov al,bl
48a248: imul eax,eax,0x16
48a24b: movzx eax,BYTE PTR [esi+eax*8-0x44]
48a250: xor edx,edx
48a252: mov dl,BYTE PTR [esp+0x1]
48a256: add edx,0x27
48a259: cmp eax,edx
48a25b: jne 0x48a333
48a261: xor eax,eax
48a263: mov al,bl
48a265: imul eax,eax,0x16
48a268: cmp BYTE PTR [esi+eax*8-0x41],0x1
48a26d: jne 0x48a2ca
48a26f: xor eax,eax
48a271: mov al,bl
48a273: imul eax,eax,0x16
48a276: fld QWORD PTR [esi+eax*8-0xa8]
48a27d: fsub DWORD PTR ds:0x48dd3c
48a283: xor eax,eax
48a285: mov al,bl
48a287: imul eax,eax,0x16
48a28a: fstp QWORD PTR [esi+eax*8-0xa8]
48a291: fwait
48a292: xor eax,eax
48a294: mov al,bl
48a296: imul eax,eax,0x16
48a299: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a29e: jne 0x48a2ae
48a2a0: push 0x40100000
48a2a5: push 0x0
48a2a7: mov eax,ebx
48a2a9: call 0x47648c
48a2ae: xor eax,eax
48a2b0: mov al,bl
48a2b2: imul eax,eax,0x16
48a2b5: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a2ba: jne 0x48a2ca
48a2bc: push 0xc0100000
48a2c1: push 0x0
48a2c3: mov eax,ebx
48a2c5: call 0x47648c
48a2ca: xor eax,eax
48a2cc: mov al,bl
48a2ce: imul eax,eax,0x16
48a2d1: cmp BYTE PTR [esi+eax*8-0x41],0x2
48a2d6: jne 0x48a333
48a2d8: xor eax,eax
48a2da: mov al,bl
48a2dc: imul eax,eax,0x16
48a2df: fld QWORD PTR [esi+eax*8-0xa8]
48a2e6: fsub DWORD PTR ds:0x48dd68
48a2ec: xor eax,eax
48a2ee: mov al,bl
48a2f0: imul eax,eax,0x16
48a2f3: fstp QWORD PTR [esi+eax*8-0xa8]
48a2fa: fwait
48a2fb: xor eax,eax
48a2fd: mov al,bl
48a2ff: imul eax,eax,0x16
48a302: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a307: jne 0x48a317
48a309: push 0x40200000
48a30e: push 0x0
48a310: mov eax,ebx
48a312: call 0x47648c
48a317: xor eax,eax
48a319: mov al,bl
48a31b: imul eax,eax,0x16
48a31e: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a323: jne 0x48a333
48a325: push 0xc0200000
48a32a: push 0x0
48a32c: mov eax,ebx
48a32e: call 0x47648c
48a333: xor eax,eax
48a335: mov al,bl
48a337: imul eax,eax,0x16
48a33a: movzx eax,BYTE PTR [esi+eax*8-0x44]
48a33f: xor edx,edx
48a341: mov dl,BYTE PTR [esp+0x1]
48a345: add edx,0x28
48a348: cmp eax,edx
48a34a: jne 0x48a358
48a34c: xor eax,eax
48a34e: mov al,bl
48a350: imul eax,eax,0x16
48a353: mov BYTE PTR [esi+eax*8-0x46],0x1
48a358: xor eax,eax
48a35a: mov al,bl
48a35c: imul eax,eax,0x16
48a35f: mov BYTE PTR [esi+eax*8-0x47],0x1
48a364: xor eax,eax
48a366: mov al,bl
48a368: imul eax,eax,0x16
48a36b: cmp BYTE PTR [esi+eax*8-0x45],0x1b
48a370: jne 0x48a623
48a376: xor eax,eax
48a378: mov al,bl
48a37a: imul eax,eax,0x16
48a37d: cmp WORD PTR [esi+eax*8-0x3c],0x0
48a383: jne 0x48a397
48a385: xor eax,eax
48a387: mov al,bl
48a389: imul eax,eax,0x16
48a38c: mov dl,BYTE PTR [esp+0x1]
48a390: add dl,0x29
48a393: mov BYTE PTR [esi+eax*8-0x44],dl
48a397: xor eax,eax
48a399: mov al,bl
48a39b: imul eax,eax,0x16
48a39e: cmp WORD PTR [esi+eax*8-0x3c],0x2
48a3a4: jne 0x48a3b8
48a3a6: xor eax,eax
48a3a8: mov al,bl
48a3aa: imul eax,eax,0x16
48a3ad: mov dl,BYTE PTR [esp+0x1]
48a3b1: add dl,0x2a
48a3b4: mov BYTE PTR [esi+eax*8-0x44],dl
48a3b8: xor eax,eax
48a3ba: mov al,bl
48a3bc: imul eax,eax,0x16
48a3bf: cmp WORD PTR [esi+eax*8-0x3c],0x4
48a3c5: jne 0x48a3d9
48a3c7: xor eax,eax
48a3c9: mov al,bl
48a3cb: imul eax,eax,0x16
48a3ce: mov dl,BYTE PTR [esp+0x1]
48a3d2: add dl,0x29
48a3d5: mov BYTE PTR [esi+eax*8-0x44],dl
48a3d9: xor eax,eax
48a3db: mov al,bl
48a3dd: imul eax,eax,0x16
48a3e0: cmp WORD PTR [esi+eax*8-0x3c],0x6
48a3e6: jne 0x48a3fa
48a3e8: xor eax,eax
48a3ea: mov al,bl
48a3ec: imul eax,eax,0x16
48a3ef: mov dl,BYTE PTR [esp+0x1]
48a3f3: add dl,0x2b
48a3f6: mov BYTE PTR [esi+eax*8-0x44],dl
48a3fa: xor eax,eax
48a3fc: mov al,bl
48a3fe: imul eax,eax,0x16
48a401: cmp WORD PTR [esi+eax*8-0x3c],0x8
48a407: jne 0x48a41b
48a409: xor eax,eax
48a40b: mov al,bl
48a40d: imul eax,eax,0x16
48a410: mov dl,BYTE PTR [esp+0x1]
48a414: add dl,0x2c
48a417: mov BYTE PTR [esi+eax*8-0x44],dl
48a41b: xor eax,eax
48a41d: mov al,bl
48a41f: imul eax,eax,0x16
48a422: cmp WORD PTR [esi+eax*8-0x3c],0xa
48a428: jne 0x48a43c
48a42a: xor eax,eax
48a42c: mov al,bl
48a42e: imul eax,eax,0x16
48a431: mov dl,BYTE PTR [esp+0x1]
48a435: add dl,0x2b
48a438: mov BYTE PTR [esi+eax*8-0x44],dl
48a43c: xor eax,eax
48a43e: mov al,bl
48a440: imul eax,eax,0x16
48a443: cmp WORD PTR [esi+eax*8-0x3c],0xc
48a449: jne 0x48a45d
48a44b: xor eax,eax
48a44d: mov al,bl
48a44f: imul eax,eax,0x16
48a452: mov dl,BYTE PTR [esp+0x1]
48a456: add dl,0x29
48a459: mov BYTE PTR [esi+eax*8-0x44],dl
48a45d: xor eax,eax
48a45f: mov al,bl
48a461: imul eax,eax,0x16
48a464: cmp WORD PTR [esi+eax*8-0x3c],0xe
48a46a: jne 0x48a47e
48a46c: xor eax,eax
48a46e: mov al,bl
48a470: imul eax,eax,0x16
48a473: mov dl,BYTE PTR [esp+0x1]
48a477: add dl,0x2a
48a47a: mov BYTE PTR [esi+eax*8-0x44],dl
48a47e: xor eax,eax
48a480: mov al,bl
48a482: imul eax,eax,0x16
48a485: cmp WORD PTR [esi+eax*8-0x3c],0x10
48a48b: jne 0x48a49f
48a48d: xor eax,eax
48a48f: mov al,bl
48a491: imul eax,eax,0x16
48a494: mov dl,BYTE PTR [esp+0x1]
48a498: add dl,0x29
48a49b: mov BYTE PTR [esi+eax*8-0x44],dl
48a49f: xor eax,eax
48a4a1: mov al,bl
48a4a3: imul eax,eax,0x16
48a4a6: fld QWORD PTR [esi+eax*8-0xa8]
48a4ad: fsub DWORD PTR ds:0x48dd00
48a4b3: xor eax,eax
48a4b5: mov al,bl
48a4b7: imul eax,eax,0x16
48a4ba: fstp QWORD PTR [esi+eax*8-0xa8]
48a4c1: fwait
48a4c2: xor eax,eax
48a4c4: mov al,bl
48a4c6: imul eax,eax,0x16
48a4c9: fild WORD PTR [esi+eax*8-0x3c]
48a4cd: xor eax,eax
48a4cf: mov al,bl
48a4d1: imul eax,eax,0x16
48a4d4: fadd QWORD PTR [esi+eax*8-0xa8]
48a4db: xor eax,eax
48a4dd: mov al,bl
48a4df: imul eax,eax,0x16
48a4e2: fstp QWORD PTR [esi+eax*8-0xa8]
48a4e9: fwait
48a4ea: xor eax,eax
48a4ec: mov al,bl
48a4ee: imul eax,eax,0x16
48a4f1: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a4f6: jne 0x48a514
48a4f8: xor eax,eax
48a4fa: mov al,bl
48a4fc: imul eax,eax,0x16
48a4ff: cmp BYTE PTR [esi+eax*8-0x41],0x1
48a504: jne 0x48a514
48a506: push 0x40240000
48a50b: push 0x0
48a50d: mov eax,ebx
48a50f: call 0x47648c
48a514: xor eax,eax
48a516: mov al,bl
48a518: imul eax,eax,0x16
48a51b: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a520: jne 0x48a53e
48a522: xor eax,eax
48a524: mov al,bl
48a526: imul eax,eax,0x16
48a529: cmp BYTE PTR [esi+eax*8-0x41],0x1
48a52e: jne 0x48a53e
48a530: push 0xc0240000
48a535: push 0x0
48a537: mov eax,ebx
48a539: call 0x47648c
48a53e: xor eax,eax
48a540: mov al,bl
48a542: imul eax,eax,0x16
48a545: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a54a: jne 0x48a568
48a54c: xor eax,eax
48a54e: mov al,bl
48a550: imul eax,eax,0x16
48a553: cmp BYTE PTR [esi+eax*8-0x41],0x2
48a558: jne 0x48a568
48a55a: push 0x402e0000
48a55f: push 0x0
48a561: mov eax,ebx
48a563: call 0x47648c
48a568: xor eax,eax
48a56a: mov al,bl
48a56c: imul eax,eax,0x16
48a56f: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a574: jne 0x48a592
48a576: xor eax,eax
48a578: mov al,bl
48a57a: imul eax,eax,0x16
48a57d: cmp BYTE PTR [esi+eax*8-0x41],0x2
48a582: jne 0x48a592
48a584: push 0xc02e0000
48a589: push 0x0
48a58b: mov eax,ebx
48a58d: call 0x47648c
48a592: xor eax,eax
48a594: mov al,bl
48a596: imul eax,eax,0x16
48a599: cmp WORD PTR [esi+eax*8-0x3c],0x2
48a59f: jne 0x48a5a9
48a5a1: mov eax,ds:0x4b1098
48a5a6: mov BYTE PTR [eax],0x37
48a5a9: xor eax,eax
48a5ab: mov al,bl
48a5ad: imul eax,eax,0x16
48a5b0: cmp WORD PTR [esi+eax*8-0x3c],0x8
48a5b6: jne 0x48a5c0
48a5b8: mov eax,ds:0x4b1098
48a5bd: mov BYTE PTR [eax],0x37
48a5c0: xor eax,eax
48a5c2: mov al,bl
48a5c4: imul eax,eax,0x16
48a5c7: cmp WORD PTR [esi+eax*8-0x3c],0xe
48a5cd: jne 0x48a5d7
48a5cf: mov eax,ds:0x4b1098
48a5d4: mov BYTE PTR [eax],0x38
48a5d7: xor eax,eax
48a5d9: mov al,bl
48a5db: imul eax,eax,0x16
48a5de: cmp WORD PTR [esi+eax*8-0x3c],0x6
48a5e4: jl 0x48a608
48a5e6: xor eax,eax
48a5e8: mov al,bl
48a5ea: imul eax,eax,0x16
48a5ed: cmp WORD PTR [esi+eax*8-0x3c],0x10
48a5f3: jg 0x48a608
48a5f5: xor eax,eax
48a5f7: mov al,bl
48a5f9: mov edx,0x3
48a5fe: sub edx,eax
48a600: imul eax,edx,0x16
48a603: mov BYTE PTR [esi+eax*8-0x1e],0x0
48a608: xor eax,eax
48a60a: mov al,bl
48a60c: imul eax,eax,0x16
48a60f: cmp WORD PTR [esi+eax*8-0x3c],0xa
48a615: jl 0x48a623
48a617: xor eax,eax
48a619: mov al,bl
48a61b: imul eax,eax,0x16
48a61e: mov BYTE PTR [esi+eax*8-0x47],0x1
48a623: xor eax,eax
48a625: mov al,bl
48a627: imul eax,eax,0x16
48a62a: cmp BYTE PTR [esi+eax*8-0x45],0x1c
48a62f: jne 0x48a82f
48a635: xor eax,eax
48a637: mov al,bl
48a639: imul eax,eax,0x16
48a63c: cmp WORD PTR [esi+eax*8-0x3c],0x0
48a642: jne 0x48a656
48a644: xor eax,eax
48a646: mov al,bl
48a648: imul eax,eax,0x16
48a64b: mov dl,BYTE PTR [esp+0x1]
48a64f: add dl,0x26
48a652: mov BYTE PTR [esi+eax*8-0x44],dl
48a656: xor eax,eax
48a658: mov al,bl
48a65a: imul eax,eax,0x16
48a65d: cmp WORD PTR [esi+eax*8-0x3c],0x4
48a663: jne 0x48a677
48a665: xor eax,eax
48a667: mov al,bl
48a669: imul eax,eax,0x16
48a66c: mov dl,BYTE PTR [esp+0x1]
48a670: add dl,0x27
48a673: mov BYTE PTR [esi+eax*8-0x44],dl
48a677: xor eax,eax
48a679: mov al,bl
48a67b: imul eax,eax,0x16
48a67e: cmp WORD PTR [esi+eax*8-0x3c],0x8
48a684: jne 0x48a698
48a686: xor eax,eax
48a688: mov al,bl
48a68a: imul eax,eax,0x16
48a68d: mov dl,BYTE PTR [esp+0x1]
48a691: add dl,0x28
48a694: mov BYTE PTR [esi+eax*8-0x44],dl
48a698: xor eax,eax
48a69a: mov al,bl
48a69c: imul eax,eax,0x16
48a69f: cmp WORD PTR [esi+eax*8-0x3c],0xa
48a6a5: jne 0x48a6b9
48a6a7: xor eax,eax
48a6a9: mov al,bl
48a6ab: imul eax,eax,0x16
48a6ae: mov dl,BYTE PTR [esp+0x1]
48a6b2: add dl,0x26
48a6b5: mov BYTE PTR [esi+eax*8-0x44],dl
48a6b9: xor eax,eax
48a6bb: mov al,bl
48a6bd: imul eax,eax,0x16
48a6c0: cmp WORD PTR [esi+eax*8-0x3c],0xd
48a6c6: jne 0x48a6da
48a6c8: xor eax,eax
48a6ca: mov al,bl
48a6cc: imul eax,eax,0x16
48a6cf: mov dl,BYTE PTR [esp+0x1]
48a6d3: add dl,0x27
48a6d6: mov BYTE PTR [esi+eax*8-0x44],dl
48a6da: xor eax,eax
48a6dc: mov al,bl
48a6de: imul eax,eax,0x16
48a6e1: cmp WORD PTR [esi+eax*8-0x3c],0x19
48a6e7: jne 0x48a6fb
48a6e9: xor eax,eax
48a6eb: mov al,bl
48a6ed: imul eax,eax,0x16
48a6f0: mov dl,BYTE PTR [esp+0x1]
48a6f4: add dl,0x28
48a6f7: mov BYTE PTR [esi+eax*8-0x44],dl
48a6fb: xor eax,eax
48a6fd: mov al,bl
48a6ff: imul eax,eax,0x16
48a702: cmp WORD PTR [esi+eax*8-0x3c],0x8
48a708: jg 0x48a742
48a70a: xor eax,eax
48a70c: mov al,bl
48a70e: imul eax,eax,0x16
48a711: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a716: jne 0x48a726
48a718: push 0x402e0000
48a71d: push 0x0
48a71f: mov eax,ebx
48a721: call 0x47648c
48a726: xor eax,eax
48a728: mov al,bl
48a72a: imul eax,eax,0x16
48a72d: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a732: jne 0x48a742
48a734: push 0xc02e0000
48a739: push 0x0
48a73b: mov eax,ebx
48a73d: call 0x47648c
48a742: xor eax,eax
48a744: mov al,bl
48a746: imul eax,eax,0x16
48a749: cmp WORD PTR [esi+eax*8-0x3c],0xd
48a74f: jl 0x48a7bb
48a751: xor eax,eax
48a753: mov al,bl
48a755: imul eax,eax,0x16
48a758: cmp WORD PTR [esi+eax*8-0x3c],0x19
48a75e: jge 0x48a7bb
48a760: xor eax,eax
48a762: mov al,bl
48a764: imul eax,eax,0x16
48a767: fld QWORD PTR [esi+eax*8-0xa8]
48a76e: fsub DWORD PTR ds:0x48dd04
48a774: xor eax,eax
48a776: mov al,bl
48a778: imul eax,eax,0x16
48a77b: fstp QWORD PTR [esi+eax*8-0xa8]
48a782: fwait
48a783: xor eax,eax
48a785: mov al,bl
48a787: imul eax,eax,0x16
48a78a: cmp BYTE PTR [esi+eax*8-0x43],0x1
48a78f: jne 0x48a79f
48a791: push 0x40100000
48a796: push 0x0
48a798: mov eax,ebx
48a79a: call 0x47648c
48a79f: xor eax,eax
48a7a1: mov al,bl
48a7a3: imul eax,eax,0x16
48a7a6: cmp BYTE PTR [esi+eax*8-0x43],0x2
48a7ab: jne 0x48a7bb
48a7ad: push 0xc0100000
48a7b2: push 0x0
48a7b4: mov eax,ebx
48a7b6: call 0x47648c
48a7bb: xor eax,eax
48a7bd: mov al,bl
48a7bf: imul eax,eax,0x16
48a7c2: cmp WORD PTR [esi+eax*8-0x3c],0x19
48a7c8: jne 0x48a7ee
48a7ca: xor eax,eax
48a7cc: mov al,bl
48a7ce: imul eax,eax,0x16
48a7d1: mov BYTE PTR [esi+eax*8-0x46],0x1
48a7d6: xor eax,eax
48a7d8: mov al,bl
48a7da: imul eax,eax,0x16
48a7dd: mov BYTE PTR [esi+eax*8-0x42],0x0
48a7e2: xor eax,eax
48a7e4: mov al,bl
48a7e6: imul eax,eax,0x16
48a7e9: mov BYTE PTR [esi+eax*8-0x38],0xf8
48a7ee: xor eax,eax
48a7f0: mov al,bl
48a7f2: mov edx,0x3
48a7f7: sub edx,eax
48a7f9: imul eax,edx,0x16
48a7fc: mov BYTE PTR [esi+eax*8-0x3e],0x0
48a801: xor eax,eax
48a803: mov al,bl
48a805: imul eax,eax,0x16
48a808: cmp WORD PTR [esi+eax*8-0x3c],0xd
48a80e: jl 0x48a82f
48a810: xor eax,eax
48a812: mov al,bl
48a814: imul eax,eax,0x16
48a817: mov BYTE PTR [esi+eax*8-0x47],0x1
48a81c: xor eax,eax
48a81e: mov al,bl
48a820: mov edx,0x3
48a825: sub edx,eax
48a827: imul eax,edx,0x16
48a82a: mov BYTE PTR [esi+eax*8-0x1e],0x0
48a82f: push 0x1e
48a831: push 0x1a
48a833: push 0xaf
48a838: xor edx,edx
48a83a: mov dl,BYTE PTR [esp+0xd]
48a83e: inc edx
48a83f: xor eax,eax
48a841: mov al,bl
48a843: mov ecx,0xfffffff8
48a848: call 0x476870
48a84d: push 0x1e
48a84f: push 0x1a
48a851: push 0xaf
48a856: xor edx,edx
48a858: mov dl,BYTE PTR [esp+0xd]
48a85c: add edx,0x2
48a85f: xor eax,eax
48a861: mov al,bl
48a863: mov ecx,0xfffffff8
48a868: call 0x476870
48a86d: push 0x1e
48a86f: push 0x1a
48a871: push 0xaf
48a876: xor edx,edx
48a878: mov dl,BYTE PTR [esp+0xd]
48a87c: add edx,0x3
48a87f: xor eax,eax
48a881: mov al,bl
48a883: mov ecx,0xfffffff8
48a888: call 0x476870
48a88d: push 0x1e
48a88f: push 0x1a
48a891: push 0xaf
48a896: xor edx,edx
48a898: mov dl,BYTE PTR [esp+0xd]
48a89c: add edx,0x4
48a89f: xor eax,eax
48a8a1: mov al,bl
48a8a3: mov ecx,0xfffffff8
48a8a8: call 0x476870
48a8ad: push 0x1e
48a8af: push 0x1a
48a8b1: push 0xaf
48a8b6: xor edx,edx
48a8b8: mov dl,BYTE PTR [esp+0xd]
48a8bc: add edx,0x6
48a8bf: xor eax,eax
48a8c1: mov al,bl
48a8c3: mov ecx,0xfffffff8
48a8c8: call 0x476870
48a8cd: push 0x1e
48a8cf: push 0x1a
48a8d1: push 0xaf
48a8d6: xor edx,edx
48a8d8: mov dl,BYTE PTR [esp+0xd]
48a8dc: add edx,0x8
48a8df: xor eax,eax
48a8e1: mov al,bl
48a8e3: mov ecx,0xfffffff8
48a8e8: call 0x476870
48a8ed: push 0x1e
48a8ef: push 0x1a
48a8f1: push 0xaf
48a8f6: xor edx,edx
48a8f8: mov dl,BYTE PTR [esp+0xd]
48a8fc: add edx,0xa
48a8ff: xor eax,eax
48a901: mov al,bl
48a903: mov ecx,0xfffffff8
48a908: call 0x476870
48a90d: push 0x48
48a90f: push 0x18
48a911: push 0xaa
48a916: xor edx,edx
48a918: mov dl,BYTE PTR [esp+0xd]
48a91c: add edx,0xc
48a91f: xor eax,eax
48a921: mov al,bl
48a923: mov ecx,0xfffffff7
48a928: call 0x476870
48a92d: push 0x48
48a92f: push 0x18
48a931: push 0xaa
48a936: xor edx,edx
48a938: mov dl,BYTE PTR [esp+0xd]
48a93c: add edx,0xd
48a93f: xor eax,eax
48a941: mov al,bl
48a943: mov ecx,0xfffffff7
48a948: call 0x476870
48a94d: push 0x48
48a94f: push 0x18
48a951: push 0xaa
48a956: xor edx,edx
48a958: mov dl,BYTE PTR [esp+0xd]
48a95c: add edx,0xf
48a95f: xor eax,eax
48a961: mov al,bl
48a963: mov ecx,0xfffffff7
48a968: call 0x476870
48a96d: push 0x48
48a96f: push 0x18
48a971: push 0xaa
48a976: xor edx,edx
48a978: mov dl,BYTE PTR [esp+0xd]
48a97c: add edx,0x11
48a97f: xor eax,eax
48a981: mov al,bl
48a983: mov ecx,0xfffffff7
48a988: call 0x476870
48a98d: push 0x5a
48a98f: push 0x18
48a991: push 0xaa
48a996: xor edx,edx
48a998: mov dl,BYTE PTR [esp+0xd]
48a99c: add edx,0x13
48a99f: xor eax,eax
48a9a1: mov al,bl
48a9a3: mov ecx,0xfffffff7
48a9a8: call 0x476870
48a9ad: push 0x1c
48a9af: push 0x13
48a9b1: push 0x8c
48a9b6: xor edx,edx
48a9b8: mov dl,BYTE PTR [esp+0xd]
48a9bc: add edx,0x15
48a9bf: xor eax,eax
48a9c1: mov al,bl
48a9c3: mov ecx,0xfffffff1
48a9c8: call 0x476870
48a9cd: push 0x4e
48a9cf: push 0x24
48a9d1: push 0x70
48a9d3: xor edx,edx
48a9d5: mov dl,BYTE PTR [esp+0xd]
48a9d9: add edx,0x1c
48a9dc: xor eax,eax
48a9de: mov al,bl
48a9e0: mov ecx,0xffffffe4
48a9e5: call 0x476870
48a9ea: push 0x76
48a9ec: push 0x24
48a9ee: push 0x98
48a9f3: xor edx,edx
48a9f5: mov dl,BYTE PTR [esp+0xd]
48a9f9: add edx,0x1d
48a9fc: xor eax,eax
48a9fe: mov al,bl
48aa00: mov ecx,0xffffffe4
48aa05: call 0x476870
48aa0a: push 0x1e
48aa0c: push 0x13
48aa0e: push 0xaa
48aa13: xor edx,edx
48aa15: mov dl,BYTE PTR [esp+0xd]
48aa19: add edx,0x1f
48aa1c: xor eax,eax
48aa1e: mov al,bl
48aa20: mov ecx,0xfffffff2
48aa25: call 0x476870
48aa2a: push 0x48
48aa2c: push 0x18
48aa2e: push 0xaa
48aa33: xor edx,edx
48aa35: mov dl,BYTE PTR [esp+0xd]
48aa39: add edx,0x20
48aa3c: xor eax,eax
48aa3e: mov al,bl
48aa40: mov ecx,0xfffffff7
48aa45: call 0x476870
48aa4a: push 0x1e
48aa4c: push 0x1a
48aa4e: push 0xaf
48aa53: xor edx,edx
48aa55: mov dl,BYTE PTR [esp+0xd]
48aa59: add edx,0x23
48aa5c: xor eax,eax
48aa5e: mov al,bl
48aa60: mov ecx,0xfffffff8
48aa65: call 0x476870
48aa6a: push 0x1e
48aa6c: push 0x19
48aa6e: push 0xaa
48aa73: xor edx,edx
48aa75: mov dl,BYTE PTR [esp+0xd]
48aa79: add edx,0x27
48aa7c: xor eax,eax
48aa7e: mov al,bl
48aa80: mov ecx,0xfffffff2
48aa85: call 0x476870
48aa8a: push 0x46
48aa8c: push 0x13
48aa8e: push 0x96
48aa93: xor edx,edx
48aa95: mov dl,BYTE PTR [esp+0xd]
48aa99: add edx,0x29
48aa9c: xor eax,eax
48aa9e: mov al,bl
48aaa0: mov ecx,0xfffffff2
48aaa5: call 0x476870
48aaaa: push 0xf
48aaac: push 0x3c
48aaae: push 0x50
48aab0: push 0x46
48aab2: push 0x1
48aab4: push 0x1
48aab6: push 0x7
48aab8: push 0x0
48aaba: xor eax,eax
48aabc: mov al,bl
48aabe: mov ecx,0x2
48aac3: mov edx,0x3
48aac8: call 0x4768f8
48aacd: push 0xf
48aacf: push 0x6e
48aad1: push 0x3a
48aad3: push 0x91
48aad8: push 0x1
48aada: push 0x1
48aadc: push 0x7
48aade: push 0x0
48aae0: xor eax,eax
48aae2: mov al,bl
48aae4: mov ecx,0x2
48aae9: mov edx,0x4
48aaee: call 0x4768f8
48aaf3: push 0xf
48aaf5: push 0xa
48aaf7: push 0x3c
48aaf9: push 0x3c
48aafb: push 0x1
48aafd: push 0x2
48aaff: push 0x5
48ab01: push 0x0
48ab03: xor eax,eax
48ab05: mov al,bl
48ab07: mov ecx,0x2
48ab0c: mov edx,0x5
48ab11: call 0x4768f8
48ab16: push 0xf
48ab18: push 0xa
48ab1a: push 0x3c
48ab1c: push 0x3c
48ab1e: push 0x1
48ab20: push 0x2
48ab22: push 0xa
48ab24: push 0x0
48ab26: xor eax,eax
48ab28: mov al,bl
48ab2a: mov ecx,0x5
48ab2f: mov edx,0x5
48ab34: call 0x4768f8
48ab39: push 0xf
48ab3b: push 0x3c
48ab3d: push 0x61
48ab3f: push 0x50
48ab41: push 0x1
48ab43: push 0x2
48ab45: push 0xe
48ab47: push 0x0
48ab49: xor eax,eax
48ab4b: mov al,bl
48ab4d: mov ecx,0x5
48ab52: mov edx,0x6
48ab57: call 0x4768f8
48ab5c: push 0xf
48ab5e: push 0x53
48ab60: push 0x46
48ab62: push 0x5d
48ab64: push 0x1
48ab66: push 0x1
48ab68: push 0x7
48ab6a: push 0x0
48ab6c: xor eax,eax
48ab6e: mov al,bl
48ab70: mov ecx,0x2
48ab75: mov edx,0x8
48ab7a: call 0x4768f8
48ab7f: push 0xf
48ab81: push 0x8a
48ab86: push 0x4b
48ab88: push 0xa0
48ab8d: push 0x1
48ab8f: push 0x1
48ab91: push 0x7
48ab93: push 0x0
48ab95: xor eax,eax
48ab97: mov al,bl
48ab99: mov ecx,0x2
48ab9e: mov edx,0x9
48aba3: call 0x4768f8
48aba8: push 0xa
48abaa: push 0x23
48abac: push 0x2a
48abae: push 0x5a
48abb0: push 0x1
48abb2: push 0x2
48abb4: push 0xe
48abb6: push 0x0
48abb8: xor eax,eax
48abba: mov al,bl
48abbc: mov ecx,0x5
48abc1: mov edx,0xa
48abc6: call 0x4768f8
48abcb: push 0xa
48abcd: push 0x82
48abd2: push 0x5a
48abd4: push 0xa0
48abd9: push 0x1
48abdb: push 0x2
48abdd: push 0xe
48abdf: push 0x0
48abe1: xor eax,eax
48abe3: mov al,bl
48abe5: mov ecx,0x5
48abea: mov edx,0xb
48abef: call 0x4768f8
48abf4: push 0x23
48abf6: push 0x46
48abf8: push 0x4b
48abfa: push 0x6e
48abfc: push 0x1
48abfe: push 0x1
48ac00: push 0x7
48ac02: push 0x0
48ac04: xor eax,eax
48ac06: mov al,bl
48ac08: mov ecx,0x2
48ac0d: mov edx,0xd
48ac12: call 0x4768f8
48ac17: push 0x14
48ac19: push 0x50
48ac1b: push 0x5a
48ac1d: push 0x87
48ac22: push 0x1
48ac24: push 0x1
48ac26: push 0x7
48ac28: push 0x0
48ac2a: xor eax,eax
48ac2c: mov al,bl
48ac2e: mov ecx,0x2
48ac33: mov edx,0xe
48ac38: call 0x4768f8
48ac3d: push 0x23
48ac3f: push 0x46
48ac41: push 0x4b
48ac43: push 0x6e
48ac45: push 0x1
48ac47: push 0x2
48ac49: push 0xe
48ac4b: push 0x0
48ac4d: xor eax,eax
48ac4f: mov al,bl
48ac51: mov ecx,0x5
48ac56: mov edx,0xf
48ac5b: call 0x4768f8
48ac60: push 0x14
48ac62: push 0x50
48ac64: push 0x5a
48ac66: push 0x87
48ac6b: push 0x1
48ac6d: push 0x2
48ac6f: push 0xe
48ac71: push 0x0
48ac73: xor eax,eax
48ac75: mov al,bl
48ac77: mov ecx,0x5
48ac7c: mov edx,0x10
48ac81: call 0x4768f8
48ac86: push 0x5
48ac88: push 0xfffffff8
48ac8a: push 0x2d
48ac8c: push 0x6e
48ac8e: push 0x1
48ac90: push 0x0
48ac92: push 0x14
48ac94: push 0x4
48ac96: xor eax,eax
48ac98: mov al,bl
48ac9a: mov ecx,0x3
48ac9f: mov edx,0x1a
48aca4: call 0x4768f8
48aca9: push 0x0
48acab: push 0x0
48acad: push 0x0
48acaf: push 0x0
48acb1: push 0x0
48acb3: push 0x0
48acb5: push 0x0
48acb7: push 0x0
48acb9: xor eax,eax
48acbb: mov al,bl
48acbd: mov ecx,0x9
48acc2: mov edx,0x1a
48acc7: call 0x4768f8
48accc: push 0x5
48acce: push 0x68
48acd0: push 0x5a
48acd2: push 0x84
48acd7: push 0x1
48acd9: push 0x0
48acdb: push 0x8
48acdd: push 0x2
48acdf: xor eax,eax
48ace1: mov al,bl
48ace3: mov ecx,0x2
48ace8: mov edx,0x1b
48aced: call 0x4768f8
48acf2: push 0x5
48acf4: push 0x68
48acf6: push 0x5a
48acf8: push 0x84
48acfd: push 0x1
48acff: push 0x0
48ad01: push 0x8
48ad03: push 0x2
48ad05: xor eax,eax
48ad07: mov al,bl
48ad09: mov ecx,0x8
48ad0e: mov edx,0x1b
48ad13: call 0x4768f8
48ad18: push 0x5
48ad1a: push 0x68
48ad1c: push 0x5a
48ad1e: push 0x84
48ad23: push 0x1
48ad25: push 0x0
48ad27: push 0x8
48ad29: push 0x2
48ad2b: xor eax,eax
48ad2d: mov al,bl
48ad2f: mov ecx,0xc
48ad34: mov edx,0x1b
48ad39: call 0x4768f8
48ad3e: push 0x0
48ad40: push 0x0
48ad42: push 0x0
48ad44: push 0x0
48ad46: push 0x0
48ad48: push 0x0
48ad4a: push 0x0
48ad4c: push 0x0
48ad4e: xor eax,eax
48ad50: mov al,bl
48ad52: mov ecx,0x11
48ad57: mov edx,0x1b
48ad5c: call 0x4768f8
48ad61: push 0x5
48ad63: push 0xfffffffe
48ad65: push 0x2d
48ad67: push 0x6e
48ad69: push 0x1
48ad6b: push 0x2
48ad6d: push 0x1
48ad6f: push 0x1
48ad71: xor eax,eax
48ad73: mov al,bl
48ad75: mov ecx,0x1
48ad7a: mov edx,0x1c
48ad7f: call 0x4768f8
48ad84: push 0x5
48ad86: push 0xfffffffe
48ad88: push 0x2d
48ad8a: push 0x6e
48ad8c: push 0x1
48ad8e: push 0x2
48ad90: push 0x2
48ad92: push 0x2
48ad94: xor eax,eax
48ad96: mov al,bl
48ad98: mov ecx,0x5
48ad9d: mov edx,0x1c
48ada2: call 0x4768f8
48ada7: push 0x5
48ada9: push 0xfffffffe
48adab: push 0x2d
48adad: push 0x6e
48adaf: push 0x1
48adb1: push 0x2
48adb3: push 0x1
48adb5: push 0x3
48adb7: xor eax,eax
48adb9: mov al,bl
48adbb: mov ecx,0x9
48adc0: mov edx,0x1c
48adc5: call 0x4768f8
48adca: push 0x5
48adcc: push 0xfffffffe
48adce: push 0x2d
48add0: push 0x6e
48add2: push 0x1
48add4: push 0x2
48add6: push 0x5
48add8: push 0x2
48adda: xor eax,eax
48addc: mov al,bl
48adde: mov ecx,0xd
48ade3: mov edx,0x1c
48ade8: call 0x4768f8
48aded: push 0x5
48adef: push 0xfffffffe
48adf1: push 0x2d
48adf3: push 0x6e
48adf5: push 0x1
48adf7: push 0x2
48adf9: push 0x5
48adfb: push 0x1
48adfd: xor eax,eax
48adff: mov al,bl
48ae01: mov ecx,0xf
48ae06: mov edx,0x1c
48ae0b: call 0x4768f8
48ae10: push 0x5
48ae12: push 0xfffffffe
48ae14: push 0x2d
48ae16: push 0x6e
48ae18: push 0x1
48ae1a: push 0x2
48ae1c: push 0x7
48ae1e: push 0x2
48ae20: xor eax,eax
48ae22: mov al,bl
48ae24: mov ecx,0x11
48ae29: mov edx,0x1c
48ae2e: call 0x4768f8
48ae33: push 0x5
48ae35: push 0xfffffffe
48ae37: push 0x2d
48ae39: push 0x6e
48ae3b: push 0x1
48ae3d: push 0x2
48ae3f: push 0x7
48ae41: push 0x1
48ae43: xor eax,eax
48ae45: mov al,bl
48ae47: mov ecx,0x13
48ae4c: mov edx,0x1c
48ae51: call 0x4768f8
48ae56: push 0x5
48ae58: push 0xfffffffe
48ae5a: push 0x2d
48ae5c: push 0x6e
48ae5e: push 0x1
48ae60: push 0x2
48ae62: push 0x5
48ae64: push 0x1
48ae66: xor eax,eax
48ae68: mov al,bl
48ae6a: mov ecx,0x15
48ae6f: mov edx,0x1c
48ae74: call 0x4768f8
48ae79: push 0x5
48ae7b: push 0xfffffffe
48ae7d: push 0x2d
48ae7f: push 0x6e
48ae81: push 0x1
48ae83: push 0x2
48ae85: push 0x9
48ae87: push 0x1
48ae89: xor eax,eax
48ae8b: mov al,bl
48ae8d: mov ecx,0x17
48ae92: mov edx,0x1c
48ae97: call 0x4768f8
48ae9c: push 0x0
48ae9e: push 0x0
48aea0: push 0x0
48aea2: push 0x0
48aea4: push 0x0
48aea6: push 0x0
48aea8: push 0x0
48aeaa: push 0x0
48aeac: xor eax,eax
48aeae: mov al,bl
48aeb0: mov ecx,0x19
48aeb5: mov edx,0x1c
48aeba: call 0x4768f8
48aebf: xor eax,eax
48aec1: mov al,bl
48aec3: imul eax,eax,0x16
48aec6: cmp BYTE PTR [esi+eax*8-0xa0],0xd
48aece: jne 0x48be60
48aed4: xor eax,eax
48aed6: mov al,bl
48aed8: imul eax,eax,0x16
48aedb: cmp BYTE PTR [esi+eax*8-0x45],0x17
48aee0: jne 0x48af8a
48aee6: xor eax,eax
48aee8: mov al,bl
48aeea: imul eax,eax,0x16
48aeed: mov dl,BYTE PTR [esp+0x1]
48aef1: add dl,0x21
48aef4: mov BYTE PTR [esi+eax*8-0x44],dl
48aef8: xor eax,eax
48aefa: mov al,bl
48aefc: imul eax,eax,0x16
48aeff: fild WORD PTR [esi+eax*8-0x3c]
48af03: fdiv DWORD PTR ds:0x48dcf0
48af09: call 0x40286c
48af0e: fmul DWORD PTR ds:0x48dd58
48af14: call 0x402894
48af19: mov DWORD PTR [esp+0xc],eax
48af1d: mov DWORD PTR [esp+0x10],edx
48af21: fild QWORD PTR [esp+0xc]
48af25: xor eax,eax
48af27: mov al,bl
48af29: imul eax,eax,0x16
48af2c: fsubr QWORD PTR [esi+eax*8-0xa8]
48af33: xor eax,eax
48af35: mov al,bl
48af37: imul eax,eax,0x16
48af3a: fstp QWORD PTR [esi+eax*8-0xa8]
48af41: fwait
48af42: mov eax,ds:0x4b11f8
48af47: movsx eax,WORD PTR [eax]
48af4a: sub eax,0xa
48af4d: mov DWORD PTR [esp+0x4],eax
48af51: fild DWORD PTR [esp+0x4]
48af55: xor eax,eax
48af57: mov al,bl
48af59: imul eax,eax,0x16
48af5c: fcomp QWORD PTR [esi+eax*8-0xa8]
48af63: fnstsw ax
48af65: sahf
48af66: jae 0x48af8a
48af68: mov eax,ds:0x4b11f8
48af6d: movsx eax,WORD PTR [eax]
48af70: sub eax,0xa
48af73: mov DWORD PTR [esp+0x4],eax
48af77: fild DWORD PTR [esp+0x4]
48af7b: xor eax,eax
48af7d: mov al,bl
48af7f: imul eax,eax,0x16
48af82: fstp QWORD PTR [esi+eax*8-0xa8]
48af89: fwait
48af8a: xor eax,eax
48af8c: mov al,bl
48af8e: imul eax,eax,0x16
48af91: cmp BYTE PTR [esi+eax*8-0x45],0x19
48af96: jne 0x48b19a
48af9c: xor eax,eax
48af9e: mov al,bl
48afa0: imul eax,eax,0x16
48afa3: cmp WORD PTR [esi+eax*8-0x3c],0x0
48afa9: jne 0x48afbd
48afab: xor eax,eax
48afad: mov al,bl
48afaf: imul eax,eax,0x16
48afb2: mov dl,BYTE PTR [esp+0x1]
48afb6: add dl,0x22
48afb9: mov BYTE PTR [esi+eax*8-0x44],dl
48afbd: xor eax,eax
48afbf: mov al,bl
48afc1: imul eax,eax,0x16
48afc4: cmp WORD PTR [esi+eax*8-0x3c],0x5
48afca: jne 0x48afde
48afcc: xor eax,eax
48afce: mov al,bl
48afd0: imul eax,eax,0x16
48afd3: mov dl,BYTE PTR [esp+0x1]
48afd7: add dl,0x23
48afda: mov BYTE PTR [esi+eax*8-0x44],dl
48afde: xor eax,eax
48afe0: mov al,bl
48afe2: imul eax,eax,0x16
48afe5: cmp WORD PTR [esi+eax*8-0x3c],0xa
48afeb: jne 0x48b183
48aff1: xor eax,eax
48aff3: mov al,bl
48aff5: imul eax,eax,0x16
48aff8: mov dl,BYTE PTR [esp+0x1]
48affc: add dl,0x24
48afff: mov BYTE PTR [esi+eax*8-0x44],dl
48b003: xor eax,eax
48b005: mov al,bl
48b007: imul eax,eax,0x16
48b00a: cmp BYTE PTR [esi+eax*8-0x43],0x1
48b00f: jne 0x48b063
48b011: xor eax,eax
48b013: mov al,bl
48b015: imul eax,eax,0x16
48b018: cmp BYTE PTR [esi+eax*8-0x41],0x1
48b01d: jne 0x48b063
48b01f: xor eax,eax
48b021: mov al,bl
48b023: imul eax,eax,0x16
48b026: fld QWORD PTR [esi+eax*8-0xb0]
48b02d: fadd DWORD PTR ds:0x48dd14
48b033: add esp,0xfffffff8
48b036: fstp QWORD PTR [esp]
48b039: fwait
48b03a: xor eax,eax
48b03c: mov al,bl
48b03e: imul eax,eax,0x16
48b041: fld QWORD PTR [esi+eax*8-0xa8]
48b048: fsub DWORD PTR ds:0x48dcfc
48b04e: add esp,0xfffffff8
48b051: fstp QWORD PTR [esp]
48b054: fwait
48b055: mov ecx,ebx
48b057: mov edx,0x48dcd4
48b05c: mov al,0x1a
48b05e: call 0x476a04
48b063: xor eax,eax
48b065: mov al,bl
48b067: imul eax,eax,0x16
48b06a: cmp BYTE PTR [esi+eax*8-0x43],0x2
48b06f: jne 0x48b0c3
48b071: xor eax,eax
48b073: mov al,bl
48b075: imul eax,eax,0x16
48b078: cmp BYTE PTR [esi+eax*8-0x41],0x1
48b07d: jne 0x48b0c3
48b07f: xor eax,eax
48b081: mov al,bl
48b083: imul eax,eax,0x16
48b086: fld QWORD PTR [esi+eax*8-0xb0]
48b08d: fsub DWORD PTR ds:0x48dd14
48b093: add esp,0xfffffff8
48b096: fstp QWORD PTR [esp]
48b099: fwait
48b09a: xor eax,eax
48b09c: mov al,bl
48b09e: imul eax,eax,0x16
48b0a1: fld QWORD PTR [esi+eax*8-0xa8]
48b0a8: fsub DWORD PTR ds:0x48dcfc
48b0ae: add esp,0xfffffff8
48b0b1: fstp QWORD PTR [esp]
48b0b4: fwait
48b0b5: mov ecx,ebx
48b0b7: mov edx,0x48dcd4
48b0bc: mov al,0x1a
48b0be: call 0x476a04
48b0c3: xor eax,eax
48b0c5: mov al,bl
48b0c7: imul eax,eax,0x16
48b0ca: cmp BYTE PTR [esi+eax*8-0x43],0x1
48b0cf: jne 0x48b123
48b0d1: xor eax,eax
48b0d3: mov al,bl
48b0d5: imul eax,eax,0x16
48b0d8: cmp BYTE PTR [esi+eax*8-0x41],0x2
48b0dd: jne 0x48b123
48b0df: xor eax,eax
48b0e1: mov al,bl
48b0e3: imul eax,eax,0x16
48b0e6: fld QWORD PTR [esi+eax*8-0xb0]
48b0ed: fadd DWORD PTR ds:0x48dd14
48b0f3: add esp,0xfffffff8
48b0f6: fstp QWORD PTR [esp]
48b0f9: fwait
48b0fa: xor eax,eax
48b0fc: mov al,bl
48b0fe: imul eax,eax,0x16
48b101: fld QWORD PTR [esi+eax*8-0xa8]
48b108: fsub DWORD PTR ds:0x48dcfc
48b10e: add esp,0xfffffff8
48b111: fstp QWORD PTR [esp]
48b114: fwait
48b115: mov ecx,ebx
48b117: mov edx,0x48dce0
48b11c: mov al,0x1a
48b11e: call 0x476a04
48b123: xor eax,eax
48b125: mov al,bl
48b127: imul eax,eax,0x16
48b12a: cmp BYTE PTR [esi+eax*8-0x43],0x2
48b12f: jne 0x48b183
48b131: xor eax,eax
48b133: mov al,bl
48b135: imul eax,eax,0x16
48b138: cmp BYTE PTR [esi+eax*8-0x41],0x2
48b13d: jne 0x48b183
48b13f: xor eax,eax
48b141: mov al,bl
48b143: imul eax,eax,0x16
48b146: fld QWORD PTR [esi+eax*8-0xb0]
48b14d: fsub DWORD PTR ds:0x48dd14
48b153: add esp,0xfffffff8
48b156: fstp QWORD PTR [esp]
48b159: fwait
48b15a: xor eax,eax
48b15c: mov al,bl
48b15e: imul eax,eax,0x16
48b161: fld QWORD PTR [esi+eax*8-0xa8]
48b168: fsub DWORD PTR ds:0x48dcfc
48b16e: add esp,0xfffffff8
48b171: fstp QWORD PTR [esp]
48b174: fwait
48b175: mov ecx,ebx
48b177: mov edx,0x48dce0
48b17c: mov al,0x1a
48b17e: call 0x476a04
48b183: xor eax,eax
48b185: mov al,bl
48b187: imul eax,eax,0x16
48b18a: cmp WORD PTR [esi+eax*8-0x3c],0x3
48b190: jne 0x48b19a
48b192: mov eax,ds:0x4b1098
48b197: mov BYTE PTR [eax],0x39
48b19a: xor eax,eax
48b19c: mov al,bl
48b19e: imul eax,eax,0x16
48b1a1: cmp BYTE PTR [esi+eax*8-0x45],0x1a
48b1a6: jne 0x48b2f9
48b1ac: xor eax,eax
48b1ae: mov al,bl
48b1b0: imul eax,eax,0x16
48b1b3: cmp WORD PTR [esi+eax*8-0x3c],0x0
48b1b9: jne 0x48b1cd
48b1bb: xor eax,eax
48b1bd: mov al,bl
48b1bf: imul eax,eax,0x16
48b1c2: mov dl,BYTE PTR [esp+0x1]
48b1c6: add dl,0x25
48b1c9: mov BYTE PTR [esi+eax*8-0x44],dl
48b1cd: xor eax,eax
48b1cf: mov al,bl
48b1d1: imul eax,eax,0x16
48b1d4: cmp WORD PTR [esi+eax*8-0x3c],0x2
48b1da: jne 0x48b1ee
48b1dc: xor eax,eax
48b1de: mov al,bl
48b1e0: imul eax,eax,0x16
48b1e3: mov dl,BYTE PTR [esp+0x1]
48b1e7: add dl,0x26
48b1ea: mov BYTE PTR [esi+eax*8-0x44],dl
48b1ee: xor eax,eax
48b1f0: mov al,bl
48b1f2: imul eax,eax,0x16
48b1f5: cmp WORD PTR [esi+eax*8-0x3c],0x5
48b1fb: jne 0x48b20f
48b1fd: xor eax,eax
48b1ff: mov al,bl
48b201: imul eax,eax,0x16
48b204: mov dl,BYTE PTR [esp+0x1]
48b208: add dl,0x27
48b20b: mov BYTE PTR [esi+eax*8-0x44],dl
48b20f: xor eax,eax
48b211: mov al,bl
48b213: imul eax,eax,0x16
48b216: cmp WORD PTR [esi+eax*8-0x3c],0x8
48b21c: jne 0x48b230
48b21e: xor eax,eax
48b220: mov al,bl
48b222: imul eax,eax,0x16
48b225: mov dl,BYTE PTR [esp+0x1]
48b229: add dl,0x28
48b22c: mov BYTE PTR [esi+eax*8-0x44],dl
48b230: xor eax,eax
48b232: mov al,bl
48b234: imul eax,eax,0x16
48b237: cmp WORD PTR [esi+eax*8-0x3c],0xb
48b23d: jne 0x48b251
48b23f: xor eax,eax
48b241: mov al,bl
48b243: imul eax,eax,0x16
48b246: mov dl,BYTE PTR [esp+0x1]
48b24a: add dl,0x29
48b24d: mov BYTE PTR [esi+eax*8-0x44],dl
48b251: xor eax,eax
48b253: mov al,bl
48b255: imul eax,eax,0x16
48b258: cmp BYTE PTR [esi+eax*8-0x43],0x1
48b25d: jne 0x48b27b
48b25f: xor eax,eax
48b261: mov al,bl
48b263: imul eax,eax,0x16
48b266: cmp BYTE PTR [esi+eax*8-0x41],0x1
48b26b: jne 0x48b27b
48b26d: push 0x40200000
48b272: push 0x0
48b274: mov eax,ebx
48b276: call 0x47648c
48b27b: xor eax,eax
48b27d: mov al,bl
48b27f: imul eax,eax,0x16
48b282: cmp BYTE PTR [esi+eax*8-0x43],0x2
48b287: jne 0x48b2a5
48b289: xor eax,eax
48b28b: mov al,bl
48b28d: imul eax,eax,0x16
48b290: cmp BYTE PTR [esi+eax*8-0x41],0x1
48b295: jne 0x48b2a5
48b297: push 0xc0200000
48b29c: push 0x0
48b29e: mov eax,ebx
48b2a0: call 0x47648c
48b2a5: xor eax,eax
48b2a7: mov al,bl
48b2a9: imul eax,eax,0x16
48b2ac: cmp BYTE PTR [esi+eax*8-0x43],0x1
48b2b1: jne 0x48b2cf
48b2b3: xor eax,eax
48b2b5: mov al,bl
48b2b7: imul eax,eax,0x16
48b2ba: cmp BYTE PTR [esi+eax*8-0x41],0x2
48b2bf: jne 0x48b2cf
48b2c1: push 0x402a0000
48b2c6: push 0x0
48b2c8: mov eax,ebx
48b2ca: call 0x47648c
48b2cf: xor eax,eax
48b2d1: mov al,bl
48b2d3: imul eax,eax,0x16
48b2d6: cmp BYTE PTR [esi+eax*8-0x43],0x2
48b2db: jne 0x48b2f9
48b2dd: xor eax,eax
48b2df: mov al,bl
48b2e1: imul eax,eax,0x16
48b2e4: cmp BYTE PTR [esi+eax*8-0x41],0x2
48b2e9: jne 0x48b2f9
48b2eb: push 0xc02a0000
48b2f0: push 0x0
48b2f2: mov eax,ebx
48b2f4: call 0x47648c
48b2f9: xor eax,eax
48b2fb: mov al,bl
48b2fd: imul eax,eax,0x16
48b300: cmp BYTE PTR [esi+eax*8-0x45],0x1b
48b305: jne 0x48b509
48b30b: xor eax,eax
48b30d: mov al,bl
48b30f: imul eax,eax,0x16
48b312: fild WORD PTR [esi+eax*8-0x3c]
48b316: fdiv DWORD PTR ds:0x48dd34
48b31c: call 0x40287c
48b321: xor eax,eax
48b323: mov al,bl
48b325: imul eax,eax,0x16
48b328: fild WORD PTR [esi+eax*8-0x3c]
48b32c: fdiv DWORD PTR ds:0x48dd34
48b332: fcompp
48b334: fnstsw ax
48b336: sahf
48b337: jne 0x48b34d
48b339: xor eax,eax
48b33b: mov al,bl
48b33d: imul eax,eax,0x16
48b340: mov dl,BYTE PTR [esp+0x1]
48b344: add dl,0x2a
48b347: mov BYTE PTR [esi+eax*8-0x44],dl
48b34b: jmp 0x48b35f
48b34d: xor eax,eax
48b34f: mov al,bl
48b351: imul eax,eax,0x16
48b354: mov dl,BYTE PTR [esp+0x1]
48b358: add dl,0x2b
48b35b: mov BYTE PTR [esi+eax*8-0x44],dl
48b35f: xor eax,eax
48b361: mov al,bl
48b363: imul eax,eax,0x16
48b366: cmp WORD PTR [esi+eax*8-0x3c],0x3
48b36c: jne 0x48b4f2
48b372: xor eax,eax
48b374: mov al,bl
48b376: imul eax,eax,0x16
48b379: cmp BYTE PTR [esi+eax*8-0x43],0x1
48b37e: jne 0x48b3d2
48b380: xor eax,eax
48b382: mov al,bl
48b384: imul eax,eax,0x16
48b387: cmp BYTE PTR [esi+eax*8-0x41],0x1
48b38c: jne 0x48b3d2
48b38e: xor eax,eax
48b390: mov al,bl
48b392: imul eax,eax,0x16
48b395: fld QWORD PTR [esi+eax*8-0xb0]
48b39c: fadd DWORD PTR ds:0x48dcc8
48b3a2: add esp,0xfffffff8
48b3a5: fstp QWORD PTR [esp]
48b3a8: fwait
48b3a9: xor eax,eax
48b3ab: mov al,bl
48b3ad: imul eax,eax,0x16
48b3b0: fld QWORD PTR [esi+eax*8-0xa8]
48b3b7: fsub DWORD PTR ds:0x48dd6c
48b3bd: add esp,0xfffffff8
48b3c0: fstp QWORD PTR [esp]
48b3c3: fwait
48b3c4: mov ecx,ebx
48b3c6: mov edx,0x48dcd4
48b3cb: mov al,0x1b
48b3cd: call 0x476a04
48b3d2: xor eax,eax
48b3d4: mov al,bl
48b3d6: imul eax,eax,0x16
48b3d9: cmp BYTE PTR [esi+eax*8-0x43],0x2
48b3de: jne 0x48b432
48b3e0: xor eax,eax
48b3e2: mov al,bl
48b3e4: imul eax,eax,0x16
48b3e7: cmp BYTE PTR [esi+eax*8-0x41],0x1
48b3ec: jne 0x48b432
48b3ee: xor eax,eax
48b3f0: mov al,bl
48b3f2: imul eax,eax,0x16
48b3f5: fld QWORD PTR [esi+eax*8-0xb0]
48b3fc: fsub DWORD PTR ds:0x48dcc8
48b402: add esp,0xfffffff8
48b405: fstp QWORD PTR [esp]
48b408: fwait
48b409: xor eax,eax
48b40b: mov al,bl
48b40d: imul eax,eax,0x16
48b410: fld QWORD PTR [esi+eax*8-0xa8]
48b417: fsub DWORD PTR ds:0x48dd6c
48b41d: add esp,0xfffffff8
48b420: fstp QWORD PTR [esp]
48b423: fwait
48b424: mov ecx,ebx
48b426: mov edx,0x48dcd4
48b42b: mov al,0x1b
48b42d: call 0x476a04
48b432: xor eax,eax
48b434: mov al,bl
48b436: imul eax,eax,0x16
48b439: cmp BYTE PTR [esi+eax*8-0x43],0x1
48b43e: jne 0x48b492
48b440: xor eax,eax
48b442: mov al,bl
48b444: imul eax,eax,0x16
48b447: cmp BYTE PTR [esi+eax*8-0x41],0x2
48b44c: jne 0x48b492
48b44e: xor eax,eax
48b450: mov al,bl
48b452: imul eax,eax,0x16
48b455: fld QWORD PTR [esi+eax*8-0xb0]
48b45c: fadd DWORD PTR ds:0x48dcc8
48b462: add esp,0xfffffff8
48b465: fstp QWORD PTR [esp]
48b468: fwait
48b469: xor eax,eax
48b46b: mov al,bl
48b46d: imul eax,eax,0x16
48b470: fld QWORD PTR [esi+eax*8-0xa8]
48b477: fsub DWORD PTR ds:0x48dd6c
48b47d: add esp,0xfffffff8
48b480: fstp QWORD PTR [esp]
48b483: fwait
48b484: mov ecx,ebx
48b486: mov edx,0x48dce0
48b48b: mov al,0x1b
48b48d: call 0x476a04
48b492: xor eax,eax
48b494: mov al,bl
48b496: imul eax,eax,0x16
48b499: cmp BYTE PTR [esi+eax*8-0x43],0x2
48b49e: jne 0x48b4f2
48b4a0: xor eax,eax
48b4a2: mov al,bl
48b4a4: imul eax,eax,0x16
48b4a7: cmp BYTE PTR [esi+eax*8-0x41],0x2
48b4ac: jne 0x48b4f2
48b4ae: xor eax,eax
48b4b0: mov al,bl
48b4b2: imul eax,eax,0x16
48b4b5: fld QWORD PTR [esi+eax*8-0xb0]
48b4bc: fsub DWORD PTR ds:0x48dcc8
48b4c2: add esp,0xfffffff8
48b4c5: fstp QWORD PTR [esp]
48b4c8: fwait
48b4c9: xor eax,eax
48b4cb: mov al,bl
48b4cd: imul eax,eax,0x16
48b4d0: fld QWORD PTR [esi+eax*8-0xa8]
48b4d7: fsub DWORD PTR ds:0x48dd6c
48b4dd: add esp,0xfffffff8
48b4e0: fstp QWORD PTR [esp]
48b4e3: fwait
48b4e4: mov ecx,ebx
48b4e6: mov edx,0x48dce0
48b4eb: mov al,0x1b
48b4ed: call 0x476a04
48b4f2: xor eax,eax
48b4f4: mov al,bl
48b4f6: imul eax,eax,0x16
48b4f9: cmp WORD PTR [esi+eax*8-0x3c],0x3
48b4ff: jne 0x48b509
48b501: mov eax,ds:0x4b1098
48b506: mov BYTE PTR [eax],0x3a
48b509: xor eax,eax
48b50b: mov al,bl
48b50d: imul eax,eax,0x16
48b510: cmp BYTE PTR [esi+eax*8-0x45],0x1c
48b515: jne 0x48b789
48b51b: xor eax,eax
48b51d: mov al,bl
48b51f: imul eax,eax,0x16
48b522: cmp WORD PTR [esi+eax*8-0x3c],0x1
48b528: jne 0x48b53c
48b52a: xor eax,eax
48b52c: mov al,bl
48b52e: imul eax,eax,0x16
48b531: mov dl,BYTE PTR [esp+0x1]
48b535: add dl,0x21
48b538: mov BYTE PTR [esi+eax*8-0x44],dl
48b53c: xor eax,eax
48b53e: mov al,bl
48b540: imul eax,eax,0x16
48b543: cmp WORD PTR [esi+eax*8-0x3c],0xa
48b549: jne 0x48b789
48b54f: xor eax,eax
48b551: mov al,bl
48b553: imul eax,eax,0x16
48b556: push DWORD PTR [esi+eax*8-0xac]
48b55d: push DWORD PTR [esi+eax*8-0xb0]
48b564: xor eax,eax
48b566: mov al,bl
48b568: imul eax,eax,0x16
48b56b: fld QWORD PTR [esi+eax*8-0xa8]
48b572: fsub DWORD PTR ds:0x48dd40
48b578: add esp,0xfffffff8
48b57b: fstp QWORD PTR [esp]
48b57e: fwait
48b57f: mov ecx,ebx
48b581: xor edx,edx
48b583: mov al,0x11
48b585: call 0x476a04
48b58a: mov eax,ds:0x4b11b4
48b58f: mov eax,DWORD PTR [eax]
48b591: add eax,0x50
48b594: mov DWORD PTR [esp+0x4],eax
48b598: fild DWORD PTR [esp+0x4]
48b59c: add esp,0xfffffff8
48b59f: fstp QWORD PTR [esp]
48b5a2: fwait
48b5a3: mov eax,ds:0x4b1144
48b5a8: mov eax,DWORD PTR [eax]
48b5aa: add eax,0x6e
48b5ad: mov DWORD PTR [esp+0x10],eax
48b5b1: fild DWORD PTR [esp+0x10]
48b5b5: add esp,0xfffffff8
48b5b8: fstp QWORD PTR [esp]
48b5bb: fwait
48b5bc: mov ecx,ebx
48b5be: xor edx,edx
48b5c0: mov al,0x11
48b5c2: call 0x476a04
48b5c7: mov eax,ds:0x4b11b4
48b5cc: mov eax,DWORD PTR [eax]
48b5ce: add eax,0xa0
48b5d3: mov DWORD PTR [esp+0x4],eax
48b5d7: fild DWORD PTR [esp+0x4]
48b5db: add esp,0xfffffff8
48b5de: fstp QWORD PTR [esp]
48b5e1: fwait
48b5e2: mov eax,ds:0x4b1144
48b5e7: mov eax,DWORD PTR [eax]
48b5e9: add eax,0x6e
48b5ec: mov DWORD PTR [esp+0x10],eax
48b5f0: fild DWORD PTR [esp+0x10]
48b5f4: add esp,0xfffffff8
48b5f7: fstp QWORD PTR [esp]
48b5fa: fwait
48b5fb: mov ecx,ebx
48b5fd: xor edx,edx
48b5ff: mov al,0x11
48b601: call 0x476a04
48b606: mov eax,ds:0x4b11b4
48b60b: mov eax,DWORD PTR [eax]
48b60d: add eax,0xf0
48b612: mov DWORD PTR [esp+0x4],eax
48b616: fild DWORD PTR [esp+0x4]
48b61a: add esp,0xfffffff8
48b61d: fstp QWORD PTR [esp]
48b620: fwait
48b621: mov eax,ds:0x4b1144
48b626: mov eax,DWORD PTR [eax]
48b628: add eax,0x6e
48b62b: mov DWORD PTR [esp+0x10],eax
48b62f: fild DWORD PTR [esp+0x10]
48b633: add esp,0xfffffff8
48b636: fstp QWORD PTR [esp]
48b639: fwait
48b63a: mov ecx,ebx
48b63c: xor edx,edx
48b63e: mov al,0x11
48b640: call 0x476a04
48b645: mov eax,ds:0x4b11b4
48b64a: mov eax,DWORD PTR [eax]
48b64c: add eax,0x140
48b651: mov DWORD PTR [esp+0x4],eax
48b655: fild DWORD PTR [esp+0x4]
48b659: add esp,0xfffffff8
48b65c: fstp QWORD PTR [esp]
48b65f: fwait
48b660: mov eax,ds:0x4b1144
48b665: mov eax,DWORD PTR [eax]
48b667: add eax,0x6e
48b66a: mov DWORD PTR [esp+0x10],eax
48b66e: fild DWORD PTR [esp+0x10]
48b672: add esp,0xfffffff8
48b675: fstp QWORD PTR [esp]
48b678: fwait
48b679: mov ecx,ebx
48b67b: xor edx,edx
48b67d: mov al,0x11
48b67f: call 0x476a04
48b684: xor eax,eax
48b686: mov al,bl
48b688: imul eax,eax,0x16
48b68b: cmp BYTE PTR [esi+eax*8-0x41],0x1
48b690: jne 0x48b6b3
48b692: mov eax,ds:0x4b11b4
48b697: mov eax,DWORD PTR [eax]
48b699: add eax,0x50
48b69c: mov DWORD PTR [esp+0x4],eax
48b6a0: fild DWORD PTR [esp+0x4]
48b6a4: xor eax,eax
48b6a6: mov al,bl
48b6a8: imul eax,eax,0x16
48b6ab: fstp QWORD PTR [esi+eax*8-0xb0]
48b6b2: fwait
48b6b3: xor eax,eax
48b6b5: mov al,bl
48b6b7: imul eax,eax,0x16
48b6ba: cmp BYTE PTR [esi+eax*8-0x41],0x2
48b6bf: jne 0x48b6e4
48b6c1: mov eax,ds:0x4b11b4
48b6c6: mov eax,DWORD PTR [eax]
48b6c8: add eax,0xa0
48b6cd: mov DWORD PTR [esp+0x4],eax
48b6d1: fild DWORD PTR [esp+0x4]
48b6d5: xor eax,eax
48b6d7: mov al,bl
48b6d9: imul eax,eax,0x16
48b6dc: fstp QWORD PTR [esi+eax*8-0xb0]
48b6e3: fwait
48b6e4: xor eax,eax
48b6e6: mov al,bl
48b6e8: imul eax,eax,0x16
48b6eb: cmp BYTE PTR [esi+eax*8-0x41],0x3
48b6f0: jne 0x48b715
48b6f2: mov eax,ds:0x4b11b4
48b6f7: mov eax,DWORD PTR [eax]
48b6f9: add eax,0xf0
48b6fe: mov DWORD PTR [esp+0x4],eax
48b702: fild DWORD PTR [esp+0x4]
48b706: xor eax,eax
48b708: mov al,bl
48b70a: imul eax,eax,0x16
48b70d: fstp QWORD PTR [esi+eax*8-0xb0]
48b714: fwait
48b715: xor eax,eax
48b717: mov al,bl
48b719: imul eax,eax,0x16
48b71c: cmp BYTE PTR [esi+eax*8-0x41],0x4
48b721: jne 0x48b746
48b723: mov eax,ds:0x4b11b4
48b728: mov eax,DWORD PTR [eax]
48b72a: add eax,0x140
48b72f: mov DWORD PTR [esp+0x4],eax
48b733: fild DWORD PTR [esp+0x4]
48b737: xor eax,eax
48b739: mov al,bl
48b73b: imul eax,eax,0x16
48b73e: fstp QWORD PTR [esi+eax*8-0xb0]
48b745: fwait
48b746: mov eax,ds:0x4b1144
48b74b: mov eax,DWORD PTR [eax]
48b74d: add eax,0x96
48b752: mov DWORD PTR [esp+0x4],eax
48b756: fild DWORD PTR [esp+0x4]
48b75a: xor eax,eax
48b75c: mov al,bl
48b75e: imul eax,eax,0x16
48b761: fstp QWORD PTR [esi+eax*8-0xa8]
48b768: fwait
48b769: xor eax,eax
48b76b: mov al,bl
48b76d: imul eax,eax,0x16
48b770: mov BYTE PTR [esi+eax*8-0x46],0x1
48b775: xor eax,eax
48b777: mov al,bl
48b779: imul eax,eax,0x16
48b77c: mov BYTE PTR [esi+eax*8-0x38],0x0
48b781: mov eax,ds:0x4b1098
48b786: mov BYTE PTR [eax],0x29
48b789: xor eax,eax
48b78b: mov al,bl
48b78d: imul eax,eax,0x16
48b790: cmp BYTE PTR [esi+eax*8-0x45],0x1d
48b795: jne 0x48b87a
48b79b: xor eax,eax
48b79d: mov al,bl
48b79f: imul eax,eax,0x16
48b7a2: fild WORD PTR [esi+eax*8-0x3c]
48b7a6: fdiv DWORD PTR ds:0x48dd34
48b7ac: call 0x40287c
48b7b1: xor eax,eax
48b7b3: mov al,bl
48b7b5: imul eax,eax,0x16
48b7b8: fild WORD PTR [esi+eax*8-0x3c]
48b7bc: fdiv DWORD PTR ds:0x48dd34
48b7c2: fcompp
48b7c4: fnstsw ax
48b7c6: sahf
48b7c7: jne 0x48b7dd
48b7c9: xor eax,eax
48b7cb: mov al,bl
48b7cd: imul eax,eax,0x16
48b7d0: mov dl,BYTE PTR [esp+0x1]
48b7d4: add dl,0x2c
48b7d7: mov BYTE PTR [esi+eax*8-0x44],dl
48b7db: jmp 0x48b7ef
48b7dd: xor eax,eax
48b7df: mov al,bl
48b7e1: imul eax,eax,0x16
48b7e4: mov dl,BYTE PTR [esp+0x1]
48b7e8: add dl,0x2d
48b7eb: mov BYTE PTR [esi+eax*8-0x44],dl
48b7ef: xor eax,eax
48b7f1: mov al,bl
48b7f3: imul eax,eax,0x16
48b7f6: cmp BYTE PTR [esi+eax*8-0x43],0x1
48b7fb: jne 0x48b80b
48b7fd: push 0x402c0000
48b802: push 0x0
48b804: mov eax,ebx
48b806: call 0x47648c
48b80b: xor eax,eax
48b80d: mov al,bl
48b80f: imul eax,eax,0x16
48b812: cmp BYTE PTR [esi+eax*8-0x43],0x2
48b817: jne 0x48b827
48b819: push 0xc02c0000
48b81e: push 0x0
48b820: mov eax,ebx
48b822: call 0x47648c
48b827: xor eax,eax
48b829: mov al,bl
48b82b: imul eax,eax,0x16
48b82e: cmp BYTE PTR [esi+eax*8-0x1b],0x1
48b833: jbe 0x48b848
48b835: xor eax,eax
48b837: mov al,bl
48b839: mov edx,0x3
48b83e: sub edx,eax
48b840: imul eax,edx,0x16
48b843: mov BYTE PTR [esi+eax*8-0x1e],0x0
48b848: xor eax,eax
48b84a: mov al,bl
48b84c: imul eax,eax,0x16
48b84f: cmp WORD PTR [esi+eax*8-0x3c],0xf
48b855: jl 0x48b863
48b857: xor eax,eax
48b859: mov al,bl
48b85b: imul eax,eax,0x16
48b85e: mov BYTE PTR [esi+eax*8-0x47],0x1
48b863: xor eax,eax
48b865: mov al,bl
48b867: imul eax,eax,0x16
48b86a: cmp WORD PTR [esi+eax*8-0x3c],0x2
48b870: jne 0x48b87a
48b872: mov eax,ds:0x4b1098
48b877: mov BYTE PTR [eax],0x3b
48b87a: push 0x19
48b87c: push 0x17
48b87e: push 0xa0
48b883: xor edx,edx
48b885: mov dl,BYTE PTR [esp+0xd]
48b889: inc edx
48b88a: xor eax,eax
48b88c: mov al,bl
48b88e: mov ecx,0xfffffff4
48b893: call 0x476870
48b898: push 0x19
48b89a: push 0x17
48b89c: push 0xa0
48b8a1: xor edx,edx
48b8a3: mov dl,BYTE PTR [esp+0xd]
48b8a7: add edx,0x2
48b8aa: xor eax,eax
48b8ac: mov al,bl
48b8ae: mov ecx,0xfffffff4
48b8b3: call 0x476870
48b8b8: push 0x19
48b8ba: push 0x17
48b8bc: push 0xa0
48b8c1: xor edx,edx
48b8c3: mov dl,BYTE PTR [esp+0xd]
48b8c7: add edx,0x3
48b8ca: xor eax,eax
48b8cc: mov al,bl
48b8ce: mov ecx,0xfffffff4
48b8d3: call 0x476870
48b8d8: push 0x19
48b8da: push 0x17
48b8dc: push 0xa0
48b8e1: xor edx,edx
48b8e3: mov dl,BYTE PTR [esp+0xd]
48b8e7: add edx,0x4
48b8ea: xor eax,eax
48b8ec: mov al,bl
48b8ee: mov ecx,0xfffffff4
48b8f3: call 0x476870
48b8f8: push 0x19
48b8fa: push 0x17
48b8fc: push 0xa0
48b901: xor edx,edx
48b903: mov dl,BYTE PTR [esp+0xd]
48b907: add edx,0x6
48b90a: xor eax,eax
48b90c: mov al,bl
48b90e: mov ecx,0xfffffff4
48b913: call 0x476870
48b918: push 0x19
48b91a: push 0x17
48b91c: push 0xa0
48b921: xor edx,edx
48b923: mov dl,BYTE PTR [esp+0xd]
48b927: add edx,0x8
48b92a: xor eax,eax
48b92c: mov al,bl
48b92e: mov ecx,0xfffffff4
48b933: call 0x476870
48b938: push 0x19
48b93a: push 0x17
48b93c: push 0xa0
48b941: xor edx,edx
48b943: mov dl,BYTE PTR [esp+0xd]
48b947: add edx,0xa
48b94a: xor eax,eax
48b94c: mov al,bl
48b94e: mov ecx,0xfffffff4
48b953: call 0x476870
48b958: push 0x37
48b95a: push 0x17
48b95c: push 0xa0
48b961: xor edx,edx
48b963: mov dl,BYTE PTR [esp+0xd]
48b967: add edx,0xc
48b96a: xor eax,eax
48b96c: mov al,bl
48b96e: mov ecx,0xfffffff4
48b973: call 0x476870
48b978: push 0x37
48b97a: push 0x17
48b97c: push 0xa0
48b981: xor edx,edx
48b983: mov dl,BYTE PTR [esp+0xd]
48b987: add edx,0xd
48b98a: xor eax,eax
48b98c: mov al,bl
48b98e: mov ecx,0xfffffff4
48b993: call 0x476870
48b998: push 0x37
48b99a: push 0x17
48b99c: push 0xa0
48b9a1: xor edx,edx
48b9a3: mov dl,BYTE PTR [esp+0xd]
48b9a7: add edx,0xf
48b9aa: xor eax,eax
48b9ac: mov al,bl
48b9ae: mov ecx,0xfffffff4
48b9b3: call 0x476870
48b9b8: push 0x37
48b9ba: push 0x17
48b9bc: push 0xa0
48b9c1: xor edx,edx
48b9c3: mov dl,BYTE PTR [esp+0xd]
48b9c7: add edx,0x11
48b9ca: xor eax,eax
48b9cc: mov al,bl
48b9ce: mov ecx,0xfffffff4
48b9d3: call 0x476870
48b9d8: push 0x37
48b9da: push 0x17
48b9dc: push 0xa0
48b9e1: xor edx,edx
48b9e3: mov dl,BYTE PTR [esp+0xd]
48b9e7: add edx,0x13
48b9ea: xor eax,eax
48b9ec: mov al,bl
48b9ee: mov ecx,0xfffffff4
48b9f3: call 0x476870
48b9f8: push 0x1e
48b9fa: push 0x11
48b9fc: push 0x78
48b9fe: xor edx,edx
48ba00: mov dl,BYTE PTR [esp+0xd]
48ba04: add edx,0x15
48ba07: xor eax,eax
48ba09: mov al,bl
48ba0b: mov ecx,0xffffffef
48ba10: call 0x476870
48ba15: push 0x3c
48ba17: push 0x1b
48ba19: push 0x78
48ba1b: xor edx,edx
48ba1d: mov dl,BYTE PTR [esp+0xd]
48ba21: add edx,0x1c
48ba24: xor eax,eax
48ba26: mov al,bl
48ba28: mov ecx,0xffffffe5
48ba2d: call 0x476870
48ba32: push 0x64
48ba34: push 0x1b
48ba36: push 0x82
48ba3b: xor edx,edx
48ba3d: mov dl,BYTE PTR [esp+0xd]
48ba41: add edx,0x1d
48ba44: xor eax,eax
48ba46: mov al,bl
48ba48: mov ecx,0xffffffe5
48ba4d: call 0x476870
48ba52: push 0x19
48ba54: push 0x17
48ba56: push 0xa0
48ba5b: xor edx,edx
48ba5d: mov dl,BYTE PTR [esp+0xd]
48ba61: add edx,0x1f
48ba64: xor eax,eax
48ba66: mov al,bl
48ba68: mov ecx,0xfffffff4
48ba6d: call 0x476870
48ba72: push 0x3e
48ba74: push 0x17
48ba76: push 0xa0
48ba7b: xor edx,edx
48ba7d: mov dl,BYTE PTR [esp+0xd]
48ba81: add edx,0x20
48ba84: xor eax,eax
48ba86: mov al,bl
48ba88: mov ecx,0xfffffff4
48ba8d: call 0x476870
48ba92: push 0x19
48ba94: push 0x17
48ba96: push 0xa0
48ba9b: xor edx,edx
48ba9d: mov dl,BYTE PTR [esp+0xd]
48baa1: add edx,0x21
48baa4: xor eax,eax
48baa6: mov al,bl
48baa8: mov ecx,0xfffffff4
48baad: call 0x476870
48bab2: push 0x19
48bab4: push 0x17
48bab6: push 0xa0
48babb: xor edx,edx
48babd: mov dl,BYTE PTR [esp+0xd]
48bac1: add edx,0x22
48bac4: xor eax,eax
48bac6: mov al,bl
48bac8: mov ecx,0xfffffff4
48bacd: call 0x476870
48bad2: push 0x2d
48bad4: push 0x2d
48bad6: push 0x78
48bad8: xor edx,edx
48bada: mov dl,BYTE PTR [esp+0xd]
48bade: add edx,0x25
48bae1: xor eax,eax
48bae3: mov al,bl
48bae5: mov ecx,0xfffffff8
48baea: call 0x476870
48baef: push 0x19
48baf1: push 0x17
48baf3: push 0xa0
48baf8: xor edx,edx
48bafa: mov dl,BYTE PTR [esp+0xd]
48bafe: add edx,0x2a
48bb01: xor eax,eax
48bb03: mov al,bl
48bb05: mov ecx,0xfffffff4
48bb0a: call 0x476870
48bb0f: push 0x32
48bb11: push 0xc
48bb13: push 0x64
48bb15: xor edx,edx
48bb17: mov dl,BYTE PTR [esp+0xd]
48bb1b: add edx,0x2c
48bb1e: xor eax,eax
48bb20: mov al,bl
48bb22: mov ecx,0xfffffff4
48bb27: call 0x476870
48bb2c: push 0xf
48bb2e: push 0x26
48bb30: push 0x57
48bb32: push 0x34
48bb34: push 0x1
48bb36: push 0x1
48bb38: push 0x7
48bb3a: push 0x0
48bb3c: xor eax,eax
48bb3e: mov al,bl
48bb40: mov ecx,0x2
48bb45: mov edx,0x3
48bb4a: call 0x4768f8
48bb4f: push 0xf
48bb51: push 0x5f
48bb53: push 0x4b
48bb55: push 0x82
48bb5a: push 0x1
48bb5c: push 0x1
48bb5e: push 0x7
48bb60: push 0x0
48bb62: xor eax,eax
48bb64: mov al,bl
48bb66: mov ecx,0x2
48bb6b: mov edx,0x4
48bb70: call 0x4768f8
48bb75: push 0xf
48bb77: push 0x26
48bb79: push 0x5a
48bb7b: push 0x34
48bb7d: push 0x1
48bb7f: push 0x2
48bb81: push 0xe
48bb83: push 0x0
48bb85: xor eax,eax
48bb87: mov al,bl
48bb89: mov ecx,0x5
48bb8e: mov edx,0x5
48bb93: call 0x4768f8
48bb98: push 0xf
48bb9a: push 0x37
48bb9c: push 0x64
48bb9e: push 0x4b
48bba0: push 0x1
48bba2: push 0x2
48bba4: push 0xe
48bba6: push 0x0
48bba8: xor eax,eax
48bbaa: mov al,bl
48bbac: mov ecx,0x5
48bbb1: mov edx,0x6
48bbb6: call 0x4768f8
48bbbb: push 0xf
48bbbd: push 0x3f
48bbbf: push 0x41
48bbc1: push 0x4e
48bbc3: push 0x1
48bbc5: push 0x1
48bbc7: push 0x7
48bbc9: push 0x0
48bbcb: xor eax,eax
48bbcd: mov al,bl
48bbcf: mov ecx,0x2
48bbd4: mov edx,0x8
48bbd9: call 0x4768f8
48bbde: push 0xf
48bbe0: push 0x8a
48bbe5: push 0x44
48bbe7: push 0xa0
48bbec: push 0x1
48bbee: push 0x1
48bbf0: push 0x7
48bbf2: push 0x0
48bbf4: xor eax,eax
48bbf6: mov al,bl
48bbf8: mov ecx,0x2
48bbfd: mov edx,0x9
48bc02: call 0x4768f8
48bc07: push 0x14
48bc09: push 0x4b
48bc0b: push 0x4b
48bc0d: push 0x5a
48bc0f: push 0x1
48bc11: push 0x2
48bc13: push 0xe
48bc15: push 0x0
48bc17: xor eax,eax
48bc19: mov al,bl
48bc1b: mov ecx,0x5
48bc20: mov edx,0xa
48bc25: call 0x4768f8
48bc2a: push 0xa
48bc2c: push 0x82
48bc31: push 0x32
48bc33: push 0xa0
48bc38: push 0x1
48bc3a: push 0x2
48bc3c: push 0xe
48bc3e: push 0x0
48bc40: xor eax,eax
48bc42: mov al,bl
48bc44: mov ecx,0x5
48bc49: mov edx,0xb
48bc4e: call 0x4768f8
48bc53: push 0x23
48bc55: push 0x46
48bc57: push 0x5a
48bc59: push 0x6b
48bc5b: push 0x1
48bc5d: push 0x1
48bc5f: push 0x7
48bc61: push 0x0
48bc63: xor eax,eax
48bc65: mov al,bl
48bc67: mov ecx,0x2
48bc6c: mov edx,0xd
48bc71: call 0x4768f8
48bc76: push 0xffffffba
48bc78: push 0x5a
48bc7a: push 0x53
48bc7c: push 0x78
48bc7e: push 0x1
48bc80: push 0x1
48bc82: push 0x7
48bc84: push 0x0
48bc86: xor eax,eax
48bc88: mov al,bl
48bc8a: mov ecx,0x2
48bc8f: mov edx,0xe
48bc94: call 0x4768f8
48bc99: push 0x23
48bc9b: push 0x46
48bc9d: push 0x5a
48bc9f: push 0x6b
48bca1: push 0x1
48bca3: push 0x2
48bca5: push 0xe
48bca7: push 0x0
48bca9: xor eax,eax
48bcab: mov al,bl
48bcad: mov ecx,0x5
48bcb2: mov edx,0xf
48bcb7: call 0x4768f8
48bcbc: push 0xffffffba
48bcbe: push 0x5a
48bcc0: push 0x53
48bcc2: push 0x78
48bcc4: push 0x1
48bcc6: push 0x2
48bcc8: push 0xe
48bcca: push 0x0
48bccc: xor eax,eax
48bcce: mov al,bl
48bcd0: mov ecx,0x5
48bcd5: mov edx,0x10
48bcda: call 0x4768f8
48bcdf: push 0x1e
48bce1: push 0x28
48bce3: push 0x4b
48bce5: push 0x5a
48bce7: push 0x1
48bce9: push 0x2
48bceb: push 0xa
48bced: push 0x2
48bcef: xor eax,eax
48bcf1: mov al,bl
48bcf3: mov ecx,0x5
48bcf8: mov edx,0x1a
48bcfd: call 0x4768f8
48bd02: push 0x1e
48bd04: push 0x2d
48bd06: push 0x5a
48bd08: push 0x78
48bd0a: push 0x1
48bd0c: push 0x1
48bd0e: push 0x8
48bd10: push 0x1
48bd12: xor eax,eax
48bd14: mov al,bl
48bd16: mov ecx,0x8
48bd1b: mov edx,0x1a
48bd20: call 0x4768f8
48bd25: push 0x1e
48bd27: push 0x50
48bd29: push 0x46
48bd2b: push 0x78
48bd2d: push 0x1
48bd2f: push 0x2
48bd31: push 0x3
48bd33: push 0x0
48bd35: xor eax,eax
48bd37: mov al,bl
48bd39: mov ecx,0xb
48bd3e: mov edx,0x1a
48bd43: call 0x4768f8
48bd48: push 0xffffffc4
48bd4a: push 0x2d
48bd4c: push 0x5a
48bd4e: push 0x69
48bd50: push 0x1
48bd52: push 0x2
48bd54: push 0x3
48bd56: push 0x2
48bd58: xor eax,eax
48bd5a: mov al,bl
48bd5c: mov ecx,0x1
48bd61: mov edx,0x1d
48bd66: call 0x4768f8
48bd6b: push 0xffffffc4
48bd6d: push 0x2d
48bd6f: push 0x5a
48bd71: push 0x69
48bd73: push 0x1
48bd75: push 0x2
48bd77: push 0x4
48bd79: push 0x2
48bd7b: xor eax,eax
48bd7d: mov al,bl
48bd7f: mov ecx,0x3
48bd84: mov edx,0x1d
48bd89: call 0x4768f8
48bd8e: push 0xffffffc4
48bd90: push 0x2d
48bd92: push 0x5a
48bd94: push 0x69
48bd96: push 0x1
48bd98: push 0x2
48bd9a: push 0x3
48bd9c: push 0x2
48bd9e: xor eax,eax
48bda0: mov al,bl
48bda2: mov ecx,0x5
48bda7: mov edx,0x1d
48bdac: call 0x4768f8
48bdb1: push 0xffffffc4
48bdb3: push 0x2d
48bdb5: push 0x5a
48bdb7: push 0x69
48bdb9: push 0x1
48bdbb: push 0x2
48bdbd: push 0x4
48bdbf: push 0x2
48bdc1: xor eax,eax
48bdc3: mov al,bl
48bdc5: mov ecx,0x7
48bdca: mov edx,0x1d
48bdcf: call 0x4768f8
48bdd4: push 0xffffffc4
48bdd6: push 0x2d
48bdd8: push 0x5a
48bdda: push 0x69
48bddc: push 0x1
48bdde: push 0x2
48bde0: push 0x3
48bde2: push 0x3
48bde4: xor eax,eax
48bde6: mov al,bl
48bde8: mov ecx,0x9
48bded: mov edx,0x1d
48bdf2: call 0x4768f8
48bdf7: push 0xffffffc4
48bdf9: push 0x2d
48bdfb: push 0x5a
48bdfd: push 0x69
48bdff: push 0x1
48be01: push 0x2
48be03: push 0x4
48be05: push 0x2
48be07: xor eax,eax
48be09: mov al,bl
48be0b: mov ecx,0xb
48be10: mov edx,0x1d
48be15: call 0x4768f8
48be1a: push 0xffffffc4
48be1c: push 0x2d
48be1e: push 0x5a
48be20: push 0x69
48be22: push 0x1
48be24: push 0x2
48be26: push 0x3
48be28: push 0x2
48be2a: xor eax,eax
48be2c: mov al,bl
48be2e: mov ecx,0xd
48be33: mov edx,0x1d
48be38: call 0x4768f8
48be3d: push 0xffffffc4
48be3f: push 0x2d
48be41: push 0x5a
48be43: push 0x69
48be45: push 0x1
48be47: push 0x2
48be49: push 0x12
48be4b: push 0x3
48be4d: xor eax,eax
48be4f: mov al,bl
48be51: mov ecx,0xf
48be56: mov edx,0x1d
48be5b: call 0x4768f8
48be60: xor eax,eax
48be62: mov al,bl
48be64: imul eax,eax,0x16
48be67: cmp BYTE PTR [esi+eax*8-0xa0],0xe
48be6f: jne 0x48cbc7
48be75: xor eax,eax
48be77: mov al,bl
48be79: imul eax,eax,0x16
48be7c: cmp BYTE PTR [esi+eax*8-0x45],0x17
48be81: jne 0x48bef0
48be83: xor eax,eax
48be85: mov al,bl
48be87: imul eax,eax,0x16
48be8a: fild WORD PTR [esi+eax*8-0x3c]
48be8e: fdiv DWORD PTR ds:0x48dcf0
48be94: call 0x40287c
48be99: xor eax,eax
48be9b: mov al,bl
48be9d: imul eax,eax,0x16
48bea0: fild WORD PTR [esi+eax*8-0x3c]
48bea4: fdiv DWORD PTR ds:0x48dcf0
48beaa: fcompp
48beac: fnstsw ax
48beae: sahf
48beaf: jne 0x48bef0
48beb1: xor eax,eax
48beb3: mov al,bl
48beb5: imul eax,eax,0x16
48beb8: movzx eax,BYTE PTR [esi+eax*8-0x44]
48bebd: xor edx,edx
48bebf: mov dl,BYTE PTR [esp+0x1]
48bec3: add edx,0x21
48bec6: cmp eax,edx
48bec8: jne 0x48bede
48beca: xor eax,eax
48becc: mov al,bl
48bece: imul eax,eax,0x16
48bed1: mov dl,BYTE PTR [esp+0x1]
48bed5: add dl,0x22
48bed8: mov BYTE PTR [esi+eax*8-0x44],dl
48bedc: jmp 0x48bef0
48bede: xor eax,eax
48bee0: mov al,bl
48bee2: imul eax,eax,0x16
48bee5: mov dl,BYTE PTR [esp+0x1]
48bee9: add dl,0x21
48beec: mov BYTE PTR [esi+eax*8-0x44],dl
48bef0: xor eax,eax
48bef2: mov al,bl
48bef4: imul eax,eax,0x16
48bef7: cmp BYTE PTR [esi+eax*8-0x45],0x19
48befc: jne 0x48c100
48bf02: xor eax,eax
48bf04: mov al,bl
48bf06: imul eax,eax,0x16
48bf09: cmp WORD PTR [esi+eax*8-0x3c],0x0
48bf0f: jne 0x48bf23
48bf11: xor eax,eax
48bf13: mov al,bl
48bf15: imul eax,eax,0x16
48bf18: mov dl,BYTE PTR [esp+0x1]
48bf1c: add dl,0x23
48bf1f: mov BYTE PTR [esi+eax*8-0x44],dl
48bf23: xor eax,eax
48bf25: mov al,bl
48bf27: imul eax,eax,0x16
48bf2a: cmp WORD PTR [esi+eax*8-0x3c],0x7
48bf30: jne 0x48bf44
48bf32: xor eax,eax
48bf34: mov al,bl
48bf36: imul eax,eax,0x16
48bf39: mov dl,BYTE PTR [esp+0x1]
48bf3d: add dl,0x24
48bf40: mov BYTE PTR [esi+eax*8-0x44],dl
48bf44: xor eax,eax
48bf46: mov al,bl
48bf48: imul eax,eax,0x16
48bf4b: cmp WORD PTR [esi+eax*8-0x3c],0xa
48bf51: jne 0x48c0e9
48bf57: xor eax,eax
48bf59: mov al,bl
48bf5b: imul eax,eax,0x16
48bf5e: mov dl,BYTE PTR [esp+0x1]
48bf62: add dl,0x25
48bf65: mov BYTE PTR [esi+eax*8-0x44],dl
48bf69: xor eax,eax
48bf6b: mov al,bl
48bf6d: imul eax,eax,0x16
48bf70: cmp BYTE PTR [esi+eax*8-0x43],0x1
48bf75: jne 0x48bfc9
48bf77: xor eax,eax
48bf79: mov al,bl
48bf7b: imul eax,eax,0x16
48bf7e: cmp BYTE PTR [esi+eax*8-0x41],0x1
48bf83: jne 0x48bfc9
48bf85: xor eax,eax
48bf87: mov al,bl
48bf89: imul eax,eax,0x16
48bf8c: fld QWORD PTR [esi+eax*8-0xb0]
48bf93: fadd DWORD PTR ds:0x48dd14
48bf99: add esp,0xfffffff8
48bf9c: fstp QWORD PTR [esp]
48bf9f: fwait
48bfa0: xor eax,eax
48bfa2: mov al,bl
48bfa4: imul eax,eax,0x16
48bfa7: fld QWORD PTR [esi+eax*8-0xa8]
48bfae: fsub DWORD PTR ds:0x48dcec
48bfb4: add esp,0xfffffff8
48bfb7: fstp QWORD PTR [esp]
48bfba: fwait
48bfbb: mov ecx,ebx
48bfbd: mov edx,0x48dcd4
48bfc2: mov al,0x1d
48bfc4: call 0x476a04
48bfc9: xor eax,eax
48bfcb: mov al,bl
48bfcd: imul eax,eax,0x16
48bfd0: cmp BYTE PTR [esi+eax*8-0x43],0x2
48bfd5: jne 0x48c029
48bfd7: xor eax,eax
48bfd9: mov al,bl
48bfdb: imul eax,eax,0x16
48bfde: cmp BYTE PTR [esi+eax*8-0x41],0x1
48bfe3: jne 0x48c029
48bfe5: xor eax,eax
48bfe7: mov al,bl
48bfe9: imul eax,eax,0x16
48bfec: fld QWORD PTR [esi+eax*8-0xb0]
48bff3: fsub DWORD PTR ds:0x48dd14
48bff9: add esp,0xfffffff8
48bffc: fstp QWORD PTR [esp]
48bfff: fwait
48c000: xor eax,eax
48c002: mov al,bl
48c004: imul eax,eax,0x16
48c007: fld QWORD PTR [esi+eax*8-0xa8]
48c00e: fsub DWORD PTR ds:0x48dcec
48c014: add esp,0xfffffff8
48c017: fstp QWORD PTR [esp]
48c01a: fwait
48c01b: mov ecx,ebx
48c01d: mov edx,0x48dcd4
48c022: mov al,0x1d
48c024: call 0x476a04
48c029: xor eax,eax
48c02b: mov al,bl
48c02d: imul eax,eax,0x16
48c030: cmp BYTE PTR [esi+eax*8-0x43],0x1
48c035: jne 0x48c089
48c037: xor eax,eax
48c039: mov al,bl
48c03b: imul eax,eax,0x16
48c03e: cmp BYTE PTR [esi+eax*8-0x41],0x2
48c043: jne 0x48c089
48c045: xor eax,eax
48c047: mov al,bl
48c049: imul eax,eax,0x16
48c04c: fld QWORD PTR [esi+eax*8-0xb0]
48c053: fadd DWORD PTR ds:0x48dd14
48c059: add esp,0xfffffff8
48c05c: fstp QWORD PTR [esp]
48c05f: fwait
48c060: xor eax,eax
48c062: mov al,bl
48c064: imul eax,eax,0x16
48c067: fld QWORD PTR [esi+eax*8-0xa8]
48c06e: fsub DWORD PTR ds:0x48dcec
48c074: add esp,0xfffffff8
48c077: fstp QWORD PTR [esp]
48c07a: fwait
48c07b: mov ecx,ebx
48c07d: mov edx,0x48dce0
48c082: mov al,0x1d
48c084: call 0x476a04
48c089: xor eax,eax
48c08b: mov al,bl
48c08d: imul eax,eax,0x16
48c090: cmp BYTE PTR [esi+eax*8-0x43],0x2
48c095: jne 0x48c0e9
48c097: xor eax,eax
48c099: mov al,bl
48c09b: imul eax,eax,0x16
48c09e: cmp BYTE PTR [esi+eax*8-0x41],0x2
48c0a3: jne 0x48c0e9
48c0a5: xor eax,eax
48c0a7: mov al,bl
48c0a9: imul eax,eax,0x16
48c0ac: fld QWORD PTR [esi+eax*8-0xb0]
48c0b3: fsub DWORD PTR ds:0x48dd14
48c0b9: add esp,0xfffffff8
48c0bc: fstp QWORD PTR [esp]
48c0bf: fwait
48c0c0: xor eax,eax
48c0c2: mov al,bl
48c0c4: imul eax,eax,0x16
48c0c7: fld QWORD PTR [esi+eax*8-0xa8]
48c0ce: fsub DWORD PTR ds:0x48dcec
48c0d4: add esp,0xfffffff8
48c0d7: fstp QWORD PTR [esp]
48c0da: fwait
48c0db: mov ecx,ebx
48c0dd: mov edx,0x48dce0
48c0e2: mov al,0x1d
48c0e4: call 0x476a04
48c0e9: xor eax,eax
48c0eb: mov al,bl
48c0ed: imul eax,eax,0x16
48c0f0: cmp WORD PTR [esi+eax*8-0x3c],0x3
48c0f6: jne 0x48c100
48c0f8: mov eax,ds:0x4b1098
48c0fd: mov BYTE PTR [eax],0x3c
48c100: xor eax,eax
48c102: mov al,bl
48c104: imul eax,eax,0x16
48c107: cmp BYTE PTR [esi+eax*8-0x45],0x1a
48c10c: jne 0x48c234
48c112: xor eax,eax
48c114: mov al,bl
48c116: imul eax,eax,0x16
48c119: cmp WORD PTR [esi+eax*8-0x3c],0x0
48c11f: jne 0x48c133
48c121: xor eax,eax
48c123: mov al,bl
48c125: imul eax,eax,0x16
48c128: mov dl,BYTE PTR [esp+0x1]
48c12c: add dl,0x26
48c12f: mov BYTE PTR [esi+eax*8-0x44],dl
48c133: xor eax,eax
48c135: mov al,bl
48c137: imul eax,eax,0x16
48c13a: cmp WORD PTR [esi+eax*8-0x3c],0x5
48c140: jne 0x48c1fc
48c146: xor eax,eax
48c148: mov al,bl
48c14a: imul eax,eax,0x16
48c14d: mov dl,BYTE PTR [esp+0x1]
48c151: add dl,0x27
48c154: mov BYTE PTR [esi+eax*8-0x44],dl
48c158: xor eax,eax
48c15a: mov al,bl
48c15c: imul eax,eax,0x16
48c15f: cmp BYTE PTR [esi+eax*8-0x43],0x1
48c164: jne 0x48c1aa
48c166: xor eax,eax
48c168: mov al,bl
48c16a: imul eax,eax,0x16
48c16d: fld QWORD PTR [esi+eax*8-0xb0]
48c174: fadd DWORD PTR ds:0x48dd70
48c17a: add esp,0xfffffff8
48c17d: fstp QWORD PTR [esp]
48c180: fwait
48c181: xor eax,eax
48c183: mov al,bl
48c185: imul eax,eax,0x16
48c188: fld QWORD PTR [esi+eax*8-0xa8]
48c18f: fsub DWORD PTR ds:0x48dd74
48c195: add esp,0xfffffff8
48c198: fstp QWORD PTR [esp]
48c19b: fwait
48c19c: mov ecx,ebx
48c19e: mov edx,0x48dcd4
48c1a3: mov al,0x1e
48c1a5: call 0x476a04
48c1aa: xor eax,eax
48c1ac: mov al,bl
48c1ae: imul eax,eax,0x16
48c1b1: cmp BYTE PTR [esi+eax*8-0x43],0x2
48c1b6: jne 0x48c1fc
48c1b8: xor eax,eax
48c1ba: mov al,bl
48c1bc: imul eax,eax,0x16
48c1bf: fld QWORD PTR [esi+eax*8-0xb0]
48c1c6: fsub DWORD PTR ds:0x48dd70
48c1cc: add esp,0xfffffff8
48c1cf: fstp QWORD PTR [esp]
48c1d2: fwait
48c1d3: xor eax,eax
48c1d5: mov al,bl
48c1d7: imul eax,eax,0x16
48c1da: fld QWORD PTR [esi+eax*8-0xa8]
48c1e1: fsub DWORD PTR ds:0x48dd74
48c1e7: add esp,0xfffffff8
48c1ea: fstp QWORD PTR [esp]
48c1ed: fwait
48c1ee: mov ecx,ebx
48c1f0: mov edx,0x48dcd4
48c1f5: mov al,0x1e
48c1f7: call 0x476a04
48c1fc: xor eax,eax
48c1fe: mov al,bl
48c200: imul eax,eax,0x16
48c203: cmp WORD PTR [esi+eax*8-0x3c],0x20
48c209: jne 0x48c21d
48c20b: xor eax,eax
48c20d: mov al,bl
48c20f: imul eax,eax,0x16
48c212: mov dl,BYTE PTR [esp+0x1]
48c216: add dl,0x26
48c219: mov BYTE PTR [esi+eax*8-0x44],dl
48c21d: xor eax,eax
48c21f: mov al,bl
48c221: imul eax,eax,0x16
48c224: cmp WORD PTR [esi+eax*8-0x3c],0x3
48c22a: jne 0x48c234
48c22c: mov eax,ds:0x4b1098
48c231: mov BYTE PTR [eax],0x3d
48c234: xor eax,eax
48c236: mov al,bl
48c238: imul eax,eax,0x16
48c23b: cmp BYTE PTR [esi+eax*8-0x45],0x1b
48c240: jne 0x48c3ea
48c246: xor eax,eax
48c248: mov al,bl
48c24a: imul eax,eax,0x16
48c24d: cmp WORD PTR [esi+eax*8-0x3c],0x0
48c253: jne 0x48c267
48c255: xor eax,eax
48c257: mov al,bl
48c259: imul eax,eax,0x16
48c25c: mov dl,BYTE PTR [esp+0x1]
48c260: add dl,0x28
48c263: mov BYTE PTR [esi+eax*8-0x44],dl
48c267: xor eax,eax
48c269: mov al,bl
48c26b: imul eax,eax,0x16
48c26e: cmp WORD PTR [esi+eax*8-0x3c],0x1
48c274: jne 0x48c288
48c276: xor eax,eax
48c278: mov al,bl
48c27a: imul eax,eax,0x16
48c27d: mov dl,BYTE PTR [esp+0x1]
48c281: add dl,0x28
48c284: mov BYTE PTR [esi+eax*8-0x44],dl
48c288: xor eax,eax
48c28a: mov al,bl
48c28c: imul eax,eax,0x16
48c28f: cmp WORD PTR [esi+eax*8-0x3c],0x3
48c295: jne 0x48c2a9
48c297: xor eax,eax
48c299: mov al,bl
48c29b: imul eax,eax,0x16
48c29e: mov dl,BYTE PTR [esp+0x1]
48c2a2: add dl,0x29
48c2a5: mov BYTE PTR [esi+eax*8-0x44],dl
48c2a9: xor eax,eax
48c2ab: mov al,bl
48c2ad: imul eax,eax,0x16
48c2b0: cmp WORD PTR [esi+eax*8-0x3c],0x5
48c2b6: jne 0x48c2ca
48c2b8: xor eax,eax
48c2ba: mov al,bl
48c2bc: imul eax,eax,0x16
48c2bf: mov dl,BYTE PTR [esp+0x1]
48c2c3: add dl,0x2a
48c2c6: mov BYTE PTR [esi+eax*8-0x44],dl
48c2ca: xor eax,eax
48c2cc: mov al,bl
48c2ce: imul eax,eax,0x16
48c2d1: cmp WORD PTR [esi+eax*8-0x3c],0x7
48c2d7: jne 0x48c2eb
48c2d9: xor eax,eax
48c2db: mov al,bl
48c2dd: imul eax,eax,0x16
48c2e0: mov dl,BYTE PTR [esp+0x1]
48c2e4: add dl,0x2b
48c2e7: mov BYTE PTR [esi+eax*8-0x44],dl
48c2eb: xor eax,eax
48c2ed: mov al,bl
48c2ef: imul eax,eax,0x16
48c2f2: cmp WORD PTR [esi+eax*8-0x3c],0x9
48c2f8: jne 0x48c308
48c2fa: xor eax,eax
48c2fc: mov al,bl
48c2fe: imul eax,eax,0x16
48c301: mov WORD PTR [esi+eax*8-0x3c],0x1
48c308: xor eax,eax
48c30a: mov al,bl
48c30c: imul eax,eax,0x16
48c30f: cmp WORD PTR [esi+eax*8-0x3c],0x0
48c315: jne 0x48c31f
48c317: mov eax,ds:0x4b1098
48c31c: mov BYTE PTR [eax],0x3e
48c31f: xor eax,eax
48c321: mov al,bl
48c323: imul eax,eax,0x16
48c326: cmp BYTE PTR [esi+eax*8-0x43],0x1
48c32b: jne 0x48c349
48c32d: xor eax,eax
48c32f: mov al,bl
48c331: imul eax,eax,0x16
48c334: cmp BYTE PTR [esi+eax*8-0x41],0x1
48c339: jne 0x48c349
48c33b: push 0x40180000
48c340: push 0x0
48c342: mov eax,ebx
48c344: call 0x47648c
48c349: xor eax,eax
48c34b: mov al,bl
48c34d: imul eax,eax,0x16
48c350: cmp BYTE PTR [esi+eax*8-0x43],0x2
48c355: jne 0x48c373
48c357: xor eax,eax
48c359: mov al,bl
48c35b: imul eax,eax,0x16
48c35e: cmp BYTE PTR [esi+eax*8-0x41],0x1
48c363: jne 0x48c373
48c365: push 0xc0180000
48c36a: push 0x0
48c36c: mov eax,ebx
48c36e: call 0x47648c
48c373: xor eax,eax
48c375: mov al,bl
48c377: imul eax,eax,0x16
48c37a: cmp BYTE PTR [esi+eax*8-0x43],0x1
48c37f: jne 0x48c39d
48c381: xor eax,eax
48c383: mov al,bl
48c385: imul eax,eax,0x16
48c388: cmp BYTE PTR [esi+eax*8-0x41],0x2
48c38d: jne 0x48c39d
48c38f: push 0x40220000
48c394: push 0x0
48c396: mov eax,ebx
48c398: call 0x47648c
48c39d: xor eax,eax
48c39f: mov al,bl
48c3a1: imul eax,eax,0x16
48c3a4: cmp BYTE PTR [esi+eax*8-0x43],0x2
48c3a9: jne 0x48c3c7
48c3ab: xor eax,eax
48c3ad: mov al,bl
48c3af: imul eax,eax,0x16
48c3b2: cmp BYTE PTR [esi+eax*8-0x41],0x2
48c3b7: jne 0x48c3c7
48c3b9: push 0xc0220000
48c3be: push 0x0
48c3c0: mov eax,ebx
48c3c2: call 0x47648c
48c3c7: xor eax,eax
48c3c9: mov al,bl
48c3cb: imul eax,eax,0x16
48c3ce: fld QWORD PTR [esi+eax*8-0xa8]
48c3d5: fadd DWORD PTR ds:0x48dd5c
48c3db: xor eax,eax
48c3dd: mov al,bl
48c3df: imul eax,eax,0x16
48c3e2: fstp QWORD PTR [esi+eax*8-0xa8]
48c3e9: fwait
48c3ea: xor eax,eax
48c3ec: mov al,bl
48c3ee: imul eax,eax,0x16
48c3f1: cmp BYTE PTR [esi+eax*8-0x45],0x1c
48c3f6: jne 0x48c5f7
48c3fc: xor eax,eax
48c3fe: mov al,bl
48c400: imul eax,eax,0x16
48c403: cmp WORD PTR [esi+eax*8-0x3c],0x0
48c409: jne 0x48c41d
48c40b: xor eax,eax
48c40d: mov al,bl
48c40f: imul eax,eax,0x16
48c412: mov dl,BYTE PTR [esp+0x1]
48c416: add dl,0x2c
48c419: mov BYTE PTR [esi+eax*8-0x44],dl
48c41d: xor eax,eax
48c41f: mov al,bl
48c421: imul eax,eax,0x16
48c424: cmp WORD PTR [esi+eax*8-0x3c],0x3
48c42a: jne 0x48c43e
48c42c: xor eax,eax
48c42e: mov al,bl
48c430: imul eax,eax,0x16
48c433: mov dl,BYTE PTR [esp+0x1]
48c437: add dl,0x2d
48c43a: mov BYTE PTR [esi+eax*8-0x44],dl
48c43e: xor eax,eax
48c440: mov al,bl
48c442: imul eax,eax,0x16
48c445: cmp WORD PTR [esi+eax*8-0x3c],0x5
48c44b: jne 0x48c45f
48c44d: xor eax,eax
48c44f: mov al,bl
48c451: imul eax,eax,0x16
48c454: mov dl,BYTE PTR [esp+0x1]
48c458: add dl,0x2e
48c45b: mov BYTE PTR [esi+eax*8-0x44],dl
48c45f: xor eax,eax
48c461: mov al,bl
48c463: imul eax,eax,0x16
48c466: cmp WORD PTR [esi+eax*8-0x3c],0x4
48c46c: jl 0x48c58f
48c472: xor eax,eax
48c474: mov al,bl
48c476: imul eax,eax,0x16
48c479: cmp WORD PTR [esi+eax*8-0x3c],0xf
48c47f: jg 0x48c58f
48c485: xor eax,eax
48c487: mov al,bl
48c489: imul eax,eax,0x16
48c48c: cmp BYTE PTR [esi+eax*8-0x43],0x1
48c491: jne 0x48c4af
48c493: xor eax,eax
48c495: mov al,bl
48c497: imul eax,eax,0x16
48c49a: cmp BYTE PTR [esi+eax*8-0x41],0x1
48c49f: jne 0x48c4af
48c4a1: push 0x40100000
48c4a6: push 0x0
48c4a8: mov eax,ebx
48c4aa: call 0x47648c
48c4af: xor eax,eax
48c4b1: mov al,bl
48c4b3: imul eax,eax,0x16
48c4b6: cmp BYTE PTR [esi+eax*8-0x43],0x2
48c4bb: jne 0x48c4d9
48c4bd: xor eax,eax
48c4bf: mov al,bl
48c4c1: imul eax,eax,0x16
48c4c4: cmp BYTE PTR [esi+eax*8-0x41],0x1
48c4c9: jne 0x48c4d9
48c4cb: push 0xc0100000
48c4d0: push 0x0
48c4d2: mov eax,ebx
48c4d4: call 0x47648c
48c4d9: xor eax,eax
48c4db: mov al,bl
48c4dd: imul eax,eax,0x16
48c4e0: cmp BYTE PTR [esi+eax*8-0x43],0x1
48c4e5: jne 0x48c503
48c4e7: xor eax,eax
48c4e9: mov al,bl
48c4eb: imul eax,eax,0x16
48c4ee: cmp BYTE PTR [esi+eax*8-0x41],0x2
48c4f3: jne 0x48c503
48c4f5: push 0x40200000
48c4fa: push 0x0
48c4fc: mov eax,ebx
48c4fe: call 0x47648c
48c503: xor eax,eax
48c505: mov al,bl
48c507: imul eax,eax,0x16
48c50a: cmp BYTE PTR [esi+eax*8-0x43],0x2
48c50f: jne 0x48c52d
48c511: xor eax,eax
48c513: mov al,bl
48c515: imul eax,eax,0x16
48c518: cmp BYTE PTR [esi+eax*8-0x41],0x2
48c51d: jne 0x48c52d
48c51f: push 0xc0200000
48c524: push 0x0
48c526: mov eax,ebx
48c528: call 0x47648c
48c52d: xor eax,eax
48c52f: mov al,bl
48c531: imul eax,eax,0x16
48c534: cmp BYTE PTR [esi+eax*8-0x41],0x1
48c539: jne 0x48c55e
48c53b: xor eax,eax
48c53d: mov al,bl
48c53f: imul eax,eax,0x16
48c542: fld QWORD PTR [esi+eax*8-0xa8]
48c549: fsub DWORD PTR ds:0x48dd58
48c54f: xor eax,eax
48c551: mov al,bl
48c553: imul eax,eax,0x16
48c556: fstp QWORD PTR [esi+eax*8-0xa8]
48c55d: fwait
48c55e: xor eax,eax
48c560: mov al,bl
48c562: imul eax,eax,0x16
48c565: cmp BYTE PTR [esi+eax*8-0x41],0x2
48c56a: jne 0x48c58f
48c56c: xor eax,eax
48c56e: mov al,bl
48c570: imul eax,eax,0x16
48c573: fld QWORD PTR [esi+eax*8-0xa8]
48c57a: fsub DWORD PTR ds:0x48dd50
48c580: xor eax,eax
48c582: mov al,bl
48c584: imul eax,eax,0x16
48c587: fstp QWORD PTR [esi+eax*8-0xa8]
48c58e: fwait
48c58f: xor eax,eax
48c591: mov al,bl
48c593: imul eax,eax,0x16
48c596: cmp WORD PTR [esi+eax*8-0x3c],0x11
48c59c: jne 0x48c5d4
48c59e: xor eax,eax
48c5a0: mov al,bl
48c5a2: imul eax,eax,0x16
48c5a5: mov BYTE PTR [esi+eax*8-0x46],0x1
48c5aa: xor eax,eax
48c5ac: mov al,bl
48c5ae: imul eax,eax,0x16
48c5b1: mov BYTE PTR [esi+eax*8-0x42],0x0
48c5b6: xor eax,eax
48c5b8: mov al,bl
48c5ba: imul eax,eax,0x16
48c5bd: mov BYTE PTR [esi+eax*8-0x38],0xfe
48c5c2: xor eax,eax
48c5c4: mov al,bl
48c5c6: imul eax,eax,0x16
48c5c9: mov dl,BYTE PTR [esp+0x1]
48c5cd: add dl,0x15
48c5d0: mov BYTE PTR [esi+eax*8-0x44],dl
48c5d4: xor eax,eax
48c5d6: mov al,bl
48c5d8: imul eax,eax,0x16
48c5db: cmp WORD PTR [esi+eax*8-0x3c],0x2
48c5e1: jne 0x48c5eb
48c5e3: mov eax,ds:0x4b1098
48c5e8: mov BYTE PTR [eax],0x3c
48c5eb: xor eax,eax
48c5ed: mov al,bl
48c5ef: imul eax,eax,0x16
48c5f2: mov BYTE PTR [esi+eax*8-0x47],0x1
48c5f7: xor eax,eax
48c5f9: mov al,bl
48c5fb: imul eax,eax,0x16
48c5fe: cmp BYTE PTR [esi+eax*8-0x45],0x1d
48c603: jne 0x48c701
48c609: xor eax,eax
48c60b: mov al,bl
48c60d: imul eax,eax,0x16
48c610: fild WORD PTR [esi+eax*8-0x3c]
48c614: fdiv DWORD PTR ds:0x48dd34
48c61a: call 0x40287c
48c61f: xor eax,eax
48c621: mov al,bl
48c623: imul eax,eax,0x16
48c626: fild WORD PTR [esi+eax*8-0x3c]
48c62a: fdiv DWORD PTR ds:0x48dd34
48c630: fcompp
48c632: fnstsw ax
48c634: sahf
48c635: jne 0x48c676
48c637: xor eax,eax
48c639: mov al,bl
48c63b: imul eax,eax,0x16
48c63e: movzx eax,BYTE PTR [esi+eax*8-0x44]
48c643: xor edx,edx
48c645: mov dl,BYTE PTR [esp+0x1]
48c649: add edx,0x2f
48c64c: cmp eax,edx
48c64e: jne 0x48c664
48c650: xor eax,eax
48c652: mov al,bl
48c654: imul eax,eax,0x16
48c657: mov dl,BYTE PTR [esp+0x1]
48c65b: add dl,0x30
48c65e: mov BYTE PTR [esi+eax*8-0x44],dl
48c662: jmp 0x48c676
48c664: xor eax,eax
48c666: mov al,bl
48c668: imul eax,eax,0x16
48c66b: mov dl,BYTE PTR [esp+0x1]
48c66f: add dl,0x2f
48c672: mov BYTE PTR [esi+eax*8-0x44],dl
48c676: xor eax,eax
48c678: mov al,bl
48c67a: imul eax,eax,0x16
48c67d: cmp WORD PTR [esi+eax*8-0x3c],0x1
48c683: jne 0x48c701
48c685: xor eax,eax
48c687: mov al,bl
48c689: imul eax,eax,0x16
48c68c: push DWORD PTR [esi+eax*8-0xac]
48c693: push DWORD PTR [esi+eax*8-0xb0]
48c69a: xor eax,eax
48c69c: mov al,bl
48c69e: imul eax,eax,0x16
48c6a1: fld QWORD PTR [esi+eax*8-0xa8]
48c6a8: fsub DWORD PTR ds:0x48dd20
48c6ae: add esp,0xfffffff8
48c6b1: fstp QWORD PTR [esp]
48c6b4: fwait
48c6b5: mov ecx,ebx
48c6b7: mov edx,0x48dcd4
48c6bc: mov al,0x1f
48c6be: call 0x476a04
48c6c3: xor eax,eax
48c6c5: mov al,bl
48c6c7: imul eax,eax,0x16
48c6ca: push DWORD PTR [esi+eax*8-0xac]
48c6d1: push DWORD PTR [esi+eax*8-0xb0]
48c6d8: xor eax,eax
48c6da: mov al,bl
48c6dc: imul eax,eax,0x16
48c6df: fld QWORD PTR [esi+eax*8-0xa8]
48c6e6: fsub DWORD PTR ds:0x48dd20
48c6ec: add esp,0xfffffff8
48c6ef: fstp QWORD PTR [esp]
48c6f2: fwait
48c6f3: mov ecx,ebx
48c6f5: mov edx,0x48dcd4
48c6fa: mov al,0x20
48c6fc: call 0x476a04
48c701: push 0x2a
48c703: push 0x12
48c705: push 0xa0
48c70a: xor edx,edx
48c70c: mov dl,BYTE PTR [esp+0xd]
48c710: inc edx
48c711: xor eax,eax
48c713: mov al,bl
48c715: mov ecx,0xfffffff4
48c71a: call 0x476870
48c71f: push 0x2a
48c721: push 0x12
48c723: push 0xa0
48c728: xor edx,edx
48c72a: mov dl,BYTE PTR [esp+0xd]
48c72e: add edx,0x2
48c731: xor eax,eax
48c733: mov al,bl
48c735: mov ecx,0xfffffff4
48c73a: call 0x476870
48c73f: push 0x2a
48c741: push 0x12
48c743: push 0xa0
48c748: xor edx,edx
48c74a: mov dl,BYTE PTR [esp+0xd]
48c74e: add edx,0x3
48c751: xor eax,eax
48c753: mov al,bl
48c755: mov ecx,0xfffffff4
48c75a: call 0x476870
48c75f: push 0x2a
48c761: push 0x12
48c763: push 0xa0
48c768: xor edx,edx
48c76a: mov dl,BYTE PTR [esp+0xd]
48c76e: add edx,0x4
48c771: xor eax,eax
48c773: mov al,bl
48c775: mov ecx,0xfffffff4
48c77a: call 0x476870
48c77f: push 0x2a
48c781: push 0x12
48c783: push 0xa0
48c788: xor edx,edx
48c78a: mov dl,BYTE PTR [esp+0xd]
48c78e: add edx,0x6
48c791: xor eax,eax
48c793: mov al,bl
48c795: mov ecx,0xfffffff4
48c79a: call 0x476870
48c79f: push 0x2a
48c7a1: push 0x12
48c7a3: push 0xa0
48c7a8: xor edx,edx
48c7aa: mov dl,BYTE PTR [esp+0xd]
48c7ae: add edx,0x8
48c7b1: xor eax,eax
48c7b3: mov al,bl
48c7b5: mov ecx,0xfffffff4
48c7ba: call 0x476870
48c7bf: push 0x2a
48c7c1: push 0x12
48c7c3: push 0xa0
48c7c8: xor edx,edx
48c7ca: mov dl,BYTE PTR [esp+0xd]
48c7ce: add edx,0xa
48c7d1: xor eax,eax
48c7d3: mov al,bl
48c7d5: mov ecx,0xfffffff4
48c7da: call 0x476870
48c7df: push 0x55
48c7e1: push 0x12
48c7e3: push 0xa0
48c7e8: xor edx,edx
48c7ea: mov dl,BYTE PTR [esp+0xd]
48c7ee: add edx,0xc
48c7f1: xor eax,eax
48c7f3: mov al,bl
48c7f5: mov ecx,0xfffffff4
48c7fa: call 0x476870
48c7ff: push 0x55
48c801: push 0x12
48c803: push 0xa0
48c808: xor edx,edx
48c80a: mov dl,BYTE PTR [esp+0xd]
48c80e: add edx,0xd
48c811: xor eax,eax
48c813: mov al,bl
48c815: mov ecx,0xfffffff4
48c81a: call 0x476870
48c81f: push 0x55
48c821: push 0x12
48c823: push 0xa0
48c828: xor edx,edx
48c82a: mov dl,BYTE PTR [esp+0xd]
48c82e: add edx,0xf
48c831: xor eax,eax
48c833: mov al,bl
48c835: mov ecx,0xfffffff4
48c83a: call 0x476870
48c83f: push 0x55
48c841: push 0x12
48c843: push 0xa0
48c848: xor edx,edx
48c84a: mov dl,BYTE PTR [esp+0xd]
48c84e: add edx,0x11
48c851: xor eax,eax
48c853: mov al,bl
48c855: mov ecx,0xfffffff4
48c85a: call 0x476870
48c85f: push 0x55
48c861: push 0x12
48c863: push 0xa0
48c868: xor edx,edx
48c86a: mov dl,BYTE PTR [esp+0xd]
48c86e: add edx,0x13
48c871: xor eax,eax
48c873: mov al,bl
48c875: mov ecx,0xfffffff4
48c87a: call 0x476870
48c87f: push 0x2a
48c881: push 0x11
48c883: push 0x82
48c888: xor edx,edx
48c88a: mov dl,BYTE PTR [esp+0xd]
48c88e: add edx,0x15
48c891: xor eax,eax
48c893: mov al,bl
48c895: mov ecx,0xffffffef
48c89a: call 0x476870
48c89f: push 0x46
48c8a1: push 0x23
48c8a3: push 0x6e
48c8a5: xor edx,edx
48c8a7: mov dl,BYTE PTR [esp+0xd]
48c8ab: add edx,0x1c
48c8ae: xor eax,eax
48c8b0: mov al,bl
48c8b2: mov ecx,0xffffffe5
48c8b7: call 0x476870
48c8bc: push 0x78
48c8be: push 0x23
48c8c0: push 0x87
48c8c5: xor edx,edx
48c8c7: mov dl,BYTE PTR [esp+0xd]
48c8cb: add edx,0x1d
48c8ce: xor eax,eax
48c8d0: mov al,bl
48c8d2: mov ecx,0xffffffe5
48c8d7: call 0x476870
48c8dc: push 0x2a
48c8de: push 0x12
48c8e0: push 0xa0
48c8e5: xor edx,edx
48c8e7: mov dl,BYTE PTR [esp+0xd]
48c8eb: add edx,0x1f
48c8ee: xor eax,eax
48c8f0: mov al,bl
48c8f2: mov ecx,0xfffffff4
48c8f7: call 0x476870
48c8fc: push 0x55
48c8fe: push 0x12
48c900: push 0xa0
48c905: xor edx,edx
48c907: mov dl,BYTE PTR [esp+0xd]
48c90b: add edx,0x20
48c90e: xor eax,eax
48c910: mov al,bl
48c912: mov ecx,0xfffffff4
48c917: call 0x476870
48c91c: push 0x3e
48c91e: push 0x11
48c920: push 0x6e
48c922: xor edx,edx
48c924: mov dl,BYTE PTR [esp+0xd]
48c928: add edx,0x28
48c92b: xor eax,eax
48c92d: mov al,bl
48c92f: mov ecx,0xffffffef
48c934: call 0x476870
48c939: push 0xf
48c93b: push 0x35
48c93d: push 0x41
48c93f: push 0x43
48c941: push 0x1
48c943: push 0x1
48c945: push 0x7
48c947: push 0x0
48c949: xor eax,eax
48c94b: mov al,bl
48c94d: mov ecx,0x2
48c952: mov edx,0x3
48c957: call 0x4768f8
48c95c: push 0xf
48c95e: push 0x78
48c960: push 0x2f
48c962: push 0x96
48c967: push 0x1
48c969: push 0x1
48c96b: push 0x7
48c96d: push 0x0
48c96f: xor eax,eax
48c971: mov al,bl
48c973: mov ecx,0x2
48c978: mov edx,0x4
48c97d: call 0x4768f8
48c982: push 0xf
48c984: push 0x3a
48c986: push 0x3e
48c988: push 0x48
48c98a: push 0x1
48c98c: push 0x2
48c98e: push 0xe
48c990: push 0x0
48c992: xor eax,eax
48c994: mov al,bl
48c996: mov ecx,0x5
48c99b: mov edx,0x5
48c9a0: call 0x4768f8
48c9a5: push 0xf
48c9a7: push 0x62
48c9a9: push 0x48
48c9ab: push 0x9b
48c9b0: push 0x1
48c9b2: push 0x2
48c9b4: push 0xe
48c9b6: push 0x0
48c9b8: xor eax,eax
48c9ba: mov al,bl
48c9bc: mov ecx,0x5
48c9c1: mov edx,0x6
48c9c6: call 0x4768f8
48c9cb: push 0xf
48c9cd: push 0x5f
48c9cf: push 0x3e
48c9d1: push 0x6b
48c9d3: push 0x1
48c9d5: push 0x1
48c9d7: push 0x7
48c9d9: push 0x0
48c9db: xor eax,eax
48c9dd: mov al,bl
48c9df: mov ecx,0x2
48c9e4: mov edx,0x8
48c9e9: call 0x4768f8
48c9ee: push 0xf
48c9f0: push 0x8a
48c9f5: push 0x3a
48c9f7: push 0xa0
48c9fc: push 0x1
48c9fe: push 0x1
48ca00: push 0x7
48ca02: push 0x0
48ca04: xor eax,eax
48ca06: mov al,bl
48ca08: mov ecx,0x2
48ca0d: mov edx,0x9
48ca12: call 0x4768f8
48ca17: push 0xf
48ca19: push 0x5d
48ca1b: push 0x36
48ca1d: push 0x6a
48ca1f: push 0x1
48ca21: push 0x2
48ca23: push 0xe
48ca25: push 0x0
48ca27: xor eax,eax
48ca29: mov al,bl
48ca2b: mov ecx,0x5
48ca30: mov edx,0xa
48ca35: call 0x4768f8
48ca3a: push 0xa
48ca3c: push 0x82
48ca41: push 0x4a
48ca43: push 0xa0
48ca48: push 0x1
48ca4a: push 0x2
48ca4c: push 0xe
48ca4e: push 0x0
48ca50: xor eax,eax
48ca52: mov al,bl
48ca54: mov ecx,0x5
48ca59: mov edx,0xb
48ca5e: call 0x4768f8
48ca63: push 0x23
48ca65: push 0x3c
48ca67: push 0x50
48ca69: push 0x64
48ca6b: push 0x1
48ca6d: push 0x1
48ca6f: push 0x7
48ca71: push 0x0
48ca73: xor eax,eax
48ca75: mov al,bl
48ca77: mov ecx,0x2
48ca7c: mov edx,0xd
48ca81: call 0x4768f8
48ca86: push 0xf
48ca88: push 0x56
48ca8a: push 0x4d
48ca8c: push 0x82
48ca91: push 0x1
48ca93: push 0x1
48ca95: push 0x7
48ca97: push 0x0
48ca99: xor eax,eax
48ca9b: mov al,bl
48ca9d: mov ecx,0x2
48caa2: mov edx,0xe
48caa7: call 0x4768f8
48caac: push 0x23
48caae: push 0x3c
48cab0: push 0x50
48cab2: push 0x64
48cab4: push 0x1
48cab6: push 0x2
48cab8: push 0xe
48caba: push 0x0
48cabc: xor eax,eax
48cabe: mov al,bl
48cac0: mov ecx,0x5
48cac5: mov edx,0xf
48caca: call 0x4768f8
48cacf: push 0xf
48cad1: push 0x56
48cad3: push 0x4d
48cad5: push 0x82
48cada: push 0x1
48cadc: push 0x2
48cade: push 0xe
48cae0: push 0x0
48cae2: xor eax,eax
48cae4: mov al,bl
48cae6: mov ecx,0x5
48caeb: mov edx,0x10
48caf0: call 0x4768f8
48caf5: push 0xffffffe9
48caf7: push 0x38
48caf9: push 0x17
48cafb: push 0x74
48cafd: push 0x1
48caff: push 0x0
48cb01: push 0x4
48cb03: push 0x1
48cb05: xor eax,eax
48cb07: mov al,bl
48cb09: mov ecx,0x1
48cb0e: mov edx,0x1b
48cb13: call 0x4768f8
48cb18: push 0xffffffe9
48cb1a: push 0x38
48cb1c: push 0x17
48cb1e: push 0x74
48cb20: push 0x1
48cb22: push 0x0
48cb24: push 0x3
48cb26: push 0x1
48cb28: xor eax,eax
48cb2a: mov al,bl
48cb2c: mov ecx,0x3
48cb31: mov edx,0x1b
48cb36: call 0x4768f8
48cb3b: push 0xffffffe9
48cb3d: push 0x38
48cb3f: push 0x17
48cb41: push 0x74
48cb43: push 0x1
48cb45: push 0x0
48cb47: push 0x4
48cb49: push 0x1
48cb4b: xor eax,eax
48cb4d: mov al,bl
48cb4f: mov ecx,0x5
48cb54: mov edx,0x1b
48cb59: call 0x4768f8
48cb5e: push 0xffffffe9
48cb60: push 0x38
48cb62: push 0x17
48cb64: push 0x74
48cb66: push 0x1
48cb68: push 0x0
48cb6a: push 0x3
48cb6c: push 0x1
48cb6e: xor eax,eax
48cb70: mov al,bl
48cb72: mov ecx,0x7
48cb77: mov edx,0x1b
48cb7c: call 0x4768f8
48cb81: push 0xa
48cb83: push 0xa
48cb85: push 0x28
48cb87: push 0x5a
48cb89: push 0x1
48cb8b: push 0x2
48cb8d: push 0x12
48cb8f: push 0x3
48cb91: xor eax,eax
48cb93: mov al,bl
48cb95: mov ecx,0x3
48cb9a: mov edx,0x1c
48cb9f: call 0x4768f8
48cba4: push 0x0
48cba6: push 0x0
48cba8: push 0x0
48cbaa: push 0x0
48cbac: push 0x0
48cbae: push 0x0
48cbb0: push 0x0
48cbb2: push 0x0
48cbb4: xor eax,eax
48cbb6: mov al,bl
48cbb8: mov ecx,0x14
48cbbd: mov edx,0x1c
48cbc2: call 0x4768f8
48cbc7: xor eax,eax
48cbc9: mov al,bl
48cbcb: imul eax,eax,0x16
48cbce: cmp BYTE PTR [esi+eax*8-0xa0],0xf
48cbd6: jne 0x48dcb8
48cbdc: xor eax,eax
48cbde: mov al,bl
48cbe0: imul eax,eax,0x16
48cbe3: cmp BYTE PTR [esi+eax*8-0x45],0x17
48cbe8: jne 0x48cc4d
48cbea: xor eax,eax
48cbec: mov al,bl
48cbee: imul eax,eax,0x16
48cbf1: cmp WORD PTR [esi+eax*8-0x3c],0xa
48cbf7: jg 0x48cc0b
48cbf9: xor eax,eax
48cbfb: mov al,bl
48cbfd: imul eax,eax,0x16
48cc00: mov dl,BYTE PTR [esp+0x1]
48cc04: add dl,0x21
48cc07: mov BYTE PTR [esi+eax*8-0x44],dl
48cc0b: xor eax,eax
48cc0d: mov al,bl
48cc0f: imul eax,eax,0x16
48cc12: cmp WORD PTR [esi+eax*8-0x3c],0xa
48cc18: jne 0x48cc2c
48cc1a: xor eax,eax
48cc1c: mov al,bl
48cc1e: imul eax,eax,0x16
48cc21: mov dl,BYTE PTR [esp+0x1]
48cc25: add dl,0x22
48cc28: mov BYTE PTR [esi+eax*8-0x44],dl
48cc2c: xor eax,eax
48cc2e: mov al,bl
48cc30: imul eax,eax,0x16
48cc33: cmp WORD PTR [esi+eax*8-0x3c],0xe
48cc39: jne 0x48cc4d
48cc3b: xor eax,eax
48cc3d: mov al,bl
48cc3f: imul eax,eax,0x16
48cc42: mov dl,BYTE PTR [esp+0x1]
48cc46: add dl,0x23
48cc49: mov BYTE PTR [esi+eax*8-0x44],dl
48cc4d: xor eax,eax
48cc4f: mov al,bl
48cc51: imul eax,eax,0x16
48cc54: cmp BYTE PTR [esi+eax*8-0x45],0x19
48cc59: jne 0x48ce5d
48cc5f: xor eax,eax
48cc61: mov al,bl
48cc63: imul eax,eax,0x16
48cc66: cmp WORD PTR [esi+eax*8-0x3c],0x0
48cc6c: jne 0x48cc80
48cc6e: xor eax,eax
48cc70: mov al,bl
48cc72: imul eax,eax,0x16
48cc75: mov dl,BYTE PTR [esp+0x1]
48cc79: add dl,0x24
48cc7c: mov BYTE PTR [esi+eax*8-0x44],dl
48cc80: xor eax,eax
48cc82: mov al,bl
48cc84: imul eax,eax,0x16
48cc87: cmp WORD PTR [esi+eax*8-0x3c],0x7
48cc8d: jne 0x48cca1
48cc8f: xor eax,eax
48cc91: mov al,bl
48cc93: imul eax,eax,0x16
48cc96: mov dl,BYTE PTR [esp+0x1]
48cc9a: add dl,0x25
48cc9d: mov BYTE PTR [esi+eax*8-0x44],dl
48cca1: xor eax,eax
48cca3: mov al,bl
48cca5: imul eax,eax,0x16
48cca8: cmp WORD PTR [esi+eax*8-0x3c],0xa
48ccae: jne 0x48ce46
48ccb4: xor eax,eax
48ccb6: mov al,bl
48ccb8: imul eax,eax,0x16
48ccbb: mov dl,BYTE PTR [esp+0x1]
48ccbf: add dl,0x26
48ccc2: mov BYTE PTR [esi+eax*8-0x44],dl
48ccc6: xor eax,eax
48ccc8: mov al,bl
48ccca: imul eax,eax,0x16
48cccd: cmp BYTE PTR [esi+eax*8-0x43],0x1
48ccd2: jne 0x48cd26
48ccd4: xor eax,eax
48ccd6: mov al,bl
48ccd8: imul eax,eax,0x16
48ccdb: cmp BYTE PTR [esi+eax*8-0x41],0x1
48cce0: jne 0x48cd26
48cce2: xor eax,eax
48cce4: mov al,bl
48cce6: imul eax,eax,0x16
48cce9: fld QWORD PTR [esi+eax*8-0xb0]
48ccf0: fadd DWORD PTR ds:0x48dce8
48ccf6: add esp,0xfffffff8
48ccf9: fstp QWORD PTR [esp]
48ccfc: fwait
48ccfd: xor eax,eax
48ccff: mov al,bl
48cd01: imul eax,eax,0x16
48cd04: fld QWORD PTR [esi+eax*8-0xa8]
48cd0b: fsub DWORD PTR ds:0x48dd78
48cd11: add esp,0xfffffff8
48cd14: fstp QWORD PTR [esp]
48cd17: fwait
48cd18: mov ecx,ebx
48cd1a: mov edx,0x48dcd4
48cd1f: mov al,0x21
48cd21: call 0x476a04
48cd26: xor eax,eax
48cd28: mov al,bl
48cd2a: imul eax,eax,0x16
48cd2d: cmp BYTE PTR [esi+eax*8-0x43],0x2
48cd32: jne 0x48cd86
48cd34: xor eax,eax
48cd36: mov al,bl
48cd38: imul eax,eax,0x16
48cd3b: cmp BYTE PTR [esi+eax*8-0x41],0x1
48cd40: jne 0x48cd86
48cd42: xor eax,eax
48cd44: mov al,bl
48cd46: imul eax,eax,0x16
48cd49: fld QWORD PTR [esi+eax*8-0xb0]
48cd50: fsub DWORD PTR ds:0x48dce8
48cd56: add esp,0xfffffff8
48cd59: fstp QWORD PTR [esp]
48cd5c: fwait
48cd5d: xor eax,eax
48cd5f: mov al,bl
48cd61: imul eax,eax,0x16
48cd64: fld QWORD PTR [esi+eax*8-0xa8]
48cd6b: fsub DWORD PTR ds:0x48dd78
48cd71: add esp,0xfffffff8
48cd74: fstp QWORD PTR [esp]
48cd77: fwait
48cd78: mov ecx,ebx
48cd7a: mov edx,0x48dcd4
48cd7f: mov al,0x21
48cd81: call 0x476a04
48cd86: xor eax,eax
48cd88: mov al,bl
48cd8a: imul eax,eax,0x16
48cd8d: cmp BYTE PTR [esi+eax*8-0x43],0x1
48cd92: jne 0x48cde6
48cd94: xor eax,eax
48cd96: mov al,bl
48cd98: imul eax,eax,0x16
48cd9b: cmp BYTE PTR [esi+eax*8-0x41],0x2
48cda0: jne 0x48cde6
48cda2: xor eax,eax
48cda4: mov al,bl
48cda6: imul eax,eax,0x16
48cda9: fld QWORD PTR [esi+eax*8-0xb0]
48cdb0: fadd DWORD PTR ds:0x48dce8
48cdb6: add esp,0xfffffff8
48cdb9: fstp QWORD PTR [esp]
48cdbc: fwait
48cdbd: xor eax,eax
48cdbf: mov al,bl
48cdc1: imul eax,eax,0x16
48cdc4: fld QWORD PTR [esi+eax*8-0xa8]
48cdcb: fsub DWORD PTR ds:0x48dd78
48cdd1: add esp,0xfffffff8
48cdd4: fstp QWORD PTR [esp]
48cdd7: fwait
48cdd8: mov ecx,ebx
48cdda: mov edx,0x48dce0
48cddf: mov al,0x21
48cde1: call 0x476a04
48cde6: xor eax,eax
48cde8: mov al,bl
48cdea: imul eax,eax,0x16
48cded: cmp BYTE PTR [esi+eax*8-0x43],0x2
48cdf2: jne 0x48ce46
48cdf4: xor eax,eax
48cdf6: mov al,bl
48cdf8: imul eax,eax,0x16
48cdfb: cmp BYTE PTR [esi+eax*8-0x41],0x2
48ce00: jne 0x48ce46
48ce02: xor eax,eax
48ce04: mov al,bl
48ce06: imul eax,eax,0x16
48ce09: fld QWORD PTR [esi+eax*8-0xb0]
48ce10: fsub DWORD PTR ds:0x48dce8
48ce16: add esp,0xfffffff8
48ce19: fstp QWORD PTR [esp]
48ce1c: fwait
48ce1d: xor eax,eax
48ce1f: mov al,bl
48ce21: imul eax,eax,0x16
48ce24: fld QWORD PTR [esi+eax*8-0xa8]
48ce2b: fsub DWORD PTR ds:0x48dd78
48ce31: add esp,0xfffffff8
48ce34: fstp QWORD PTR [esp]
48ce37: fwait
48ce38: mov ecx,ebx
48ce3a: mov edx,0x48dce0
48ce3f: mov al,0x21
48ce41: call 0x476a04
48ce46: xor eax,eax
48ce48: mov al,bl
48ce4a: imul eax,eax,0x16
48ce4d: cmp WORD PTR [esi+eax*8-0x3c],0x3
48ce53: jne 0x48ce5d
48ce55: mov eax,ds:0x4b1098
48ce5a: mov BYTE PTR [eax],0x3f
48ce5d: xor eax,eax
48ce5f: mov al,bl
48ce61: imul eax,eax,0x16
48ce64: cmp BYTE PTR [esi+eax*8-0x45],0x1a
48ce69: jne 0x48d025
48ce6f: xor eax,eax
48ce71: mov al,bl
48ce73: imul eax,eax,0x16
48ce76: cmp WORD PTR [esi+eax*8-0x3c],0x0
48ce7c: jne 0x48ce90
48ce7e: xor eax,eax
48ce80: mov al,bl
48ce82: imul eax,eax,0x16
48ce85: mov dl,BYTE PTR [esp+0x1]
48ce89: add dl,0x27
48ce8c: mov BYTE PTR [esi+eax*8-0x44],dl
48ce90: xor eax,eax
48ce92: mov al,bl
48ce94: imul eax,eax,0x16
48ce97: cmp WORD PTR [esi+eax*8-0x3c],0x4
48ce9d: jne 0x48ceb1
48ce9f: xor eax,eax
48cea1: mov al,bl
48cea3: imul eax,eax,0x16
48cea6: mov dl,BYTE PTR [esp+0x1]
48ceaa: add dl,0x28
48cead: mov BYTE PTR [esi+eax*8-0x44],dl
48ceb1: xor eax,eax
48ceb3: mov al,bl
48ceb5: imul eax,eax,0x16
48ceb8: cmp WORD PTR [esi+eax*8-0x3c],0x8
48cebe: jne 0x48ced2
48cec0: xor eax,eax
48cec2: mov al,bl
48cec4: imul eax,eax,0x16
48cec7: mov dl,BYTE PTR [esp+0x1]
48cecb: add dl,0x29
48cece: mov BYTE PTR [esi+eax*8-0x44],dl
48ced2: xor eax,eax
48ced4: mov al,bl
48ced6: imul eax,eax,0x16
48ced9: cmp WORD PTR [esi+eax*8-0x3c],0xc
48cedf: jne 0x48cef3
48cee1: xor eax,eax
48cee3: mov al,bl
48cee5: imul eax,eax,0x16
48cee8: mov dl,BYTE PTR [esp+0x1]
48ceec: add dl,0x2a
48ceef: mov BYTE PTR [esi+eax*8-0x44],dl
48cef3: xor eax,eax
48cef5: mov al,bl
48cef7: imul eax,eax,0x16
48cefa: cmp WORD PTR [esi+eax*8-0x3c],0x2
48cf00: jl 0x48cf57
48cf02: xor eax,eax
48cf04: mov al,bl
48cf06: imul eax,eax,0x16
48cf09: cmp WORD PTR [esi+eax*8-0x3c],0x4
48cf0f: jg 0x48cf57
48cf11: xor eax,eax
48cf13: mov al,bl
48cf15: imul eax,eax,0x16
48cf18: cmp BYTE PTR [esi+eax*8-0x41],0x2
48cf1d: jne 0x48cf57
48cf1f: xor eax,eax
48cf21: mov al,bl
48cf23: imul eax,eax,0x16
48cf26: cmp BYTE PTR [esi+eax*8-0x43],0x1
48cf2b: jne 0x48cf3b
48cf2d: push 0x402e0000
48cf32: push 0x0
48cf34: mov eax,ebx
48cf36: call 0x47648c
48cf3b: xor eax,eax
48cf3d: mov al,bl
48cf3f: imul eax,eax,0x16
48cf42: cmp BYTE PTR [esi+eax*8-0x43],0x2
48cf47: jne 0x48cf57
48cf49: push 0xc02e0000
48cf4e: push 0x0
48cf50: mov eax,ebx
48cf52: call 0x47648c
48cf57: xor eax,eax
48cf59: mov al,bl
48cf5b: imul eax,eax,0x16
48cf5e: cmp WORD PTR [esi+eax*8-0x3c],0x3
48cf64: jne 0x48d00e
48cf6a: xor eax,eax
48cf6c: mov al,bl
48cf6e: imul eax,eax,0x16
48cf71: cmp BYTE PTR [esi+eax*8-0x43],0x1
48cf76: jne 0x48cfbc
48cf78: xor eax,eax
48cf7a: mov al,bl
48cf7c: imul eax,eax,0x16
48cf7f: fld QWORD PTR [esi+eax*8-0xb0]
48cf86: fadd DWORD PTR ds:0x48dd28
48cf8c: add esp,0xfffffff8
48cf8f: fstp QWORD PTR [esp]
48cf92: fwait
48cf93: xor eax,eax
48cf95: mov al,bl
48cf97: imul eax,eax,0x16
48cf9a: fld QWORD PTR [esi+eax*8-0xa8]
48cfa1: fsub DWORD PTR ds:0x48dd14
48cfa7: add esp,0xfffffff8
48cfaa: fstp QWORD PTR [esp]
48cfad: fwait
48cfae: mov ecx,ebx
48cfb0: mov edx,0x48dcd4
48cfb5: mov al,0x22
48cfb7: call 0x476a04
48cfbc: xor eax,eax
48cfbe: mov al,bl
48cfc0: imul eax,eax,0x16
48cfc3: cmp BYTE PTR [esi+eax*8-0x43],0x2
48cfc8: jne 0x48d00e
48cfca: xor eax,eax
48cfcc: mov al,bl
48cfce: imul eax,eax,0x16
48cfd1: fld QWORD PTR [esi+eax*8-0xb0]
48cfd8: fsub DWORD PTR ds:0x48dd28
48cfde: add esp,0xfffffff8
48cfe1: fstp QWORD PTR [esp]
48cfe4: fwait
48cfe5: xor eax,eax
48cfe7: mov al,bl
48cfe9: imul eax,eax,0x16
48cfec: fld QWORD PTR [esi+eax*8-0xa8]
48cff3: fsub DWORD PTR ds:0x48dd14
48cff9: add esp,0xfffffff8
48cffc: fstp QWORD PTR [esp]
48cfff: fwait
48d000: mov ecx,ebx
48d002: mov edx,0x48dcd4
48d007: mov al,0x22
48d009: call 0x476a04
48d00e: xor eax,eax
48d010: mov al,bl
48d012: imul eax,eax,0x16
48d015: cmp WORD PTR [esi+eax*8-0x3c],0x1
48d01b: jne 0x48d025
48d01d: mov eax,ds:0x4b1098
48d022: mov BYTE PTR [eax],0x40
48d025: xor eax,eax
48d027: mov al,bl
48d029: imul eax,eax,0x16
48d02c: cmp BYTE PTR [esi+eax*8-0x45],0x1b
48d031: jne 0x48d35b
48d037: xor eax,eax
48d039: mov al,bl
48d03b: imul eax,eax,0x16
48d03e: cmp WORD PTR [esi+eax*8-0x3c],0x0
48d044: jne 0x48d058
48d046: xor eax,eax
48d048: mov al,bl
48d04a: imul eax,eax,0x16
48d04d: mov dl,BYTE PTR [esp+0x1]
48d051: add dl,0x2b
48d054: mov BYTE PTR [esi+eax*8-0x44],dl
48d058: xor eax,eax
48d05a: mov al,bl
48d05c: imul eax,eax,0x16
48d05f: cmp WORD PTR [esi+eax*8-0x3c],0x2
48d065: jne 0x48d079
48d067: xor eax,eax
48d069: mov al,bl
48d06b: imul eax,eax,0x16
48d06e: mov dl,BYTE PTR [esp+0x1]
48d072: add dl,0x2c
48d075: mov BYTE PTR [esi+eax*8-0x44],dl
48d079: xor eax,eax
48d07b: mov al,bl
48d07d: imul eax,eax,0x16
48d080: cmp WORD PTR [esi+eax*8-0x3c],0x4
48d086: jne 0x48d09a
48d088: xor eax,eax
48d08a: mov al,bl
48d08c: imul eax,eax,0x16
48d08f: mov dl,BYTE PTR [esp+0x1]
48d093: add dl,0x2d
48d096: mov BYTE PTR [esi+eax*8-0x44],dl
48d09a: xor eax,eax
48d09c: mov al,bl
48d09e: imul eax,eax,0x16
48d0a1: cmp WORD PTR [esi+eax*8-0x3c],0x7
48d0a7: jne 0x48d0bb
48d0a9: xor eax,eax
48d0ab: mov al,bl
48d0ad: imul eax,eax,0x16
48d0b0: mov dl,BYTE PTR [esp+0x1]
48d0b4: add dl,0x2e
48d0b7: mov BYTE PTR [esi+eax*8-0x44],dl
48d0bb: xor eax,eax
48d0bd: mov al,bl
48d0bf: imul eax,eax,0x16
48d0c2: cmp WORD PTR [esi+eax*8-0x3c],0xa
48d0c8: jne 0x48d0dc
48d0ca: xor eax,eax
48d0cc: mov al,bl
48d0ce: imul eax,eax,0x16
48d0d1: mov dl,BYTE PTR [esp+0x1]
48d0d5: add dl,0x2f
48d0d8: mov BYTE PTR [esi+eax*8-0x44],dl
48d0dc: xor eax,eax
48d0de: mov al,bl
48d0e0: imul eax,eax,0x16
48d0e3: cmp WORD PTR [esi+eax*8-0x3c],0xd
48d0e9: jne 0x48d0fd
48d0eb: xor eax,eax
48d0ed: mov al,bl
48d0ef: imul eax,eax,0x16
48d0f2: mov dl,BYTE PTR [esp+0x1]
48d0f6: add dl,0x30
48d0f9: mov BYTE PTR [esi+eax*8-0x44],dl
48d0fd: xor eax,eax
48d0ff: mov al,bl
48d101: imul eax,eax,0x16
48d104: cmp WORD PTR [esi+eax*8-0x3c],0x10
48d10a: jne 0x48d11e
48d10c: xor eax,eax
48d10e: mov al,bl
48d110: imul eax,eax,0x16
48d113: mov dl,BYTE PTR [esp+0x1]
48d117: add dl,0xc
48d11a: mov BYTE PTR [esi+eax*8-0x44],dl
48d11e: xor eax,eax
48d120: mov al,bl
48d122: imul eax,eax,0x16
48d125: cmp WORD PTR [esi+eax*8-0x3c],0x5
48d12b: jne 0x48d1d5
48d131: xor eax,eax
48d133: mov al,bl
48d135: imul eax,eax,0x16
48d138: cmp BYTE PTR [esi+eax*8-0x43],0x1
48d13d: jne 0x48d183
48d13f: xor eax,eax
48d141: mov al,bl
48d143: imul eax,eax,0x16
48d146: fld QWORD PTR [esi+eax*8-0xb0]
48d14d: fadd DWORD PTR ds:0x48dd10
48d153: add esp,0xfffffff8
48d156: fstp QWORD PTR [esp]
48d159: fwait
48d15a: xor eax,eax
48d15c: mov al,bl
48d15e: imul eax,eax,0x16
48d161: fld QWORD PTR [esi+eax*8-0xa8]
48d168: fsub DWORD PTR ds:0x48dd7c
48d16e: add esp,0xfffffff8
48d171: fstp QWORD PTR [esp]
48d174: fwait
48d175: mov ecx,ebx
48d177: mov edx,0x48dcd4
48d17c: mov al,0x23
48d17e: call 0x476a04
48d183: xor eax,eax
48d185: mov al,bl
48d187: imul eax,eax,0x16
48d18a: cmp BYTE PTR [esi+eax*8-0x43],0x2
48d18f: jne 0x48d1d5
48d191: xor eax,eax
48d193: mov al,bl
48d195: imul eax,eax,0x16
48d198: fld QWORD PTR [esi+eax*8-0xb0]
48d19f: fsub DWORD PTR ds:0x48dd10
48d1a5: add esp,0xfffffff8
48d1a8: fstp QWORD PTR [esp]
48d1ab: fwait
48d1ac: xor eax,eax
48d1ae: mov al,bl
48d1b0: imul eax,eax,0x16
48d1b3: fld QWORD PTR [esi+eax*8-0xa8]
48d1ba: fsub DWORD PTR ds:0x48dd7c
48d1c0: add esp,0xfffffff8
48d1c3: fstp QWORD PTR [esp]
48d1c6: fwait
48d1c7: mov ecx,ebx
48d1c9: mov edx,0x48dcd4
48d1ce: mov al,0x23
48d1d0: call 0x476a04
48d1d5: xor eax,eax
48d1d7: mov al,bl
48d1d9: imul eax,eax,0x16
48d1dc: cmp WORD PTR [esi+eax*8-0x3c],0x0
48d1e2: jl 0x48d2ef
48d1e8: xor eax,eax
48d1ea: mov al,bl
48d1ec: imul eax,eax,0x16
48d1ef: cmp WORD PTR [esi+eax*8-0x3c],0x8
48d1f5: jg 0x48d2ef
48d1fb: xor eax,eax
48d1fd: mov al,bl
48d1ff: imul eax,eax,0x16
48d202: cmp BYTE PTR [esi+eax*8-0x41],0x1
48d207: jne 0x48d22c
48d209: xor eax,eax
48d20b: mov al,bl
48d20d: imul eax,eax,0x16
48d210: fld QWORD PTR [esi+eax*8-0xa8]
48d217: fsub DWORD PTR ds:0x48dd58
48d21d: xor eax,eax
48d21f: mov al,bl
48d221: imul eax,eax,0x16
48d224: fstp QWORD PTR [esi+eax*8-0xa8]
48d22b: fwait
48d22c: xor eax,eax
48d22e: mov al,bl
48d230: imul eax,eax,0x16
48d233: cmp BYTE PTR [esi+eax*8-0x41],0x2
48d238: jne 0x48d2ef
48d23e: xor eax,eax
48d240: mov al,bl
48d242: imul eax,eax,0x16
48d245: fld QWORD PTR [esi+eax*8-0xa8]
48d24c: fsub DWORD PTR ds:0x48dcc0
48d252: xor eax,eax
48d254: mov al,bl
48d256: imul eax,eax,0x16
48d259: fstp QWORD PTR [esi+eax*8-0xa8]
48d260: fwait
48d261: xor eax,eax
48d263: mov al,bl
48d265: imul eax,eax,0x16
48d268: cmp WORD PTR [esi+eax*8-0x3c],0x2
48d26e: jg 0x48d2a8
48d270: xor eax,eax
48d272: mov al,bl
48d274: imul eax,eax,0x16
48d277: cmp BYTE PTR [esi+eax*8-0x43],0x1
48d27c: jne 0x48d28c
48d27e: push 0x40240000
48d283: push 0x0
48d285: mov eax,ebx
48d287: call 0x47648c
48d28c: xor eax,eax
48d28e: mov al,bl
48d290: imul eax,eax,0x16
48d293: cmp BYTE PTR [esi+eax*8-0x43],0x2
48d298: jne 0x48d2a8
48d29a: push 0xc0240000
48d29f: push 0x0
48d2a1: mov eax,ebx
48d2a3: call 0x47648c
48d2a8: xor eax,eax
48d2aa: mov al,bl
48d2ac: imul eax,eax,0x16
48d2af: cmp WORD PTR [esi+eax*8-0x3c],0x3
48d2b5: jl 0x48d2ef
48d2b7: xor eax,eax
48d2b9: mov al,bl
48d2bb: imul eax,eax,0x16
48d2be: cmp BYTE PTR [esi+eax*8-0x43],0x1
48d2c3: jne 0x48d2d3
48d2c5: push 0x40080000
48d2ca: push 0x0
48d2cc: mov eax,ebx
48d2ce: call 0x47648c
48d2d3: xor eax,eax
48d2d5: mov al,bl
48d2d7: imul eax,eax,0x16
48d2da: cmp BYTE PTR [esi+eax*8-0x43],0x2
48d2df: jne 0x48d2ef
48d2e1: push 0xc0080000
48d2e6: push 0x0
48d2e8: mov eax,ebx
48d2ea: call 0x47648c
48d2ef: xor eax,eax
48d2f1: mov al,bl
48d2f3: imul eax,eax,0x16
48d2f6: cmp WORD PTR [esi+eax*8-0x3c],0x9
48d2fc: jne 0x48d316
48d2fe: xor eax,eax
48d300: mov al,bl
48d302: imul eax,eax,0x16
48d305: mov BYTE PTR [esi+eax*8-0x46],0x1
48d30a: xor eax,eax
48d30c: mov al,bl
48d30e: imul eax,eax,0x16
48d311: mov BYTE PTR [esi+eax*8-0x38],0xfb
48d316: xor eax,eax
48d318: mov al,bl
48d31a: imul eax,eax,0x16
48d31d: cmp WORD PTR [esi+eax*8-0x3c],0x1
48d323: jne 0x48d32d
48d325: mov eax,ds:0x4b1098
48d32a: mov BYTE PTR [eax],0x41
48d32d: xor eax,eax
48d32f: mov al,bl
48d331: imul eax,eax,0x16
48d334: mov BYTE PTR [esi+eax*8-0x47],0x1
48d339: xor eax,eax
48d33b: mov al,bl
48d33d: imul eax,eax,0x16
48d340: cmp WORD PTR [esi+eax*8-0x3c],0x3
48d346: jg 0x48d35b
48d348: xor eax,eax
48d34a: mov al,bl
48d34c: mov edx,0x3
48d351: sub edx,eax
48d353: imul eax,edx,0x16
48d356: mov BYTE PTR [esi+eax*8-0x1e],0x0
48d35b: xor eax,eax
48d35d: mov al,bl
48d35f: imul eax,eax,0x16
48d362: cmp BYTE PTR [esi+eax*8-0x45],0x1c
48d367: jne 0x48d505
48d36d: xor eax,eax
48d36f: mov al,bl
48d371: imul eax,eax,0x16
48d374: mov dl,BYTE PTR [esp+0x1]
48d378: add dl,0x31
48d37b: mov BYTE PTR [esi+eax*8-0x44],dl
48d37f: xor eax,eax
48d381: mov al,bl
48d383: imul eax,eax,0x16
48d386: mov dl,0x12
48d388: sub dl,BYTE PTR [esi+eax*8-0x3c]
48d38c: mov BYTE PTR [esp+0x2],dl
48d390: xor eax,eax
48d392: mov al,bl
48d394: imul eax,eax,0x16
48d397: cmp BYTE PTR [esi+eax*8-0x43],0x1
48d39c: jne 0x48d3c7
48d39e: xor eax,eax
48d3a0: mov al,bl
48d3a2: imul eax,eax,0x16
48d3a5: cmp BYTE PTR [esi+eax*8-0x41],0x1
48d3aa: jne 0x48d3c7
48d3ac: movsx eax,BYTE PTR [esp+0x2]
48d3b1: mov DWORD PTR [esp+0x4],eax
48d3b5: fild DWORD PTR [esp+0x4]
48d3b9: add esp,0xfffffff8
48d3bc: fstp QWORD PTR [esp]
48d3bf: fwait
48d3c0: mov eax,ebx
48d3c2: call 0x47648c
48d3c7: xor eax,eax
48d3c9: mov al,bl
48d3cb: imul eax,eax,0x16
48d3ce: cmp BYTE PTR [esi+eax*8-0x43],0x2
48d3d3: jne 0x48d400
48d3d5: xor eax,eax
48d3d7: mov al,bl
48d3d9: imul eax,eax,0x16
48d3dc: cmp BYTE PTR [esi+eax*8-0x41],0x1
48d3e1: jne 0x48d400
48d3e3: movsx eax,BYTE PTR [esp+0x2]
48d3e8: neg eax
48d3ea: mov DWORD PTR [esp+0x4],eax
48d3ee: fild DWORD PTR [esp+0x4]
48d3f2: add esp,0xfffffff8
48d3f5: fstp QWORD PTR [esp]
48d3f8: fwait
48d3f9: mov eax,ebx
48d3fb: call 0x47648c
48d400: xor eax,eax
48d402: mov al,bl
48d404: imul eax,eax,0x16
48d407: cmp BYTE PTR [esi+eax*8-0x43],0x1
48d40c: jne 0x48d43f
48d40e: xor eax,eax
48d410: mov al,bl
48d412: imul eax,eax,0x16
48d415: cmp BYTE PTR [esi+eax*8-0x41],0x2
48d41a: jne 0x48d43f
48d41c: movsx eax,BYTE PTR [esp+0x2]
48d421: mov DWORD PTR [esp+0x4],eax
48d425: fild DWORD PTR [esp+0x4]
48d429: fld TBYTE PTR ds:0x48dd80
48d42f: fmulp st(1),st
48d431: add esp,0xfffffff8
48d434: fstp QWORD PTR [esp]
48d437: fwait
48d438: mov eax,ebx
48d43a: call 0x47648c
48d43f: xor eax,eax
48d441: mov al,bl
48d443: imul eax,eax,0x16
48d446: cmp BYTE PTR [esi+eax*8-0x43],0x2
48d44b: jne 0x48d480
48d44d: xor eax,eax
48d44f: mov al,bl
48d451: imul eax,eax,0x16
48d454: cmp BYTE PTR [esi+eax*8-0x41],0x2
48d459: jne 0x48d480
48d45b: movsx eax,BYTE PTR [esp+0x2]
48d460: mov DWORD PTR [esp+0x4],eax
48d464: fild DWORD PTR [esp+0x4]
48d468: fld TBYTE PTR ds:0x48dd80
48d46e: fmulp st(1),st
48d470: fchs
48d472: add esp,0xfffffff8
48d475: fstp QWORD PTR [esp]
48d478: fwait
48d479: mov eax,ebx
48d47b: call 0x47648c
48d480: xor eax,eax
48d482: mov al,bl
48d484: imul eax,eax,0x16
48d487: fild WORD PTR [esi+eax*8-0x3c]
48d48b: call 0x402894
48d490: add al,0xf8
48d492: mov BYTE PTR [esp+0x2],al
48d496: movsx eax,BYTE PTR [esp+0x2]
48d49b: mov DWORD PTR [esp+0x4],eax
48d49f: fild DWORD PTR [esp+0x4]
48d4a3: xor eax,eax
48d4a5: mov al,bl
48d4a7: imul eax,eax,0x16
48d4aa: fadd QWORD PTR [esi+eax*8-0xa8]
48d4b1: xor eax,eax
48d4b3: mov al,bl
48d4b5: imul eax,eax,0x16
48d4b8: fstp QWORD PTR [esi+eax*8-0xa8]
48d4bf: fwait
48d4c0: xor eax,eax
48d4c2: mov al,bl
48d4c4: imul eax,eax,0x16
48d4c7: cmp WORD PTR [esi+eax*8-0x3c],0x1
48d4cd: jne 0x48d4d7
48d4cf: mov eax,ds:0x4b1098
48d4d4: mov BYTE PTR [eax],0x42
48d4d7: xor eax,eax
48d4d9: mov al,bl
48d4db: imul eax,eax,0x16
48d4de: mov BYTE PTR [esi+eax*8-0x47],0x1
48d4e3: xor eax,eax
48d4e5: mov al,bl
48d4e7: imul eax,eax,0x16
48d4ea: cmp WORD PTR [esi+eax*8-0x3c],0x3
48d4f0: jg 0x48d505
48d4f2: xor eax,eax
48d4f4: mov al,bl
48d4f6: mov edx,0x3
48d4fb: sub edx,eax
48d4fd: imul eax,edx,0x16
48d500: mov BYTE PTR [esi+eax*8-0x1e],0x0
48d505: xor eax,eax
48d507: mov al,bl
48d509: imul eax,eax,0x16
48d50c: cmp BYTE PTR [esi+eax*8-0x45],0x1d
48d511: jne 0x48d715
48d517: xor eax,eax
48d519: mov al,bl
48d51b: imul eax,eax,0x16
48d51e: mov dl,BYTE PTR [esp+0x1]
48d522: add dl,0x32
48d525: mov BYTE PTR [esi+eax*8-0x44],dl
48d529: xor eax,eax
48d52b: mov al,bl
48d52d: imul eax,eax,0x16
48d530: mov dl,0x16
48d532: sub dl,BYTE PTR [esi+eax*8-0x3c]
48d536: mov BYTE PTR [esp+0x2],dl
48d53a: cmp BYTE PTR [esp+0x2],0x1
48d53f: jge 0x48d546
48d541: mov BYTE PTR [esp+0x2],0x1
48d546: xor eax,eax
48d548: mov al,bl
48d54a: imul eax,eax,0x16
48d54d: cmp BYTE PTR [esi+eax*8-0x43],0x1
48d552: jne 0x48d56f
48d554: movsx eax,BYTE PTR [esp+0x2]
48d559: mov DWORD PTR [esp+0x4],eax
48d55d: fild DWORD PTR [esp+0x4]
48d561: add esp,0xfffffff8
48d564: fstp QWORD PTR [esp]
48d567: fwait
48d568: mov eax,ebx
48d56a: call 0x47648c
48d56f: xor eax,eax
48d571: mov al,bl
48d573: imul eax,eax,0x16
48d576: cmp BYTE PTR [esi+eax*8-0x43],0x2
48d57b: jne 0x48d59a
48d57d: movsx eax,BYTE PTR [esp+0x2]
48d582: neg eax
48d584: mov DWORD PTR [esp+0x4],eax
48d588: fild DWORD PTR [esp+0x4]
48d58c: add esp,0xfffffff8
48d58f: fstp QWORD PTR [esp]
48d592: fwait
48d593: mov eax,ebx
48d595: call 0x47648c
48d59a: xor eax,eax
48d59c: mov al,bl
48d59e: imul eax,eax,0x16
48d5a1: cmp WORD PTR [esi+eax*8-0x3c],0x14
48d5a7: jge 0x48d679
48d5ad: xor eax,eax
48d5af: mov al,bl
48d5b1: imul eax,eax,0x16
48d5b4: cmp BYTE PTR [esi+eax*8-0x43],0x1
48d5b9: jne 0x48d613
48d5bb: xor eax,eax
48d5bd: mov al,bl
48d5bf: imul eax,eax,0x16
48d5c2: fld QWORD PTR [esi+eax*8-0xb0]
48d5c9: fsub DWORD PTR ds:0x48dd14
48d5cf: add esp,0xfffffff8
48d5d2: fstp QWORD PTR [esp]
48d5d5: fwait
48d5d6: mov eax,0x14
48d5db: call 0x402a1c
48d5e0: mov DWORD PTR [esp+0xc],eax
48d5e4: fild DWORD PTR [esp+0xc]
48d5e8: xor eax,eax
48d5ea: mov al,bl
48d5ec: imul eax,eax,0x16
48d5ef: fld QWORD PTR [esi+eax*8-0xa8]
48d5f6: fsub DWORD PTR ds:0x48dcf4
48d5fc: faddp st(1),st
48d5fe: add esp,0xfffffff8
48d601: fstp QWORD PTR [esp]
48d604: fwait
48d605: mov ecx,ebx
48d607: mov edx,0x48dcd4
48d60c: mov al,0x24
48d60e: call 0x476a04
48d613: xor eax,eax
48d615: mov al,bl
48d617: imul eax,eax,0x16
48d61a: cmp BYTE PTR [esi+eax*8-0x43],0x2
48d61f: jne 0x48d679
48d621: xor eax,eax
48d623: mov al,bl
48d625: imul eax,eax,0x16
48d628: fld QWORD PTR [esi+eax*8-0xb0]
48d62f: fadd DWORD PTR ds:0x48dd14
48d635: add esp,0xfffffff8
48d638: fstp QWORD PTR [esp]
48d63b: fwait
48d63c: mov eax,0x14
48d641: call 0x402a1c
48d646: mov DWORD PTR [esp+0xc],eax
48d64a: fild DWORD PTR [esp+0xc]
48d64e: xor eax,eax
48d650: mov al,bl
48d652: imul eax,eax,0x16
48d655: fld QWORD PTR [esi+eax*8-0xa8]
48d65c: fsub DWORD PTR ds:0x48dcf4
48d662: faddp st(1),st
48d664: add esp,0xfffffff8
48d667: fstp QWORD PTR [esp]
48d66a: fwait
48d66b: mov ecx,ebx
48d66d: mov edx,0x48dcd4
48d672: mov al,0x24
48d674: call 0x476a04
48d679: xor eax,eax
48d67b: mov al,bl
48d67d: imul eax,eax,0x16
48d680: fild WORD PTR [esi+eax*8-0x3c]
48d684: fld TBYTE PTR ds:0x48dd8c
48d68a: fmulp st(1),st
48d68c: call 0x402894
48d691: add al,0xfb
48d693: mov BYTE PTR [esp+0x2],al
48d697: movsx eax,BYTE PTR [esp+0x2]
48d69c: mov DWORD PTR [esp+0x4],eax
48d6a0: fild DWORD PTR [esp+0x4]
48d6a4: xor eax,eax
48d6a6: mov al,bl
48d6a8: imul eax,eax,0x16
48d6ab: fadd QWORD PTR [esi+eax*8-0xa8]
48d6b2: xor eax,eax
48d6b4: mov al,bl
48d6b6: imul eax,eax,0x16
48d6b9: fstp QWORD PTR [esi+eax*8-0xa8]
48d6c0: fwait
48d6c1: xor eax,eax
48d6c3: mov al,bl
48d6c5: imul eax,eax,0x16
48d6c8: cmp WORD PTR [esi+eax*8-0x3c],0x1
48d6ce: jne 0x48d6d8
48d6d0: mov eax,ds:0x4b1098
48d6d5: mov BYTE PTR [eax],0x42
48d6d8: xor eax,eax
48d6da: mov al,bl
48d6dc: imul eax,eax,0x16
48d6df: cmp WORD PTR [esi+eax*8-0x3c],0xf
48d6e5: jl 0x48d6f3
48d6e7: xor eax,eax
48d6e9: mov al,bl
48d6eb: imul eax,eax,0x16
48d6ee: mov BYTE PTR [esi+eax*8-0x47],0x1
48d6f3: xor eax,eax
48d6f5: mov al,bl
48d6f7: imul eax,eax,0x16
48d6fa: cmp WORD PTR [esi+eax*8-0x3c],0xf
48d700: jg 0x48d715
48d702: xor eax,eax
48d704: mov al,bl
48d706: mov edx,0x3
48d70b: sub edx,eax
48d70d: imul eax,edx,0x16
48d710: mov BYTE PTR [esi+eax*8-0x1e],0x0
48d715: push 0x1c
48d717: push 0x17
48d719: push 0xa0
48d71e: xor edx,edx
48d720: mov dl,BYTE PTR [esp+0xd]
48d724: inc edx
48d725: xor eax,eax
48d727: mov al,bl
48d729: mov ecx,0xfffffff8
48d72e: call 0x476870
48d733: push 0x1c
48d735: push 0x17
48d737: push 0xa0
48d73c: xor edx,edx
48d73e: mov dl,BYTE PTR [esp+0xd]
48d742: add edx,0x2
48d745: xor eax,eax
48d747: mov al,bl
48d749: mov ecx,0xfffffff8
48d74e: call 0x476870
48d753: push 0x1c
48d755: push 0x17
48d757: push 0xa0
48d75c: xor edx,edx
48d75e: mov dl,BYTE PTR [esp+0xd]
48d762: add edx,0x3
48d765: xor eax,eax
48d767: mov al,bl
48d769: mov ecx,0xfffffff8
48d76e: call 0x476870
48d773: push 0x1c
48d775: push 0x17
48d777: push 0xa0
48d77c: xor edx,edx
48d77e: mov dl,BYTE PTR [esp+0xd]
48d782: add edx,0x4
48d785: xor eax,eax
48d787: mov al,bl
48d789: mov ecx,0xfffffff8
48d78e: call 0x476870
48d793: push 0x1c
48d795: push 0x17
48d797: push 0xa0
48d79c: xor edx,edx
48d79e: mov dl,BYTE PTR [esp+0xd]
48d7a2: add edx,0x6
48d7a5: xor eax,eax
48d7a7: mov al,bl
48d7a9: mov ecx,0xfffffff8
48d7ae: call 0x476870
48d7b3: push 0x1c
48d7b5: push 0x23
48d7b7: push 0xa0
48d7bc: xor edx,edx
48d7be: mov dl,BYTE PTR [esp+0xd]
48d7c2: add edx,0x8
48d7c5: xor eax,eax
48d7c7: mov al,bl
48d7c9: mov ecx,0x5
48d7ce: call 0x476870
48d7d3: push 0x1c
48d7d5: push 0x17
48d7d7: push 0xa0
48d7dc: xor edx,edx
48d7de: mov dl,BYTE PTR [esp+0xd]
48d7e2: add edx,0xa
48d7e5: xor eax,eax
48d7e7: mov al,bl
48d7e9: mov ecx,0xfffffff8
48d7ee: call 0x476870
48d7f3: push 0x40
48d7f5: push 0x14
48d7f7: push 0xa0
48d7fc: xor edx,edx
48d7fe: mov dl,BYTE PTR [esp+0xd]
48d802: add edx,0xc
48d805: xor eax,eax
48d807: mov al,bl
48d809: mov ecx,0xfffffff4
48d80e: call 0x476870
48d813: push 0x40
48d815: push 0x14
48d817: push 0xa0
48d81c: xor edx,edx
48d81e: mov dl,BYTE PTR [esp+0xd]
48d822: add edx,0xd
48d825: xor eax,eax
48d827: mov al,bl
48d829: mov ecx,0xfffffff4
48d82e: call 0x476870
48d833: push 0x40
48d835: push 0x14
48d837: push 0xa0
48d83c: xor edx,edx
48d83e: mov dl,BYTE PTR [esp+0xd]
48d842: add edx,0xf
48d845: xor eax,eax
48d847: mov al,bl
48d849: mov ecx,0xfffffff4
48d84e: call 0x476870
48d853: push 0x40
48d855: push 0x14
48d857: push 0xa0
48d85c: xor edx,edx
48d85e: mov dl,BYTE PTR [esp+0xd]
48d862: add edx,0x11
48d865: xor eax,eax
48d867: mov al,bl
48d869: mov ecx,0xfffffff4
48d86e: call 0x476870
48d873: push 0x55
48d875: push 0x19
48d877: push 0xa0
48d87c: xor edx,edx
48d87e: mov dl,BYTE PTR [esp+0xd]
48d882: add edx,0x13
48d885: xor eax,eax
48d887: mov al,bl
48d889: mov ecx,0xffffffec
48d88e: call 0x476870
48d893: push 0x1c
48d895: push 0x17
48d897: push 0x78
48d899: xor edx,edx
48d89b: mov dl,BYTE PTR [esp+0xd]
48d89f: add edx,0x15
48d8a2: xor eax,eax
48d8a4: mov al,bl
48d8a6: mov ecx,0xfffffff8
48d8ab: call 0x476870
48d8b0: push 0x46
48d8b2: push 0x26
48d8b4: push 0x6e
48d8b6: xor edx,edx
48d8b8: mov dl,BYTE PTR [esp+0xd]
48d8bc: add edx,0x1c
48d8bf: xor eax,eax
48d8c1: mov al,bl
48d8c3: mov ecx,0xffffffe2
48d8c8: call 0x476870
48d8cd: push 0x78
48d8cf: push 0x26
48d8d1: push 0x87
48d8d6: xor edx,edx
48d8d8: mov dl,BYTE PTR [esp+0xd]
48d8dc: add edx,0x1d
48d8df: xor eax,eax
48d8e1: mov al,bl
48d8e3: mov ecx,0xffffffe2
48d8e8: call 0x476870
48d8ed: push 0x1c
48d8ef: push 0x17
48d8f1: push 0xa0
48d8f6: xor edx,edx
48d8f8: mov dl,BYTE PTR [esp+0xd]
48d8fc: add edx,0x1f
48d8ff: xor eax,eax
48d901: mov al,bl
48d903: mov ecx,0xfffffff8
48d908: call 0x476870
48d90d: push 0x40
48d90f: push 0x14
48d911: push 0xa0
48d916: xor edx,edx
48d918: mov dl,BYTE PTR [esp+0xd]
48d91c: add edx,0x20
48d91f: xor eax,eax
48d921: mov al,bl
48d923: mov ecx,0xfffffff4
48d928: call 0x476870
48d92d: push 0x1c
48d92f: push 0x17
48d931: push 0xa0
48d936: xor edx,edx
48d938: mov dl,BYTE PTR [esp+0xd]
48d93c: add edx,0x24
48d93f: xor eax,eax
48d941: mov al,bl
48d943: mov ecx,0xfffffff8
48d948: call 0x476870
48d94d: push 0x28
48d94f: push 0x17
48d951: push 0xa0
48d956: xor edx,edx
48d958: mov dl,BYTE PTR [esp+0xd]
48d95c: add edx,0x27
48d95f: xor eax,eax
48d961: mov al,bl
48d963: mov ecx,0xfffffff8
48d968: call 0x476870
48d96d: push 0x1c
48d96f: push 0x17
48d971: push 0xa0
48d976: xor edx,edx
48d978: mov dl,BYTE PTR [esp+0xd]
48d97c: add edx,0x2b
48d97f: xor eax,eax
48d981: mov al,bl
48d983: mov ecx,0xfffffff8
48d988: call 0x476870
48d98d: push 0x1c
48d98f: push 0x17
48d991: push 0xa0
48d996: xor edx,edx
48d998: mov dl,BYTE PTR [esp+0xd]
48d99c: add edx,0x31
48d99f: xor eax,eax
48d9a1: mov al,bl
48d9a3: mov ecx,0xfffffff8
48d9a8: call 0x476870
48d9ad: push 0x1c
48d9af: push 0x17
48d9b1: push 0xa0
48d9b6: xor edx,edx
48d9b8: mov dl,BYTE PTR [esp+0xd]
48d9bc: add edx,0x32
48d9bf: xor eax,eax
48d9c1: mov al,bl
48d9c3: mov ecx,0xfffffff8
48d9c8: call 0x476870
48d9cd: push 0xf
48d9cf: push 0x2d
48d9d1: push 0x49
48d9d3: push 0x35
48d9d5: push 0x1
48d9d7: push 0x1
48d9d9: push 0x7
48d9db: push 0x0
48d9dd: xor eax,eax
48d9df: mov al,bl
48d9e1: mov ecx,0x2
48d9e6: mov edx,0x3
48d9eb: call 0x4768f8
48d9f0: push 0xf
48d9f2: push 0x6e
48d9f4: push 0x45
48d9f6: push 0x96
48d9fb: push 0x1
48d9fd: push 0x1
48d9ff: push 0x7
48da01: push 0x0
48da03: xor eax,eax
48da05: mov al,bl
48da07: mov ecx,0x2
48da0c: mov edx,0x4
48da11: call 0x4768f8
48da16: push 0xf
48da18: push 0x2d
48da1a: push 0x53
48da1c: push 0x35
48da1e: push 0x1
48da20: push 0x2
48da22: push 0xe
48da24: push 0x0
48da26: xor eax,eax
48da28: mov al,bl
48da2a: mov ecx,0x5
48da2f: mov edx,0x5
48da34: call 0x4768f8
48da39: push 0xf
48da3b: push 0x14
48da3d: push 0x4b
48da3f: push 0x50
48da41: push 0x1
48da43: push 0x2
48da45: push 0xe
48da47: push 0x0
48da49: xor eax,eax
48da4b: mov al,bl
48da4d: mov ecx,0x5
48da52: mov edx,0x6
48da57: call 0x4768f8
48da5c: push 0xf
48da5e: push 0x52
48da60: push 0x4b
48da62: push 0x5b
48da64: push 0x1
48da66: push 0x1
48da68: push 0x7
48da6a: push 0x0
48da6c: xor eax,eax
48da6e: mov al,bl
48da70: mov ecx,0x2
48da75: mov edx,0x8
48da7a: call 0x4768f8
48da7f: push 0xf
48da81: push 0x82
48da86: push 0x49
48da88: push 0xa0
48da8d: push 0x1
48da8f: push 0x1
48da91: push 0x7
48da93: push 0x0
48da95: xor eax,eax
48da97: mov al,bl
48da99: mov ecx,0x2
48da9e: mov edx,0x9
48daa3: call 0x4768f8
48daa8: push 0xf
48daaa: push 0x4a
48daac: push 0x44
48daae: push 0x53
48dab0: push 0x1
48dab2: push 0x2
48dab4: push 0xe
48dab6: push 0x0
48dab8: xor eax,eax
48daba: mov al,bl
48dabc: mov ecx,0x5
48dac1: mov edx,0xa
48dac6: call 0x4768f8
48dacb: push 0xa
48dacd: push 0x6e
48dacf: push 0x5e
48dad1: push 0xa0
48dad6: push 0x1
48dad8: push 0x2
48dada: push 0xe
48dadc: push 0x0
48dade: xor eax,eax
48dae0: mov al,bl
48dae2: mov ecx,0x5
48dae7: mov edx,0xb
48daec: call 0x4768f8
48daf1: push 0x19
48daf3: push 0x3c
48daf5: push 0x46
48daf7: push 0x69
48daf9: push 0x1
48dafb: push 0x1
48dafd: push 0x7
48daff: push 0x0
48db01: xor eax,eax
48db03: mov al,bl
48db05: mov ecx,0x2
48db0a: mov edx,0xd
48db0f: call 0x4768f8
48db14: push 0xa
48db16: push 0x5a
48db18: push 0x50
48db1a: push 0x78
48db1c: push 0x1
48db1e: push 0x1
48db20: push 0x7
48db22: push 0x0
48db24: xor eax,eax
48db26: mov al,bl
48db28: mov ecx,0x2
48db2d: mov edx,0xe
48db32: call 0x4768f8
48db37: push 0x19
48db39: push 0x3c
48db3b: push 0x46
48db3d: push 0x69
48db3f: push 0x1
48db41: push 0x2
48db43: push 0xe
48db45: push 0x0
48db47: xor eax,eax
48db49: mov al,bl
48db4b: mov ecx,0x5
48db50: mov edx,0xf
48db55: call 0x4768f8
48db5a: push 0xa
48db5c: push 0x5a
48db5e: push 0x50
48db60: push 0x78
48db62: push 0x1
48db64: push 0x2
48db66: push 0xe
48db68: push 0x0
48db6a: xor eax,eax
48db6c: mov al,bl
48db6e: mov ecx,0x5
48db73: mov edx,0x10
48db78: call 0x4768f8
48db7d: push 0xffffffd8
48db7f: push 0xffffffe2
48db81: push 0x4b
48db83: push 0x6e
48db85: push 0x1
48db87: push 0x0
48db89: push 0x12
48db8b: push 0x3
48db8d: xor eax,eax
48db8f: mov al,bl
48db91: mov ecx,0x5
48db96: mov edx,0x1b
48db9b: call 0x4768f8
48dba0: push 0x0
48dba2: push 0x0
48dba4: push 0x0
48dba6: push 0x0
48dba8: push 0x0
48dbaa: push 0x0
48dbac: push 0x0
48dbae: push 0x0
48dbb0: xor eax,eax
48dbb2: mov al,bl
48dbb4: mov ecx,0xa
48dbb9: mov edx,0x1b
48dbbe: call 0x4768f8
48dbc3: push 0xa
48dbc5: push 0x36
48dbc7: push 0x44
48dbc9: push 0x5a
48dbcb: push 0x1
48dbcd: push 0x0
48dbcf: push 0xf
48dbd1: push 0x3
48dbd3: xor eax,eax
48dbd5: mov al,bl
48dbd7: mov ecx,0x2
48dbdc: mov edx,0x1c
48dbe1: call 0x4768f8
48dbe6: push 0xa
48dbe8: push 0x36
48dbea: push 0x44
48dbec: push 0x5a
48dbee: push 0x1
48dbf0: push 0x2
48dbf2: push 0x9
48dbf4: push 0x2
48dbf6: xor eax,eax
48dbf8: mov al,bl
48dbfa: mov ecx,0x2
48dbff: mov edx,0x1d
48dc04: call 0x4768f8
48dc09: push 0xa
48dc0b: push 0x36
48dc0d: push 0x44
48dc0f: push 0x5a
48dc11: push 0x1
48dc13: push 0x2
48dc15: push 0x5
48dc17: push 0x1
48dc19: xor eax,eax
48dc1b: mov al,bl
48dc1d: mov ecx,0x5
48dc22: mov edx,0x1d
48dc27: call 0x4768f8
48dc2c: push 0xa
48dc2e: push 0x36
48dc30: push 0x44
48dc32: push 0x5a
48dc34: push 0x1
48dc36: push 0x2
48dc38: push 0x5
48dc3a: push 0x1
48dc3c: xor eax,eax
48dc3e: mov al,bl
48dc40: mov ecx,0x7
48dc45: mov edx,0x1d
48dc4a: call 0x4768f8
48dc4f: push 0xa
48dc51: push 0x36
48dc53: push 0x44
48dc55: push 0x5a
48dc57: push 0x1
48dc59: push 0x2
48dc5b: push 0x7
48dc5d: push 0x2
48dc5f: xor eax,eax
48dc61: mov al,bl
48dc63: mov ecx,0xa
48dc68: mov edx,0x1d
48dc6d: call 0x4768f8
48dc72: push 0xa
48dc74: push 0x36
48dc76: push 0x44
48dc78: push 0x5a
48dc7a: push 0x1
48dc7c: push 0x2
48dc7e: push 0x5
48dc80: push 0x1
48dc82: xor eax,eax
48dc84: mov al,bl
48dc86: mov ecx,0xd
48dc8b: mov edx,0x1d
48dc90: call 0x4768f8
48dc95: push 0xa
48dc97: push 0x36
48dc99: push 0x44
48dc9b: push 0x5a
48dc9d: push 0x1
48dc9f: push 0x2
48dca1: push 0xc
48dca3: push 0x2
48dca5: xor eax,eax
48dca7: mov al,bl
48dca9: mov ecx,0xf
48dcae: mov edx,0x1d
48dcb3: call 0x4768f8
48dcb8: add esp,0x1c
48dcbb: pop ebp
48dcbc: pop edi
48dcbd: pop esi
48dcbe: pop ebx
48dcbf: ret
.data 4b0ef0 e8444b000c204b0030b8
.data 48dcc0 00002041000000000000
.data 48dcc4 0000000000003442ffff
.data 4b11f8 98444b00db444b004027
.data 48dcc8 00003442ffffffff0100
.data 4b1098 09584b0078b640005472
.data 48dce4 0000a041000070420000
.data 48dce8 000070420000aa420000
.data 48dcec 0000aa42000040400000
.data 48dcf0 000040400000dc420000
.data 48dcf4 0000dc4200005c420000
.data 4b0d68 9a444b0020b840002420
.data 48dcf8 00005c420000c8420000
.data 48dcfc 0000c842000030410000
.data 48dd00 00003041000040410000
.data 48dd04 00004041000050410000
.data 48dd08 00005041000087430000
.data 48dd0c 00008743000020420000
.data 4b0d98 a8584b0004204b000024
.data 4b0fc8 9b444b00a5584b00a158
.data 48dd10 000020420000f0410000
.data 48dd14 0000f041000016430000
.data 48dd18 00001643000002430000
.data 4b11f4 88584b0098444b00db44
.data 4b0e84 f9574b00c8b64000f0b6
.data 48dd1c 000002430000a0420000
.data 48dd20 0000a042000080400000
.data 4b1094 c0444b0009584b0078b6
.data 48dd24 00008040000082420000
.data 48dd28 00008242000048420000
.data 48dd2c 000048420000ce420000
.data 48dd30 0000ce42000000400000
.data 48dd34 00000040000096420000
.data 48dd38 00009642000070410000
.data 48dd3c 000070410000b4420000
.data 48dd40 0000b44200000c420000
.data 48dd44 00000c42000040420000
.data 48dd48 00004042000014420000
.data 48dd4c 00001442000010410000
.data 48dd50 00001041000090410000
.data 48dd54 000090410000c0400000
.data 48dd58 0000c040000000410000
.data 48dd5c 00000041000096430000
.data 4b11b4 c8444b00a0b640003470
.data 48dd60 000096430000d2420000
.data 48dd64 0000d242000088410000
.data 48dd68 0000884100009c420000
.data 48dd6c 00009c42000028420000
.data 4b1144 cc444b0004004b0098b8
.data 48dd70 000028420000ba420000
.data 48dd74 0000ba420000b8420000
.data 48dd78 0000b842000020436666
.data 48dd7c 00002043666666666666
.data 48dd80 66666666666666a6ff3f
.data 48dd8c cdccccccccccccccfd3f
.string 48dcd4 41
.string 48dce0 42
