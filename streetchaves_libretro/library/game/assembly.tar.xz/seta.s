; entry 4905a8
; exit 403468
4905a8: push ebp
4905a9: mov ebp,esp
4905ab: add esp,0xfffffff8
4905ae: push ebx
4905af: push esi
4905b0: mov DWORD PTR [ebp-0x4],ecx
4905b3: mov ebx,edx
4905b5: mov esi,eax
4905b7: mov eax,DWORD PTR [ebp-0x4]
4905ba: call 0x403e04
4905bf: xor eax,eax
4905c1: push ebp
4905c2: push 0x490855
4905c7: push DWORD PTR fs:[eax]
4905ca: mov DWORD PTR fs:[eax],esp
4905cd: mov BYTE PTR [ebp-0x5],0x0
4905d1: cmp bl,0x1
4905d4: jne 0x490708
4905da: mov eax,DWORD PTR [esi+0x2d8]
4905e0: mov eax,DWORD PTR [eax+0x38]
4905e3: test BYTE PTR [eax+0x2038],0x2
4905ea: je 0x4905ff
4905ec: mov eax,DWORD PTR [ebp-0x4]
4905ef: mov edx,0x490870
4905f4: call 0x403d60
4905f9: jne 0x4905ff
4905fb: mov BYTE PTR [ebp-0x5],0x1
4905ff: mov eax,DWORD PTR [esi+0x2d8]
490605: mov eax,DWORD PTR [eax+0x38]
490608: test BYTE PTR [eax+0x2038],0x4
49060f: je 0x490638
490611: xor eax,eax
490613: mov al,bl
490615: imul eax,eax,0x16
490618: mov edx,DWORD PTR ds:0x4b0ef0
49061e: cmp BYTE PTR [edx+eax*8-0x43],0x1
490623: jne 0x490638
490625: mov eax,DWORD PTR [ebp-0x4]
490628: mov edx,0x490880
49062d: call 0x403d60
490632: jne 0x490638
490634: mov BYTE PTR [ebp-0x5],0x1
490638: mov eax,DWORD PTR [esi+0x2d8]
49063e: mov eax,DWORD PTR [eax+0x38]
490641: test BYTE PTR [eax+0x2038],0x8
490648: je 0x490671
49064a: xor eax,eax
49064c: mov al,bl
49064e: imul eax,eax,0x16
490651: mov edx,DWORD PTR ds:0x4b0ef0
490657: cmp BYTE PTR [edx+eax*8-0x43],0x2
49065c: jne 0x490671
49065e: mov eax,DWORD PTR [ebp-0x4]
490661: mov edx,0x490880
490666: call 0x403d60
49066b: jne 0x490671
49066d: mov BYTE PTR [ebp-0x5],0x1
490671: mov eax,DWORD PTR [esi+0x2d8]
490677: mov eax,DWORD PTR [eax+0x38]
49067a: test BYTE PTR [eax+0x2038],0x4
490681: je 0x4906aa
490683: xor eax,eax
490685: mov al,bl
490687: imul eax,eax,0x16
49068a: mov edx,DWORD PTR ds:0x4b0ef0
490690: cmp BYTE PTR [edx+eax*8-0x43],0x2
490695: jne 0x4906aa
490697: mov eax,DWORD PTR [ebp-0x4]
49069a: mov edx,0x490890
49069f: call 0x403d60
4906a4: jne 0x4906aa
4906a6: mov BYTE PTR [ebp-0x5],0x1
4906aa: mov eax,DWORD PTR [esi+0x2d8]
4906b0: mov eax,DWORD PTR [eax+0x38]
4906b3: test BYTE PTR [eax+0x2038],0x8
4906ba: je 0x4906e3
4906bc: xor eax,eax
4906be: mov al,bl
4906c0: imul eax,eax,0x16
4906c3: mov edx,DWORD PTR ds:0x4b0ef0
4906c9: cmp BYTE PTR [edx+eax*8-0x43],0x1
4906ce: jne 0x4906e3
4906d0: mov eax,DWORD PTR [ebp-0x4]
4906d3: mov edx,0x490890
4906d8: call 0x403d60
4906dd: jne 0x4906e3
4906df: mov BYTE PTR [ebp-0x5],0x1
4906e3: mov eax,DWORD PTR [esi+0x2d8]
4906e9: mov eax,DWORD PTR [eax+0x38]
4906ec: test BYTE PTR [eax+0x2038],0x1
4906f3: je 0x490708
4906f5: mov eax,DWORD PTR [ebp-0x4]
4906f8: mov edx,0x4908a0
4906fd: call 0x403d60
490702: jne 0x490708
490704: mov BYTE PTR [ebp-0x5],0x1
490708: cmp bl,0x2
49070b: jne 0x49083f
490711: mov eax,DWORD PTR [esi+0x2d8]
490717: mov eax,DWORD PTR [eax+0x34]
49071a: test BYTE PTR [eax+0x2038],0x2
490721: je 0x490736
490723: mov eax,DWORD PTR [ebp-0x4]
490726: mov edx,0x490870
49072b: call 0x403d60
490730: jne 0x490736
490732: mov BYTE PTR [ebp-0x5],0x1
490736: mov eax,DWORD PTR [esi+0x2d8]
49073c: mov eax,DWORD PTR [eax+0x34]
49073f: test BYTE PTR [eax+0x2038],0x4
490746: je 0x49076f
490748: xor eax,eax
49074a: mov al,bl
49074c: imul eax,eax,0x16
49074f: mov edx,DWORD PTR ds:0x4b0ef0
490755: cmp BYTE PTR [edx+eax*8-0x43],0x1
49075a: jne 0x49076f
49075c: mov eax,DWORD PTR [ebp-0x4]
49075f: mov edx,0x490880
490764: call 0x403d60
490769: jne 0x49076f
49076b: mov BYTE PTR [ebp-0x5],0x1
49076f: mov eax,DWORD PTR [esi+0x2d8]
490775: mov eax,DWORD PTR [eax+0x34]
490778: test BYTE PTR [eax+0x2038],0x8
49077f: je 0x4907a8
490781: xor eax,eax
490783: mov al,bl
490785: imul eax,eax,0x16
490788: mov edx,DWORD PTR ds:0x4b0ef0
49078e: cmp BYTE PTR [edx+eax*8-0x43],0x2
490793: jne 0x4907a8
490795: mov eax,DWORD PTR [ebp-0x4]
490798: mov edx,0x490880
49079d: call 0x403d60
4907a2: jne 0x4907a8
4907a4: mov BYTE PTR [ebp-0x5],0x1
4907a8: mov eax,DWORD PTR [esi+0x2d8]
4907ae: mov eax,DWORD PTR [eax+0x34]
4907b1: test BYTE PTR [eax+0x2038],0x4
4907b8: je 0x4907e1
4907ba: xor eax,eax
4907bc: mov al,bl
4907be: imul eax,eax,0x16
4907c1: mov edx,DWORD PTR ds:0x4b0ef0
4907c7: cmp BYTE PTR [edx+eax*8-0x43],0x2
4907cc: jne 0x4907e1
4907ce: mov eax,DWORD PTR [ebp-0x4]
4907d1: mov edx,0x490890
4907d6: call 0x403d60
4907db: jne 0x4907e1
4907dd: mov BYTE PTR [ebp-0x5],0x1
4907e1: mov eax,DWORD PTR [esi+0x2d8]
4907e7: mov eax,DWORD PTR [eax+0x34]
4907ea: test BYTE PTR [eax+0x2038],0x8
4907f1: je 0x49081a
4907f3: xor eax,eax
4907f5: mov al,bl
4907f7: imul eax,eax,0x16
4907fa: mov edx,DWORD PTR ds:0x4b0ef0
490800: cmp BYTE PTR [edx+eax*8-0x43],0x1
490805: jne 0x49081a
490807: mov eax,DWORD PTR [ebp-0x4]
49080a: mov edx,0x490890
49080f: call 0x403d60
490814: jne 0x49081a
490816: mov BYTE PTR [ebp-0x5],0x1
49081a: mov eax,DWORD PTR [esi+0x2d8]
490820: mov eax,DWORD PTR [eax+0x34]
490823: test BYTE PTR [eax+0x2038],0x1
49082a: je 0x49083f
49082c: mov eax,DWORD PTR [ebp-0x4]
49082f: mov edx,0x4908a0
490834: call 0x403d60
490839: jne 0x49083f
49083b: mov BYTE PTR [ebp-0x5],0x1
49083f: xor eax,eax
490841: pop edx
490842: pop ecx
490843: pop ecx
490844: mov DWORD PTR fs:[eax],edx
490847: push 0x49085c
49084c: lea eax,[ebp-0x4]
49084f: call 0x4039d0
490854: ret
490855: jmp 0x403468
49085c: mov al,BYTE PTR [ebp-0x5]
49085f: pop esi
490860: pop ebx
490861: pop ecx
490862: pop ecx
490863: pop ebp
490864: ret
.data 4b0ef0 e8444b000c204b0030b8
.string 490870 424149584f
.string 490880 54524153
.string 490890 4652454e5445
.string 4908a0 43494d41
