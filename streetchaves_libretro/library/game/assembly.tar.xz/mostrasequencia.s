; entry 491b5c
; exit 403468
491b5c: push ebp
491b5d: mov ebp,esp
491b5f: add esp,0xfffffff0
491b62: push ebx
491b63: push esi
491b64: push edi
491b65: xor ebx,ebx
491b67: mov DWORD PTR [ebp-0x10],ebx
491b6a: mov DWORD PTR [ebp-0xc],ebx
491b6d: mov DWORD PTR [ebp-0x8],ecx
491b70: mov DWORD PTR [ebp-0x4],edx
491b73: mov esi,eax
491b75: mov eax,DWORD PTR [ebp+0xc]
491b78: call 0x403e04
491b7d: mov eax,DWORD PTR [ebp+0x8]
491b80: call 0x403e04
491b85: xor eax,eax
491b87: push ebp
491b88: push 0x491e81
491b8d: push DWORD PTR fs:[eax]
491b90: mov DWORD PTR fs:[eax],esp
491b93: mov cl,0xff
491b95: mov dl,0xff
491b97: mov al,0xff
491b99: call 0x406de4
491b9e: mov ebx,eax
491ba0: mov eax,DWORD PTR [ebp+0xc]
491ba3: cmp BYTE PTR [eax],0x2a
491ba6: jne 0x491bb5
491ba8: mov cl,0x78
491baa: mov dl,0x78
491bac: mov al,0xff
491bae: call 0x406de4
491bb3: mov ebx,eax
491bb5: lea eax,[ebp-0xc]
491bb8: mov ecx,0x491e9c
491bbd: mov edx,DWORD PTR [ebp+0xc]
491bc0: call 0x403c9c
491bc5: mov eax,DWORD PTR [ebp-0xc]
491bc8: push eax
491bc9: push 0x2d
491bcb: push 0x9
491bcd: push ebx
491bce: mov ecx,DWORD PTR [ebp-0x8]
491bd1: mov edx,DWORD PTR [ebp-0x4]
491bd4: mov eax,esi
491bd6: call 0x48e720
491bdb: mov eax,DWORD PTR [esi+0x2d0]
491be1: mov eax,DWORD PTR [eax+0x270]
491be7: call 0x45cd9c
491bec: push eax
491bed: lea eax,[ebp-0x10]
491bf0: mov ecx,0x491e9c
491bf5: mov edx,DWORD PTR [ebp+0xc]
491bf8: call 0x403c9c
491bfd: mov edx,DWORD PTR [ebp-0x10]
491c00: pop eax
491c01: call 0x41887c
491c06: mov edi,eax
491c08: mov ebx,0x1
491c0d: jmp 0x491e49
491c12: mov eax,DWORD PTR [esi+0x2d0]
491c18: mov eax,DWORD PTR [eax+0x270]
491c1e: call 0x45cd9c
491c23: call 0x45bb18
491c28: mov eax,DWORD PTR [ebp+0x8]
491c2b: cmp BYTE PTR [eax+ebx*1-0x1],0x43
491c30: jne 0x491c61
491c32: mov eax,DWORD PTR [ebp-0x8]
491c35: add eax,0x3
491c38: push eax
491c39: push 0x0
491c3b: mov eax,DWORD PTR [esi+0x314]
491c41: mov eax,DWORD PTR [eax+0x28]
491c44: xor edx,edx
491c46: call 0x461dcc
491c4b: mov ecx,DWORD PTR [ebp-0x4]
491c4e: add ecx,edi
491c50: mov edx,DWORD PTR [esi+0x2d0]
491c56: mov edx,DWORD PTR [edx+0x270]
491c5c: call 0x46161c
491c61: mov eax,DWORD PTR [ebp+0x8]
491c64: cmp BYTE PTR [eax+ebx*1-0x1],0x42
491c69: jne 0x491c9d
491c6b: mov eax,DWORD PTR [ebp-0x8]
491c6e: add eax,0x3
491c71: push eax
491c72: push 0x0
491c74: mov eax,DWORD PTR [esi+0x314]
491c7a: mov eax,DWORD PTR [eax+0x28]
491c7d: mov edx,0x1
491c82: call 0x461dcc
491c87: mov ecx,DWORD PTR [ebp-0x4]
491c8a: add ecx,edi
491c8c: mov edx,DWORD PTR [esi+0x2d0]
491c92: mov edx,DWORD PTR [edx+0x270]
491c98: call 0x46161c
491c9d: mov eax,DWORD PTR [ebp+0x8]
491ca0: cmp BYTE PTR [eax+ebx*1-0x1],0x44
491ca5: jne 0x491cd9
491ca7: mov eax,DWORD PTR [ebp-0x8]
491caa: add eax,0x3
491cad: push eax
491cae: push 0x0
491cb0: mov eax,DWORD PTR [esi+0x314]
491cb6: mov eax,DWORD PTR [eax+0x28]
491cb9: mov edx,0x2
491cbe: call 0x461dcc
491cc3: mov ecx,DWORD PTR [ebp-0x4]
491cc6: add ecx,edi
491cc8: mov edx,DWORD PTR [esi+0x2d0]
491cce: mov edx,DWORD PTR [edx+0x270]
491cd4: call 0x46161c
491cd9: mov eax,DWORD PTR [ebp+0x8]
491cdc: cmp BYTE PTR [eax+ebx*1-0x1],0x45
491ce1: jne 0x491d15
491ce3: mov eax,DWORD PTR [ebp-0x8]
491ce6: add eax,0x3
491ce9: push eax
491cea: push 0x0
491cec: mov eax,DWORD PTR [esi+0x314]
491cf2: mov eax,DWORD PTR [eax+0x28]
491cf5: mov edx,0x3
491cfa: call 0x461dcc
491cff: mov ecx,DWORD PTR [ebp-0x4]
491d02: add ecx,edi
491d04: mov edx,DWORD PTR [esi+0x2d0]
491d0a: mov edx,DWORD PTR [edx+0x270]
491d10: call 0x46161c
491d15: mov eax,DWORD PTR [ebp+0x8]
491d18: cmp BYTE PTR [eax+ebx*1-0x1],0x59
491d1d: jne 0x491d51
491d1f: mov eax,DWORD PTR [ebp-0x8]
491d22: add eax,0x3
491d25: push eax
491d26: push 0x0
491d28: mov eax,DWORD PTR [esi+0x314]
491d2e: mov eax,DWORD PTR [eax+0x28]
491d31: mov edx,0x4
491d36: call 0x461dcc
491d3b: mov ecx,DWORD PTR [ebp-0x4]
491d3e: add ecx,edi
491d40: mov edx,DWORD PTR [esi+0x2d0]
491d46: mov edx,DWORD PTR [edx+0x270]
491d4c: call 0x46161c
491d51: mov eax,DWORD PTR [ebp+0x8]
491d54: cmp BYTE PTR [eax+ebx*1-0x1],0x5a
491d59: jne 0x491d8d
491d5b: mov eax,DWORD PTR [ebp-0x8]
491d5e: add eax,0x3
491d61: push eax
491d62: push 0x0
491d64: mov eax,DWORD PTR [esi+0x314]
491d6a: mov eax,DWORD PTR [eax+0x28]
491d6d: mov edx,0x5
491d72: call 0x461dcc
491d77: mov ecx,DWORD PTR [ebp-0x4]
491d7a: add ecx,edi
491d7c: mov edx,DWORD PTR [esi+0x2d0]
491d82: mov edx,DWORD PTR [edx+0x270]
491d88: call 0x46161c
491d8d: mov eax,DWORD PTR [ebp+0x8]
491d90: cmp BYTE PTR [eax+ebx*1-0x1],0x50
491d95: jne 0x491dbb
491d97: push 0x491ea8
491d9c: push 0x2d
491d9e: push 0x9
491da0: mov cl,0xff
491da2: mov dl,0xff
491da4: mov al,0xff
491da6: call 0x406de4
491dab: push eax
491dac: mov edx,DWORD PTR [ebp-0x4]
491daf: add edx,edi
491db1: mov ecx,DWORD PTR [ebp-0x8]
491db4: mov eax,esi
491db6: call 0x48e720
491dbb: mov eax,DWORD PTR [ebp+0x8]
491dbe: cmp BYTE PTR [eax+ebx*1-0x1],0x4b
491dc3: jne 0x491de9
491dc5: push 0x491eb4
491dca: push 0x2d
491dcc: push 0x9
491dce: mov cl,0xff
491dd0: mov dl,0xff
491dd2: mov al,0xff
491dd4: call 0x406de4
491dd9: push eax
491dda: mov edx,DWORD PTR [ebp-0x4]
491ddd: add edx,edi
491ddf: mov ecx,DWORD PTR [ebp-0x8]
491de2: mov eax,esi
491de4: call 0x48e720
491de9: mov eax,DWORD PTR [ebp+0x8]
491dec: cmp BYTE PTR [eax+ebx*1-0x1],0x52
491df1: jne 0x491e17
491df3: push 0x491ec0
491df8: push 0x2d
491dfa: push 0x9
491dfc: mov cl,0xff
491dfe: mov dl,0xff
491e00: mov al,0xff
491e02: call 0x406de4
491e07: push eax
491e08: mov edx,DWORD PTR [ebp-0x4]
491e0b: add edx,edi
491e0d: mov ecx,DWORD PTR [ebp-0x8]
491e10: mov eax,esi
491e12: call 0x48e720
491e17: mov eax,DWORD PTR [ebp+0x8]
491e1a: cmp BYTE PTR [eax+ebx*1-0x1],0x3f
491e1f: jne 0x491e45
491e21: push 0x491ed4
491e26: push 0x2d
491e28: push 0x9
491e2a: mov cl,0xff
491e2c: mov dl,0xff
491e2e: mov al,0xff
491e30: call 0x406de4
491e35: push eax
491e36: mov edx,DWORD PTR [ebp-0x4]
491e39: add edx,edi
491e3b: mov ecx,DWORD PTR [ebp-0x8]
491e3e: mov eax,esi
491e40: call 0x48e720
491e45: inc ebx
491e46: add edi,0xc
491e49: mov eax,DWORD PTR [ebp+0x8]
491e4c: call 0x403c50
491e51: cmp ebx,eax
491e53: jle 0x491c12
491e59: xor eax,eax
491e5b: pop edx
491e5c: pop ecx
491e5d: pop ecx
491e5e: mov DWORD PTR fs:[eax],edx
491e61: push 0x491e88
491e66: lea eax,[ebp-0x10]
491e69: mov edx,0x2
491e6e: call 0x4039f4
491e73: lea eax,[ebp+0x8]
491e76: mov edx,0x2
491e7b: call 0x4039f4
491e80: ret
491e81: jmp 0x403468
491e88: pop edi
491e89: pop esi
491e8a: pop ebx
491e8b: mov esp,ebp
491e8d: pop ebp
491e8e: ret 0x8
.string 491e9c 202d20
.string 491ea8 2b53
.string 491eb4 2b43
.string 491ec0 202872e17069646f29
.string 491ed4 2b532f43
