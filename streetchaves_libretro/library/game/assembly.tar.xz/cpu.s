; entry 4931ac
4931ac: push ebx
4931ad: push esi
4931ae: push edi
4931af: push ebp
4931b0: add esp,0xffffffe4
4931b3: mov ebx,edx
4931b5: mov eax,ds:0x4b0ef0
4931ba: fld QWORD PTR [eax]
4931bc: call 0x402894
4931c1: push edx
4931c2: push eax
4931c3: mov eax,ds:0x4b0ef0
4931c8: fld QWORD PTR [eax+0xb0]
4931ce: call 0x402894
4931d3: sub DWORD PTR [esp],eax
4931d6: sbb DWORD PTR [esp+0x4],edx
4931da: pop eax
4931db: pop edx
4931dc: test edx,edx
4931de: jge 0x4931e7
4931e0: neg eax
4931e2: adc edx,0x0
4931e5: neg edx
4931e7: mov edi,eax
4931e9: xor eax,eax
4931eb: mov al,bl
4931ed: mov edx,0x3
4931f2: sub edx,eax
4931f4: imul eax,edx,0x16
4931f7: mov edx,DWORD PTR ds:0x4b0ef0
4931fd: fld QWORD PTR [edx+eax*8-0xa8]
493204: call 0x402894
493209: mov DWORD PTR [esp],eax
49320c: mov BYTE PTR [esp+0x8],0x0
493211: xor eax,eax
493213: mov DWORD PTR [esp+0x4],eax
493217: mov ebp,0x50
49321c: mov esi,DWORD PTR ds:0x4b1118
493222: add esi,0x31
493225: cmp BYTE PTR [esi],0x1
493228: jne 0x493275
49322a: cmp bl,BYTE PTR [esi-0xd]
49322d: je 0x493275
49322f: cmp BYTE PTR [esi-0x6],0x0
493233: je 0x493275
493235: mov BYTE PTR [esp+0x8],0x1
49323a: xor eax,eax
49323c: mov al,bl
49323e: imul eax,eax,0x16
493241: mov edx,DWORD PTR ds:0x4b0ef0
493247: fld QWORD PTR [edx+eax*8-0xb0]
49324e: call 0x402894
493253: push edx
493254: push eax
493255: fld QWORD PTR [esi-0x31]
493258: call 0x402894
49325d: sub DWORD PTR [esp],eax
493260: sbb DWORD PTR [esp+0x4],edx
493264: pop eax
493265: pop edx
493266: test edx,edx
493268: jge 0x493271
49326a: neg eax
49326c: adc edx,0x0
49326f: neg edx
493271: mov DWORD PTR [esp+0x4],eax
493275: add esi,0x38
493278: dec ebp
493279: jne 0x493225
49327b: mov eax,ds:0x4b0d50
493280: movzx eax,BYTE PTR [eax]
493283: mov edx,0x8
493288: sub edx,eax
49328a: mov DWORD PTR [esp+0x18],edx
49328e: fild DWORD PTR [esp+0x18]
493292: fld TBYTE PTR ds:0x494b5c
493298: fmulp st(1),st
49329a: fld TBYTE PTR ds:0x494b68
4932a0: faddp st(1),st
4932a2: fstp QWORD PTR [esp+0x10]
4932a6: fwait
4932a7: mov eax,ds:0x4b116c
4932ac: movzx eax,BYTE PTR [eax]
4932af: mov DWORD PTR [esp+0x18],eax
4932b3: fild DWORD PTR [esp+0x18]
4932b7: fld TBYTE PTR ds:0x494b74
4932bd: fmulp st(1),st
4932bf: fsubr QWORD PTR [esp+0x10]
4932c3: fstp QWORD PTR [esp+0x10]
4932c7: fwait
4932c8: mov eax,0xd
4932cd: call 0x402a1c
4932d2: test eax,eax
4932d4: jne 0x493393
4932da: mov eax,0x6
4932df: call 0x402a1c
4932e4: mov ebp,eax
4932e6: test ebp,ebp
4932e8: jne 0x493302
4932ea: xor eax,eax
4932ec: mov al,bl
4932ee: imul eax,eax,0x16
4932f1: mov edx,DWORD PTR ds:0x4b0ef0
4932f7: mov DWORD PTR [edx+eax*8-0x94],0x64
493302: cmp ebp,0x1
493305: jne 0x49331f
493307: xor eax,eax
493309: mov al,bl
49330b: imul eax,eax,0x16
49330e: mov edx,DWORD PTR ds:0x4b0ef0
493314: mov DWORD PTR [edx+eax*8-0x94],0x96
49331f: cmp ebp,0x2
493322: jne 0x49333c
493324: xor eax,eax
493326: mov al,bl
493328: imul eax,eax,0x16
49332b: mov edx,DWORD PTR ds:0x4b0ef0
493331: mov DWORD PTR [edx+eax*8-0x94],0xc8
49333c: cmp ebp,0x3
49333f: jne 0x493359
493341: xor eax,eax
493343: mov al,bl
493345: imul eax,eax,0x16
493348: mov edx,DWORD PTR ds:0x4b0ef0
49334e: mov DWORD PTR [edx+eax*8-0x94],0xfa
493359: cmp ebp,0x4
49335c: jne 0x493376
49335e: xor eax,eax
493360: mov al,bl
493362: imul eax,eax,0x16
493365: mov edx,DWORD PTR ds:0x4b0ef0
49336b: mov DWORD PTR [edx+eax*8-0x94],0x12c
493376: cmp ebp,0x5
493379: jne 0x493393
49337b: xor eax,eax
49337d: mov al,bl
49337f: imul eax,eax,0x16
493382: mov edx,DWORD PTR ds:0x4b0ef0
493388: mov DWORD PTR [edx+eax*8-0x94],0x15e
493393: xor eax,eax
493395: mov al,bl
493397: imul ecx,eax,0x16
49339a: mov eax,ds:0x4b0ef0
49339f: push DWORD PTR [eax+ecx*8-0x94]
4933a6: mov eax,edi
4933a8: pop edx
4933a9: sub eax,edx
4933ab: cdq
4933ac: xor eax,edx
4933ae: sub eax,edx
4933b0: cmp eax,0x32
4933b3: jg 0x4933c1
4933b5: mov eax,ds:0x4b0ef0
4933ba: mov DWORD PTR [eax+ecx*8-0x94],edi
4933c1: xor eax,eax
4933c3: mov al,bl
4933c5: imul eax,eax,0x16
4933c8: mov edx,DWORD PTR ds:0x4b0ef0
4933ce: cmp BYTE PTR [edx+eax*8-0x1d],0x0
4933d3: jne 0x493494
4933d9: cmp BYTE PTR [esp+0x8],0x0
4933de: jne 0x493494
4933e4: xor eax,eax
4933e6: mov al,bl
4933e8: imul eax,eax,0x16
4933eb: mov edx,DWORD PTR ds:0x4b0ef0
4933f1: cmp edi,DWORD PTR [edx+eax*8-0x94]
4933f8: jl 0x493410
4933fa: mov edx,DWORD PTR ds:0x4b0ef0
493400: cmp BYTE PTR [edx+eax*8-0x43],0x1
493405: jne 0x493410
493407: mov dl,0x2
493409: mov eax,ebx
49340b: call 0x4775fc
493410: xor eax,eax
493412: mov al,bl
493414: imul eax,eax,0x16
493417: mov edx,DWORD PTR ds:0x4b0ef0
49341d: cmp edi,DWORD PTR [edx+eax*8-0x94]
493424: jge 0x49343c
493426: mov edx,DWORD PTR ds:0x4b0ef0
49342c: cmp BYTE PTR [edx+eax*8-0x43],0x1
493431: jne 0x49343c
493433: mov dl,0x1
493435: mov eax,ebx
493437: call 0x4775fc
49343c: xor eax,eax
49343e: mov al,bl
493440: imul eax,eax,0x16
493443: mov edx,DWORD PTR ds:0x4b0ef0
493449: cmp edi,DWORD PTR [edx+eax*8-0x94]
493450: jl 0x493468
493452: mov edx,DWORD PTR ds:0x4b0ef0
493458: cmp BYTE PTR [edx+eax*8-0x43],0x2
49345d: jne 0x493468
49345f: mov dl,0x1
493461: mov eax,ebx
493463: call 0x4775fc
493468: xor eax,eax
49346a: mov al,bl
49346c: imul eax,eax,0x16
49346f: mov edx,DWORD PTR ds:0x4b0ef0
493475: cmp edi,DWORD PTR [edx+eax*8-0x94]
49347c: jge 0x493494
49347e: mov edx,DWORD PTR ds:0x4b0ef0
493484: cmp BYTE PTR [edx+eax*8-0x43],0x2
493489: jne 0x493494
49348b: mov dl,0x2
49348d: mov eax,ebx
49348f: call 0x4775fc
493494: xor eax,eax
493496: mov al,bl
493498: imul esi,eax,0x16
49349b: mov eax,ds:0x4b0ef0
4934a0: cmp BYTE PTR [eax+esi*8-0x1d],0x0
4934a5: jne 0x4935ec
4934ab: cmp BYTE PTR [esp+0x8],0x0
4934b0: jne 0x4935ec
4934b6: cmp edi,0x50
4934b9: jg 0x4935ec
4934bf: fld DWORD PTR ds:0x494b80
4934c5: fmul QWORD PTR [esp+0x10]
4934c9: call 0x402894
4934ce: call 0x402a1c
4934d3: test eax,eax
4934d5: jne 0x4934e0
4934d7: mov dl,0x3
4934d9: mov eax,ebx
4934db: call 0x4775fc
4934e0: fld DWORD PTR ds:0x494b80
4934e6: fmul QWORD PTR [esp+0x10]
4934ea: call 0x402894
4934ef: call 0x402a1c
4934f4: test eax,eax
4934f6: jne 0x493501
4934f8: mov dl,0x4
4934fa: mov eax,ebx
4934fc: call 0x4775fc
493501: fld DWORD PTR ds:0x494b84
493507: fmul QWORD PTR [esp+0x10]
49350b: call 0x402894
493510: call 0x402a1c
493515: test eax,eax
493517: jne 0x493522
493519: mov dl,0x5
49351b: mov eax,ebx
49351d: call 0x4775fc
493522: fld DWORD PTR ds:0x494b84
493528: fmul QWORD PTR [esp+0x10]
49352c: call 0x402894
493531: call 0x402a1c
493536: test eax,eax
493538: jne 0x493543
49353a: mov dl,0x6
49353c: mov eax,ebx
49353e: call 0x4775fc
493543: fld DWORD PTR ds:0x494b88
493549: fmul QWORD PTR [esp+0x10]
49354d: call 0x402894
493552: call 0x402a1c
493557: test eax,eax
493559: jne 0x4935ec
49355f: mov dl,0x7
493561: mov eax,ebx
493563: call 0x4775fc
493568: fld DWORD PTR ds:0x494b8c
49356e: fmul QWORD PTR [esp+0x10]
493572: call 0x402894
493577: call 0x402a1c
49357c: test eax,eax
49357e: jne 0x493589
493580: mov dl,0x3
493582: mov eax,ebx
493584: call 0x4775fc
493589: fld DWORD PTR ds:0x494b8c
49358f: fmul QWORD PTR [esp+0x10]
493593: call 0x402894
493598: call 0x402a1c
49359d: test eax,eax
49359f: jne 0x4935aa
4935a1: mov dl,0x4
4935a3: mov eax,ebx
4935a5: call 0x4775fc
4935aa: fld DWORD PTR ds:0x494b90
4935b0: fmul QWORD PTR [esp+0x10]
4935b4: call 0x402894
4935b9: call 0x402a1c
4935be: test eax,eax
4935c0: jne 0x4935cb
4935c2: mov dl,0x5
4935c4: mov eax,ebx
4935c6: call 0x4775fc
4935cb: fld DWORD PTR ds:0x494b90
4935d1: fmul QWORD PTR [esp+0x10]
4935d5: call 0x402894
4935da: call 0x402a1c
4935df: test eax,eax
4935e1: jne 0x4935ec
4935e3: mov dl,0x6
4935e5: mov eax,ebx
4935e7: call 0x4775fc
4935ec: mov eax,ds:0x4b0ef0
4935f1: cmp BYTE PTR [eax+esi*8-0x1d],0x0
4935f6: jne 0x494b53
4935fc: mov eax,ds:0x4b0ef0
493601: cmp BYTE PTR [eax+esi*8-0xa0],0x1
493609: jne 0x4937af
49360f: cmp BYTE PTR [esp+0x8],0x1
493614: jne 0x49364e
493616: cmp DWORD PTR [esp+0x4],0x8c
49361e: jle 0x49364e
493620: fld DWORD PTR ds:0x494b94
493626: fmul QWORD PTR [esp+0x10]
49362a: call 0x402894
49362f: call 0x402a1c
493634: test eax,eax
493636: jne 0x49364e
493638: mov eax,0x2
49363d: call 0x402a1c
493642: mov edx,eax
493644: add dl,0x10
493647: mov eax,ebx
493649: call 0x4775fc
49364e: cmp BYTE PTR [esp+0x8],0x0
493653: jne 0x493688
493655: cmp edi,0x78
493658: jle 0x493688
49365a: fld DWORD PTR ds:0x494b98
493660: fmul QWORD PTR [esp+0x10]
493664: call 0x402894
493669: call 0x402a1c
49366e: test eax,eax
493670: jne 0x493688
493672: mov eax,0x2
493677: call 0x402a1c
49367c: mov edx,eax
49367e: add dl,0x10
493681: mov eax,ebx
493683: call 0x4775fc
493688: cmp BYTE PTR [esp+0x8],0x0
49368d: jne 0x4936c5
49368f: cmp edi,0xc8
493695: jge 0x4936c5
493697: fld DWORD PTR ds:0x494b9c
49369d: fmul QWORD PTR [esp+0x10]
4936a1: call 0x402894
4936a6: call 0x402a1c
4936ab: test eax,eax
4936ad: jne 0x4936c5
4936af: mov eax,0x2
4936b4: call 0x402a1c
4936b9: mov edx,eax
4936bb: add dl,0x12
4936be: mov eax,ebx
4936c0: call 0x4775fc
4936c5: cmp edi,0x96
4936cb: jge 0x493722
4936cd: mov eax,ds:0x4b11f8
4936d2: fild WORD PTR [eax]
4936d4: xor eax,eax
4936d6: mov al,bl
4936d8: mov edx,0x3
4936dd: sub edx,eax
4936df: imul eax,edx,0x16
4936e2: mov edx,DWORD PTR ds:0x4b0ef0
4936e8: fcomp QWORD PTR [edx+eax*8-0xa8]
4936ef: fnstsw ax
4936f1: sahf
4936f2: jbe 0x493722
4936f4: fld DWORD PTR ds:0x494ba0
4936fa: fmul QWORD PTR [esp+0x10]
4936fe: call 0x402894
493703: call 0x402a1c
493708: test eax,eax
49370a: jne 0x493722
49370c: mov eax,0x2
493711: call 0x402a1c
493716: mov edx,eax
493718: add dl,0x14
49371b: mov eax,ebx
49371d: call 0x4775fc
493722: cmp BYTE PTR [esp+0x8],0x0
493727: jne 0x49375f
493729: cmp edi,0xc8
49372f: jge 0x49375f
493731: fld DWORD PTR ds:0x494b9c
493737: fmul QWORD PTR [esp+0x10]
49373b: call 0x402894
493740: call 0x402a1c
493745: test eax,eax
493747: jne 0x49375f
493749: mov eax,0x2
49374e: call 0x402a1c
493753: mov edx,eax
493755: add dl,0x16
493758: mov eax,ebx
49375a: call 0x4775fc
49375f: cmp edi,0x96
493765: jge 0x4937af
493767: mov eax,ds:0x4b11f8
49376c: fild WORD PTR [eax]
49376e: xor eax,eax
493770: mov al,bl
493772: mov edx,0x3
493777: sub edx,eax
493779: imul eax,edx,0x16
49377c: mov edx,DWORD PTR ds:0x4b0ef0
493782: fcomp QWORD PTR [edx+eax*8-0xa8]
493789: fnstsw ax
49378b: sahf
49378c: jbe 0x4937af
49378e: fld DWORD PTR ds:0x494ba0
493794: fmul QWORD PTR [esp+0x10]
493798: call 0x402894
49379d: call 0x402a1c
4937a2: test eax,eax
4937a4: jne 0x4937af
4937a6: mov dl,0x18
4937a8: mov eax,ebx
4937aa: call 0x4775fc
4937af: xor eax,eax
4937b1: mov al,bl
4937b3: imul eax,eax,0x16
4937b6: mov edx,DWORD PTR ds:0x4b0ef0
4937bc: cmp BYTE PTR [edx+eax*8-0xa0],0x2
4937c4: jne 0x49393c
4937ca: cmp BYTE PTR [esp+0x8],0x1
4937cf: jne 0x493809
4937d1: cmp DWORD PTR [esp+0x4],0x8c
4937d9: jle 0x493809
4937db: fld DWORD PTR ds:0x494b80
4937e1: fmul QWORD PTR [esp+0x10]
4937e5: call 0x402894
4937ea: call 0x402a1c
4937ef: test eax,eax
4937f1: jne 0x493809
4937f3: mov eax,0x2
4937f8: call 0x402a1c
4937fd: mov edx,eax
4937ff: add dl,0x10
493802: mov eax,ebx
493804: call 0x4775fc
493809: cmp BYTE PTR [esp+0x8],0x0
49380e: jne 0x493843
493810: cmp edi,0x78
493813: jle 0x493843
493815: fld DWORD PTR ds:0x494b98
49381b: fmul QWORD PTR [esp+0x10]
49381f: call 0x402894
493824: call 0x402a1c
493829: test eax,eax
49382b: jne 0x493843
49382d: mov eax,0x2
493832: call 0x402a1c
493837: mov edx,eax
493839: add dl,0x10
49383c: mov eax,ebx
49383e: call 0x4775fc
493843: cmp BYTE PTR [esp+0x8],0x0
493848: jne 0x49387d
49384a: cmp edi,0x64
49384d: jge 0x49387d
49384f: fld DWORD PTR ds:0x494ba4
493855: fmul QWORD PTR [esp+0x10]
493859: call 0x402894
49385e: call 0x402a1c
493863: test eax,eax
493865: jne 0x49387d
493867: mov eax,0x2
49386c: call 0x402a1c
493871: mov edx,eax
493873: add dl,0x12
493876: mov eax,ebx
493878: call 0x4775fc
49387d: cmp edi,0xc8
493883: jge 0x4938df
493885: mov eax,ds:0x4b11f8
49388a: movsx eax,WORD PTR [eax]
49388d: sub eax,0x64
493890: mov DWORD PTR [esp+0x18],eax
493894: fild DWORD PTR [esp+0x18]
493898: xor eax,eax
49389a: mov al,bl
49389c: imul eax,eax,0x16
49389f: mov edx,DWORD PTR ds:0x4b0ef0
4938a5: fcomp QWORD PTR [edx+eax*8-0xa8]
4938ac: fnstsw ax
4938ae: sahf
4938af: jbe 0x4938df
4938b1: fld DWORD PTR ds:0x494ba8
4938b7: fmul QWORD PTR [esp+0x10]
4938bb: call 0x402894
4938c0: call 0x402a1c
4938c5: test eax,eax
4938c7: jne 0x4938df
4938c9: mov eax,0x2
4938ce: call 0x402a1c
4938d3: mov edx,eax
4938d5: add dl,0x14
4938d8: mov eax,ebx
4938da: call 0x4775fc
4938df: cmp BYTE PTR [esp+0x8],0x0
4938e4: jne 0x49390c
4938e6: cmp edi,0x64
4938e9: jge 0x49390c
4938eb: fld DWORD PTR ds:0x494b9c
4938f1: fmul QWORD PTR [esp+0x10]
4938f5: call 0x402894
4938fa: call 0x402a1c
4938ff: test eax,eax
493901: jne 0x49390c
493903: mov dl,0x16
493905: mov eax,ebx
493907: call 0x4775fc
49390c: cmp BYTE PTR [esp+0x8],0x0
493911: jne 0x49393c
493913: cmp edi,0xfa
493919: jge 0x49393c
49391b: fld DWORD PTR ds:0x494bac
493921: fmul QWORD PTR [esp+0x10]
493925: call 0x402894
49392a: call 0x402a1c
49392f: test eax,eax
493931: jne 0x49393c
493933: mov dl,0x17
493935: mov eax,ebx
493937: call 0x4775fc
49393c: xor eax,eax
49393e: mov al,bl
493940: imul eax,eax,0x16
493943: mov edx,DWORD PTR ds:0x4b0ef0
493949: cmp BYTE PTR [edx+eax*8-0xa0],0x3
493951: jne 0x493ab4
493957: cmp BYTE PTR [esp+0x8],0x1
49395c: jne 0x493996
49395e: cmp DWORD PTR [esp+0x4],0x8c
493966: jle 0x493996
493968: fld DWORD PTR ds:0x494b80
49396e: fmul QWORD PTR [esp+0x10]
493972: call 0x402894
493977: call 0x402a1c
49397c: test eax,eax
49397e: jne 0x493996
493980: mov eax,0x2
493985: call 0x402a1c
49398a: mov edx,eax
49398c: add dl,0x10
49398f: mov eax,ebx
493991: call 0x4775fc
493996: cmp BYTE PTR [esp+0x8],0x0
49399b: jne 0x4939d0
49399d: cmp edi,0x78
4939a0: jle 0x4939d0
4939a2: fld DWORD PTR ds:0x494bb0
4939a8: fmul QWORD PTR [esp+0x10]
4939ac: call 0x402894
4939b1: call 0x402a1c
4939b6: test eax,eax
4939b8: jne 0x4939d0
4939ba: mov eax,0x2
4939bf: call 0x402a1c
4939c4: mov edx,eax
4939c6: add dl,0x10
4939c9: mov eax,ebx
4939cb: call 0x4775fc
4939d0: cmp BYTE PTR [esp+0x8],0x0
4939d5: jne 0x493a0a
4939d7: cmp edi,0x64
4939da: jge 0x493a0a
4939dc: fld DWORD PTR ds:0x494bb4
4939e2: fmul QWORD PTR [esp+0x10]
4939e6: call 0x402894
4939eb: call 0x402a1c
4939f0: test eax,eax
4939f2: jne 0x493a0a
4939f4: mov eax,0x2
4939f9: call 0x402a1c
4939fe: mov edx,eax
493a00: add dl,0x12
493a03: mov eax,ebx
493a05: call 0x4775fc
493a0a: cmp BYTE PTR [esp+0x8],0x0
493a0f: jne 0x493a47
493a11: cmp edi,0xc8
493a17: jge 0x493a47
493a19: fld DWORD PTR ds:0x494ba4
493a1f: fmul QWORD PTR [esp+0x10]
493a23: call 0x402894
493a28: call 0x402a1c
493a2d: test eax,eax
493a2f: jne 0x493a47
493a31: mov eax,0x2
493a36: call 0x402a1c
493a3b: mov edx,eax
493a3d: add dl,0x14
493a40: mov eax,ebx
493a42: call 0x4775fc
493a47: cmp BYTE PTR [esp+0x8],0x0
493a4c: jne 0x493a84
493a4e: cmp edi,0x96
493a54: jge 0x493a84
493a56: fld DWORD PTR ds:0x494b9c
493a5c: fmul QWORD PTR [esp+0x10]
493a60: call 0x402894
493a65: call 0x402a1c
493a6a: test eax,eax
493a6c: jne 0x493a84
493a6e: mov eax,0x2
493a73: call 0x402a1c
493a78: mov edx,eax
493a7a: add dl,0x16
493a7d: mov eax,ebx
493a7f: call 0x4775fc
493a84: cmp BYTE PTR [esp+0x8],0x0
493a89: jne 0x493ab4
493a8b: cmp edi,0xfa
493a91: jge 0x493ab4
493a93: fld DWORD PTR ds:0x494bb8
493a99: fmul QWORD PTR [esp+0x10]
493a9d: call 0x402894
493aa2: call 0x402a1c
493aa7: test eax,eax
493aa9: jne 0x493ab4
493aab: mov dl,0x18
493aad: mov eax,ebx
493aaf: call 0x4775fc
493ab4: xor eax,eax
493ab6: mov al,bl
493ab8: imul eax,eax,0x16
493abb: mov edx,DWORD PTR ds:0x4b0ef0
493ac1: cmp BYTE PTR [edx+eax*8-0xa0],0x4
493ac9: jne 0x493c25
493acf: cmp BYTE PTR [esp+0x8],0x1
493ad4: jne 0x493b0e
493ad6: cmp DWORD PTR [esp+0x4],0x8c
493ade: jle 0x493b0e
493ae0: fld DWORD PTR ds:0x494b80
493ae6: fmul QWORD PTR [esp+0x10]
493aea: call 0x402894
493aef: call 0x402a1c
493af4: test eax,eax
493af6: jne 0x493b0e
493af8: mov eax,0x2
493afd: call 0x402a1c
493b02: mov edx,eax
493b04: add dl,0x10
493b07: mov eax,ebx
493b09: call 0x4775fc
493b0e: cmp BYTE PTR [esp+0x8],0x0
493b13: jne 0x493b48
493b15: cmp edi,0x78
493b18: jle 0x493b48
493b1a: fld DWORD PTR ds:0x494b9c
493b20: fmul QWORD PTR [esp+0x10]
493b24: call 0x402894
493b29: call 0x402a1c
493b2e: test eax,eax
493b30: jne 0x493b48
493b32: mov eax,0x2
493b37: call 0x402a1c
493b3c: mov edx,eax
493b3e: add dl,0x10
493b41: mov eax,ebx
493b43: call 0x4775fc
493b48: cmp BYTE PTR [esp+0x8],0x0
493b4d: jne 0x493b85
493b4f: cmp edi,0xc8
493b55: jge 0x493b85
493b57: fld DWORD PTR ds:0x494bbc
493b5d: fmul QWORD PTR [esp+0x10]
493b61: call 0x402894
493b66: call 0x402a1c
493b6b: test eax,eax
493b6d: jne 0x493b85
493b6f: mov eax,0x2
493b74: call 0x402a1c
493b79: mov edx,eax
493b7b: add dl,0x12
493b7e: mov eax,ebx
493b80: call 0x4775fc
493b85: cmp BYTE PTR [esp+0x8],0x0
493b8a: jne 0x493bc2
493b8c: cmp edi,0xc8
493b92: jge 0x493bc2
493b94: fld DWORD PTR ds:0x494b9c
493b9a: fmul QWORD PTR [esp+0x10]
493b9e: call 0x402894
493ba3: call 0x402a1c
493ba8: test eax,eax
493baa: jne 0x493bc2
493bac: mov eax,0x2
493bb1: call 0x402a1c
493bb6: mov edx,eax
493bb8: add dl,0x14
493bbb: mov eax,ebx
493bbd: call 0x4775fc
493bc2: cmp edi,0x64
493bc5: jge 0x493bf5
493bc7: fld DWORD PTR ds:0x494ba8
493bcd: fmul QWORD PTR [esp+0x10]
493bd1: call 0x402894
493bd6: call 0x402a1c
493bdb: test eax,eax
493bdd: jne 0x493bf5
493bdf: mov eax,0x2
493be4: call 0x402a1c
493be9: mov edx,eax
493beb: add dl,0x16
493bee: mov eax,ebx
493bf0: call 0x4775fc
493bf5: cmp BYTE PTR [esp+0x8],0x0
493bfa: jne 0x493c25
493bfc: cmp edi,0xfa
493c02: jge 0x493c25
493c04: fld DWORD PTR ds:0x494bb8
493c0a: fmul QWORD PTR [esp+0x10]
493c0e: call 0x402894
493c13: call 0x402a1c
493c18: test eax,eax
493c1a: jne 0x493c25
493c1c: mov dl,0x18
493c1e: mov eax,ebx
493c20: call 0x4775fc
493c25: xor eax,eax
493c27: mov al,bl
493c29: imul eax,eax,0x16
493c2c: mov edx,DWORD PTR ds:0x4b0ef0
493c32: cmp BYTE PTR [edx+eax*8-0xa0],0x5
493c3a: jne 0x493d96
493c40: cmp BYTE PTR [esp+0x8],0x1
493c45: jne 0x493c7f
493c47: cmp DWORD PTR [esp+0x4],0x8c
493c4f: jle 0x493c7f
493c51: fld DWORD PTR ds:0x494b80
493c57: fmul QWORD PTR [esp+0x10]
493c5b: call 0x402894
493c60: call 0x402a1c
493c65: test eax,eax
493c67: jne 0x493c7f
493c69: mov eax,0x2
493c6e: call 0x402a1c
493c73: mov edx,eax
493c75: add dl,0x10
493c78: mov eax,ebx
493c7a: call 0x4775fc
493c7f: cmp BYTE PTR [esp+0x8],0x0
493c84: jne 0x493cb9
493c86: cmp edi,0x78
493c89: jle 0x493cb9
493c8b: fld DWORD PTR ds:0x494ba0
493c91: fmul QWORD PTR [esp+0x10]
493c95: call 0x402894
493c9a: call 0x402a1c
493c9f: test eax,eax
493ca1: jne 0x493cb9
493ca3: mov eax,0x2
493ca8: call 0x402a1c
493cad: mov edx,eax
493caf: add dl,0x10
493cb2: mov eax,ebx
493cb4: call 0x4775fc
493cb9: cmp BYTE PTR [esp+0x8],0x0
493cbe: jne 0x493cf6
493cc0: cmp edi,0x96
493cc6: jge 0x493cf6
493cc8: fld DWORD PTR ds:0x494b98
493cce: fmul QWORD PTR [esp+0x10]
493cd2: call 0x402894
493cd7: call 0x402a1c
493cdc: test eax,eax
493cde: jne 0x493cf6
493ce0: mov eax,0x2
493ce5: call 0x402a1c
493cea: mov edx,eax
493cec: add dl,0x12
493cef: mov eax,ebx
493cf1: call 0x4775fc
493cf6: cmp BYTE PTR [esp+0x8],0x0
493cfb: jne 0x493d33
493cfd: cmp edi,0x12c
493d03: jge 0x493d33
493d05: fld DWORD PTR ds:0x494b9c
493d0b: fmul QWORD PTR [esp+0x10]
493d0f: call 0x402894
493d14: call 0x402a1c
493d19: test eax,eax
493d1b: jne 0x493d33
493d1d: mov eax,0x2
493d22: call 0x402a1c
493d27: mov edx,eax
493d29: add dl,0x14
493d2c: mov eax,ebx
493d2e: call 0x4775fc
493d33: cmp edi,0x64
493d36: jge 0x493d66
493d38: fld DWORD PTR ds:0x494ba8
493d3e: fmul QWORD PTR [esp+0x10]
493d42: call 0x402894
493d47: call 0x402a1c
493d4c: test eax,eax
493d4e: jne 0x493d66
493d50: mov eax,0x2
493d55: call 0x402a1c
493d5a: mov edx,eax
493d5c: add dl,0x16
493d5f: mov eax,ebx
493d61: call 0x4775fc
493d66: cmp BYTE PTR [esp+0x8],0x0
493d6b: jne 0x493d96
493d6d: cmp edi,0xc8
493d73: jge 0x493d96
493d75: fld DWORD PTR ds:0x494ba0
493d7b: fmul QWORD PTR [esp+0x10]
493d7f: call 0x402894
493d84: call 0x402a1c
493d89: test eax,eax
493d8b: jne 0x493d96
493d8d: mov dl,0x18
493d8f: mov eax,ebx
493d91: call 0x4775fc
493d96: xor eax,eax
493d98: mov al,bl
493d9a: imul eax,eax,0x16
493d9d: mov edx,DWORD PTR ds:0x4b0ef0
493da3: cmp BYTE PTR [edx+eax*8-0xa0],0x6
493dab: jne 0x493ed1
493db1: cmp BYTE PTR [esp+0x8],0x1
493db6: jne 0x493df0
493db8: cmp DWORD PTR [esp+0x4],0x8c
493dc0: jle 0x493df0
493dc2: fld DWORD PTR ds:0x494bc0
493dc8: fmul QWORD PTR [esp+0x10]
493dcc: call 0x402894
493dd1: call 0x402a1c
493dd6: test eax,eax
493dd8: jne 0x493df0
493dda: mov eax,0x2
493ddf: call 0x402a1c
493de4: mov edx,eax
493de6: add dl,0x12
493de9: mov eax,ebx
493deb: call 0x4775fc
493df0: cmp BYTE PTR [esp+0x8],0x0
493df5: jne 0x493e2a
493df7: cmp edi,0x78
493dfa: jle 0x493e2a
493dfc: fld DWORD PTR ds:0x494b98
493e02: fmul QWORD PTR [esp+0x10]
493e06: call 0x402894
493e0b: call 0x402a1c
493e10: test eax,eax
493e12: jne 0x493e2a
493e14: mov eax,0x4
493e19: call 0x402a1c
493e1e: mov edx,eax
493e20: add dl,0x10
493e23: mov eax,ebx
493e25: call 0x4775fc
493e2a: cmp BYTE PTR [esp+0x8],0x0
493e2f: jne 0x493e64
493e31: cmp edi,0x64
493e34: jge 0x493e64
493e36: fld DWORD PTR ds:0x494bb4
493e3c: fmul QWORD PTR [esp+0x10]
493e40: call 0x402894
493e45: call 0x402a1c
493e4a: test eax,eax
493e4c: jne 0x493e64
493e4e: mov eax,0x2
493e53: call 0x402a1c
493e58: mov edx,eax
493e5a: add dl,0x14
493e5d: mov eax,ebx
493e5f: call 0x4775fc
493e64: cmp BYTE PTR [esp+0x8],0x0
493e69: jne 0x493ea1
493e6b: cmp edi,0xc8
493e71: jge 0x493ea1
493e73: fld DWORD PTR ds:0x494bbc
493e79: fmul QWORD PTR [esp+0x10]
493e7d: call 0x402894
493e82: call 0x402a1c
493e87: test eax,eax
493e89: jne 0x493ea1
493e8b: mov eax,0x2
493e90: call 0x402a1c
493e95: mov edx,eax
493e97: add dl,0x16
493e9a: mov eax,ebx
493e9c: call 0x4775fc
493ea1: cmp BYTE PTR [esp+0x8],0x0
493ea6: jne 0x493ed1
493ea8: cmp edi,0xc8
493eae: jge 0x493ed1
493eb0: fld DWORD PTR ds:0x494bb0
493eb6: fmul QWORD PTR [esp+0x10]
493eba: call 0x402894
493ebf: call 0x402a1c
493ec4: test eax,eax
493ec6: jne 0x493ed1
493ec8: mov dl,0x18
493eca: mov eax,ebx
493ecc: call 0x4775fc
493ed1: xor eax,eax
493ed3: mov al,bl
493ed5: imul eax,eax,0x16
493ed8: mov edx,DWORD PTR ds:0x4b0ef0
493ede: cmp BYTE PTR [edx+eax*8-0xa0],0x7
493ee6: jne 0x49400a
493eec: cmp BYTE PTR [esp+0x8],0x0
493ef1: jne 0x493f26
493ef3: cmp edi,0x64
493ef6: jge 0x493f26
493ef8: fld DWORD PTR ds:0x494b9c
493efe: fmul QWORD PTR [esp+0x10]
493f02: call 0x402894
493f07: call 0x402a1c
493f0c: test eax,eax
493f0e: jne 0x493f26
493f10: mov eax,0x2
493f15: call 0x402a1c
493f1a: mov edx,eax
493f1c: add dl,0x10
493f1f: mov eax,ebx
493f21: call 0x4775fc
493f26: cmp BYTE PTR [esp+0x8],0x0
493f2b: jne 0x493f60
493f2d: cmp edi,0x64
493f30: jge 0x493f60
493f32: fld DWORD PTR ds:0x494ba8
493f38: fmul QWORD PTR [esp+0x10]
493f3c: call 0x402894
493f41: call 0x402a1c
493f46: test eax,eax
493f48: jne 0x493f60
493f4a: mov eax,0x2
493f4f: call 0x402a1c
493f54: mov edx,eax
493f56: add dl,0x12
493f59: mov eax,ebx
493f5b: call 0x4775fc
493f60: cmp BYTE PTR [esp+0x8],0x0
493f65: jne 0x493f9d
493f67: cmp edi,0x96
493f6d: jge 0x493f9d
493f6f: fld DWORD PTR ds:0x494b98
493f75: fmul QWORD PTR [esp+0x10]
493f79: call 0x402894
493f7e: call 0x402a1c
493f83: test eax,eax
493f85: jne 0x493f9d
493f87: mov eax,0x2
493f8c: call 0x402a1c
493f91: mov edx,eax
493f93: add dl,0x14
493f96: mov eax,ebx
493f98: call 0x4775fc
493f9d: cmp BYTE PTR [esp+0x8],0x0
493fa2: jne 0x493fda
493fa4: cmp edi,0xc8
493faa: jge 0x493fda
493fac: fld DWORD PTR ds:0x494b98
493fb2: fmul QWORD PTR [esp+0x10]
493fb6: call 0x402894
493fbb: call 0x402a1c
493fc0: test eax,eax
493fc2: jne 0x493fda
493fc4: mov eax,0x2
493fc9: call 0x402a1c
493fce: mov edx,eax
493fd0: add dl,0x16
493fd3: mov eax,ebx
493fd5: call 0x4775fc
493fda: cmp BYTE PTR [esp+0x8],0x0
493fdf: jne 0x49400a
493fe1: cmp edi,0xc8
493fe7: jge 0x49400a
493fe9: fld DWORD PTR ds:0x494ba0
493fef: fmul QWORD PTR [esp+0x10]
493ff3: call 0x402894
493ff8: call 0x402a1c
493ffd: test eax,eax
493fff: jne 0x49400a
494001: mov dl,0x18
494003: mov eax,ebx
494005: call 0x4775fc
49400a: xor eax,eax
49400c: mov al,bl
49400e: imul eax,eax,0x16
494011: mov edx,DWORD PTR ds:0x4b0ef0
494017: cmp BYTE PTR [edx+eax*8-0xa0],0x8
49401f: jne 0x4941a4
494025: cmp BYTE PTR [esp+0x8],0x1
49402a: jne 0x494064
49402c: cmp DWORD PTR [esp+0x4],0x8c
494034: jle 0x494064
494036: fld DWORD PTR ds:0x494b94
49403c: fmul QWORD PTR [esp+0x10]
494040: call 0x402894
494045: call 0x402a1c
49404a: test eax,eax
49404c: jne 0x494064
49404e: mov eax,0x2
494053: call 0x402a1c
494058: mov edx,eax
49405a: add dl,0x10
49405d: mov eax,ebx
49405f: call 0x4775fc
494064: cmp BYTE PTR [esp+0x8],0x0
494069: jne 0x49409e
49406b: cmp edi,0x64
49406e: jge 0x49409e
494070: fld DWORD PTR ds:0x494b98
494076: fmul QWORD PTR [esp+0x10]
49407a: call 0x402894
49407f: call 0x402a1c
494084: test eax,eax
494086: jne 0x49409e
494088: mov eax,0x2
49408d: call 0x402a1c
494092: mov edx,eax
494094: add dl,0x10
494097: mov eax,ebx
494099: call 0x4775fc
49409e: cmp edi,0xc8
4940a4: jge 0x494100
4940a6: mov eax,ds:0x4b11f8
4940ab: movsx eax,WORD PTR [eax]
4940ae: sub eax,0x64
4940b1: mov DWORD PTR [esp+0x18],eax
4940b5: fild DWORD PTR [esp+0x18]
4940b9: xor eax,eax
4940bb: mov al,bl
4940bd: imul eax,eax,0x16
4940c0: mov edx,DWORD PTR ds:0x4b0ef0
4940c6: fcomp QWORD PTR [edx+eax*8-0xa8]
4940cd: fnstsw ax
4940cf: sahf
4940d0: jbe 0x494100
4940d2: fld DWORD PTR ds:0x494bc4
4940d8: fmul QWORD PTR [esp+0x10]
4940dc: call 0x402894
4940e1: call 0x402a1c
4940e6: test eax,eax
4940e8: jne 0x494100
4940ea: mov eax,0x2
4940ef: call 0x402a1c
4940f4: mov edx,eax
4940f6: add dl,0x12
4940f9: mov eax,ebx
4940fb: call 0x4775fc
494100: cmp BYTE PTR [esp+0x8],0x0
494105: jne 0x49413d
494107: cmp edi,0x96
49410d: jge 0x49413d
49410f: fld DWORD PTR ds:0x494ba4
494115: fmul QWORD PTR [esp+0x10]
494119: call 0x402894
49411e: call 0x402a1c
494123: test eax,eax
494125: jne 0x49413d
494127: mov eax,0x2
49412c: call 0x402a1c
494131: mov edx,eax
494133: add dl,0x14
494136: mov eax,ebx
494138: call 0x4775fc
49413d: cmp BYTE PTR [esp+0x8],0x0
494142: jne 0x494177
494144: cmp edi,0x64
494147: jle 0x494177
494149: fld DWORD PTR ds:0x494b98
49414f: fmul QWORD PTR [esp+0x10]
494153: call 0x402894
494158: call 0x402a1c
49415d: test eax,eax
49415f: jne 0x494177
494161: mov eax,0x2
494166: call 0x402a1c
49416b: mov edx,eax
49416d: add dl,0x16
494170: mov eax,ebx
494172: call 0x4775fc
494177: cmp BYTE PTR [esp+0x8],0x0
49417c: jne 0x4941a4
49417e: cmp edi,0x64
494181: jle 0x4941a4
494183: fld DWORD PTR ds:0x494b9c
494189: fmul QWORD PTR [esp+0x10]
49418d: call 0x402894
494192: call 0x402a1c
494197: test eax,eax
494199: jne 0x4941a4
49419b: mov dl,0x18
49419d: mov eax,ebx
49419f: call 0x4775fc
4941a4: xor eax,eax
4941a6: mov al,bl
4941a8: imul eax,eax,0x16
4941ab: mov edx,DWORD PTR ds:0x4b0ef0
4941b1: cmp BYTE PTR [edx+eax*8-0xa0],0x9
4941b9: jne 0x4942cf
4941bf: cmp BYTE PTR [esp+0x8],0x0
4941c4: jne 0x4941fc
4941c6: cmp edi,0xc8
4941cc: jge 0x4941fc
4941ce: fld DWORD PTR ds:0x494b98
4941d4: fmul QWORD PTR [esp+0x10]
4941d8: call 0x402894
4941dd: call 0x402a1c
4941e2: test eax,eax
4941e4: jne 0x4941fc
4941e6: mov eax,0x2
4941eb: call 0x402a1c
4941f0: mov edx,eax
4941f2: add dl,0x10
4941f5: mov eax,ebx
4941f7: call 0x4775fc
4941fc: cmp edi,0x64
4941ff: jge 0x49422f
494201: fld DWORD PTR ds:0x494bc4
494207: fmul QWORD PTR [esp+0x10]
49420b: call 0x402894
494210: call 0x402a1c
494215: test eax,eax
494217: jne 0x49422f
494219: mov eax,0x2
49421e: call 0x402a1c
494223: mov edx,eax
494225: add dl,0x12
494228: mov eax,ebx
49422a: call 0x4775fc
49422f: cmp edi,0x96
494235: jge 0x494265
494237: fld DWORD PTR ds:0x494bc4
49423d: fmul QWORD PTR [esp+0x10]
494241: call 0x402894
494246: call 0x402a1c
49424b: test eax,eax
49424d: jne 0x494265
49424f: mov eax,0x2
494254: call 0x402a1c
494259: mov edx,eax
49425b: add dl,0x14
49425e: mov eax,ebx
494260: call 0x4775fc
494265: cmp BYTE PTR [esp+0x8],0x0
49426a: jne 0x49429f
49426c: cmp edi,0x64
49426f: jge 0x49429f
494271: fld DWORD PTR ds:0x494b98
494277: fmul QWORD PTR [esp+0x10]
49427b: call 0x402894
494280: call 0x402a1c
494285: test eax,eax
494287: jne 0x49429f
494289: mov eax,0x2
49428e: call 0x402a1c
494293: mov edx,eax
494295: add dl,0x16
494298: mov eax,ebx
49429a: call 0x4775fc
49429f: cmp BYTE PTR [esp+0x8],0x0
4942a4: jne 0x4942cf
4942a6: cmp edi,0xc8
4942ac: jge 0x4942cf
4942ae: fld DWORD PTR ds:0x494b9c
4942b4: fmul QWORD PTR [esp+0x10]
4942b8: call 0x402894
4942bd: call 0x402a1c
4942c2: test eax,eax
4942c4: jne 0x4942cf
4942c6: mov dl,0x18
4942c8: mov eax,ebx
4942ca: call 0x4775fc
4942cf: xor eax,eax
4942d1: mov al,bl
4942d3: imul eax,eax,0x16
4942d6: mov edx,DWORD PTR ds:0x4b0ef0
4942dc: cmp BYTE PTR [edx+eax*8-0xa0],0xa
4942e4: jne 0x4943f6
4942ea: cmp edi,0xc8
4942f0: jge 0x494320
4942f2: fld DWORD PTR ds:0x494ba4
4942f8: fmul QWORD PTR [esp+0x10]
4942fc: call 0x402894
494301: call 0x402a1c
494306: test eax,eax
494308: jne 0x494320
49430a: mov eax,0x2
49430f: call 0x402a1c
494314: mov edx,eax
494316: add dl,0x10
494319: mov eax,ebx
49431b: call 0x4775fc
494320: cmp BYTE PTR [esp+0x8],0x0
494325: jne 0x49435d
494327: cmp edi,0x12c
49432d: jge 0x49435d
49432f: fld DWORD PTR ds:0x494b9c
494335: fmul QWORD PTR [esp+0x10]
494339: call 0x402894
49433e: call 0x402a1c
494343: test eax,eax
494345: jne 0x49435d
494347: mov eax,0x2
49434c: call 0x402a1c
494351: mov edx,eax
494353: add dl,0x12
494356: mov eax,ebx
494358: call 0x4775fc
49435d: cmp edi,0x64
494360: jge 0x494390
494362: fld DWORD PTR ds:0x494ba4
494368: fmul QWORD PTR [esp+0x10]
49436c: call 0x402894
494371: call 0x402a1c
494376: test eax,eax
494378: jne 0x494390
49437a: mov eax,0x2
49437f: call 0x402a1c
494384: mov edx,eax
494386: add dl,0x14
494389: mov eax,ebx
49438b: call 0x4775fc
494390: cmp edi,0xc8
494396: jge 0x4943c6
494398: fld DWORD PTR ds:0x494b9c
49439e: fmul QWORD PTR [esp+0x10]
4943a2: call 0x402894
4943a7: call 0x402a1c
4943ac: test eax,eax
4943ae: jne 0x4943c6
4943b0: mov eax,0x2
4943b5: call 0x402a1c
4943ba: mov edx,eax
4943bc: add dl,0x16
4943bf: mov eax,ebx
4943c1: call 0x4775fc
4943c6: cmp BYTE PTR [esp+0x8],0x0
4943cb: jne 0x4943f6
4943cd: cmp edi,0xc8
4943d3: jge 0x4943f6
4943d5: fld DWORD PTR ds:0x494b9c
4943db: fmul QWORD PTR [esp+0x10]
4943df: call 0x402894
4943e4: call 0x402a1c
4943e9: test eax,eax
4943eb: jne 0x4943f6
4943ed: mov dl,0x18
4943ef: mov eax,ebx
4943f1: call 0x4775fc
4943f6: xor eax,eax
4943f8: mov al,bl
4943fa: imul eax,eax,0x16
4943fd: mov edx,DWORD PTR ds:0x4b0ef0
494403: cmp BYTE PTR [edx+eax*8-0xa0],0xb
49440b: jne 0x494519
494411: cmp edi,0xc8
494417: jge 0x494447
494419: fld DWORD PTR ds:0x494ba4
49441f: fmul QWORD PTR [esp+0x10]
494423: call 0x402894
494428: call 0x402a1c
49442d: test eax,eax
49442f: jne 0x494447
494431: mov eax,0x2
494436: call 0x402a1c
49443b: mov edx,eax
49443d: add dl,0x10
494440: mov eax,ebx
494442: call 0x4775fc
494447: cmp edi,0x12c
49444d: jge 0x49447d
49444f: fld DWORD PTR ds:0x494b9c
494455: fmul QWORD PTR [esp+0x10]
494459: call 0x402894
49445e: call 0x402a1c
494463: test eax,eax
494465: jne 0x49447d
494467: mov eax,0x2
49446c: call 0x402a1c
494471: mov edx,eax
494473: add dl,0x12
494476: mov eax,ebx
494478: call 0x4775fc
49447d: cmp edi,0x12c
494483: jge 0x4944b3
494485: fld DWORD PTR ds:0x494b98
49448b: fmul QWORD PTR [esp+0x10]
49448f: call 0x402894
494494: call 0x402a1c
494499: test eax,eax
49449b: jne 0x4944b3
49449d: mov eax,0x2
4944a2: call 0x402a1c
4944a7: mov edx,eax
4944a9: add dl,0x14
4944ac: mov eax,ebx
4944ae: call 0x4775fc
4944b3: cmp edi,0xc8
4944b9: jge 0x4944e9
4944bb: fld DWORD PTR ds:0x494b9c
4944c1: fmul QWORD PTR [esp+0x10]
4944c5: call 0x402894
4944ca: call 0x402a1c
4944cf: test eax,eax
4944d1: jne 0x4944e9
4944d3: mov eax,0x2
4944d8: call 0x402a1c
4944dd: mov edx,eax
4944df: add dl,0x16
4944e2: mov eax,ebx
4944e4: call 0x4775fc
4944e9: cmp BYTE PTR [esp+0x8],0x0
4944ee: jne 0x494519
4944f0: cmp edi,0xc8
4944f6: jge 0x494519
4944f8: fld DWORD PTR ds:0x494b9c
4944fe: fmul QWORD PTR [esp+0x10]
494502: call 0x402894
494507: call 0x402a1c
49450c: test eax,eax
49450e: jne 0x494519
494510: mov dl,0x18
494512: mov eax,ebx
494514: call 0x4775fc
494519: xor eax,eax
49451b: mov al,bl
49451d: imul eax,eax,0x16
494520: mov edx,DWORD PTR ds:0x4b0ef0
494526: cmp BYTE PTR [edx+eax*8-0xa0],0xc
49452e: jne 0x4946b6
494534: cmp BYTE PTR [esp+0x8],0x1
494539: jne 0x494573
49453b: cmp DWORD PTR [esp+0x4],0x8c
494543: jle 0x494573
494545: fld DWORD PTR ds:0x494b80
49454b: fmul QWORD PTR [esp+0x10]
49454f: call 0x402894
494554: call 0x402a1c
494559: test eax,eax
49455b: jne 0x494573
49455d: mov eax,0x2
494562: call 0x402a1c
494567: mov edx,eax
494569: add dl,0x10
49456c: mov eax,ebx
49456e: call 0x4775fc
494573: cmp BYTE PTR [esp+0x8],0x0
494578: jne 0x4945ad
49457a: cmp edi,0x78
49457d: jle 0x4945ad
49457f: fld DWORD PTR ds:0x494ba0
494585: fmul QWORD PTR [esp+0x10]
494589: call 0x402894
49458e: call 0x402a1c
494593: test eax,eax
494595: jne 0x4945ad
494597: mov eax,0x2
49459c: call 0x402a1c
4945a1: mov edx,eax
4945a3: add dl,0x10
4945a6: mov eax,ebx
4945a8: call 0x4775fc
4945ad: cmp BYTE PTR [esp+0x8],0x0
4945b2: jne 0x4945e7
4945b4: cmp edi,0x50
4945b7: jge 0x4945e7
4945b9: fld DWORD PTR ds:0x494bc8
4945bf: fmul QWORD PTR [esp+0x10]
4945c3: call 0x402894
4945c8: call 0x402a1c
4945cd: test eax,eax
4945cf: jne 0x4945e7
4945d1: mov eax,0x2
4945d6: call 0x402a1c
4945db: mov edx,eax
4945dd: add dl,0x12
4945e0: mov eax,ebx
4945e2: call 0x4775fc
4945e7: cmp BYTE PTR [esp+0x8],0x0
4945ec: jne 0x494624
4945ee: cmp edi,0x96
4945f4: jge 0x494624
4945f6: fld DWORD PTR ds:0x494ba4
4945fc: fmul QWORD PTR [esp+0x10]
494600: call 0x402894
494605: call 0x402a1c
49460a: test eax,eax
49460c: jne 0x494624
49460e: mov eax,0x2
494613: call 0x402a1c
494618: mov edx,eax
49461a: add dl,0x14
49461d: mov eax,ebx
49461f: call 0x4775fc
494624: cmp edi,0xc8
49462a: jge 0x494686
49462c: mov eax,ds:0x4b11f8
494631: movsx eax,WORD PTR [eax]
494634: sub eax,0x64
494637: mov DWORD PTR [esp+0x18],eax
49463b: fild DWORD PTR [esp+0x18]
49463f: xor eax,eax
494641: mov al,bl
494643: imul eax,eax,0x16
494646: mov edx,DWORD PTR ds:0x4b0ef0
49464c: fcomp QWORD PTR [edx+eax*8-0xa8]
494653: fnstsw ax
494655: sahf
494656: jbe 0x494686
494658: fld DWORD PTR ds:0x494ba8
49465e: fmul QWORD PTR [esp+0x10]
494662: call 0x402894
494667: call 0x402a1c
49466c: test eax,eax
49466e: jne 0x494686
494670: mov eax,0x2
494675: call 0x402a1c
49467a: mov edx,eax
49467c: add dl,0x14
49467f: mov eax,ebx
494681: call 0x4775fc
494686: cmp BYTE PTR [esp+0x8],0x0
49468b: jne 0x4946b6
49468d: cmp edi,0xfa
494693: jge 0x4946b6
494695: fld DWORD PTR ds:0x494bb8
49469b: fmul QWORD PTR [esp+0x10]
49469f: call 0x402894
4946a4: call 0x402a1c
4946a9: test eax,eax
4946ab: jne 0x4946b6
4946ad: mov dl,0x16
4946af: mov eax,ebx
4946b1: call 0x4775fc
4946b6: xor eax,eax
4946b8: mov al,bl
4946ba: imul eax,eax,0x16
4946bd: mov edx,DWORD PTR ds:0x4b0ef0
4946c3: cmp BYTE PTR [edx+eax*8-0xa0],0xd
4946cb: jne 0x494824
4946d1: cmp BYTE PTR [esp+0x8],0x1
4946d6: jne 0x494710
4946d8: cmp DWORD PTR [esp+0x4],0x8c
4946e0: jle 0x494710
4946e2: fld DWORD PTR ds:0x494b80
4946e8: fmul QWORD PTR [esp+0x10]
4946ec: call 0x402894
4946f1: call 0x402a1c
4946f6: test eax,eax
4946f8: jne 0x494710
4946fa: mov eax,0x2
4946ff: call 0x402a1c
494704: mov edx,eax
494706: add dl,0x10
494709: mov eax,ebx
49470b: call 0x4775fc
494710: cmp BYTE PTR [esp+0x8],0x0
494715: jne 0x49474a
494717: cmp edi,0x78
49471a: jle 0x49474a
49471c: fld DWORD PTR ds:0x494b9c
494722: fmul QWORD PTR [esp+0x10]
494726: call 0x402894
49472b: call 0x402a1c
494730: test eax,eax
494732: jne 0x49474a
494734: mov eax,0x2
494739: call 0x402a1c
49473e: mov edx,eax
494740: add dl,0x10
494743: mov eax,ebx
494745: call 0x4775fc
49474a: cmp BYTE PTR [esp+0x8],0x0
49474f: jne 0x494784
494751: cmp edi,0x5a
494754: jge 0x494784
494756: fld DWORD PTR ds:0x494bc8
49475c: fmul QWORD PTR [esp+0x10]
494760: call 0x402894
494765: call 0x402a1c
49476a: test eax,eax
49476c: jne 0x494784
49476e: mov eax,0x2
494773: call 0x402a1c
494778: mov edx,eax
49477a: add dl,0x12
49477d: mov eax,ebx
49477f: call 0x4775fc
494784: cmp BYTE PTR [esp+0x8],0x0
494789: jne 0x4947c1
49478b: cmp edi,0x82
494791: jle 0x4947c1
494793: fld DWORD PTR ds:0x494ba4
494799: fmul QWORD PTR [esp+0x10]
49479d: call 0x402894
4947a2: call 0x402a1c
4947a7: test eax,eax
4947a9: jne 0x4947c1
4947ab: mov eax,0x2
4947b0: call 0x402a1c
4947b5: mov edx,eax
4947b7: add dl,0x14
4947ba: mov eax,ebx
4947bc: call 0x4775fc
4947c1: cmp edi,0x78
4947c4: jle 0x4947f4
4947c6: fld DWORD PTR ds:0x494ba4
4947cc: fmul QWORD PTR [esp+0x10]
4947d0: call 0x402894
4947d5: call 0x402a1c
4947da: test eax,eax
4947dc: jne 0x4947f4
4947de: mov eax,0x4
4947e3: call 0x402a1c
4947e8: mov edx,eax
4947ea: add dl,0x16
4947ed: mov eax,ebx
4947ef: call 0x4775fc
4947f4: cmp BYTE PTR [esp+0x8],0x0
4947f9: jne 0x494824
4947fb: cmp edi,0x10e
494801: jge 0x494824
494803: fld DWORD PTR ds:0x494ba0
494809: fmul QWORD PTR [esp+0x10]
49480d: call 0x402894
494812: call 0x402a1c
494817: test eax,eax
494819: jne 0x494824
49481b: mov dl,0x1a
49481d: mov eax,ebx
49481f: call 0x4775fc
494824: xor eax,eax
494826: mov al,bl
494828: imul eax,eax,0x16
49482b: mov edx,DWORD PTR ds:0x4b0ef0
494831: cmp BYTE PTR [edx+eax*8-0xa0],0xe
494839: jne 0x494994
49483f: cmp BYTE PTR [esp+0x8],0x1
494844: jne 0x49487e
494846: cmp DWORD PTR [esp+0x4],0x8c
49484e: jle 0x49487e
494850: fld DWORD PTR ds:0x494bc0
494856: fmul QWORD PTR [esp+0x10]
49485a: call 0x402894
49485f: call 0x402a1c
494864: test eax,eax
494866: jne 0x49487e
494868: mov eax,0x2
49486d: call 0x402a1c
494872: mov edx,eax
494874: add dl,0x10
494877: mov eax,ebx
494879: call 0x4775fc
49487e: cmp BYTE PTR [esp+0x8],0x0
494883: jne 0x4948bb
494885: cmp edi,0xa0
49488b: jle 0x4948bb
49488d: fld DWORD PTR ds:0x494b80
494893: fmul QWORD PTR [esp+0x10]
494897: call 0x402894
49489c: call 0x402a1c
4948a1: test eax,eax
4948a3: jne 0x4948bb
4948a5: mov eax,0x2
4948aa: call 0x402a1c
4948af: mov edx,eax
4948b1: add dl,0x10
4948b4: mov eax,ebx
4948b6: call 0x4775fc
4948bb: cmp BYTE PTR [esp+0x8],0x1
4948c0: jne 0x4948fa
4948c2: cmp DWORD PTR [esp+0x4],0xaa
4948ca: jge 0x4948fa
4948cc: fld DWORD PTR ds:0x494b94
4948d2: fmul QWORD PTR [esp+0x10]
4948d6: call 0x402894
4948db: call 0x402a1c
4948e0: test eax,eax
4948e2: jne 0x4948fa
4948e4: mov eax,0x2
4948e9: call 0x402a1c
4948ee: mov edx,eax
4948f0: add dl,0x12
4948f3: mov eax,ebx
4948f5: call 0x4775fc
4948fa: cmp BYTE PTR [esp+0x8],0x0
4948ff: jne 0x494934
494901: cmp edi,0x78
494904: jge 0x494934
494906: fld DWORD PTR ds:0x494b8c
49490c: fmul QWORD PTR [esp+0x10]
494910: call 0x402894
494915: call 0x402a1c
49491a: test eax,eax
49491c: jne 0x494934
49491e: mov eax,0x2
494923: call 0x402a1c
494928: mov edx,eax
49492a: add dl,0x14
49492d: mov eax,ebx
49492f: call 0x4775fc
494934: cmp edi,0x50
494937: jge 0x494967
494939: fld DWORD PTR ds:0x494ba8
49493f: fmul QWORD PTR [esp+0x10]
494943: call 0x402894
494948: call 0x402a1c
49494d: test eax,eax
49494f: jne 0x494967
494951: mov eax,0x2
494956: call 0x402a1c
49495b: mov edx,eax
49495d: add dl,0x16
494960: mov eax,ebx
494962: call 0x4775fc
494967: cmp BYTE PTR [esp+0x8],0x0
49496c: jne 0x494994
49496e: cmp edi,0x78
494971: jge 0x494994
494973: fld DWORD PTR ds:0x494b98
494979: fmul QWORD PTR [esp+0x10]
49497d: call 0x402894
494982: call 0x402a1c
494987: test eax,eax
494989: jne 0x494994
49498b: mov dl,0x18
49498d: mov eax,ebx
49498f: call 0x4775fc
494994: xor eax,eax
494996: mov al,bl
494998: imul eax,eax,0x16
49499b: mov edx,DWORD PTR ds:0x4b0ef0
4949a1: cmp BYTE PTR [edx+eax*8-0xa0],0xf
4949a9: jne 0x494b53
4949af: cmp BYTE PTR [esp+0x8],0x1
4949b4: jne 0x4949ee
4949b6: cmp DWORD PTR [esp+0x4],0x8c
4949be: jle 0x4949ee
4949c0: fld DWORD PTR ds:0x494bc0
4949c6: fmul QWORD PTR [esp+0x10]
4949ca: call 0x402894
4949cf: call 0x402a1c
4949d4: test eax,eax
4949d6: jne 0x4949ee
4949d8: mov eax,0x2
4949dd: call 0x402a1c
4949e2: mov edx,eax
4949e4: add dl,0x10
4949e7: mov eax,ebx
4949e9: call 0x4775fc
4949ee: cmp BYTE PTR [esp+0x8],0x0
4949f3: jne 0x494a2b
4949f5: cmp edi,0xa0
4949fb: jle 0x494a2b
4949fd: fld DWORD PTR ds:0x494bcc
494a03: fmul QWORD PTR [esp+0x10]
494a07: call 0x402894
494a0c: call 0x402a1c
494a11: test eax,eax
494a13: jne 0x494a2b
494a15: mov eax,0x2
494a1a: call 0x402a1c
494a1f: mov edx,eax
494a21: add dl,0x10
494a24: mov eax,ebx
494a26: call 0x4775fc
494a2b: cmp BYTE PTR [esp+0x8],0x0
494a30: jne 0x494a65
494a32: cmp edi,0x64
494a35: jge 0x494a65
494a37: fld DWORD PTR ds:0x494ba4
494a3d: fmul QWORD PTR [esp+0x10]
494a41: call 0x402894
494a46: call 0x402a1c
494a4b: test eax,eax
494a4d: jne 0x494a65
494a4f: mov eax,0x2
494a54: call 0x402a1c
494a59: mov edx,eax
494a5b: add dl,0x12
494a5e: mov eax,ebx
494a60: call 0x4775fc
494a65: cmp BYTE PTR [esp+0x8],0x0
494a6a: jne 0x494a9f
494a6c: cmp edi,0x78
494a6f: jge 0x494a9f
494a71: fld DWORD PTR ds:0x494bd0
494a77: fmul QWORD PTR [esp+0x10]
494a7b: call 0x402894
494a80: call 0x402a1c
494a85: test eax,eax
494a87: jne 0x494a9f
494a89: mov eax,0x2
494a8e: call 0x402a1c
494a93: mov edx,eax
494a95: add dl,0x14
494a98: mov eax,ebx
494a9a: call 0x4775fc
494a9f: cmp BYTE PTR [esp+0x8],0x0
494aa4: jne 0x494ae9
494aa6: cmp edi,0x50
494aa9: jge 0x494ae9
494aab: mov eax,ds:0x4b11f8
494ab0: movsx eax,WORD PTR [eax]
494ab3: sub eax,0x32
494ab6: cmp eax,DWORD PTR [esp]
494ab9: jle 0x494ae9
494abb: fld DWORD PTR ds:0x494bc0
494ac1: fmul QWORD PTR [esp+0x10]
494ac5: call 0x402894
494aca: call 0x402a1c
494acf: test eax,eax
494ad1: jne 0x494ae9
494ad3: mov eax,0x2
494ad8: call 0x402a1c
494add: mov edx,eax
494adf: add dl,0x14
494ae2: mov eax,ebx
494ae4: call 0x4775fc
494ae9: cmp BYTE PTR [esp+0x8],0x0
494aee: jne 0x494b26
494af0: cmp edi,0x8c
494af6: jge 0x494b26
494af8: fld DWORD PTR ds:0x494bd4
494afe: fmul QWORD PTR [esp+0x10]
494b02: call 0x402894
494b07: call 0x402a1c
494b0c: test eax,eax
494b0e: jne 0x494b26
494b10: mov eax,0x2
494b15: call 0x402a1c
494b1a: mov edx,eax
494b1c: add dl,0x16
494b1f: mov eax,ebx
494b21: call 0x4775fc
494b26: cmp BYTE PTR [esp+0x8],0x0
494b2b: jne 0x494b53
494b2d: cmp edi,0x78
494b30: jge 0x494b53
494b32: fld DWORD PTR ds:0x494b98
494b38: fmul QWORD PTR [esp+0x10]
494b3c: call 0x402894
494b41: call 0x402a1c
494b46: test eax,eax
494b48: jne 0x494b53
494b4a: mov dl,0x18
494b4c: mov eax,ebx
494b4e: call 0x4775fc
494b53: add esp,0x1c
494b56: pop ebp
494b57: pop edi
494b58: pop esi
494b59: pop ebx
494b5a: ret
.data 4b0ef0 e8444b000c204b0030b8
.data 4b1118 48464b00d6444b0040b6
.data 4b0d50 d9444b0004704000c857
.data 494b5c 9a99999999999999fe3f
.data 494b68 66666666666666a6ff3f
.data 4b116c dd444b00c8b740000862
.data 494b74 cdccccccccccccccfb3f
.data 494b80 00000041000010410000
.data 494b84 00001041000080400000
.data 494b88 00008040000000400000
.data 494b8c 00000040000040400000
.data 494b90 000040400000e0400000
.data 494b94 0000e0400000f0410000
.data 494b98 0000f041000020420000
.data 494b9c 00002042000048420000
.data 4b11f8 98444b00db444b004027
.data 494ba0 000048420000a0410000
.data 494ba4 0000a041000020410000
.data 494ba8 0000204100005c420000
.data 494bac 00005c42000034420000
.data 494bb0 00003442000090410000
.data 494bb4 00009041000070420000
.data 494bb8 0000704200000c420000
.data 494bbc 00000c420000c0400000
.data 494bc0 0000c0400000a0400000
.data 494bc4 0000a040000070410000
.data 494bc8 00007041000040410000
.data 494bcc 000040410000c8410000
.data 494bd0 0000c8410000b0415356
.data 494bd4 0000b0415356575583c4
