; entry 476a04
; exit 403468
476a04: push ebp
476a05: mov ebp,esp
476a07: add esp,0xfffffff4
476a0a: push ebx
476a0b: push esi
476a0c: push edi
476a0d: mov ebx,ecx
476a0f: mov DWORD PTR [ebp-0x8],edx
476a12: mov BYTE PTR [ebp-0x1],al
476a15: mov eax,DWORD PTR [ebp-0x8]
476a18: call 0x403e04
476a1d: xor eax,eax
476a1f: push ebp
476a20: push 0x4775cc
476a25: push DWORD PTR fs:[eax]
476a28: mov DWORD PTR fs:[eax],esp
476a2b: mov esi,0x1
476a30: mov edi,DWORD PTR ds:0x4b1118
476a36: add edi,0x2b
476a39: cmp BYTE PTR [edi],0x0
476a3c: jne 0x4775a9
476a42: mov al,BYTE PTR [ebp-0x1]
476a45: mov BYTE PTR [edi],al
476a47: mov eax,DWORD PTR [ebp+0x10]
476a4a: mov DWORD PTR [edi-0x2b],eax
476a4d: mov eax,DWORD PTR [ebp+0x14]
476a50: mov DWORD PTR [edi-0x27],eax
476a53: mov eax,DWORD PTR [ebp+0x8]
476a56: mov DWORD PTR [edi-0x23],eax
476a59: mov eax,DWORD PTR [ebp+0xc]
476a5c: mov DWORD PTR [edi-0x1f],eax
476a5f: mov BYTE PTR [edi+0x1],0x0
476a63: mov WORD PTR [edi-0x5],0x0
476a69: mov BYTE PTR [edi-0x3],0x0
476a6d: mov BYTE PTR [edi-0xb],0x1
476a71: mov BYTE PTR [edi-0xa],0x0
476a75: mov BYTE PTR [edi+0x6],0x0
476a79: mov BYTE PTR [edi-0x2],0x0
476a7d: xor eax,eax
476a7f: mov DWORD PTR [edi-0x1b],eax
476a82: xor eax,eax
476a84: mov DWORD PTR [edi-0x17],eax
476a87: xor eax,eax
476a89: mov DWORD PTR [edi-0x13],eax
476a8c: xor eax,eax
476a8e: mov DWORD PTR [edi-0xf],eax
476a91: mov BYTE PTR [edi-0x7],bl
476a94: mov BYTE PTR [edi-0x1],0x0
476a98: mov BYTE PTR [edi+0x4],0x0
476a9c: mov BYTE PTR [edi+0x5],0x0
476aa0: mov BYTE PTR [edi+0x7],0x0
476aa4: mov BYTE PTR [edi+0x8],0x0
476aa8: mov BYTE PTR [edi+0x9],0x0
476aac: mov BYTE PTR [edi-0x9],0x0
476ab0: mov BYTE PTR [edi-0x8],0x0
476ab4: cmp BYTE PTR [edi],0x1
476ab7: jne 0x476abd
476ab9: mov BYTE PTR [edi+0x2],0x3
476abd: cmp BYTE PTR [edi],0x2
476ac0: jne 0x476aca
476ac2: mov BYTE PTR [edi+0x2],0xf
476ac6: mov BYTE PTR [edi+0x8],0x1
476aca: mov al,BYTE PTR [edi]
476acc: cmp al,0x3
476ace: je 0x476ad4
476ad0: cmp al,0x4
476ad2: jne 0x476af7
476ad4: mov BYTE PTR [edi+0x2],0x50
476ad8: mov WORD PTR [edi-0x5],0xffea
476ade: mov BYTE PTR [edi+0x9],0x1
476ae2: push 0xc
476ae4: push 0xa
476ae6: mov ecx,0xfffffff8
476aeb: mov edx,0xfffffff4
476af0: mov eax,esi
476af2: call 0x4769c4
476af7: cmp BYTE PTR [edi],0x5
476afa: jne 0x476b00
476afc: mov BYTE PTR [edi+0x2],0x14
476b00: cmp BYTE PTR [edi],0x6
476b03: jne 0x476b2b
476b05: mov BYTE PTR [edi+0x2],0x63
476b09: mov WORD PTR [edi-0x5],0xffea
476b0f: mov BYTE PTR [edi+0x9],0x1
476b13: xor eax,eax
476b15: mov al,bl
476b17: imul eax,eax,0x16
476b1a: mov edx,DWORD PTR ds:0x4b0ef0
476b20: mov al,BYTE PTR [edx+eax*8-0x43]
476b24: mov BYTE PTR [edi-0xb],al
476b27: mov BYTE PTR [edi-0xa],0x5
476b2b: cmp BYTE PTR [edi],0x7
476b2e: jne 0x476bbf
476b34: mov BYTE PTR [edi+0x2],0x5
476b38: mov BYTE PTR [edi+0x6],0x1
476b3c: mov BYTE PTR [edi+0x8],0x1
476b40: mov eax,0x5
476b45: call 0x402a1c
476b4a: test eax,eax
476b4c: jne 0x476b52
476b4e: mov BYTE PTR [edi-0x2],0x1
476b52: xor eax,eax
476b54: mov al,bl
476b56: imul eax,eax,0x16
476b59: mov edx,DWORD PTR ds:0x4b0ef0
476b5f: mov al,BYTE PTR [edx+eax*8-0x43]
476b63: mov BYTE PTR [edi-0xb],al
476b66: mov eax,DWORD PTR [ebp-0x8]
476b69: mov edx,0x4775e4
476b6e: call 0x403d60
476b73: jne 0x476b79
476b75: mov BYTE PTR [edi-0xa],0x8
476b79: mov eax,DWORD PTR [ebp-0x8]
476b7c: mov edx,0x4775f0
476b81: call 0x403d60
476b86: jne 0x476b8c
476b88: mov BYTE PTR [edi-0xa],0xb
476b8c: mov al,0xc
476b8e: mov BYTE PTR [edi-0x9],al
476b91: xor eax,eax
476b93: mov al,BYTE PTR [edi-0x9]
476b96: mov DWORD PTR [ebp-0xc],eax
476b99: fild DWORD PTR [ebp-0xc]
476b9c: fdiv DWORD PTR ds:0x4775f4
476ba2: call 0x402894
476ba7: mov BYTE PTR [edi-0x8],al
476baa: push 0x19
476bac: push 0x0
476bae: mov ecx,0xffffffda
476bb3: mov edx,0xffffffe7
476bb8: mov eax,esi
476bba: call 0x4769c4
476bbf: cmp BYTE PTR [edi],0x8
476bc2: jne 0x476c1f
476bc4: mov BYTE PTR [edi+0x2],0x17
476bc8: mov BYTE PTR [edi+0x6],0x1
476bcc: mov BYTE PTR [edi+0x8],0x1
476bd0: mov al,0x28
476bd2: mov BYTE PTR [edi-0x9],al
476bd5: xor eax,eax
476bd7: mov al,BYTE PTR [edi-0x9]
476bda: mov DWORD PTR [ebp-0xc],eax
476bdd: fild DWORD PTR [ebp-0xc]
476be0: fdiv DWORD PTR ds:0x4775f8
476be6: call 0x402894
476beb: mov BYTE PTR [edi-0x8],al
476bee: mov BYTE PTR [edi-0x2],0x1
476bf2: mov BYTE PTR [edi-0x1],0x1
476bf6: xor eax,eax
476bf8: mov al,bl
476bfa: imul eax,eax,0x16
476bfd: mov edx,DWORD PTR ds:0x4b0ef0
476c03: mov al,BYTE PTR [edx+eax*8-0x43]
476c07: mov BYTE PTR [edi-0xb],al
476c0a: push 0x1e
476c0c: push 0x0
476c0e: mov ecx,0xffffffce
476c13: mov edx,0xffffffe2
476c18: mov eax,esi
476c1a: call 0x4769c4
476c1f: cmp BYTE PTR [edi],0x9
476c22: jne 0x476caf
476c28: mov BYTE PTR [edi+0x2],0x5
476c2c: mov BYTE PTR [edi+0x6],0x1
476c30: mov eax,0x5
476c35: call 0x402a1c
476c3a: test eax,eax
476c3c: jne 0x476c42
476c3e: mov BYTE PTR [edi-0x2],0x1
476c42: xor eax,eax
476c44: mov al,bl
476c46: imul eax,eax,0x16
476c49: mov edx,DWORD PTR ds:0x4b0ef0
476c4f: mov al,BYTE PTR [edx+eax*8-0x43]
476c53: mov BYTE PTR [edi-0xb],al
476c56: mov eax,DWORD PTR [ebp-0x8]
476c59: mov edx,0x4775e4
476c5e: call 0x403d60
476c63: jne 0x476c69
476c65: mov BYTE PTR [edi-0xa],0x8
476c69: mov eax,DWORD PTR [ebp-0x8]
476c6c: mov edx,0x4775f0
476c71: call 0x403d60
476c76: jne 0x476c7c
476c78: mov BYTE PTR [edi-0xa],0xb
476c7c: mov al,0xc
476c7e: mov BYTE PTR [edi-0x9],al
476c81: xor eax,eax
476c83: mov al,BYTE PTR [edi-0x9]
476c86: mov DWORD PTR [ebp-0xc],eax
476c89: fild DWORD PTR [ebp-0xc]
476c8c: fdiv DWORD PTR ds:0x4775f4
476c92: call 0x402894
476c97: mov BYTE PTR [edi-0x8],al
476c9a: push 0x14
476c9c: push 0x4b
476c9e: mov ecx,0xfffffff2
476ca3: mov edx,0xffffffec
476ca8: mov eax,esi
476caa: call 0x4769c4
476caf: cmp BYTE PTR [edi],0xa
476cb2: jne 0x476cb8
476cb4: mov BYTE PTR [edi+0x2],0xe
476cb8: cmp BYTE PTR [edi],0xb
476cbb: jne 0x476cc1
476cbd: mov BYTE PTR [edi+0x2],0xf
476cc1: cmp BYTE PTR [edi],0xc
476cc4: jne 0x476d51
476cca: mov BYTE PTR [edi+0x2],0x5
476cce: mov BYTE PTR [edi+0x6],0x1
476cd2: mov eax,0x5
476cd7: call 0x402a1c
476cdc: test eax,eax
476cde: jne 0x476ce4
476ce0: mov BYTE PTR [edi-0x2],0x1
476ce4: xor eax,eax
476ce6: mov al,bl
476ce8: imul eax,eax,0x16
476ceb: mov edx,DWORD PTR ds:0x4b0ef0
476cf1: mov al,BYTE PTR [edx+eax*8-0x43]
476cf5: mov BYTE PTR [edi-0xb],al
476cf8: mov eax,DWORD PTR [ebp-0x8]
476cfb: mov edx,0x4775e4
476d00: call 0x403d60
476d05: jne 0x476d0b
476d07: mov BYTE PTR [edi-0xa],0x8
476d0b: mov eax,DWORD PTR [ebp-0x8]
476d0e: mov edx,0x4775f0
476d13: call 0x403d60
476d18: jne 0x476d1e
476d1a: mov BYTE PTR [edi-0xa],0xb
476d1e: mov al,0xc
476d20: mov BYTE PTR [edi-0x9],al
476d23: xor eax,eax
476d25: mov al,BYTE PTR [edi-0x9]
476d28: mov DWORD PTR [ebp-0xc],eax
476d2b: fild DWORD PTR [ebp-0xc]
476d2e: fdiv DWORD PTR ds:0x4775f4
476d34: call 0x402894
476d39: mov BYTE PTR [edi-0x8],al
476d3c: push 0x14
476d3e: push 0x55
476d40: mov ecx,0xffffffec
476d45: mov edx,0xffffffec
476d4a: mov eax,esi
476d4c: call 0x4769c4
476d51: cmp BYTE PTR [edi],0xd
476d54: jne 0x476de1
476d5a: mov BYTE PTR [edi+0x2],0x5
476d5e: mov BYTE PTR [edi+0x6],0x1
476d62: mov eax,0x5
476d67: call 0x402a1c
476d6c: test eax,eax
476d6e: jne 0x476d74
476d70: mov BYTE PTR [edi-0x2],0x1
476d74: xor eax,eax
476d76: mov al,bl
476d78: imul eax,eax,0x16
476d7b: mov edx,DWORD PTR ds:0x4b0ef0
476d81: mov al,BYTE PTR [edx+eax*8-0x43]
476d85: mov BYTE PTR [edi-0xb],al
476d88: mov eax,DWORD PTR [ebp-0x8]
476d8b: mov edx,0x4775e4
476d90: call 0x403d60
476d95: jne 0x476d9b
476d97: mov BYTE PTR [edi-0xa],0x8
476d9b: mov eax,DWORD PTR [ebp-0x8]
476d9e: mov edx,0x4775f0
476da3: call 0x403d60
476da8: jne 0x476dae
476daa: mov BYTE PTR [edi-0xa],0xb
476dae: mov al,0xc
476db0: mov BYTE PTR [edi-0x9],al
476db3: xor eax,eax
476db5: mov al,BYTE PTR [edi-0x9]
476db8: mov DWORD PTR [ebp-0xc],eax
476dbb: fild DWORD PTR [ebp-0xc]
476dbe: fdiv DWORD PTR ds:0x4775f4
476dc4: call 0x402894
476dc9: mov BYTE PTR [edi-0x8],al
476dcc: push 0x19
476dce: push 0x50
476dd0: mov ecx,0xfffffff6
476dd5: mov edx,0xffffffe7
476dda: mov eax,esi
476ddc: call 0x4769c4
476de1: cmp BYTE PTR [edi],0xe
476de4: jne 0x476dea
476de6: mov BYTE PTR [edi+0x2],0x6
476dea: cmp BYTE PTR [edi],0xf
476ded: jne 0x476e7a
476df3: mov BYTE PTR [edi+0x2],0x5
476df7: mov BYTE PTR [edi+0x6],0x1
476dfb: mov eax,0x5
476e00: call 0x402a1c
476e05: test eax,eax
476e07: jne 0x476e0d
476e09: mov BYTE PTR [edi-0x2],0x1
476e0d: xor eax,eax
476e0f: mov al,bl
476e11: imul eax,eax,0x16
476e14: mov edx,DWORD PTR ds:0x4b0ef0
476e1a: mov al,BYTE PTR [edx+eax*8-0x43]
476e1e: mov BYTE PTR [edi-0xb],al
476e21: mov eax,DWORD PTR [ebp-0x8]
476e24: mov edx,0x4775e4
476e29: call 0x403d60
476e2e: jne 0x476e34
476e30: mov BYTE PTR [edi-0xa],0x8
476e34: mov eax,DWORD PTR [ebp-0x8]
476e37: mov edx,0x4775f0
476e3c: call 0x403d60
476e41: jne 0x476e47
476e43: mov BYTE PTR [edi-0xa],0xb
476e47: mov al,0xc
476e49: mov BYTE PTR [edi-0x9],al
476e4c: xor eax,eax
476e4e: mov al,BYTE PTR [edi-0x9]
476e51: mov DWORD PTR [ebp-0xc],eax
476e54: fild DWORD PTR [ebp-0xc]
476e57: fdiv DWORD PTR ds:0x4775f4
476e5d: call 0x402894
476e62: mov BYTE PTR [edi-0x8],al
476e65: push 0x19
476e67: push 0x25
476e69: mov ecx,0xffffffe7
476e6e: mov edx,0xffffffe7
476e73: mov eax,esi
476e75: call 0x4769c4
476e7a: cmp BYTE PTR [edi],0x10
476e7d: jne 0x476e97
476e7f: mov BYTE PTR [edi+0x2],0x3
476e83: xor eax,eax
476e85: mov al,bl
476e87: imul eax,eax,0x16
476e8a: mov edx,DWORD PTR ds:0x4b0ef0
476e90: mov al,BYTE PTR [edx+eax*8-0x43]
476e94: mov BYTE PTR [edi-0xb],al
476e97: cmp BYTE PTR [edi],0x11
476e9a: jne 0x476ea0
476e9c: mov BYTE PTR [edi+0x2],0xa
476ea0: cmp BYTE PTR [edi],0x12
476ea3: jne 0x476f30
476ea9: mov BYTE PTR [edi+0x2],0x5
476ead: mov BYTE PTR [edi+0x6],0x1
476eb1: mov eax,0x5
476eb6: call 0x402a1c
476ebb: test eax,eax
476ebd: jne 0x476ec3
476ebf: mov BYTE PTR [edi-0x2],0x1
476ec3: xor eax,eax
476ec5: mov al,bl
476ec7: imul eax,eax,0x16
476eca: mov edx,DWORD PTR ds:0x4b0ef0
476ed0: mov al,BYTE PTR [edx+eax*8-0x43]
476ed4: mov BYTE PTR [edi-0xb],al
476ed7: mov eax,DWORD PTR [ebp-0x8]
476eda: mov edx,0x4775e4
476edf: call 0x403d60
476ee4: jne 0x476eea
476ee6: mov BYTE PTR [edi-0xa],0x8
476eea: mov eax,DWORD PTR [ebp-0x8]
476eed: mov edx,0x4775f0
476ef2: call 0x403d60
476ef7: jne 0x476efd
476ef9: mov BYTE PTR [edi-0xa],0xb
476efd: mov al,0xc
476eff: mov BYTE PTR [edi-0x9],al
476f02: xor eax,eax
476f04: mov al,BYTE PTR [edi-0x9]
476f07: mov DWORD PTR [ebp-0xc],eax
476f0a: fild DWORD PTR [ebp-0xc]
476f0d: fdiv DWORD PTR ds:0x4775f4
476f13: call 0x402894
476f18: mov BYTE PTR [edi-0x8],al
476f1b: push 0x1e
476f1d: push 0x50
476f1f: mov ecx,0xfffffff6
476f24: mov edx,0xffffffe2
476f29: mov eax,esi
476f2b: call 0x4769c4
476f30: cmp BYTE PTR [edi],0x13
476f33: jne 0x476fc0
476f39: mov BYTE PTR [edi+0x2],0x5
476f3d: mov BYTE PTR [edi+0x6],0x1
476f41: mov eax,0x5
476f46: call 0x402a1c
476f4b: test eax,eax
476f4d: jne 0x476f53
476f4f: mov BYTE PTR [edi-0x2],0x1
476f53: xor eax,eax
476f55: mov al,bl
476f57: imul eax,eax,0x16
476f5a: mov edx,DWORD PTR ds:0x4b0ef0
476f60: mov al,BYTE PTR [edx+eax*8-0x43]
476f64: mov BYTE PTR [edi-0xb],al
476f67: mov eax,DWORD PTR [ebp-0x8]
476f6a: mov edx,0x4775e4
476f6f: call 0x403d60
476f74: jne 0x476f7a
476f76: mov BYTE PTR [edi-0xa],0x5
476f7a: mov eax,DWORD PTR [ebp-0x8]
476f7d: mov edx,0x4775f0
476f82: call 0x403d60
476f87: jne 0x476f8d
476f89: mov BYTE PTR [edi-0xa],0x7
476f8d: mov al,0xc
476f8f: mov BYTE PTR [edi-0x9],al
476f92: xor eax,eax
476f94: mov al,BYTE PTR [edi-0x9]
476f97: mov DWORD PTR [ebp-0xc],eax
476f9a: fild DWORD PTR [ebp-0xc]
476f9d: fdiv DWORD PTR ds:0x4775f4
476fa3: call 0x402894
476fa8: mov BYTE PTR [edi-0x8],al
476fab: push 0xc
476fad: push 0x14
476faf: mov ecx,0xfffffff6
476fb4: mov edx,0xfffffff4
476fb9: mov eax,esi
476fbb: call 0x4769c4
476fc0: cmp BYTE PTR [edi],0x14
476fc3: jne 0x477027
476fc5: mov BYTE PTR [edi+0x2],0x5
476fc9: mov BYTE PTR [edi+0x6],0x1
476fcd: xor eax,eax
476fcf: mov al,bl
476fd1: imul eax,eax,0x16
476fd4: mov edx,DWORD PTR ds:0x4b0ef0
476fda: mov al,BYTE PTR [edx+eax*8-0x43]
476fde: mov BYTE PTR [edi-0xb],al
476fe1: mov eax,0x2
476fe6: call 0x402a1c
476feb: add al,0xa
476fed: mov BYTE PTR [edi-0xa],al
476ff0: mov al,0x7
476ff2: mov BYTE PTR [edi-0x9],al
476ff5: xor eax,eax
476ff7: mov al,BYTE PTR [edi-0x9]
476ffa: mov DWORD PTR [ebp-0xc],eax
476ffd: fild DWORD PTR [ebp-0xc]
477000: fdiv DWORD PTR ds:0x4775f4
477006: call 0x402894
47700b: mov BYTE PTR [edi-0x8],al
47700e: mov BYTE PTR [edi-0x2],0x1
477012: push 0x8
477014: push 0x5
477016: mov ecx,0xfffffffb
47701b: mov edx,0xfffffff8
477020: mov eax,esi
477022: call 0x4769c4
477027: cmp BYTE PTR [edi],0x15
47702a: jne 0x477076
47702c: mov BYTE PTR [edi+0x2],0x17
477030: mov eax,0x5
477035: call 0x402a1c
47703a: lea eax,[eax+eax*4]
47703d: mov dx,0xffe9
477041: sub dx,ax
477044: mov WORD PTR [edi-0x5],dx
477048: mov BYTE PTR [edi+0x9],0x1
47704c: mov eax,0x2
477051: call 0x402a1c
477056: inc eax
477057: mov BYTE PTR [edi-0xb],al
47705a: mov eax,0xa
47705f: call 0x402a1c
477064: mov BYTE PTR [edi-0xa],al
477067: mov eax,0x3
47706c: call 0x402a1c
477071: add al,0x35
477073: mov BYTE PTR [edi+0x3],al
477076: cmp BYTE PTR [edi],0x16
477079: jne 0x477138
47707f: mov BYTE PTR [edi+0x2],0x14
477083: mov BYTE PTR [edi+0x3],0x38
477087: mov BYTE PTR [edi+0x9],0x1
47708b: mov eax,DWORD PTR [ebp-0x8]
47708e: mov edx,0x4775e4
477093: call 0x403d60
477098: jne 0x4770a0
47709a: mov WORD PTR [edi-0x5],0xfff3
4770a0: mov eax,DWORD PTR [ebp-0x8]
4770a3: mov edx,0x4775f0
4770a8: call 0x403d60
4770ad: jne 0x4770b5
4770af: mov WORD PTR [edi-0x5],0xffef
4770b5: mov BYTE PTR [edi+0x6],0x1
4770b9: mov eax,0x5
4770be: call 0x402a1c
4770c3: test eax,eax
4770c5: jne 0x4770cb
4770c7: mov BYTE PTR [edi-0x2],0x1
4770cb: xor eax,eax
4770cd: mov al,bl
4770cf: imul eax,eax,0x16
4770d2: mov edx,DWORD PTR ds:0x4b0ef0
4770d8: mov al,BYTE PTR [edx+eax*8-0x43]
4770dc: mov BYTE PTR [edi-0xb],al
4770df: mov eax,DWORD PTR [ebp-0x8]
4770e2: mov edx,0x4775e4
4770e7: call 0x403d60
4770ec: jne 0x4770f2
4770ee: mov BYTE PTR [edi-0xa],0xa
4770f2: mov eax,DWORD PTR [ebp-0x8]
4770f5: mov edx,0x4775f0
4770fa: call 0x403d60
4770ff: jne 0x477105
477101: mov BYTE PTR [edi-0xa],0xd
477105: mov al,0xa
477107: mov BYTE PTR [edi-0x9],al
47710a: xor eax,eax
47710c: mov al,BYTE PTR [edi-0x9]
47710f: mov DWORD PTR [ebp-0xc],eax
477112: fild DWORD PTR [ebp-0xc]
477115: fdiv DWORD PTR ds:0x4775f4
47711b: call 0x402894
477120: mov BYTE PTR [edi-0x8],al
477123: push 0xc
477125: push 0x5
477127: mov ecx,0xfffffffb
47712c: mov edx,0xfffffff4
477131: mov eax,esi
477133: call 0x4769c4
477138: cmp BYTE PTR [edi],0x17
47713b: jne 0x477198
47713d: mov BYTE PTR [edi+0x2],0x1a
477141: mov BYTE PTR [edi+0x6],0x1
477145: mov al,0xc
477147: mov BYTE PTR [edi-0x9],al
47714a: xor eax,eax
47714c: mov al,BYTE PTR [edi-0x9]
47714f: mov DWORD PTR [ebp-0xc],eax
477152: fild DWORD PTR [ebp-0xc]
477155: fdiv DWORD PTR ds:0x4775f4
47715b: call 0x402894
477160: mov BYTE PTR [edi-0x8],al
477163: xor eax,eax
477165: mov al,bl
477167: imul eax,eax,0x16
47716a: mov edx,DWORD PTR ds:0x4b0ef0
477170: mov al,BYTE PTR [edx+eax*8-0x43]
477174: mov BYTE PTR [edi-0xb],al
477177: mov BYTE PTR [edi-0x1],0x1
47717b: mov BYTE PTR [edi-0x2],0x1
47717f: mov BYTE PTR [edi+0x8],0x1
477183: push 0x1e
477185: push 0x0
477187: mov ecx,0xffffff6f
47718c: mov edx,0xffffffe2
477191: mov eax,esi
477193: call 0x4769c4
477198: cmp BYTE PTR [edi],0x18
47719b: jne 0x4771ac
47719d: mov eax,0xf
4771a2: call 0x402a1c
4771a7: add al,0xf
4771a9: mov BYTE PTR [edi+0x2],al
4771ac: cmp BYTE PTR [edi],0x19
4771af: jne 0x4771b5
4771b1: mov BYTE PTR [edi+0x2],0x24
4771b5: cmp BYTE PTR [edi],0x1a
4771b8: jne 0x477245
4771be: mov BYTE PTR [edi+0x2],0x6
4771c2: mov BYTE PTR [edi+0x6],0x1
4771c6: mov eax,0x5
4771cb: call 0x402a1c
4771d0: test eax,eax
4771d2: jne 0x4771d8
4771d4: mov BYTE PTR [edi-0x2],0x1
4771d8: xor eax,eax
4771da: mov al,bl
4771dc: imul eax,eax,0x16
4771df: mov edx,DWORD PTR ds:0x4b0ef0
4771e5: mov al,BYTE PTR [edx+eax*8-0x43]
4771e9: mov BYTE PTR [edi-0xb],al
4771ec: mov eax,DWORD PTR [ebp-0x8]
4771ef: mov edx,0x4775e4
4771f4: call 0x403d60
4771f9: jne 0x4771ff
4771fb: mov BYTE PTR [edi-0xa],0x8
4771ff: mov eax,DWORD PTR [ebp-0x8]
477202: mov edx,0x4775f0
477207: call 0x403d60
47720c: jne 0x477212
47720e: mov BYTE PTR [edi-0xa],0xb
477212: mov al,0xc
477214: mov BYTE PTR [edi-0x9],al
477217: xor eax,eax
477219: mov al,BYTE PTR [edi-0x9]
47721c: mov DWORD PTR [ebp-0xc],eax
47721f: fild DWORD PTR [ebp-0xc]
477222: fdiv DWORD PTR ds:0x4775f4
477228: call 0x402894
47722d: mov BYTE PTR [edi-0x8],al
477230: push 0x19
477232: push 0x46
477234: mov ecx,0xffffffe7
477239: mov edx,0xffffffe7
47723e: mov eax,esi
477240: call 0x4769c4
477245: cmp BYTE PTR [edi],0x1b
477248: jne 0x4772b2
47724a: mov BYTE PTR [edi+0x2],0x6
47724e: mov BYTE PTR [edi-0x9],0x0
477252: xor eax,eax
477254: mov al,bl
477256: imul eax,eax,0x16
477259: mov edx,DWORD PTR ds:0x4b0ef0
47725f: mov al,BYTE PTR [edx+eax*8-0x43]
477263: mov BYTE PTR [edi-0xb],al
477266: mov eax,DWORD PTR [ebp-0x8]
477269: mov edx,0x4775e4
47726e: call 0x403d60
477273: jne 0x477279
477275: mov BYTE PTR [edi-0xa],0x3
477279: mov eax,DWORD PTR [ebp-0x8]
47727c: mov edx,0x4775f0
477281: call 0x403d60
477286: jne 0x47728c
477288: mov BYTE PTR [edi-0xa],0x4
47728c: mov eax,DWORD PTR [ebp-0x8]
47728f: mov edx,0x4775e4
477294: call 0x403d60
477299: jne 0x47729f
47729b: mov BYTE PTR [edi+0x5],0x16
47729f: mov eax,DWORD PTR [ebp-0x8]
4772a2: mov edx,0x4775f0
4772a7: call 0x403d60
4772ac: jne 0x4772b2
4772ae: mov BYTE PTR [edi+0x5],0x23
4772b2: cmp BYTE PTR [edi],0x1c
4772b5: jne 0x47730e
4772b7: mov BYTE PTR [edi+0x2],0x4
4772bb: mov BYTE PTR [edi+0x5],0x14
4772bf: mov BYTE PTR [edi+0x6],0x1
4772c3: mov BYTE PTR [edi-0x1],0x1
4772c7: mov al,0x2
4772c9: mov BYTE PTR [edi-0x9],al
4772cc: xor eax,eax
4772ce: mov al,BYTE PTR [edi-0x9]
4772d1: mov DWORD PTR [ebp-0xc],eax
4772d4: fild DWORD PTR [ebp-0xc]
4772d7: fdiv DWORD PTR ds:0x4775f4
4772dd: call 0x402894
4772e2: mov BYTE PTR [edi-0x8],al
4772e5: xor eax,eax
4772e7: mov al,bl
4772e9: imul eax,eax,0x16
4772ec: mov edx,DWORD PTR ds:0x4b0ef0
4772f2: mov al,BYTE PTR [edx+eax*8-0x43]
4772f6: mov BYTE PTR [edi-0xb],al
4772f9: push 0x28
4772fb: push 0x28
4772fd: mov ecx,0xffffffd8
477302: mov edx,0xffffffd8
477307: mov eax,esi
477309: call 0x4769c4
47730e: cmp BYTE PTR [edi],0x1d
477311: jne 0x47739e
477317: mov BYTE PTR [edi+0x2],0x6
47731b: mov BYTE PTR [edi+0x6],0x1
47731f: mov eax,0x5
477324: call 0x402a1c
477329: test eax,eax
47732b: jne 0x477331
47732d: mov BYTE PTR [edi-0x2],0x1
477331: xor eax,eax
477333: mov al,bl
477335: imul eax,eax,0x16
477338: mov edx,DWORD PTR ds:0x4b0ef0
47733e: mov al,BYTE PTR [edx+eax*8-0x43]
477342: mov BYTE PTR [edi-0xb],al
477345: mov eax,DWORD PTR [ebp-0x8]
477348: mov edx,0x4775e4
47734d: call 0x403d60
477352: jne 0x477358
477354: mov BYTE PTR [edi-0xa],0x8
477358: mov eax,DWORD PTR [ebp-0x8]
47735b: mov edx,0x4775f0
477360: call 0x403d60
477365: jne 0x47736b
477367: mov BYTE PTR [edi-0xa],0xb
47736b: mov al,0xc
47736d: mov BYTE PTR [edi-0x9],al
477370: xor eax,eax
477372: mov al,BYTE PTR [edi-0x9]
477375: mov DWORD PTR [ebp-0xc],eax
477378: fild DWORD PTR [ebp-0xc]
47737b: fdiv DWORD PTR ds:0x4775f4
477381: call 0x402894
477386: mov BYTE PTR [edi-0x8],al
477389: push 0x19
47738b: push 0x46
47738d: mov ecx,0xffffffe7
477392: mov edx,0xffffffe7
477397: mov eax,esi
477399: call 0x4769c4
47739e: cmp BYTE PTR [edi],0x1e
4773a1: jne 0x477406
4773a3: mov BYTE PTR [edi+0x2],0x5
4773a7: mov BYTE PTR [edi+0x5],0x19
4773ab: mov BYTE PTR [edi+0x6],0x1
4773af: mov BYTE PTR [edi-0x1],0x1
4773b3: xor eax,eax
4773b5: mov al,bl
4773b7: imul eax,eax,0x16
4773ba: mov edx,DWORD PTR ds:0x4b0ef0
4773c0: mov al,BYTE PTR [edx+eax*8-0x43]
4773c4: mov BYTE PTR [edi-0xb],al
4773c7: mov BYTE PTR [edi-0x2],0x1
4773cb: mov BYTE PTR [edi+0x7],0x1
4773cf: mov BYTE PTR [edi-0xa],0x0
4773d3: mov al,0xa
4773d5: mov BYTE PTR [edi-0x9],al
4773d8: xor eax,eax
4773da: mov al,BYTE PTR [edi-0x9]
4773dd: mov DWORD PTR [ebp-0xc],eax
4773e0: fild DWORD PTR [ebp-0xc]
4773e3: fdiv DWORD PTR ds:0x4775f4
4773e9: call 0x402894
4773ee: mov BYTE PTR [edi-0x8],al
4773f1: push 0xf
4773f3: push 0x1e
4773f5: mov ecx,0xffffffe2
4773fa: mov edx,0xfffffff1
4773ff: mov eax,esi
477401: call 0x4769c4
477406: mov al,BYTE PTR [edi]
477408: cmp al,0x1f
47740a: je 0x477410
47740c: cmp al,0x20
47740e: jne 0x47747d
477410: mov BYTE PTR [edi+0x2],0x6
477414: mov BYTE PTR [edi+0x5],0x46
477418: mov BYTE PTR [edi+0x6],0x1
47741c: mov BYTE PTR [edi-0x1],0x1
477420: mov BYTE PTR [edi-0x2],0x1
477424: mov eax,0x5
477429: call 0x402a1c
47742e: test eax,eax
477430: jne 0x477436
477432: mov BYTE PTR [edi-0x2],0x1
477436: xor eax,eax
477438: mov al,bl
47743a: imul eax,eax,0x16
47743d: mov edx,DWORD PTR ds:0x4b0ef0
477443: mov al,BYTE PTR [edx+eax*8-0x43]
477447: mov BYTE PTR [edi-0xb],al
47744a: mov al,0x23
47744c: mov BYTE PTR [edi-0x9],al
47744f: xor eax,eax
477451: mov al,BYTE PTR [edi-0x9]
477454: mov DWORD PTR [ebp-0xc],eax
477457: fild DWORD PTR [ebp-0xc]
47745a: fdiv DWORD PTR ds:0x4775f8
477460: call 0x402894
477465: mov BYTE PTR [edi-0x8],al
477468: push 0x19
47746a: push 0x46
47746c: mov ecx,0xffffffe7
477471: mov edx,0xffffffe7
477476: mov eax,esi
477478: call 0x4769c4
47747d: cmp BYTE PTR [edi],0x21
477480: jne 0x47750d
477486: mov BYTE PTR [edi+0x2],0x6
47748a: mov BYTE PTR [edi+0x6],0x1
47748e: mov eax,0x5
477493: call 0x402a1c
477498: test eax,eax
47749a: jne 0x4774a0
47749c: mov BYTE PTR [edi-0x2],0x1
4774a0: xor eax,eax
4774a2: mov al,bl
4774a4: imul eax,eax,0x16
4774a7: mov edx,DWORD PTR ds:0x4b0ef0
4774ad: mov al,BYTE PTR [edx+eax*8-0x43]
4774b1: mov BYTE PTR [edi-0xb],al
4774b4: mov eax,DWORD PTR [ebp-0x8]
4774b7: mov edx,0x4775e4
4774bc: call 0x403d60
4774c1: jne 0x4774c7
4774c3: mov BYTE PTR [edi-0xa],0x8
4774c7: mov eax,DWORD PTR [ebp-0x8]
4774ca: mov edx,0x4775f0
4774cf: call 0x403d60
4774d4: jne 0x4774da
4774d6: mov BYTE PTR [edi-0xa],0xb
4774da: mov al,0xc
4774dc: mov BYTE PTR [edi-0x9],al
4774df: xor eax,eax
4774e1: mov al,BYTE PTR [edi-0x9]
4774e4: mov DWORD PTR [ebp-0xc],eax
4774e7: fild DWORD PTR [ebp-0xc]
4774ea: fdiv DWORD PTR ds:0x4775f4
4774f0: call 0x402894
4774f5: mov BYTE PTR [edi-0x8],al
4774f8: push 0x12
4774fa: push 0x46
4774fc: mov ecx,0xfffffff1
477501: mov edx,0xffffffee
477506: mov eax,esi
477508: call 0x4769c4
47750d: cmp BYTE PTR [edi],0x22
477510: jne 0x47756d
477512: mov BYTE PTR [edi+0x2],0x14
477516: mov BYTE PTR [edi+0x6],0x1
47751a: mov BYTE PTR [edi+0x8],0x1
47751e: mov BYTE PTR [edi-0x1],0x1
477522: mov BYTE PTR [edi-0x2],0x1
477526: xor eax,eax
477528: mov al,bl
47752a: imul eax,eax,0x16
47752d: mov edx,DWORD PTR ds:0x4b0ef0
477533: mov al,BYTE PTR [edx+eax*8-0x43]
477537: mov BYTE PTR [edi-0xb],al
47753a: mov al,0x12
47753c: mov BYTE PTR [edi-0x9],al
47753f: xor eax,eax
477541: mov al,BYTE PTR [edi-0x9]
477544: mov DWORD PTR [ebp-0xc],eax
477547: fild DWORD PTR [ebp-0xc]
47754a: fdiv DWORD PTR ds:0x4775f4
477550: call 0x402894
477555: mov BYTE PTR [edi-0x8],al
477558: push 0x2d
47755a: push 0x1e
47755c: mov ecx,0xffffffb5
477561: mov edx,0xffffffd3
477566: mov eax,esi
477568: call 0x4769c4
47756d: cmp BYTE PTR [edi],0x23
477570: jne 0x47758a
477572: mov BYTE PTR [edi+0x2],0xa
477576: xor eax,eax
477578: mov al,bl
47757a: imul eax,eax,0x16
47757d: mov edx,DWORD PTR ds:0x4b0ef0
477583: mov al,BYTE PTR [edx+eax*8-0x43]
477587: mov BYTE PTR [edi-0xb],al
47758a: cmp BYTE PTR [edi],0x24
47758d: jne 0x4775b6
47758f: mov BYTE PTR [edi+0x2],0xa
477593: xor eax,eax
477595: mov al,bl
477597: imul eax,eax,0x16
47759a: mov edx,DWORD PTR ds:0x4b0ef0
4775a0: mov al,BYTE PTR [edx+eax*8-0x43]
4775a4: mov BYTE PTR [edi-0xb],al
4775a7: jmp 0x4775b6
4775a9: inc esi
4775aa: add edi,0x38
4775ad: cmp esi,0x51
4775b0: jne 0x476a39
4775b6: xor eax,eax
4775b8: pop edx
4775b9: pop ecx
4775ba: pop ecx
4775bb: mov DWORD PTR fs:[eax],edx
4775be: push 0x4775d3
4775c3: lea eax,[ebp-0x8]
4775c6: call 0x4039d0
4775cb: ret
4775cc: jmp 0x403468
4775d3: pop edi
4775d4: pop esi
4775d5: pop ebx
4775d6: mov esp,ebp
4775d8: pop ebp
4775d9: ret 0x10
.data 4b1118 48464b00d6444b0040b6
.data 4b0ef0 e8444b000c204b0030b8
.data 4775f4 00008040000070415356
.data 4775f8 000070415356575583c4
.string 4775e4 41
.string 4775f0 42
