; entry 48e69c
48e69c: push ebp
48e69d: mov ebp,esp
48e69f: push ebx
48e6a0: push esi
48e6a1: push edi
48e6a2: mov edi,ecx
48e6a4: mov esi,edx
48e6a6: mov ebx,eax
48e6a8: mov eax,DWORD PTR [ebx+0x2d0]
48e6ae: mov eax,DWORD PTR [eax+0x270]
48e6b4: call 0x45cd9c
48e6b9: mov eax,DWORD PTR [eax+0x10]
48e6bc: mov edx,DWORD PTR [ebp+0xc]
48e6bf: call 0x417ed8
48e6c4: mov eax,DWORD PTR [ebx+0x2d0]
48e6ca: mov eax,DWORD PTR [eax+0x270]
48e6d0: call 0x45cd9c
48e6d5: mov eax,DWORD PTR [eax+0x14]
48e6d8: mov edx,DWORD PTR [ebp+0x8]
48e6db: call 0x4181bc
48e6e0: mov eax,DWORD PTR [ebp+0x14]
48e6e3: push eax
48e6e4: mov eax,DWORD PTR [ebp+0x10]
48e6e7: push eax
48e6e8: mov eax,DWORD PTR [ebx+0x2d0]
48e6ee: mov eax,DWORD PTR [eax+0x270]
48e6f4: call 0x45cd9c
48e6f9: mov ecx,edi
48e6fb: mov edx,esi
48e6fd: call 0x418560
48e702: mov eax,DWORD PTR [ebx+0x2d0]
48e708: mov eax,DWORD PTR [eax+0x270]
48e70e: call 0x45cd9c
48e713: call 0x45bb18
48e718: pop edi
48e719: pop esi
48e71a: pop ebx
48e71b: pop ebp
48e71c: ret 0x10
