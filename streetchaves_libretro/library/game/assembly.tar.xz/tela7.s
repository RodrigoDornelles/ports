; entry 4a44b3
; exit 4ab259
4a44b3: mov eax,ds:0x4b111c
4a44b8: cmp BYTE PTR [eax],0x7
4a44bb: jne 0x4aa29a
4a44c1: mov eax,ds:0x4b11f8
4a44c6: mov WORD PTR [eax],0x12c
4a44cb: mov eax,ds:0x4b11fc
4a44d0: cmp BYTE PTR [eax],0x1
4a44d3: jne 0x4a4591
4a44d9: mov eax,ds:0x4b0db4
4a44de: cmp BYTE PTR [eax],0x0
4a44e1: jne 0x4a4591
4a44e7: mov eax,ds:0x4b0ef0
4a44ec: xor edx,edx
4a44ee: mov DWORD PTR [eax],edx
4a44f0: mov DWORD PTR [eax+0x4],edx
4a44f3: mov eax,ds:0x4b0ef0
4a44f8: mov BYTE PTR [eax+0x6e],0x3
4a44fc: mov eax,ds:0x4b0ef0
4a4501: xor edx,edx
4a4503: mov DWORD PTR [eax+0xb0],edx
4a4509: mov DWORD PTR [eax+0xb4],0x4082c000
4a4513: mov eax,ds:0x4b0ef0
4a4518: mov BYTE PTR [eax+0x11e],0x2
4a451f: mov DWORD PTR [ebp-0xc],0x2
4a4526: mov ebx,DWORD PTR ds:0x4b0ef0
4a452c: add ebx,0x8
4a452f: mov eax,ds:0x4b11f8
4a4534: fild WORD PTR [eax]
4a4536: fstp QWORD PTR [ebx]
4a4538: fwait
4a4539: mov BYTE PTR [ebx+0x62],0x1
4a453d: mov BYTE PTR [ebx+0x70],0xe7
4a4541: mov BYTE PTR [ebx+0x64],0x15
4a4545: mov BYTE PTR [ebx+0x63],0xc
4a4549: mov WORD PTR [ebx+0x6c],0x0
4a454f: mov WORD PTR [ebx+0x6e],0x63
4a4555: add ebx,0xb0
4a455b: dec DWORD PTR [ebp-0xc]
4a455e: jne 0x4a452f
4a4560: mov eax,ds:0x4b110c
4a4565: mov BYTE PTR [eax],0x1
4a4568: mov eax,ds:0x4b0ef0
4a456d: fld QWORD PTR [eax+0x8]
4a4570: mov eax,ds:0x4b0ef0
4a4575: fadd QWORD PTR [eax+0xb8]
4a457b: fdiv DWORD PTR ds:0x4aef18
4a4581: call 0x402894
4a4586: sub eax,0x37
4a4589: mov edx,DWORD PTR ds:0x4b1144
4a458f: mov DWORD PTR [edx],eax
4a4591: mov eax,ds:0x4b116c
4a4596: cmp BYTE PTR [eax],0x8
4a4599: jne 0x4a45f1
4a459b: mov eax,ds:0x4b11fc
4a45a0: cmp BYTE PTR [eax],0x1
4a45a3: jne 0x4a45f1
4a45a5: mov eax,ds:0x4b0db4
4a45aa: cmp BYTE PTR [eax],0x1
4a45ad: jne 0x4a45f1
4a45af: mov eax,ds:0x4b0ef0
4a45b4: cmp BYTE PTR [eax+0x9e],0x0
4a45bb: je 0x4a45cb
4a45bd: mov eax,ds:0x4b0ef0
4a45c2: cmp BYTE PTR [eax+0x14e],0x0
4a45c9: jne 0x4a45f1
4a45cb: mov eax,ds:0x4b117c
4a45d0: mov WORD PTR [eax],0x258
4a45d5: mov eax,ds:0x4b0db4
4a45da: mov BYTE PTR [eax],0x2
4a45dd: mov eax,ds:0x4b123c
4a45e2: mov WORD PTR [eax],0xff88
4a45e7: mov eax,ds:0x4b0fb8
4a45ec: mov WORD PTR [eax],0x3c
4a45f1: mov eax,ds:0x4b117c
4a45f6: cmp WORD PTR [eax],0x0
4a45fa: jbe 0x4a4604
4a45fc: mov eax,ds:0x4b117c
4a4601: dec WORD PTR [eax]
4a4604: mov eax,ds:0x4b1210
4a4609: cmp BYTE PTR [eax],0x0
4a460c: je 0x4a4637
4a460e: mov eax,ds:0x4b0f6c
4a4613: cmp BYTE PTR [eax],0x1
4a4616: jne 0x4a4637
4a4618: mov eax,DWORD PTR [esi+0x318]
4a461e: mov eax,DWORD PTR [eax+0x28]
4a4621: xor edx,edx
4a4623: call 0x449f54
4a4628: xor edx,edx
4a462a: call 0x449cac
4a462f: mov eax,ds:0x4b0f6c
4a4634: mov BYTE PTR [eax],0x0
4a4637: mov eax,ds:0x4b1098
4a463c: cmp BYTE PTR [eax],0x0
4a463f: je 0x4a4682
4a4641: mov eax,DWORD PTR [esi+0x30c]
4a4647: mov eax,DWORD PTR [eax+0x28]
4a464a: call 0x40efcc
4a464f: mov edx,DWORD PTR ds:0x4b1098
4a4655: movzx edx,BYTE PTR [edx]
4a4658: cmp eax,edx
4a465a: jle 0x4a4682
4a465c: mov edx,DWORD PTR ds:0x4b1098
4a4662: movzx edx,BYTE PTR [edx]
4a4665: mov eax,DWORD PTR [esi+0x30c]
4a466b: mov eax,DWORD PTR [eax+0x28]
4a466e: call 0x449f54
4a4673: xor edx,edx
4a4675: call 0x449cac
4a467a: mov eax,ds:0x4b1098
4a467f: mov BYTE PTR [eax],0x0
4a4682: mov eax,ds:0x4b1074
4a4687: cmp BYTE PTR [eax],0x0
4a468a: jbe 0x4a47f1
4a4690: mov eax,ds:0x4b1074
4a4695: dec BYTE PTR [eax]
4a4697: xor eax,eax
4a4699: mov DWORD PTR [ebp-0x14],eax
4a469c: mov eax,ds:0x4b1074
4a46a1: movzx eax,BYTE PTR [eax]
4a46a4: mov DWORD PTR [ebp-0x48],eax
4a46a7: fild DWORD PTR [ebp-0x48]
4a46aa: fdiv DWORD PTR ds:0x4aec88
4a46b0: call 0x40287c
4a46b5: mov eax,ds:0x4b1074
4a46ba: movzx eax,BYTE PTR [eax]
4a46bd: mov DWORD PTR [ebp-0x1bc],eax
4a46c3: fild DWORD PTR [ebp-0x1bc]
4a46c9: fdiv DWORD PTR ds:0x4aec88
4a46cf: fcompp
4a46d1: fnstsw ax
4a46d3: sahf
4a46d4: jne 0x4a46dd
4a46d6: mov DWORD PTR [ebp-0x14],0x14
4a46dd: mov eax,ds:0x4b1074
4a46e2: movzx eax,BYTE PTR [eax]
4a46e5: mov DWORD PTR [ebp-0x48],eax
4a46e8: fild DWORD PTR [ebp-0x48]
4a46eb: fdiv DWORD PTR ds:0x4aef1c
4a46f1: call 0x40287c
4a46f6: mov eax,ds:0x4b1074
4a46fb: movzx eax,BYTE PTR [eax]
4a46fe: mov DWORD PTR [ebp-0x1bc],eax
4a4704: fild DWORD PTR [ebp-0x1bc]
4a470a: fdiv DWORD PTR ds:0x4aef1c
4a4710: fcompp
4a4712: fnstsw ax
4a4714: sahf
4a4715: jne 0x4a471e
4a4717: mov DWORD PTR [ebp-0x14],0x28
4a471e: mov eax,ds:0x4b1074
4a4723: movzx eax,BYTE PTR [eax]
4a4726: mov DWORD PTR [ebp-0x48],eax
4a4729: fild DWORD PTR [ebp-0x48]
4a472c: fdiv DWORD PTR ds:0x4aeee8
4a4732: call 0x40287c
4a4737: mov eax,ds:0x4b1074
4a473c: movzx eax,BYTE PTR [eax]
4a473f: mov DWORD PTR [ebp-0x1bc],eax
4a4745: fild DWORD PTR [ebp-0x1bc]
4a474b: fdiv DWORD PTR ds:0x4aeee8
4a4751: fcompp
4a4753: fnstsw ax
4a4755: sahf
4a4756: jne 0x4a475f
4a4758: mov DWORD PTR [ebp-0x14],0x3c
4a475f: mov eax,ds:0x4b1074
4a4764: movzx eax,BYTE PTR [eax]
4a4767: mov DWORD PTR [ebp-0x48],eax
4a476a: fild DWORD PTR [ebp-0x48]
4a476d: fdiv DWORD PTR ds:0x4aef20
4a4773: call 0x40287c
4a4778: mov eax,ds:0x4b1074
4a477d: movzx eax,BYTE PTR [eax]
4a4780: mov DWORD PTR [ebp-0x1bc],eax
4a4786: fild DWORD PTR [ebp-0x1bc]
4a478c: fdiv DWORD PTR ds:0x4aef20
4a4792: fcompp
4a4794: fnstsw ax
4a4796: sahf
4a4797: jne 0x4a47a0
4a4799: mov DWORD PTR [ebp-0x14],0x50
4a47a0: xor eax,eax
4a47a2: mov DWORD PTR [ebp-0xc],eax
4a47a5: xor eax,eax
4a47a7: mov DWORD PTR [ebp-0x10],eax
4a47aa: imul eax,DWORD PTR [ebp-0x10],0x64
4a47ae: push eax
4a47af: push 0x0
4a47b1: mov eax,DWORD PTR [esi+0x314]
4a47b7: mov eax,DWORD PTR [eax+0x28]
4a47ba: mov edx,0x7
4a47bf: call 0x461dcc
4a47c4: imul ecx,DWORD PTR [ebp-0xc],0x64
4a47c8: add ecx,0xffffffb0
4a47cb: add ecx,DWORD PTR [ebp-0x14]
4a47ce: mov edx,DWORD PTR [esi+0x2d0]
4a47d4: mov edx,DWORD PTR [edx+0x270]
4a47da: call 0x46161c
4a47df: inc DWORD PTR [ebp-0x10]
4a47e2: cmp DWORD PTR [ebp-0x10],0x5
4a47e6: jne 0x4a47aa
4a47e8: inc DWORD PTR [ebp-0xc]
4a47eb: cmp DWORD PTR [ebp-0xc],0x6
4a47ef: jne 0x4a47a5
4a47f1: mov eax,ds:0x4b110c
4a47f6: cmp BYTE PTR [eax],0x0
4a47f9: jne 0x4a484e
4a47fb: mov eax,ds:0x4b0ef0
4a4800: fld QWORD PTR [eax]
4a4802: mov eax,ds:0x4b0ef0
4a4807: fadd QWORD PTR [eax+0xb0]
4a480d: fdiv DWORD PTR ds:0x4aec88
4a4813: call 0x402894
4a4818: sub eax,0xc8
4a481d: mov edx,DWORD PTR ds:0x4b11b4
4a4823: mov DWORD PTR [edx],eax
4a4825: mov eax,ds:0x4b0ef0
4a482a: fld QWORD PTR [eax+0x8]
4a482d: mov eax,ds:0x4b0ef0
4a4832: fadd QWORD PTR [eax+0xb8]
4a4838: fdiv DWORD PTR ds:0x4aef18
4a483e: call 0x402894
4a4843: sub eax,0x37
4a4846: mov edx,DWORD PTR ds:0x4b1144
4a484c: mov DWORD PTR [edx],eax
4a484e: mov eax,ds:0x4b0d68
4a4853: cmp BYTE PTR [eax],0x0
4a4856: jbe 0x4a489d
4a4858: mov eax,ds:0x4b0d68
4a485d: dec BYTE PTR [eax]
4a485f: mov eax,0x14
4a4864: call 0x402a1c
4a4869: mov edx,DWORD PTR ds:0x4b11b4
4a486f: mov edx,DWORD PTR [edx]
4a4871: sub edx,0xa
4a4874: add eax,edx
4a4876: mov edx,DWORD PTR ds:0x4b11b4
4a487c: mov DWORD PTR [edx],eax
4a487e: mov eax,0x14
4a4883: call 0x402a1c
4a4888: mov edx,DWORD PTR ds:0x4b1144
4a488e: mov edx,DWORD PTR [edx]
4a4890: sub edx,0xa
4a4893: add eax,edx
4a4895: mov edx,DWORD PTR ds:0x4b1144
4a489b: mov DWORD PTR [edx],eax
4a489d: mov eax,ds:0x4b11b4
4a48a2: cmp DWORD PTR [eax],0x0
4a48a5: jge 0x4a48b0
4a48a7: mov eax,ds:0x4b11b4
4a48ac: xor edx,edx
4a48ae: mov DWORD PTR [eax],edx
4a48b0: mov eax,ds:0x4b11b4
4a48b5: cmp DWORD PTR [eax],0xc8
4a48bb: jle 0x4a48c8
4a48bd: mov eax,ds:0x4b11b4
4a48c2: mov DWORD PTR [eax],0xc8
4a48c8: mov eax,ds:0x4b1144
4a48cd: cmp DWORD PTR [eax],0x0
4a48d0: jge 0x4a48db
4a48d2: mov eax,ds:0x4b1144
4a48d7: xor edx,edx
4a48d9: mov DWORD PTR [eax],edx
4a48db: mov eax,ds:0x4b1144
4a48e0: cmp DWORD PTR [eax],0x14
4a48e3: jle 0x4a48f0
4a48e5: mov eax,ds:0x4b1144
4a48ea: mov DWORD PTR [eax],0x14
4a48f0: mov eax,DWORD PTR [esi+0x2d0]
4a48f6: mov eax,DWORD PTR [eax+0x270]
4a48fc: call 0x45cd9c
4a4901: call 0x45bb18
4a4906: mov eax,ds:0x4b1074
4a490b: cmp BYTE PTR [eax],0x0
4a490e: jne 0x4a4960
4a4910: mov eax,DWORD PTR [esi+0x310]
4a4916: mov eax,DWORD PTR [eax+0x28]
4a4919: call 0x40efcc
4a491e: test eax,eax
4a4920: jle 0x4a4960
4a4922: mov eax,ds:0x4b1144
4a4927: mov eax,DWORD PTR [eax]
4a4929: neg eax
4a492b: push eax
4a492c: push 0x0
4a492e: mov eax,DWORD PTR [esi+0x310]
4a4934: mov eax,DWORD PTR [eax+0x28]
4a4937: xor edx,edx
4a4939: call 0x461dcc
4a493e: mov ecx,DWORD PTR ds:0x4b11b4
4a4944: mov ecx,DWORD PTR [ecx]
4a4946: neg ecx
4a4948: mov edx,DWORD PTR [esi+0x2d0]
4a494e: mov edx,DWORD PTR [edx+0x270]
4a4954: call 0x46161c
4a4959: mov eax,esi
4a495b: call 0x49a3f4
4a4960: mov eax,DWORD PTR [esi+0x310]
4a4966: mov eax,DWORD PTR [eax+0x28]
4a4969: xor edx,edx
4a496b: call 0x461dcc
4a4970: mov eax,DWORD PTR [eax+0x20]
4a4973: call 0x41a9fc
4a4978: mov edx,DWORD PTR [eax]
4a497a: call DWORD PTR [edx+0x1c]
4a497d: cmp al,0x1
4a497f: jne 0x4a49ac
4a4981: mov eax,ds:0x4b1074
4a4986: cmp BYTE PTR [eax],0x0
4a4989: jne 0x4a49ac
4a498b: push 0x190
4a4990: push 0x12c
4a4995: xor ecx,ecx
4a4997: xor edx,edx
4a4999: xor eax,eax
4a499b: call 0x406de4
4a49a0: push eax
4a49a1: xor ecx,ecx
4a49a3: xor edx,edx
4a49a5: mov eax,esi
4a49a7: call 0x48e444
4a49ac: lea ecx,[ebp-0x208]
4a49b2: mov eax,DWORD PTR [esi+0x2f4]
4a49b8: mov eax,DWORD PTR [eax+0x208]
4a49be: mov edx,0x1d
4a49c3: mov ebx,DWORD PTR [eax]
4a49c5: call DWORD PTR [ebx+0xc]
4a49c8: push DWORD PTR [ebp-0x208]
4a49ce: push 0x4aef2c
4a49d3: lea edx,[ebp-0x20c]
4a49d9: mov eax,ds:0x4b116c
4a49de: movzx eax,BYTE PTR [eax]
4a49e1: call 0x408190
4a49e6: push DWORD PTR [ebp-0x20c]
4a49ec: lea eax,[ebp-0x204]
4a49f2: mov edx,0x3
4a49f7: call 0x403d10
4a49fc: mov eax,DWORD PTR [ebp-0x204]
4a4a02: push eax
4a4a03: push 0x63
4a4a05: push 0x7
4a4a07: mov cl,0xff
4a4a09: mov dl,0xff
4a4a0b: mov al,0xff
4a4a0d: call 0x406de4
4a4a12: push eax
4a4a13: mov ecx,DWORD PTR ds:0x4b123c
4a4a19: movsx ecx,WORD PTR [ecx]
4a4a1c: add ecx,0x3
4a4a1f: mov edx,0xc8
4a4a24: mov eax,esi
4a4a26: call 0x48e720
4a4a2b: push 0xe6
4a4a30: mov eax,ds:0x4b123c
4a4a35: movsx eax,WORD PTR [eax]
4a4a38: add eax,0x36
4a4a3b: push eax
4a4a3c: push 0xf
4a4a3e: mov cl,0xff
4a4a40: mov dl,0xff
4a4a42: mov al,0xff
4a4a44: call 0x406de4
4a4a49: push eax
4a4a4a: mov cl,0xff
4a4a4c: mov dl,0xff
4a4a4e: mov al,0xff
4a4a50: call 0x406de4
4a4a55: push eax
4a4a56: mov ecx,DWORD PTR ds:0x4b123c
4a4a5c: movsx ecx,WORD PTR [ecx]
4a4a5f: add ecx,0xf
4a4a62: mov edx,0xaa
4a4a67: mov eax,esi
4a4a69: call 0x48e570
4a4a6e: push 0xe4
4a4a73: mov eax,ds:0x4b123c
4a4a78: movsx eax,WORD PTR [eax]
4a4a7b: add eax,0x34
4a4a7e: push eax
4a4a7f: push 0xf
4a4a81: mov cl,0xaa
4a4a83: mov dl,0xaa
4a4a85: mov al,0xaa
4a4a87: call 0x406de4
4a4a8c: push eax
4a4a8d: mov cl,0xaa
4a4a8f: mov dl,0xaa
4a4a91: mov al,0xaa
4a4a93: call 0x406de4
4a4a98: push eax
4a4a99: mov ecx,DWORD PTR ds:0x4b123c
4a4a9f: movsx ecx,WORD PTR [ecx]
4a4aa2: add ecx,0x11
4a4aa5: mov edx,0xac
4a4aaa: mov eax,esi
4a4aac: call 0x48e570
4a4ab1: push 0xe2
4a4ab6: mov eax,ds:0x4b123c
4a4abb: movsx eax,WORD PTR [eax]
4a4abe: add eax,0x32
4a4ac1: push eax
4a4ac2: push 0xf
4a4ac4: xor ecx,ecx
4a4ac6: xor edx,edx
4a4ac8: xor eax,eax
4a4aca: call 0x406de4
4a4acf: push eax
4a4ad0: xor ecx,ecx
4a4ad2: xor edx,edx
4a4ad4: xor eax,eax
4a4ad6: call 0x406de4
4a4adb: push eax
4a4adc: mov ecx,DWORD PTR ds:0x4b123c
4a4ae2: movsx ecx,WORD PTR [ecx]
4a4ae5: add ecx,0x13
4a4ae8: mov edx,0xae
4a4aed: mov eax,esi
4a4aef: call 0x48e570
4a4af4: mov eax,ds:0x4b10b8
4a4af9: cmp BYTE PTR [eax],0x4
4a4afc: je 0x4a4cae
4a4b02: mov cl,0x32
4a4b04: mov dl,0x32
4a4b06: mov al,0xff
4a4b08: call 0x406de4
4a4b0d: mov DWORD PTR [ebp-0x18],eax
4a4b10: mov eax,ds:0x4b0f3c
4a4b15: cmp BYTE PTR [eax],0x2
4a4b18: ja 0x4a4b28
4a4b1a: mov cl,0xb4
4a4b1c: mov dl,0xb4
4a4b1e: mov al,0xff
4a4b20: call 0x406de4
4a4b25: mov DWORD PTR [ebp-0x18],eax
4a4b28: mov eax,ds:0x4b0eec
4a4b2d: cmp BYTE PTR [eax],0xa
4a4b30: jb 0x4a4b6c
4a4b32: lea edx,[ebp-0x210]
4a4b38: mov eax,ds:0x4b0eec
4a4b3d: movzx eax,BYTE PTR [eax]
4a4b40: call 0x408190
4a4b45: mov eax,DWORD PTR [ebp-0x210]
4a4b4b: push eax
4a4b4c: push 0x63
4a4b4e: push 0x19
4a4b50: mov eax,DWORD PTR [ebp-0x18]
4a4b53: push eax
4a4b54: mov ecx,DWORD PTR ds:0x4b123c
4a4b5a: movsx ecx,WORD PTR [ecx]
4a4b5d: add ecx,0xa
4a4b60: mov edx,0xc8
4a4b65: mov eax,esi
4a4b67: call 0x48e720
4a4b6c: mov eax,ds:0x4b0eec
4a4b71: cmp BYTE PTR [eax],0xa
4a4b74: jae 0x4a4bc6
4a4b76: lea edx,[ebp-0x218]
4a4b7c: mov eax,ds:0x4b0eec
4a4b81: movzx eax,BYTE PTR [eax]
4a4b84: call 0x408190
4a4b89: mov ecx,DWORD PTR [ebp-0x218]
4a4b8f: lea eax,[ebp-0x214]
4a4b95: mov edx,0x4aef38
4a4b9a: call 0x403c9c
4a4b9f: mov eax,DWORD PTR [ebp-0x214]
4a4ba5: push eax
4a4ba6: push 0x63
4a4ba8: push 0x19
4a4baa: mov eax,DWORD PTR [ebp-0x18]
4a4bad: push eax
4a4bae: mov ecx,DWORD PTR ds:0x4b123c
4a4bb4: movsx ecx,WORD PTR [ecx]
4a4bb7: add ecx,0xa
4a4bba: mov edx,0xc8
4a4bbf: mov eax,esi
4a4bc1: call 0x48e720
4a4bc6: mov eax,ds:0x4b0eec
4a4bcb: cmp BYTE PTR [eax],0xa
4a4bce: jae 0x4a4c66
4a4bd4: mov eax,ds:0x4b0f3c
4a4bd9: movzx eax,BYTE PTR [eax]
4a4bdc: mov DWORD PTR [ebp-0x48],eax
4a4bdf: fild DWORD PTR [ebp-0x48]
4a4be2: fdiv DWORD PTR ds:0x4aec88
4a4be8: call 0x40287c
4a4bed: mov eax,ds:0x4b0f3c
4a4bf2: movzx eax,BYTE PTR [eax]
4a4bf5: mov DWORD PTR [ebp-0x1bc],eax
4a4bfb: fild DWORD PTR [ebp-0x1bc]
4a4c01: fdiv DWORD PTR ds:0x4aec88
4a4c07: fcompp
4a4c09: fnstsw ax
4a4c0b: sahf
4a4c0c: jne 0x4a4c66
4a4c0e: lea edx,[ebp-0x220]
4a4c14: mov eax,ds:0x4b0eec
4a4c19: movzx eax,BYTE PTR [eax]
4a4c1c: call 0x408190
4a4c21: mov ecx,DWORD PTR [ebp-0x220]
4a4c27: lea eax,[ebp-0x21c]
4a4c2d: mov edx,0x4aef38
4a4c32: call 0x403c9c
4a4c37: mov eax,DWORD PTR [ebp-0x21c]
4a4c3d: push eax
4a4c3e: push 0x63
4a4c40: push 0x19
4a4c42: mov cl,0xb4
4a4c44: mov dl,0xb4
4a4c46: mov al,0xff
4a4c48: call 0x406de4
4a4c4d: push eax
4a4c4e: mov ecx,DWORD PTR ds:0x4b123c
4a4c54: movsx ecx,WORD PTR [ecx]
4a4c57: add ecx,0xa
4a4c5a: mov edx,0xc8
4a4c5f: mov eax,esi
4a4c61: call 0x48e720
4a4c66: mov eax,ds:0x4b1074
4a4c6b: cmp BYTE PTR [eax],0x0
4a4c6e: jne 0x4a4c8b
4a4c70: mov eax,ds:0x4b0e84
4a4c75: cmp BYTE PTR [eax],0x0
4a4c78: jne 0x4a4c8b
4a4c7a: mov eax,ds:0x4b110c
4a4c7f: cmp BYTE PTR [eax],0x0
4a4c82: jne 0x4a4c8b
4a4c84: mov eax,ds:0x4b0f3c
4a4c89: dec BYTE PTR [eax]
4a4c8b: mov eax,ds:0x4b0f3c
4a4c90: cmp BYTE PTR [eax],0x0
4a4c93: ja 0x4a4cae
4a4c95: mov eax,ds:0x4b0f3c
4a4c9a: mov BYTE PTR [eax],0x19
4a4c9d: mov eax,ds:0x4b0eec
4a4ca2: cmp BYTE PTR [eax],0x0
4a4ca5: jbe 0x4a4cae
4a4ca7: mov eax,ds:0x4b0eec
4a4cac: dec BYTE PTR [eax]
4a4cae: mov DWORD PTR [ebp-0xc],0x1
4a4cb5: mov ebx,DWORD PTR ds:0x4b0ef0
4a4cbb: add ebx,0x40
4a4cbe: mov eax,ds:0x4b0ef0
4a4cc3: fld QWORD PTR [eax+0x40]
4a4cc6: fcomp DWORD PTR ds:0x4aef3c
4a4ccc: fnstsw ax
4a4cce: sahf
4a4ccf: jbe 0x4a4cf3
4a4cd1: mov eax,ds:0x4b0ef0
4a4cd6: fld QWORD PTR [eax+0xf0]
4a4cdc: fcomp DWORD PTR ds:0x4aef3c
4a4ce2: fnstsw ax
4a4ce4: sahf
4a4ce5: jbe 0x4a4cf3
4a4ce7: fld QWORD PTR [ebx]
4a4ce9: mov eax,ds:0x4b1268
4a4cee: fadd QWORD PTR [eax]
4a4cf0: fstp QWORD PTR [ebx]
4a4cf2: fwait
4a4cf3: mov eax,ds:0x4b0f64
4a4cf8: cmp WORD PTR [eax],0x0
4a4cfc: jle 0x4a4d0f
4a4cfe: xor eax,eax
4a4d00: mov DWORD PTR [ebx],eax
4a4d02: mov DWORD PTR [ebx+0x4],0x405f4000
4a4d09: mov WORD PTR [ebx+0x18],0x3
4a4d0f: fld QWORD PTR [ebx]
4a4d11: fcomp DWORD PTR ds:0x4aef3c
4a4d17: fnstsw ax
4a4d19: sahf
4a4d1a: jae 0x4a4d23
4a4d1c: xor eax,eax
4a4d1e: mov DWORD PTR [ebx],eax
4a4d20: mov DWORD PTR [ebx+0x4],eax
4a4d23: fld QWORD PTR [ebx]
4a4d25: fcomp DWORD PTR ds:0x4aef40
4a4d2b: fnstsw ax
4a4d2d: sahf
4a4d2e: jbe 0x4a4d3b
4a4d30: xor eax,eax
4a4d32: mov DWORD PTR [ebx],eax
4a4d34: mov DWORD PTR [ebx+0x4],0x405f4000
4a4d3b: cmp DWORD PTR [ebp-0xc],0x1
4a4d3f: jne 0x4a4d48
4a4d41: mov DWORD PTR [ebp-0x10],0xffffffff
4a4d48: cmp DWORD PTR [ebp-0xc],0x2
4a4d4c: jne 0x4a4d55
4a4d4e: mov DWORD PTR [ebp-0x10],0x1
4a4d55: mov eax,ds:0x4b1094
4a4d5a: movzx eax,BYTE PTR [eax]
4a4d5d: mov DWORD PTR [ebp-0x48],eax
4a4d60: fild DWORD PTR [ebp-0x48]
4a4d63: fdiv DWORD PTR ds:0x4aef44
4a4d69: call 0x40286c
4a4d6e: fmul DWORD PTR ds:0x4aef48
4a4d74: call 0x402894
4a4d79: mov edx,DWORD PTR ds:0x4b0f84
4a4d7f: mov DWORD PTR [edx],eax
4a4d81: cmp DWORD PTR [ebp-0xc],0x1
4a4d85: jne 0x4a4da5
4a4d87: mov edx,DWORD PTR ds:0x4b0f84
4a4d8d: mov dl,BYTE PTR [edx]
4a4d8f: add dl,0x32
4a4d92: mov eax,ds:0x4b0f84
4a4d97: mov al,BYTE PTR [eax]
4a4d99: add al,0x32
4a4d9b: mov cl,0xff
4a4d9d: call 0x406de4
4a4da2: mov DWORD PTR [ebp-0x18],eax
4a4da5: cmp DWORD PTR [ebp-0xc],0x2
4a4da9: jne 0x4a4dcb
4a4dab: mov ecx,DWORD PTR ds:0x4b0f84
4a4db1: mov cl,BYTE PTR [ecx]
4a4db3: add cl,0x1e
4a4db6: mov edx,DWORD PTR ds:0x4b0f84
4a4dbc: mov dl,BYTE PTR [edx]
4a4dbe: add dl,0x1e
4a4dc1: mov al,0xff
4a4dc3: call 0x406de4
4a4dc8: mov DWORD PTR [ebp-0x18],eax
4a4dcb: imul eax,DWORD PTR [ebp-0x10],0x82
4a4dd2: add eax,0xc8
4a4dd7: push eax
4a4dd8: mov eax,ds:0x4b123c
4a4ddd: movsx eax,WORD PTR [eax]
4a4de0: add eax,0x44
4a4de3: push eax
4a4de4: mov eax,DWORD PTR [ebp-0x18]
4a4de7: push eax
4a4de8: mov ecx,DWORD PTR ds:0x4b123c
4a4dee: movsx ecx,WORD PTR [ecx]
4a4df1: add ecx,0x28
4a4df4: imul edx,DWORD PTR [ebp-0x10],0xc6
4a4dfb: add edx,0xc8
4a4e01: mov eax,esi
4a4e03: call 0x48e444
4a4e08: imul eax,DWORD PTR [ebp-0x10],0x82
4a4e0f: add eax,0xc8
4a4e14: push eax
4a4e15: mov eax,ds:0x4b123c
4a4e1a: movsx eax,WORD PTR [eax]
4a4e1d: add eax,0x44
4a4e20: push eax
4a4e21: mov cl,0xff
4a4e23: mov dl,0xff
4a4e25: mov al,0xff
4a4e27: call 0x406de4
4a4e2c: push eax
4a4e2d: mov ecx,DWORD PTR ds:0x4b123c
4a4e33: movsx ecx,WORD PTR [ecx]
4a4e36: add ecx,0x28
4a4e39: imul edx,DWORD PTR [ebp-0x10],0xc6
4a4e40: add edx,0xc8
4a4e46: mov eax,esi
4a4e48: call 0x48e4c0
4a4e4d: mov eax,DWORD PTR [ebp-0x10]
4a4e50: mov edx,eax
4a4e52: shl eax,0x4
4a4e55: add eax,edx
4a4e57: add eax,0xc8
4a4e5c: push eax
4a4e5d: mov eax,ds:0x4b123c
4a4e62: movsx eax,WORD PTR [eax]
4a4e65: add eax,0x32
4a4e68: push eax
4a4e69: push 0x8
4a4e6b: xor ecx,ecx
4a4e6d: xor edx,edx
4a4e6f: xor eax,eax
4a4e71: call 0x406de4
4a4e76: push eax
4a4e77: mov cl,0xff
4a4e79: mov dl,0xff
4a4e7b: mov al,0xff
4a4e7d: call 0x406de4
4a4e82: push eax
4a4e83: mov ecx,DWORD PTR ds:0x4b123c
4a4e89: movsx ecx,WORD PTR [ecx]
4a4e8c: add ecx,0x1e
4a4e8f: imul edx,DWORD PTR [ebp-0x10],0x9d
4a4e96: add edx,0xc8
4a4e9c: mov eax,esi
4a4e9e: call 0x48e570
4a4ea3: imul eax,DWORD PTR [ebp-0x10],0x13
4a4ea7: add eax,0xc8
4a4eac: push eax
4a4ead: mov eax,ds:0x4b123c
4a4eb2: movsx eax,WORD PTR [eax]
4a4eb5: add eax,0x30
4a4eb8: push eax
4a4eb9: push 0x8
4a4ebb: mov cl,0xaa
4a4ebd: mov dl,0xaa
4a4ebf: mov al,0xaa
4a4ec1: call 0x406de4
4a4ec6: push eax
4a4ec7: mov cl,0xaa
4a4ec9: mov dl,0xaa
4a4ecb: mov al,0xaa
4a4ecd: call 0x406de4
4a4ed2: push eax
4a4ed3: mov ecx,DWORD PTR ds:0x4b123c
4a4ed9: movsx ecx,WORD PTR [ecx]
4a4edc: add ecx,0x20
4a4edf: imul edx,DWORD PTR [ebp-0x10],0x9b
4a4ee6: add edx,0xc8
4a4eec: mov eax,esi
4a4eee: call 0x48e570
4a4ef3: imul eax,DWORD PTR [ebp-0x10],0x15
4a4ef7: add eax,0xc8
4a4efc: push eax
4a4efd: mov eax,ds:0x4b123c
4a4f02: movsx eax,WORD PTR [eax]
4a4f05: add eax,0x2e
4a4f08: push eax
4a4f09: push 0x8
4a4f0b: xor ecx,ecx
4a4f0d: xor edx,edx
4a4f0f: xor eax,eax
4a4f11: call 0x406de4
4a4f16: push eax
4a4f17: xor ecx,ecx
4a4f19: xor edx,edx
4a4f1b: xor eax,eax
4a4f1d: call 0x406de4
4a4f22: push eax
4a4f23: mov ecx,DWORD PTR ds:0x4b123c
4a4f29: movsx ecx,WORD PTR [ecx]
4a4f2c: add ecx,0x22
4a4f2f: imul edx,DWORD PTR [ebp-0x10],0x99
4a4f36: add edx,0xc8
4a4f3c: mov eax,esi
4a4f3e: call 0x48e570
4a4f43: fld QWORD PTR [ebx]
4a4f45: fcomp DWORD PTR ds:0x4aef4c
4a4f4b: fnstsw ax
4a4f4d: sahf
4a4f4e: ja 0x4a4fde
4a4f54: mov eax,ds:0x4b1094
4a4f59: movzx eax,BYTE PTR [eax]
4a4f5c: mov DWORD PTR [ebp-0x48],eax
4a4f5f: fild DWORD PTR [ebp-0x48]
4a4f62: fdiv DWORD PTR ds:0x4aec88
4a4f68: call 0x40287c
4a4f6d: mov eax,ds:0x4b1094
4a4f72: movzx eax,BYTE PTR [eax]
4a4f75: mov DWORD PTR [ebp-0x1bc],eax
4a4f7b: fild DWORD PTR [ebp-0x1bc]
4a4f81: fdiv DWORD PTR ds:0x4aec88
4a4f87: fcompp
4a4f89: fnstsw ax
4a4f8b: sahf
4a4f8c: jne 0x4a4fde
4a4f8e: imul eax,DWORD PTR [ebp-0x10],0x15
4a4f92: add eax,0xc8
4a4f97: push eax
4a4f98: mov eax,ds:0x4b123c
4a4f9d: movsx eax,WORD PTR [eax]
4a4fa0: add eax,0x2e
4a4fa3: push eax
4a4fa4: push 0x8
4a4fa6: xor ecx,ecx
4a4fa8: xor edx,edx
4a4faa: xor eax,eax
4a4fac: call 0x406de4
4a4fb1: push eax
4a4fb2: xor ecx,ecx
4a4fb4: xor edx,edx
4a4fb6: mov al,0xc8
4a4fb8: call 0x406de4
4a4fbd: push eax
4a4fbe: mov ecx,DWORD PTR ds:0x4b123c
4a4fc4: movsx ecx,WORD PTR [ecx]
4a4fc7: add ecx,0x22
4a4fca: imul edx,DWORD PTR [ebp-0x10],0x99
4a4fd1: add edx,0xc8
4a4fd7: mov eax,esi
4a4fd9: call 0x48e570
4a4fde: mov eax,ds:0x4b0f84
4a4fe3: xor edx,edx
4a4fe5: mov DWORD PTR [eax],edx
4a4fe7: fld QWORD PTR [ebx+0x8]
4a4fea: fcomp QWORD PTR [ebx]
4a4fec: fnstsw ax
4a4fee: sahf
4a4fef: jbe 0x4a5036
4a4ff1: mov eax,ds:0x4b1094
4a4ff6: movzx eax,BYTE PTR [eax]
4a4ff9: mov DWORD PTR [ebp-0x48],eax
4a4ffc: fild DWORD PTR [ebp-0x48]
4a4fff: fdiv DWORD PTR ds:0x4aec88
4a5005: call 0x40287c
4a500a: mov eax,ds:0x4b1094
4a500f: movzx eax,BYTE PTR [eax]
4a5012: mov DWORD PTR [ebp-0x1bc],eax
4a5018: fild DWORD PTR [ebp-0x1bc]
4a501e: fdiv DWORD PTR ds:0x4aec88
4a5024: fcompp
4a5026: fnstsw ax
4a5028: sahf
4a5029: jne 0x4a5036
4a502b: mov eax,ds:0x4b0f84
4a5030: mov DWORD PTR [eax],0xffffffff
4a5036: fld QWORD PTR [ebx+0x8]
4a5039: fcomp QWORD PTR [ebx]
4a503b: fnstsw ax
4a503d: sahf
4a503e: jbe 0x4a5085
4a5040: mov eax,ds:0x4b1094
4a5045: movzx eax,BYTE PTR [eax]
4a5048: mov DWORD PTR [ebp-0x48],eax
4a504b: fild DWORD PTR [ebp-0x48]
4a504e: fdiv DWORD PTR ds:0x4aec88
4a5054: call 0x40287c
4a5059: mov eax,ds:0x4b1094
4a505e: movzx eax,BYTE PTR [eax]
4a5061: mov DWORD PTR [ebp-0x1bc],eax
4a5067: fild DWORD PTR [ebp-0x1bc]
4a506d: fdiv DWORD PTR ds:0x4aec88
4a5073: fcompp
4a5075: fnstsw ax
4a5077: sahf
4a5078: je 0x4a5085
4a507a: mov eax,ds:0x4b0f84
4a507f: mov DWORD PTR [eax],0x1
4a5085: cmp DWORD PTR [ebp-0xc],0x1
4a5089: jne 0x4a50fc
4a508b: mov eax,ds:0x4b0f84
4a5090: cmp DWORD PTR [eax],0x0
4a5093: jne 0x4a50fc
4a5095: mov eax,DWORD PTR [esi+0x304]
4a509b: mov eax,DWORD PTR [eax+0x28]
4a509e: call 0x40efcc
4a50a3: mov edx,DWORD PTR ds:0x4b0ef0
4a50a9: movsx edx,BYTE PTR [edx+0x10]
4a50ad: dec edx
4a50ae: lea edx,[edx+edx*4]
4a50b1: cmp eax,edx
4a50b3: jle 0x4a50fc
4a50b5: mov eax,ds:0x4b123c
4a50ba: movsx eax,WORD PTR [eax]
4a50bd: add eax,0x7
4a50c0: push eax
4a50c1: push 0x0
4a50c3: mov eax,ds:0x4b0ef0
4a50c8: movsx eax,BYTE PTR [eax+0x10]
4a50cc: dec eax
4a50cd: lea edx,[eax+eax*4]
4a50d0: mov eax,DWORD PTR [esi+0x304]
4a50d6: mov eax,DWORD PTR [eax+0x28]
4a50d9: call 0x461dcc
4a50de: mov edx,DWORD PTR ds:0x4b0f84
4a50e4: mov ecx,0x3
4a50e9: sub ecx,DWORD PTR [edx]
4a50eb: mov edx,DWORD PTR [esi+0x2d0]
4a50f1: mov edx,DWORD PTR [edx+0x270]
4a50f7: call 0x46161c
4a50fc: cmp DWORD PTR [ebp-0xc],0x1
4a5100: jne 0x4a5179
4a5102: mov eax,ds:0x4b0f84
4a5107: cmp DWORD PTR [eax],0x0
4a510a: je 0x4a5179
4a510c: mov eax,DWORD PTR [esi+0x304]
4a5112: mov eax,DWORD PTR [eax+0x28]
4a5115: call 0x40efcc
4a511a: mov edx,DWORD PTR ds:0x4b0ef0
4a5120: movsx edx,BYTE PTR [edx+0x10]
4a5124: dec edx
4a5125: lea edx,[edx+edx*4]
4a5128: add edx,0x2
4a512b: cmp eax,edx
4a512d: jle 0x4a5179
4a512f: mov eax,ds:0x4b123c
4a5134: movsx eax,WORD PTR [eax]
4a5137: add eax,0x7
4a513a: push eax
4a513b: push 0x0
4a513d: mov eax,ds:0x4b0ef0
4a5142: movsx eax,BYTE PTR [eax+0x10]
4a5146: dec eax
4a5147: lea edx,[eax+eax*4]
4a514a: add edx,0x2
4a514d: mov eax,DWORD PTR [esi+0x304]
4a5153: mov eax,DWORD PTR [eax+0x28]
4a5156: call 0x461dcc
4a515b: mov edx,DWORD PTR ds:0x4b0f84
4a5161: mov ecx,0x3
4a5166: sub ecx,DWORD PTR [edx]
4a5168: mov edx,DWORD PTR [esi+0x2d0]
4a516e: mov edx,DWORD PTR [edx+0x270]
4a5174: call 0x46161c
4a5179: cmp DWORD PTR [ebp-0xc],0x2
4a517d: jne 0x4a51f8
4a517f: mov eax,ds:0x4b0f84
4a5184: cmp DWORD PTR [eax],0x0
4a5187: jne 0x4a51f8
4a5189: mov eax,DWORD PTR [esi+0x304]
4a518f: mov eax,DWORD PTR [eax+0x28]
4a5192: call 0x40efcc
4a5197: mov edx,DWORD PTR ds:0x4b0ef0
4a519d: movsx edx,BYTE PTR [edx+0xc0]
4a51a4: dec edx
4a51a5: lea edx,[edx+edx*4]
4a51a8: inc edx
4a51a9: cmp eax,edx
4a51ab: jle 0x4a51f8
4a51ad: mov eax,ds:0x4b123c
4a51b2: movsx eax,WORD PTR [eax]
4a51b5: add eax,0x7
4a51b8: push eax
4a51b9: push 0x0
4a51bb: mov eax,ds:0x4b0ef0
4a51c0: movsx eax,BYTE PTR [eax+0xc0]
4a51c7: dec eax
4a51c8: lea edx,[eax+eax*4]
4a51cb: inc edx
4a51cc: mov eax,DWORD PTR [esi+0x304]
4a51d2: mov eax,DWORD PTR [eax+0x28]
4a51d5: call 0x461dcc
4a51da: mov edx,DWORD PTR ds:0x4b0f84
4a51e0: mov ecx,0x15b
4a51e5: sub ecx,DWORD PTR [edx]
4a51e7: mov edx,DWORD PTR [esi+0x2d0]
4a51ed: mov edx,DWORD PTR [edx+0x270]
4a51f3: call 0x46161c
4a51f8: cmp DWORD PTR [ebp-0xc],0x2
4a51fc: jne 0x4a527b
4a51fe: mov eax,ds:0x4b0f84
4a5203: cmp DWORD PTR [eax],0x0
4a5206: je 0x4a527b
4a5208: mov eax,DWORD PTR [esi+0x304]
4a520e: mov eax,DWORD PTR [eax+0x28]
4a5211: call 0x40efcc
4a5216: mov edx,DWORD PTR ds:0x4b0ef0
4a521c: movsx edx,BYTE PTR [edx+0xc0]
4a5223: dec edx
4a5224: lea edx,[edx+edx*4]
4a5227: add edx,0x3
4a522a: cmp eax,edx
4a522c: jle 0x4a527b
4a522e: mov eax,ds:0x4b123c
4a5233: movsx eax,WORD PTR [eax]
4a5236: add eax,0x7
4a5239: push eax
4a523a: push 0x0
4a523c: mov eax,ds:0x4b0ef0
4a5241: movsx eax,BYTE PTR [eax+0xc0]
4a5248: dec eax
4a5249: lea edx,[eax+eax*4]
4a524c: add edx,0x3
4a524f: mov eax,DWORD PTR [esi+0x304]
4a5255: mov eax,DWORD PTR [eax+0x28]
4a5258: call 0x461dcc
4a525d: mov edx,DWORD PTR ds:0x4b0f84
4a5263: mov ecx,0x15b
4a5268: sub ecx,DWORD PTR [edx]
4a526a: mov edx,DWORD PTR [esi+0x2d0]
4a5270: mov edx,DWORD PTR [edx+0x270]
4a5276: call 0x46161c
4a527b: xor eax,eax
4a527d: mov DWORD PTR [ebp-0x14],eax
4a5280: fld QWORD PTR [ebx]
4a5282: fcomp DWORD PTR ds:0x4aef4c
4a5288: fnstsw ax
4a528a: sahf
4a528b: jbe 0x4a52ce
4a528d: mov edi,DWORD PTR [ebp-0x14]
4a5290: shl edi,0x4
4a5293: add edi,0x28
4a5296: imul edi,DWORD PTR [ebp-0x10]
4a529a: add edi,0xc8
4a52a0: push edi
4a52a1: mov eax,ds:0x4b123c
4a52a6: movsx eax,WORD PTR [eax]
4a52a9: add eax,0x2d
4a52ac: push eax
4a52ad: mov cl,0x50
4a52af: mov dl,0x50
4a52b1: mov al,0x50
4a52b3: call 0x406de4
4a52b8: push eax
4a52b9: mov ecx,DWORD PTR ds:0x4b123c
4a52bf: movsx ecx,WORD PTR [ecx]
4a52c2: add ecx,0x23
4a52c5: mov edx,edi
4a52c7: mov eax,esi
4a52c9: call 0x48e4c0
4a52ce: fld QWORD PTR [ebx]
4a52d0: fcomp DWORD PTR ds:0x4aef4c
4a52d6: fnstsw ax
4a52d8: sahf
4a52d9: ja 0x4a531c
4a52db: mov edi,DWORD PTR [ebp-0x14]
4a52de: shl edi,0x4
4a52e1: add edi,0x28
4a52e4: imul edi,DWORD PTR [ebp-0x10]
4a52e8: add edi,0xc8
4a52ee: push edi
4a52ef: mov eax,ds:0x4b123c
4a52f4: movsx eax,WORD PTR [eax]
4a52f7: add eax,0x2d
4a52fa: push eax
4a52fb: mov cl,0x1e
4a52fd: mov dl,0x1e
4a52ff: mov al,0x96
4a5301: call 0x406de4
4a5306: push eax
4a5307: mov ecx,DWORD PTR ds:0x4b123c
4a530d: movsx ecx,WORD PTR [ecx]
4a5310: add ecx,0x23
4a5313: mov edx,edi
4a5315: mov eax,esi
4a5317: call 0x48e4c0
4a531c: inc DWORD PTR [ebp-0x14]
4a531f: cmp DWORD PTR [ebp-0x14],0x7
4a5323: jne 0x4a5280
4a5329: fld QWORD PTR [ebx+0x8]
4a532c: fcomp DWORD PTR ds:0x4aef40
4a5332: fnstsw ax
4a5334: sahf
4a5335: jbe 0x4a5343
4a5337: xor eax,eax
4a5339: mov DWORD PTR [ebx+0x8],eax
4a533c: mov DWORD PTR [ebx+0xc],0x405f4000
4a5343: mov eax,DWORD PTR [ebp-0x10]
4a5346: lea eax,[eax+eax*4]
4a5349: lea eax,[eax+eax*4]
4a534c: add eax,0xc8
4a5351: push eax
4a5352: mov eax,ds:0x4b123c
4a5357: movsx eax,WORD PTR [eax]
4a535a: add eax,0x2d
4a535d: push eax
4a535e: xor ecx,ecx
4a5360: xor edx,edx
4a5362: mov al,0xaa
4a5364: call 0x406de4
4a5369: push eax
4a536a: fld DWORD PTR ds:0x4aef50
4a5370: fadd QWORD PTR [ebx+0x8]
4a5373: fild DWORD PTR [ebp-0x10]
4a5376: fmulp st(1),st
4a5378: call 0x402894
4a537d: mov edx,eax
4a537f: add edx,0xc8
4a5385: mov ecx,DWORD PTR ds:0x4b123c
4a538b: movsx ecx,WORD PTR [ecx]
4a538e: add ecx,0x23
4a5391: mov eax,esi
4a5393: call 0x48e444
4a5398: mov eax,ds:0x4b1074
4a539d: cmp BYTE PTR [eax],0x0
4a53a0: jne 0x4a53e6
4a53a2: mov eax,ds:0x4b0e84
4a53a7: cmp BYTE PTR [eax],0x0
4a53aa: jne 0x4a53e6
4a53ac: fld QWORD PTR [ebx+0x10]
4a53af: fcomp DWORD PTR ds:0x4aef3c
4a53b5: fnstsw ax
4a53b7: sahf
4a53b8: jne 0x4a53e6
4a53ba: fld QWORD PTR [ebx+0x8]
4a53bd: fcomp QWORD PTR [ebx]
4a53bf: fnstsw ax
4a53c1: sahf
4a53c2: jbe 0x4a53d1
4a53c4: fld QWORD PTR [ebx+0x8]
4a53c7: fsub DWORD PTR ds:0x4aef1c
4a53cd: fstp QWORD PTR [ebx+0x8]
4a53d0: fld QWORD PTR [ebx+0x8]
4a53d1: fld QWORD PTR [ebx+0x8]
4a53d4: fcomp QWORD PTR [ebx]
4a53d6: fnstsw ax
4a53d8: sahf
4a53d9: jae 0x4a53e6
4a53db: mov eax,DWORD PTR [ebx]
4a53dd: mov DWORD PTR [ebx+0x8],eax
4a53e0: mov eax,DWORD PTR [ebx+0x4]
4a53e3: mov DWORD PTR [ebx+0xc],eax
4a53e6: fld QWORD PTR [ebx+0x10]
4a53e9: fcomp DWORD PTR ds:0x4aef3c
4a53ef: fnstsw ax
4a53f1: sahf
4a53f2: jbe 0x4a5401
4a53f4: fld QWORD PTR [ebx+0x10]
4a53f7: fsub DWORD PTR ds:0x4aef54
4a53fd: fstp QWORD PTR [ebx+0x10]
4a5400: fld QWORD PTR [ebx]
4a5401: fld QWORD PTR [ebx]
4a5403: fcomp DWORD PTR ds:0x4aef40
4a5409: fnstsw ax
4a540b: sahf
4a540c: jbe 0x4a5419
4a540e: xor eax,eax
4a5410: mov DWORD PTR [ebx],eax
4a5412: mov DWORD PTR [ebx+0x4],0x405f4000
4a5419: fld QWORD PTR [ebx]
4a541b: fcomp DWORD PTR ds:0x4aef3c
4a5421: fnstsw ax
4a5423: sahf
4a5424: jae 0x4a542d
4a5426: xor eax,eax
4a5428: mov DWORD PTR [ebx],eax
4a542a: mov DWORD PTR [ebx+0x4],eax
4a542d: mov eax,DWORD PTR [ebp-0x10]
4a5430: lea eax,[eax+eax*4]
4a5433: lea eax,[eax+eax*4]
4a5436: add eax,0xc8
4a543b: push eax
4a543c: mov eax,ds:0x4b123c
4a5441: movsx eax,WORD PTR [eax]
4a5444: add eax,0x2d
4a5447: push eax
4a5448: xor ecx,ecx
4a544a: mov dl,0x96
4a544c: mov al,0x96
4a544e: call 0x406de4
4a5453: push eax
4a5454: fld DWORD PTR ds:0x4aef50
4a545a: fadd QWORD PTR [ebx]
4a545c: fild DWORD PTR [ebp-0x10]
4a545f: fmulp st(1),st
4a5461: call 0x402894
4a5466: mov edx,eax
4a5468: add edx,0xc8
4a546e: mov ecx,DWORD PTR ds:0x4b123c
4a5474: movsx ecx,WORD PTR [ecx]
4a5477: add ecx,0x23
4a547a: mov eax,esi
4a547c: call 0x48e444
4a5481: mov eax,DWORD PTR [ebp-0x10]
4a5484: lea eax,[eax+eax*4]
4a5487: lea eax,[eax+eax*4]
4a548a: add eax,0xc8
4a548f: push eax
4a5490: mov eax,ds:0x4b123c
4a5495: movsx eax,WORD PTR [eax]
4a5498: add eax,0x2c
4a549b: push eax
4a549c: mov cl,0x46
4a549e: mov dl,0xdc
4a54a0: mov al,0xdc
4a54a2: call 0x406de4
4a54a7: push eax
4a54a8: fld DWORD PTR ds:0x4aef50
4a54ae: fadd QWORD PTR [ebx]
4a54b0: fild DWORD PTR [ebp-0x10]
4a54b3: fmulp st(1),st
4a54b5: call 0x402894
4a54ba: mov edx,eax
4a54bc: add edx,0xc8
4a54c2: mov ecx,DWORD PTR ds:0x4b123c
4a54c8: movsx ecx,WORD PTR [ecx]
4a54cb: add ecx,0x24
4a54ce: mov eax,esi
4a54d0: call 0x48e444
4a54d5: mov eax,DWORD PTR [ebp-0x10]
4a54d8: lea eax,[eax+eax*4]
4a54db: lea eax,[eax+eax*4]
4a54de: add eax,0xc8
4a54e3: push eax
4a54e4: mov eax,ds:0x4b123c
4a54e9: movsx eax,WORD PTR [eax]
4a54ec: add eax,0x2a
4a54ef: push eax
4a54f0: mov cl,0x64
4a54f2: mov dl,0xfa
4a54f4: mov al,0xfa
4a54f6: call 0x406de4
4a54fb: push eax
4a54fc: fld DWORD PTR ds:0x4aef50
4a5502: fadd QWORD PTR [ebx]
4a5504: fild DWORD PTR [ebp-0x10]
4a5507: fmulp st(1),st
4a5509: call 0x402894
4a550e: mov edx,eax
4a5510: add edx,0xc8
4a5516: mov ecx,DWORD PTR ds:0x4b123c
4a551c: movsx ecx,WORD PTR [ecx]
4a551f: add ecx,0x26
4a5522: mov eax,esi
4a5524: call 0x48e444
4a5529: mov eax,DWORD PTR [ebp-0x10]
4a552c: lea eax,[eax+eax*4]
4a552f: lea eax,[eax+eax*4]
4a5532: add eax,0xc8
4a5537: push eax
4a5538: mov eax,ds:0x4b123c
4a553d: movsx eax,WORD PTR [eax]
4a5540: add eax,0x28
4a5543: push eax
4a5544: mov cl,0xff
4a5546: mov dl,0xff
4a5548: mov al,0xff
4a554a: call 0x406de4
4a554f: push eax
4a5550: fld DWORD PTR ds:0x4aef50
4a5556: fadd QWORD PTR [ebx]
4a5558: fild DWORD PTR [ebp-0x10]
4a555b: fmulp st(1),st
4a555d: call 0x402894
4a5562: mov edx,eax
4a5564: add edx,0xc8
4a556a: mov ecx,DWORD PTR ds:0x4b123c
4a5570: movsx ecx,WORD PTR [ecx]
4a5573: add ecx,0x27
4a5576: mov eax,esi
4a5578: call 0x48e444
4a557d: mov eax,ds:0x4b1094
4a5582: movzx eax,BYTE PTR [eax]
4a5585: mov DWORD PTR [ebp-0x48],eax
4a5588: fild DWORD PTR [ebp-0x48]
4a558b: fld TBYTE PTR ds:0x4aef58
4a5591: fdivp st(1),st
4a5593: call 0x40286c
4a5598: fmul DWORD PTR ds:0x4aef64
4a559e: call 0x402894
4a55a3: mov edx,DWORD PTR ds:0x4b0f84
4a55a9: mov DWORD PTR [edx],eax
4a55ab: mov edi,DWORD PTR ds:0x4b113c
4a55b1: movzx edi,BYTE PTR [edi]
4a55b4: test edi,edi
4a55b6: jle 0x4a5745
4a55bc: mov DWORD PTR [ebp-0x14],0x1
4a55c3: mov eax,DWORD PTR [ebp-0x14]
4a55c6: dec eax
4a55c7: mov edx,eax
4a55c9: shl eax,0x4
4a55cc: add eax,edx
4a55ce: mov edx,0xb4
4a55d3: sub edx,eax
4a55d5: imul edx,DWORD PTR [ebp-0x10]
4a55d9: add edx,0xc8
4a55df: push edx
4a55e0: mov eax,ds:0x4b123c
4a55e5: movsx eax,WORD PTR [eax]
4a55e8: add eax,0x55
4a55eb: push eax
4a55ec: push 0x5
4a55ee: mov cl,0xff
4a55f0: mov dl,0xff
4a55f2: mov al,0xff
4a55f4: call 0x406de4
4a55f9: push eax
4a55fa: xor ecx,ecx
4a55fc: xor edx,edx
4a55fe: xor eax,eax
4a5600: call 0x406de4
4a5605: push eax
4a5606: mov eax,DWORD PTR [ebp-0x14]
4a5609: dec eax
4a560a: mov edx,eax
4a560c: shl eax,0x4
4a560f: add eax,edx
4a5611: mov edx,0xc3
4a5616: sub edx,eax
4a5618: imul edx,DWORD PTR [ebp-0x10]
4a561c: add edx,0xc8
4a5622: mov ecx,DWORD PTR ds:0x4b123c
4a5628: movsx ecx,WORD PTR [ecx]
4a562b: add ecx,0x46
4a562e: mov eax,esi
4a5630: call 0x48e570
4a5635: xor eax,eax
4a5637: mov al,BYTE PTR [ebx+0x4c]
4a563a: cmp eax,DWORD PTR [ebp-0x14]
4a563d: jl 0x4a573b
4a5643: mov eax,DWORD PTR [ebp-0x14]
4a5646: dec eax
4a5647: mov edx,eax
4a5649: shl eax,0x4
4a564c: add eax,edx
4a564e: mov edx,0xb4
4a5653: sub edx,eax
4a5655: imul edx,DWORD PTR [ebp-0x10]
4a5659: add edx,0xc8
4a565f: push edx
4a5660: mov eax,ds:0x4b123c
4a5665: movsx eax,WORD PTR [eax]
4a5668: add eax,0x55
4a566b: push eax
4a566c: push 0x5
4a566e: mov cl,0xff
4a5670: mov dl,0xff
4a5672: mov al,0xff
4a5674: call 0x406de4
4a5679: push eax
4a567a: mov eax,ds:0x4b0f84
4a567f: push DWORD PTR [eax]
4a5681: mov al,0xa0
4a5683: pop edx
4a5684: sub al,dl
4a5686: xor ecx,ecx
4a5688: xor edx,edx
4a568a: call 0x406de4
4a568f: push eax
4a5690: mov eax,DWORD PTR [ebp-0x14]
4a5693: dec eax
4a5694: mov edx,eax
4a5696: shl eax,0x4
4a5699: add eax,edx
4a569b: mov edx,0xc3
4a56a0: sub edx,eax
4a56a2: imul edx,DWORD PTR [ebp-0x10]
4a56a6: add edx,0xc8
4a56ac: mov ecx,DWORD PTR ds:0x4b123c
4a56b2: movsx ecx,WORD PTR [ecx]
4a56b5: add ecx,0x46
4a56b8: mov eax,esi
4a56ba: call 0x48e570
4a56bf: mov eax,ds:0x4b1094
4a56c4: cmp BYTE PTR [eax],0xa
4a56c7: jae 0x4a573b
4a56c9: mov eax,DWORD PTR [ebp-0x14]
4a56cc: dec eax
4a56cd: mov edx,eax
4a56cf: shl eax,0x4
4a56d2: add eax,edx
4a56d4: mov edx,0xb4
4a56d9: sub edx,eax
4a56db: imul edx,DWORD PTR [ebp-0x10]
4a56df: add edx,0xc8
4a56e5: push edx
4a56e6: mov eax,ds:0x4b123c
4a56eb: movsx eax,WORD PTR [eax]
4a56ee: add eax,0x55
4a56f1: push eax
4a56f2: push 0x5
4a56f4: mov cl,0xff
4a56f6: mov dl,0xff
4a56f8: mov al,0xff
4a56fa: call 0x406de4
4a56ff: push eax
4a5700: xor ecx,ecx
4a5702: xor edx,edx
4a5704: mov al,0xff
4a5706: call 0x406de4
4a570b: push eax
4a570c: mov eax,DWORD PTR [ebp-0x14]
4a570f: dec eax
4a5710: mov edx,eax
4a5712: shl eax,0x4
4a5715: add eax,edx
4a5717: mov edx,0xc3
4a571c: sub edx,eax
4a571e: imul edx,DWORD PTR [ebp-0x10]
4a5722: add edx,0xc8
4a5728: mov ecx,DWORD PTR ds:0x4b123c
4a572e: movsx ecx,WORD PTR [ecx]
4a5731: add ecx,0x46
4a5734: mov eax,esi
4a5736: call 0x48e570
4a573b: inc DWORD PTR [ebp-0x14]
4a573e: dec edi
4a573f: jne 0x4a55c3
4a5745: cmp BYTE PTR [ebx+0x5e],0x0
4a5749: jne 0x4a581c
4a574f: mov eax,ds:0x4b0f64
4a5754: cmp WORD PTR [eax],0x0
4a5758: jne 0x4a581c
4a575e: mov eax,ds:0x4b1094
4a5763: cmp BYTE PTR [eax],0xf
4a5766: jae 0x4a57b8
4a5768: mov eax,ds:0x4b0f44
4a576d: cmp BYTE PTR [eax],0x0
4a5770: jne 0x4a57b8
4a5772: lea ecx,[ebp-0x224]
4a5778: mov eax,DWORD PTR [esi+0x2f4]
4a577e: mov eax,DWORD PTR [eax+0x208]
4a5784: mov edx,0x6
4a5789: mov edi,DWORD PTR [eax]
4a578b: call DWORD PTR [edi+0xc]
4a578e: mov eax,DWORD PTR [ebp-0x224]
4a5794: push eax
4a5795: push 0x63
4a5797: push 0xa
4a5799: mov cl,0xff
4a579b: mov dl,0xff
4a579d: mov al,0xff
4a579f: call 0x406de4
4a57a4: push eax
4a57a5: imul edx,DWORD PTR [ebp-0x10],0x64
4a57a9: add edx,0xc8
4a57af: xor ecx,ecx
4a57b1: mov eax,esi
4a57b3: call 0x48e720
4a57b8: mov eax,ds:0x4b1094
4a57bd: cmp BYTE PTR [eax],0xf
4a57c0: jae 0x4a581c
4a57c2: mov eax,ds:0x4b0f44
4a57c7: cmp BYTE PTR [eax],0x0
4a57ca: jbe 0x4a581c
4a57cc: mov eax,ds:0x4b110c
4a57d1: cmp BYTE PTR [eax],0x0
4a57d4: jne 0x4a581c
4a57d6: lea ecx,[ebp-0x228]
4a57dc: mov eax,DWORD PTR [esi+0x2f4]
4a57e2: mov eax,DWORD PTR [eax+0x208]
4a57e8: mov edx,0x7
4a57ed: mov edi,DWORD PTR [eax]
4a57ef: call DWORD PTR [edi+0xc]
4a57f2: mov eax,DWORD PTR [ebp-0x228]
4a57f8: push eax
4a57f9: push 0x63
4a57fb: push 0xa
4a57fd: mov cl,0xff
4a57ff: mov dl,0xff
4a5801: mov al,0xff
4a5803: call 0x406de4
4a5808: push eax
4a5809: imul edx,DWORD PTR [ebp-0x10],0x64
4a580d: add edx,0xc8
4a5813: xor ecx,ecx
4a5815: mov eax,esi
4a5817: call 0x48e720
4a581c: cmp DWORD PTR [ebp-0xc],0x1
4a5820: jne 0x4a5874
4a5822: lea ecx,[ebp-0x22c]
4a5828: movsx edx,BYTE PTR [ebx-0x30]
4a582c: mov eax,DWORD PTR [esi+0x2f0]
4a5832: mov eax,DWORD PTR [eax+0x208]
4a5838: mov edi,DWORD PTR [eax]
4a583a: call DWORD PTR [edi+0xc]
4a583d: mov eax,DWORD PTR [ebp-0x22c]
4a5843: push eax
4a5844: push 0x2d
4a5846: push 0xc
4a5848: mov cl,0xff
4a584a: mov dl,0x78
4a584c: mov al,0x78
4a584e: call 0x406de4
4a5853: push eax
4a5854: mov ecx,DWORD PTR ds:0x4b123c
4a585a: movsx ecx,WORD PTR [ecx]
4a585d: add ecx,0x2d
4a5860: imul edx,DWORD PTR [ebp-0x10],0x91
4a5867: add edx,0xc8
4a586d: mov eax,esi
4a586f: call 0x48e720
4a5874: cmp DWORD PTR [ebp-0xc],0x2
4a5878: jne 0x4a58cc
4a587a: lea ecx,[ebp-0x230]
4a5880: movsx edx,BYTE PTR [ebx-0x30]
4a5884: mov eax,DWORD PTR [esi+0x2f0]
4a588a: mov eax,DWORD PTR [eax+0x208]
4a5890: mov edi,DWORD PTR [eax]
4a5892: call DWORD PTR [edi+0xc]
4a5895: mov eax,DWORD PTR [ebp-0x230]
4a589b: push eax
4a589c: push 0x65
4a589e: push 0xc
4a58a0: mov cl,0x6e
4a58a2: mov dl,0x6e
4a58a4: mov al,0xff
4a58a6: call 0x406de4
4a58ab: push eax
4a58ac: mov ecx,DWORD PTR ds:0x4b123c
4a58b2: movsx ecx,WORD PTR [ecx]
4a58b5: add ecx,0x2d
4a58b8: imul edx,DWORD PTR [ebp-0x10],0x91
4a58bf: add edx,0xc8
4a58c5: mov eax,esi
4a58c7: call 0x48e720
4a58cc: cmp BYTE PTR [ebx+0x5e],0x1
4a58d0: jne 0x4a5a54
4a58d6: mov eax,ds:0x4b1094
4a58db: movzx eax,BYTE PTR [eax]
4a58de: mov DWORD PTR [ebp-0x48],eax
4a58e1: fild DWORD PTR [ebp-0x48]
4a58e4: fdiv DWORD PTR ds:0x4aef44
4a58ea: call 0x40286c
4a58ef: fmul DWORD PTR ds:0x4aeeec
4a58f5: call 0x402894
4a58fa: mov edx,DWORD PTR ds:0x4b0f84
4a5900: mov DWORD PTR [edx],eax
4a5902: cmp DWORD PTR [ebp-0xc],0x1
4a5906: jne 0x4a594d
4a5908: push 0x4aef70
4a590d: push 0x2d
4a590f: push 0xc
4a5911: mov edx,DWORD PTR ds:0x4b0f84
4a5917: mov dl,BYTE PTR [edx]
4a5919: add dl,0x78
4a591c: mov eax,ds:0x4b0f84
4a5921: mov al,BYTE PTR [eax]
4a5923: add al,0x78
4a5925: mov cl,0xff
4a5927: call 0x406de4
4a592c: push eax
4a592d: mov ecx,DWORD PTR ds:0x4b123c
4a5933: movsx ecx,WORD PTR [ecx]
4a5936: add ecx,0xa
4a5939: imul edx,DWORD PTR [ebp-0x10],0x91
4a5940: add edx,0xc8
4a5946: mov eax,esi
4a5948: call 0x48e720
4a594d: cmp DWORD PTR [ebp-0xc],0x1
4a5951: jne 0x4a59a9
4a5953: mov eax,DWORD PTR [ebx+0x48]
4a5956: xor edx,edx
4a5958: push edx
4a5959: push eax
4a595a: lea eax,[ebp-0x234]
4a5960: call 0x4081c0
4a5965: mov eax,DWORD PTR [ebp-0x234]
4a596b: push eax
4a596c: push 0x65
4a596e: push 0xc
4a5970: mov edx,DWORD PTR ds:0x4b0f84
4a5976: mov dl,BYTE PTR [edx]
4a5978: add dl,0x78
4a597b: mov eax,ds:0x4b0f84
4a5980: mov al,BYTE PTR [eax]
4a5982: add al,0x78
4a5984: mov cl,0xff
4a5986: call 0x406de4
4a598b: push eax
4a598c: mov ecx,DWORD PTR ds:0x4b123c
4a5992: movsx ecx,WORD PTR [ecx]
4a5995: add ecx,0xa
4a5998: imul edx,DWORD PTR [ebp-0x10],0x32
4a599c: add edx,0xc8
4a59a2: mov eax,esi
4a59a4: call 0x48e720
4a59a9: cmp DWORD PTR [ebp-0xc],0x2
4a59ad: jne 0x4a59f6
4a59af: push 0x4aef7c
4a59b4: push 0x65
4a59b6: push 0xc
4a59b8: mov ecx,DWORD PTR ds:0x4b0f84
4a59be: mov cl,BYTE PTR [ecx]
4a59c0: add cl,0x6e
4a59c3: mov edx,DWORD PTR ds:0x4b0f84
4a59c9: mov dl,BYTE PTR [edx]
4a59cb: add dl,0x6e
4a59ce: mov al,0xff
4a59d0: call 0x406de4
4a59d5: push eax
4a59d6: mov ecx,DWORD PTR ds:0x4b123c
4a59dc: movsx ecx,WORD PTR [ecx]
4a59df: add ecx,0xa
4a59e2: imul edx,DWORD PTR [ebp-0x10],0x91
4a59e9: add edx,0xc8
4a59ef: mov eax,esi
4a59f1: call 0x48e720
4a59f6: cmp DWORD PTR [ebp-0xc],0x2
4a59fa: jne 0x4a5a54
4a59fc: mov eax,DWORD PTR [ebx+0x48]
4a59ff: xor edx,edx
4a5a01: push edx
4a5a02: push eax
4a5a03: lea eax,[ebp-0x238]
4a5a09: call 0x4081c0
4a5a0e: mov eax,DWORD PTR [ebp-0x238]
4a5a14: push eax
4a5a15: push 0x2d
4a5a17: push 0xc
4a5a19: mov ecx,DWORD PTR ds:0x4b0f84
4a5a1f: mov cl,BYTE PTR [ecx]
4a5a21: add cl,0x6e
4a5a24: mov edx,DWORD PTR ds:0x4b0f84
4a5a2a: mov dl,BYTE PTR [edx]
4a5a2c: add dl,0x6e
4a5a2f: mov al,0xff
4a5a31: call 0x406de4
4a5a36: push eax
4a5a37: mov ecx,DWORD PTR ds:0x4b123c
4a5a3d: movsx ecx,WORD PTR [ecx]
4a5a40: add ecx,0xa
4a5a43: imul edx,DWORD PTR [ebp-0x10],0x32
4a5a47: add edx,0xc8
4a5a4d: mov eax,esi
4a5a4f: call 0x48e720
4a5a54: inc DWORD PTR [ebp-0xc]
4a5a57: add ebx,0xb0
4a5a5d: cmp DWORD PTR [ebp-0xc],0x3
4a5a61: jne 0x4a4cbe
4a5a67: mov eax,DWORD PTR [esi+0x2d8]
4a5a6d: call 0x44dee8
4a5a72: mov eax,ds:0x4b1074
4a5a77: cmp BYTE PTR [eax],0x0
4a5a7a: jne 0x4a6123
4a5a80: mov eax,ds:0x4b0e84
4a5a85: cmp BYTE PTR [eax],0x0
4a5a88: jne 0x4a6123
4a5a8e: mov eax,ds:0x4b1004
4a5a93: cmp BYTE PTR [eax],0x0
4a5a96: jne 0x4a6123
4a5a9c: mov eax,ds:0x4b110c
4a5aa1: cmp BYTE PTR [eax],0x0
4a5aa4: jne 0x4a6123
4a5aaa: mov eax,ds:0x4b0ef0
4a5aaf: cmp BYTE PTR [eax+0x9e],0x1
4a5ab6: jne 0x4a5dc8
4a5abc: mov eax,DWORD PTR [esi+0x2d8]
4a5ac2: mov eax,DWORD PTR [eax+0x38]
4a5ac5: test BYTE PTR [eax+0x2038],0x2
4a5acc: setne al
4a5acf: test al,al
4a5ad1: jne 0x4a5b09
4a5ad3: mov eax,DWORD PTR [esi+0x2d8]
4a5ad9: mov eax,DWORD PTR [eax+0x38]
4a5adc: test BYTE PTR [eax+0x2038],0x4
4a5ae3: je 0x4a5aee
4a5ae5: mov dl,0x1
4a5ae7: mov al,0x1
4a5ae9: call 0x4775fc
4a5aee: mov eax,DWORD PTR [esi+0x2d8]
4a5af4: mov eax,DWORD PTR [eax+0x38]
4a5af7: test BYTE PTR [eax+0x2038],0x8
4a5afe: je 0x4a5b09
4a5b00: mov dl,0x2
4a5b02: mov al,0x1
4a5b04: call 0x4775fc
4a5b09: mov eax,DWORD PTR [esi+0x2d8]
4a5b0f: mov eax,DWORD PTR [eax+0x38]
4a5b12: test BYTE PTR [eax+0x2038],0x2
4a5b19: je 0x4a5b24
4a5b1b: mov dl,0x7
4a5b1d: mov al,0x1
4a5b1f: call 0x4775fc
4a5b24: mov eax,DWORD PTR [esi+0x2d8]
4a5b2a: mov eax,DWORD PTR [eax+0x38]
4a5b2d: test BYTE PTR [eax+0x2038],0x2
4a5b34: setne al
4a5b37: test al,al
4a5b39: jne 0x4a5b4f
4a5b3b: mov eax,ds:0x4b0ef0
4a5b40: cmp BYTE PTR [eax+0x6b],0x7
4a5b44: jne 0x4a5b4f
4a5b46: mov eax,ds:0x4b0ef0
4a5b4b: mov BYTE PTR [eax+0x6b],0x1
4a5b4f: mov eax,DWORD PTR [esi+0x2d8]
4a5b55: mov eax,DWORD PTR [eax+0x38]
4a5b58: test BYTE PTR [eax+0x2038],0x1
4a5b5f: je 0x4a5c2b
4a5b65: mov eax,ds:0x4b0ef0
4a5b6a: cmp BYTE PTR [eax+0x6b],0x1
4a5b6e: je 0x4a5b95
4a5b70: mov eax,ds:0x4b0ef0
4a5b75: cmp BYTE PTR [eax+0x6b],0x2
4a5b79: je 0x4a5b95
4a5b7b: mov eax,ds:0x4b0ef0
4a5b80: cmp BYTE PTR [eax+0x6b],0x15
4a5b84: je 0x4a5b95
4a5b86: mov eax,ds:0x4b0ef0
4a5b8b: cmp BYTE PTR [eax+0x6b],0x16
4a5b8f: jne 0x4a5c2b
4a5b95: mov eax,ds:0x4b0ef0
4a5b9a: cmp BYTE PTR [eax+0x78],0x0
4a5b9e: jne 0x4a5c2b
4a5ba4: mov eax,ds:0x4b0ef0
4a5ba9: cmp BYTE PTR [eax+0x6a],0x0
4a5bad: jne 0x4a5c2b
4a5baf: mov eax,ds:0x4b0ef0
4a5bb4: mov BYTE PTR [eax+0x78],0xe0
4a5bb8: mov eax,ds:0x4b0ef0
4a5bbd: mov BYTE PTR [eax+0x6a],0x1
4a5bc1: mov eax,ds:0x4b0ef0
4a5bc6: mov BYTE PTR [eax+0x6b],0xc
4a5bca: mov eax,ds:0x4b0ef0
4a5bcf: mov WORD PTR [eax+0x74],0x0
4a5bd5: mov eax,ds:0x4b0ef0
4a5bda: mov WORD PTR [eax+0x76],0x63
4a5be0: mov eax,ds:0x4b0ef0
4a5be5: mov BYTE PTR [eax+0x93],0x0
4a5bec: mov eax,ds:0x4b0ef0
4a5bf1: mov BYTE PTR [eax+0x6e],0x1
4a5bf5: mov eax,DWORD PTR [esi+0x2d8]
4a5bfb: mov eax,DWORD PTR [eax+0x38]
4a5bfe: test BYTE PTR [eax+0x2038],0x4
4a5c05: je 0x4a5c10
4a5c07: mov eax,ds:0x4b0ef0
4a5c0c: mov BYTE PTR [eax+0x6e],0x2
4a5c10: mov eax,DWORD PTR [esi+0x2d8]
4a5c16: mov eax,DWORD PTR [eax+0x38]
4a5c19: test BYTE PTR [eax+0x2038],0x8
4a5c20: je 0x4a5c2b
4a5c22: mov eax,ds:0x4b0ef0
4a5c27: mov BYTE PTR [eax+0x6e],0x3
4a5c2b: mov eax,DWORD PTR [esi+0x2d8]
4a5c31: mov eax,DWORD PTR [eax+0x38]
4a5c34: test BYTE PTR [eax+0x2038],0x4
4a5c3b: setne al
4a5c3e: test al,al
4a5c40: jne 0x4a5c78
4a5c42: mov eax,DWORD PTR [esi+0x2d8]
4a5c48: mov eax,DWORD PTR [eax+0x38]
4a5c4b: test BYTE PTR [eax+0x2038],0x8
4a5c52: setne al
4a5c55: test al,al
4a5c57: jne 0x4a5c78
4a5c59: mov eax,ds:0x4b0ef0
4a5c5e: cmp BYTE PTR [eax+0x6b],0x2
4a5c62: jne 0x4a5c78
4a5c64: mov eax,ds:0x4b0ef0
4a5c69: mov BYTE PTR [eax+0x6b],0x1
4a5c6d: mov eax,ds:0x4b0ef0
4a5c72: mov WORD PTR [eax+0x74],0x0
4a5c78: mov eax,DWORD PTR [esi+0x2d8]
4a5c7e: mov eax,DWORD PTR [eax+0x38]
4a5c81: test BYTE PTR [eax+0x2038],0x10
4a5c88: je 0x4a5ca3
4a5c8a: mov eax,ds:0x4b0ef0
4a5c8f: cmp BYTE PTR [eax+0xa8],0x0
4a5c96: jne 0x4a5ca3
4a5c98: mov cl,0x1
4a5c9a: mov dl,0x1
4a5c9c: mov eax,esi
4a5c9e: call 0x4951ec
4a5ca3: mov eax,DWORD PTR [esi+0x2d8]
4a5ca9: mov eax,DWORD PTR [eax+0x38]
4a5cac: test BYTE PTR [eax+0x2038],0x20
4a5cb3: je 0x4a5cce
4a5cb5: mov eax,ds:0x4b0ef0
4a5cba: cmp BYTE PTR [eax+0xa9],0x0
4a5cc1: jne 0x4a5cce
4a5cc3: mov cl,0x2
4a5cc5: mov dl,0x1
4a5cc7: mov eax,esi
4a5cc9: call 0x4951ec
4a5cce: mov eax,DWORD PTR [esi+0x2d8]
4a5cd4: mov eax,DWORD PTR [eax+0x38]
4a5cd7: test BYTE PTR [eax+0x2038],0x40
4a5cde: je 0x4a5cf9
4a5ce0: mov eax,ds:0x4b0ef0
4a5ce5: cmp BYTE PTR [eax+0xaa],0x0
4a5cec: jne 0x4a5cf9
4a5cee: mov cl,0x3
4a5cf0: mov dl,0x1
4a5cf2: mov eax,esi
4a5cf4: call 0x4951ec
4a5cf9: mov eax,DWORD PTR [esi+0x2d8]
4a5cff: mov eax,DWORD PTR [eax+0x38]
4a5d02: test BYTE PTR [eax+0x2038],0x80
4a5d09: je 0x4a5d24
4a5d0b: mov eax,ds:0x4b0ef0
4a5d10: cmp BYTE PTR [eax+0xab],0x0
4a5d17: jne 0x4a5d24
4a5d19: mov cl,0x4
4a5d1b: mov dl,0x1
4a5d1d: mov eax,esi
4a5d1f: call 0x4951ec
4a5d24: mov eax,DWORD PTR [esi+0x2d8]
4a5d2a: mov eax,DWORD PTR [eax+0x38]
4a5d2d: test BYTE PTR [eax+0x2038],0x10
4a5d34: je 0x4a5d4d
4a5d36: mov eax,ds:0x4b0ef0
4a5d3b: cmp BYTE PTR [eax+0xa8],0x0
4a5d42: jne 0x4a5d4d
4a5d44: mov dl,0x3
4a5d46: mov al,0x1
4a5d48: call 0x4775fc
4a5d4d: mov eax,DWORD PTR [esi+0x2d8]
4a5d53: mov eax,DWORD PTR [eax+0x38]
4a5d56: test BYTE PTR [eax+0x2038],0x20
4a5d5d: je 0x4a5d76
4a5d5f: mov eax,ds:0x4b0ef0
4a5d64: cmp BYTE PTR [eax+0xa9],0x0
4a5d6b: jne 0x4a5d76
4a5d6d: mov dl,0x4
4a5d6f: mov al,0x1
4a5d71: call 0x4775fc
4a5d76: mov eax,DWORD PTR [esi+0x2d8]
4a5d7c: mov eax,DWORD PTR [eax+0x38]
4a5d7f: test BYTE PTR [eax+0x2038],0x40
4a5d86: je 0x4a5d9f
4a5d88: mov eax,ds:0x4b0ef0
4a5d8d: cmp BYTE PTR [eax+0xaa],0x0
4a5d94: jne 0x4a5d9f
4a5d96: mov dl,0x5
4a5d98: mov al,0x1
4a5d9a: call 0x4775fc
4a5d9f: mov eax,DWORD PTR [esi+0x2d8]
4a5da5: mov eax,DWORD PTR [eax+0x38]
4a5da8: test BYTE PTR [eax+0x2038],0x80
4a5daf: je 0x4a5dc8
4a5db1: mov eax,ds:0x4b0ef0
4a5db6: cmp BYTE PTR [eax+0xab],0x0
4a5dbd: jne 0x4a5dc8
4a5dbf: mov dl,0x6
4a5dc1: mov al,0x1
4a5dc3: call 0x4775fc
4a5dc8: mov eax,ds:0x4b0ef0
4a5dcd: cmp BYTE PTR [eax+0x14e],0x1
4a5dd4: jne 0x4a6123
4a5dda: mov eax,DWORD PTR [esi+0x2d8]
4a5de0: mov eax,DWORD PTR [eax+0x34]
4a5de3: test BYTE PTR [eax+0x2038],0x2
4a5dea: setne al
4a5ded: test al,al
4a5def: jne 0x4a5e27
4a5df1: mov eax,DWORD PTR [esi+0x2d8]
4a5df7: mov eax,DWORD PTR [eax+0x34]
4a5dfa: test BYTE PTR [eax+0x2038],0x4
4a5e01: je 0x4a5e0c
4a5e03: mov dl,0x1
4a5e05: mov al,0x2
4a5e07: call 0x4775fc
4a5e0c: mov eax,DWORD PTR [esi+0x2d8]
4a5e12: mov eax,DWORD PTR [eax+0x34]
4a5e15: test BYTE PTR [eax+0x2038],0x8
4a5e1c: je 0x4a5e27
4a5e1e: mov dl,0x2
4a5e20: mov al,0x2
4a5e22: call 0x4775fc
4a5e27: mov eax,DWORD PTR [esi+0x2d8]
4a5e2d: mov eax,DWORD PTR [eax+0x34]
4a5e30: test BYTE PTR [eax+0x2038],0x2
4a5e37: je 0x4a5e42
4a5e39: mov dl,0x7
4a5e3b: mov al,0x2
4a5e3d: call 0x4775fc
4a5e42: mov eax,DWORD PTR [esi+0x2d8]
4a5e48: mov eax,DWORD PTR [eax+0x34]
4a5e4b: test BYTE PTR [eax+0x2038],0x2
4a5e52: setne al
4a5e55: test al,al
4a5e57: jne 0x4a5e73
4a5e59: mov eax,ds:0x4b0ef0
4a5e5e: cmp BYTE PTR [eax+0x11b],0x7
4a5e65: jne 0x4a5e73
4a5e67: mov eax,ds:0x4b0ef0
4a5e6c: mov BYTE PTR [eax+0x11b],0x1
4a5e73: mov eax,DWORD PTR [esi+0x2d8]
4a5e79: mov eax,DWORD PTR [eax+0x34]
4a5e7c: test BYTE PTR [eax+0x2038],0x1
4a5e83: je 0x4a5f7d
4a5e89: mov eax,ds:0x4b0ef0
4a5e8e: cmp BYTE PTR [eax+0x11b],0x1
4a5e95: je 0x4a5ec5
4a5e97: mov eax,ds:0x4b0ef0
4a5e9c: cmp BYTE PTR [eax+0x11b],0x2
4a5ea3: je 0x4a5ec5
4a5ea5: mov eax,ds:0x4b0ef0
4a5eaa: cmp BYTE PTR [eax+0x11b],0x15
4a5eb1: je 0x4a5ec5
4a5eb3: mov eax,ds:0x4b0ef0
4a5eb8: cmp BYTE PTR [eax+0x11b],0x16
4a5ebf: jne 0x4a5f7d
4a5ec5: mov eax,ds:0x4b0ef0
4a5eca: cmp BYTE PTR [eax+0x128],0x0
4a5ed1: jne 0x4a5f7d
4a5ed7: mov eax,ds:0x4b0ef0
4a5edc: cmp BYTE PTR [eax+0x11a],0x0
4a5ee3: jne 0x4a5f7d
4a5ee9: mov eax,ds:0x4b0ef0
4a5eee: mov BYTE PTR [eax+0x128],0xe0
4a5ef5: mov eax,ds:0x4b0ef0
4a5efa: mov BYTE PTR [eax+0x11a],0x1
4a5f01: mov eax,ds:0x4b0ef0
4a5f06: mov BYTE PTR [eax+0x11b],0xc
4a5f0d: mov eax,ds:0x4b0ef0
4a5f12: mov WORD PTR [eax+0x124],0x0
4a5f1b: mov eax,ds:0x4b0ef0
4a5f20: mov WORD PTR [eax+0x126],0x63
4a5f29: mov eax,ds:0x4b0ef0
4a5f2e: mov BYTE PTR [eax+0x143],0x0
4a5f35: mov eax,ds:0x4b0ef0
4a5f3a: mov BYTE PTR [eax+0x11e],0x1
4a5f41: mov eax,DWORD PTR [esi+0x2d8]
4a5f47: mov eax,DWORD PTR [eax+0x34]
4a5f4a: test BYTE PTR [eax+0x2038],0x4
4a5f51: je 0x4a5f5f
4a5f53: mov eax,ds:0x4b0ef0
4a5f58: mov BYTE PTR [eax+0x11e],0x2
4a5f5f: mov eax,DWORD PTR [esi+0x2d8]
4a5f65: mov eax,DWORD PTR [eax+0x34]
4a5f68: test BYTE PTR [eax+0x2038],0x8
4a5f6f: je 0x4a5f7d
4a5f71: mov eax,ds:0x4b0ef0
4a5f76: mov BYTE PTR [eax+0x11e],0x3
4a5f7d: mov eax,DWORD PTR [esi+0x2d8]
4a5f83: mov eax,DWORD PTR [eax+0x34]
4a5f86: test BYTE PTR [eax+0x2038],0x4
4a5f8d: setne al
4a5f90: test al,al
4a5f92: jne 0x4a5fd3
4a5f94: mov eax,DWORD PTR [esi+0x2d8]
4a5f9a: mov eax,DWORD PTR [eax+0x34]
4a5f9d: test BYTE PTR [eax+0x2038],0x8
4a5fa4: setne al
4a5fa7: test al,al
4a5fa9: jne 0x4a5fd3
4a5fab: mov eax,ds:0x4b0ef0
4a5fb0: cmp BYTE PTR [eax+0x11b],0x2
4a5fb7: jne 0x4a5fd3
4a5fb9: mov eax,ds:0x4b0ef0
4a5fbe: mov BYTE PTR [eax+0x11b],0x1
4a5fc5: mov eax,ds:0x4b0ef0
4a5fca: mov WORD PTR [eax+0x124],0x0
4a5fd3: mov eax,DWORD PTR [esi+0x2d8]
4a5fd9: mov eax,DWORD PTR [eax+0x34]
4a5fdc: test BYTE PTR [eax+0x2038],0x10
4a5fe3: je 0x4a5ffe
4a5fe5: mov eax,ds:0x4b0ef0
4a5fea: cmp BYTE PTR [eax+0x158],0x0
4a5ff1: jne 0x4a5ffe
4a5ff3: mov cl,0x1
4a5ff5: mov dl,0x2
4a5ff7: mov eax,esi
4a5ff9: call 0x4951ec
4a5ffe: mov eax,DWORD PTR [esi+0x2d8]
4a6004: mov eax,DWORD PTR [eax+0x34]
4a6007: test BYTE PTR [eax+0x2038],0x20
4a600e: je 0x4a6029
4a6010: mov eax,ds:0x4b0ef0
4a6015: cmp BYTE PTR [eax+0x159],0x0
4a601c: jne 0x4a6029
4a601e: mov cl,0x2
4a6020: mov dl,0x2
4a6022: mov eax,esi
4a6024: call 0x4951ec
4a6029: mov eax,DWORD PTR [esi+0x2d8]
4a602f: mov eax,DWORD PTR [eax+0x34]
4a6032: test BYTE PTR [eax+0x2038],0x40
4a6039: je 0x4a6054
4a603b: mov eax,ds:0x4b0ef0
4a6040: cmp BYTE PTR [eax+0x15a],0x0
4a6047: jne 0x4a6054
4a6049: mov cl,0x3
4a604b: mov dl,0x2
4a604d: mov eax,esi
4a604f: call 0x4951ec
4a6054: mov eax,DWORD PTR [esi+0x2d8]
4a605a: mov eax,DWORD PTR [eax+0x34]
4a605d: test BYTE PTR [eax+0x2038],0x80
4a6064: je 0x4a607f
4a6066: mov eax,ds:0x4b0ef0
4a606b: cmp BYTE PTR [eax+0x15b],0x0
4a6072: jne 0x4a607f
4a6074: mov cl,0x4
4a6076: mov dl,0x2
4a6078: mov eax,esi
4a607a: call 0x4951ec
4a607f: mov eax,DWORD PTR [esi+0x2d8]
4a6085: mov eax,DWORD PTR [eax+0x34]
4a6088: test BYTE PTR [eax+0x2038],0x10
4a608f: je 0x4a60a8
4a6091: mov eax,ds:0x4b0ef0
4a6096: cmp BYTE PTR [eax+0x158],0x0
4a609d: jne 0x4a60a8
4a609f: mov dl,0x3
4a60a1: mov al,0x2
4a60a3: call 0x4775fc
4a60a8: mov eax,DWORD PTR [esi+0x2d8]
4a60ae: mov eax,DWORD PTR [eax+0x34]
4a60b1: test BYTE PTR [eax+0x2038],0x20
4a60b8: je 0x4a60d1
4a60ba: mov eax,ds:0x4b0ef0
4a60bf: cmp BYTE PTR [eax+0x159],0x0
4a60c6: jne 0x4a60d1
4a60c8: mov dl,0x4
4a60ca: mov al,0x2
4a60cc: call 0x4775fc
4a60d1: mov eax,DWORD PTR [esi+0x2d8]
4a60d7: mov eax,DWORD PTR [eax+0x34]
4a60da: test BYTE PTR [eax+0x2038],0x40
4a60e1: je 0x4a60fa
4a60e3: mov eax,ds:0x4b0ef0
4a60e8: cmp BYTE PTR [eax+0x15a],0x0
4a60ef: jne 0x4a60fa
4a60f1: mov dl,0x5
4a60f3: mov al,0x2
4a60f5: call 0x4775fc
4a60fa: mov eax,DWORD PTR [esi+0x2d8]
4a6100: mov eax,DWORD PTR [eax+0x34]
4a6103: test BYTE PTR [eax+0x2038],0x80
4a610a: je 0x4a6123
4a610c: mov eax,ds:0x4b0ef0
4a6111: cmp BYTE PTR [eax+0x15b],0x0
4a6118: jne 0x4a6123
4a611a: mov dl,0x6
4a611c: mov al,0x2
4a611e: call 0x4775fc
4a6123: mov dl,0x1
4a6125: mov eax,esi
4a6127: call 0x4968b0
4a612c: mov dl,0x2
4a612e: mov eax,esi
4a6130: call 0x4968b0
4a6135: mov eax,ds:0x4b1074
4a613a: cmp BYTE PTR [eax],0x0
4a613d: jne 0x4a618e
4a613f: mov eax,ds:0x4b0e84
4a6144: cmp BYTE PTR [eax],0x0
4a6147: jne 0x4a618e
4a6149: mov eax,ds:0x4b1004
4a614e: cmp BYTE PTR [eax],0x0
4a6151: jne 0x4a618e
4a6153: mov DWORD PTR [ebp-0xc],0x1
4a615a: mov ebx,DWORD PTR ds:0x4b0ef0
4a6160: add ebx,0x9e
4a6166: cmp BYTE PTR [ebx],0x0
4a6169: jne 0x4a617f
4a616b: mov eax,ds:0x4b110c
4a6170: cmp BYTE PTR [eax],0x0
4a6173: jne 0x4a617f
4a6175: mov dl,BYTE PTR [ebp-0xc]
4a6178: mov eax,esi
4a617a: call 0x4931ac
4a617f: inc DWORD PTR [ebp-0xc]
4a6182: add ebx,0xb0
4a6188: cmp DWORD PTR [ebp-0xc],0x3
4a618c: jne 0x4a6166
4a618e: mov eax,ds:0x4b1124
4a6193: cmp BYTE PTR [eax],0x1
4a6196: je 0x4a61b0
4a6198: mov eax,ds:0x4b1124
4a619d: cmp BYTE PTR [eax],0x2
4a61a0: jne 0x4a6228
4a61a6: mov eax,ds:0x4b110c
4a61ab: cmp BYTE PTR [eax],0x0
4a61ae: jne 0x4a6228
4a61b0: mov eax,ds:0x4b0d58
4a61b5: cmp BYTE PTR [eax+0xc],0x0
4a61b9: jne 0x4a6228
4a61bb: mov eax,ds:0x4b11b4
4a61c0: cmp DWORD PTR [eax],0x28
4a61c3: jle 0x4a6228
4a61c5: mov eax,ds:0x4b11b4
4a61ca: cmp DWORD PTR [eax],0xa0
4a61d0: jge 0x4a6228
4a61d2: mov eax,ds:0x4b0d58
4a61d7: movzx eax,WORD PTR [eax+0xa]
4a61db: call 0x402a1c
4a61e0: test eax,eax
4a61e2: jne 0x4a6228
4a61e4: mov eax,ds:0x4b11b4
4a61e9: mov eax,DWORD PTR [eax]
4a61eb: sub eax,0x50
4a61ee: mov edx,DWORD PTR ds:0x4b0d58
4a61f4: mov DWORD PTR [edx],eax
4a61f6: mov eax,ds:0x4b0d58
4a61fb: mov DWORD PTR [eax+0x4],0x92
4a6202: mov eax,ds:0x4b0d58
4a6207: mov BYTE PTR [eax+0x8],0x7
4a620b: mov eax,0x2
4a6210: call 0x402a1c
4a6215: inc eax
4a6216: mov edx,DWORD PTR ds:0x4b0d58
4a621c: mov BYTE PTR [edx+0x9],al
4a621f: mov eax,ds:0x4b0d58
4a6224: mov BYTE PTR [eax+0xc],0x1
4a6228: mov eax,ds:0x4b0d58
4a622d: cmp BYTE PTR [eax+0xc],0x1
4a6231: jne 0x4a644b
4a6237: mov eax,DWORD PTR [esi+0x2d0]
4a623d: mov eax,DWORD PTR [eax+0x270]
4a6243: call 0x45cd9c
4a6248: call 0x45bb18
4a624d: mov eax,ds:0x4b0d58
4a6252: mov eax,DWORD PTR [eax+0x4]
4a6255: add eax,0x84
4a625a: mov edx,DWORD PTR ds:0x4b1144
4a6260: sub eax,DWORD PTR [edx]
4a6262: push eax
4a6263: push 0x0
4a6265: mov eax,DWORD PTR [esi+0x308]
4a626b: mov eax,DWORD PTR [eax+0x28]
4a626e: xor edx,edx
4a6270: call 0x461dcc
4a6275: mov ecx,DWORD PTR ds:0x4b0d58
4a627b: mov ecx,DWORD PTR [ecx]
4a627d: add ecx,0xa
4a6280: mov edx,DWORD PTR ds:0x4b11b4
4a6286: sub ecx,DWORD PTR [edx]
4a6288: mov edx,DWORD PTR [esi+0x2d0]
4a628e: mov edx,DWORD PTR [edx+0x270]
4a6294: call 0x46161c
4a6299: mov eax,ds:0x4b0d58
4a629e: mov eax,DWORD PTR [eax+0x4]
4a62a1: mov edx,DWORD PTR ds:0x4b1144
4a62a7: sub eax,DWORD PTR [edx]
4a62a9: push eax
4a62aa: push 0x0
4a62ac: mov eax,DWORD PTR [esi+0x308]
4a62b2: mov eax,DWORD PTR [eax+0x28]
4a62b5: mov edx,0x9
4a62ba: call 0x461dcc
4a62bf: mov ecx,DWORD PTR ds:0x4b0d58
4a62c5: mov ecx,DWORD PTR [ecx]
4a62c7: mov edx,DWORD PTR ds:0x4b11b4
4a62cd: sub ecx,DWORD PTR [edx]
4a62cf: mov edx,DWORD PTR [esi+0x2d0]
4a62d5: mov edx,DWORD PTR [edx+0x270]
4a62db: call 0x46161c
4a62e0: mov eax,ds:0x4b1074
4a62e5: cmp BYTE PTR [eax],0x0
4a62e8: jne 0x4a6305
4a62ea: mov eax,ds:0x4b0e84
4a62ef: cmp BYTE PTR [eax],0x0
4a62f2: jne 0x4a6305
4a62f4: mov eax,ds:0x4b0d58
4a62f9: movzx eax,BYTE PTR [eax+0x8]
4a62fd: mov edx,DWORD PTR ds:0x4b0d58
4a6303: add DWORD PTR [edx],eax
4a6305: mov eax,ds:0x4b0d58
4a630a: mov eax,DWORD PTR [eax]
4a630c: mov edx,DWORD PTR ds:0x4b11b4
4a6312: mov edx,DWORD PTR [edx]
4a6314: add edx,0x1a4
4a631a: cmp eax,edx
4a631c: jle 0x4a6327
4a631e: mov eax,ds:0x4b0d58
4a6323: mov BYTE PTR [eax+0xc],0x0
4a6327: mov eax,ds:0x4b0d58
4a632c: cmp BYTE PTR [eax+0x9],0x0
4a6330: je 0x4a644b
4a6336: mov eax,ds:0x4b0d58
4a633b: mov eax,DWORD PTR [eax]
4a633d: mov edx,DWORD PTR ds:0x4b11b4
4a6343: mov edx,DWORD PTR [edx]
4a6345: add edx,0x96
4a634b: cmp eax,edx
4a634d: jle 0x4a644b
4a6353: mov eax,ds:0x4b0d58
4a6358: mov eax,DWORD PTR [eax]
4a635a: mov edx,DWORD PTR ds:0x4b11b4
4a6360: mov edx,DWORD PTR [edx]
4a6362: add edx,0xfa
4a6368: cmp eax,edx
4a636a: jge 0x4a644b
4a6370: mov eax,0x5
4a6375: call 0x402a1c
4a637a: test eax,eax
4a637c: jne 0x4a644b
4a6382: mov eax,ds:0x4b1074
4a6387: cmp BYTE PTR [eax],0x0
4a638a: jne 0x4a644b
4a6390: mov eax,ds:0x4b0e84
4a6395: cmp BYTE PTR [eax],0x0
4a6398: jne 0x4a644b
4a639e: mov eax,ds:0x4b110c
4a63a3: cmp BYTE PTR [eax],0x0
4a63a6: jne 0x4a644b
4a63ac: mov eax,ds:0x4b0d58
4a63b1: cmp BYTE PTR [eax+0x9],0x1
4a63b5: jne 0x4a63f7
4a63b7: mov eax,ds:0x4b0d58
4a63bc: mov eax,DWORD PTR [eax]
4a63be: add eax,0xd
4a63c1: mov DWORD PTR [ebp-0x48],eax
4a63c4: fild DWORD PTR [ebp-0x48]
4a63c7: add esp,0xfffffff8
4a63ca: fstp QWORD PTR [esp]
4a63cd: fwait
4a63ce: mov eax,ds:0x4b0d58
4a63d3: mov eax,DWORD PTR [eax+0x4]
4a63d6: sub eax,0x5
4a63d9: mov DWORD PTR [ebp-0x1bc],eax
4a63df: fild DWORD PTR [ebp-0x1bc]
4a63e5: add esp,0xfffffff8
4a63e8: fstp QWORD PTR [esp]
4a63eb: fwait
4a63ec: xor ecx,ecx
4a63ee: xor edx,edx
4a63f0: mov al,0x3
4a63f2: call 0x476a04
4a63f7: mov eax,ds:0x4b0d58
4a63fc: cmp BYTE PTR [eax+0x9],0x2
4a6400: jne 0x4a6442
4a6402: mov eax,ds:0x4b0d58
4a6407: mov eax,DWORD PTR [eax]
4a6409: add eax,0xd
4a640c: mov DWORD PTR [ebp-0x48],eax
4a640f: fild DWORD PTR [ebp-0x48]
4a6412: add esp,0xfffffff8
4a6415: fstp QWORD PTR [esp]
4a6418: fwait
4a6419: mov eax,ds:0x4b0d58
4a641e: mov eax,DWORD PTR [eax+0x4]
4a6421: sub eax,0x5
4a6424: mov DWORD PTR [ebp-0x1bc],eax
4a642a: fild DWORD PTR [ebp-0x1bc]
4a6430: add esp,0xfffffff8
4a6433: fstp QWORD PTR [esp]
4a6436: fwait
4a6437: xor ecx,ecx
4a6439: xor edx,edx
4a643b: mov al,0x4
4a643d: call 0x476a04
4a6442: mov eax,ds:0x4b0d58
4a6447: mov BYTE PTR [eax+0x9],0x0
4a644b: mov eax,ds:0x4b1110
4a6450: cmp BYTE PTR [eax+0x18],0x0
4a6454: je 0x4a64ac
4a6456: mov eax,ds:0x4b1074
4a645b: cmp BYTE PTR [eax],0x0
4a645e: jne 0x4a64ac
4a6460: mov eax,ds:0x4b1110
4a6465: mov eax,DWORD PTR [eax+0x4]
4a6468: mov edx,DWORD PTR ds:0x4b1144
4a646e: sub eax,DWORD PTR [edx]
4a6470: push eax
4a6471: push 0x0
4a6473: mov edx,DWORD PTR ds:0x4b1110
4a6479: movzx edx,BYTE PTR [edx+0x18]
4a647d: mov eax,DWORD PTR [esi+0x314]
4a6483: mov eax,DWORD PTR [eax+0x28]
4a6486: call 0x461dcc
4a648b: mov ecx,DWORD PTR ds:0x4b1110
4a6491: mov ecx,DWORD PTR [ecx]
4a6493: mov edx,DWORD PTR ds:0x4b11b4
4a6499: sub ecx,DWORD PTR [edx]
4a649b: mov edx,DWORD PTR [esi+0x2d0]
4a64a1: mov edx,DWORD PTR [edx+0x270]
4a64a7: call 0x46161c
4a64ac: mov DWORD PTR [ebp-0xc],0x2
4a64b3: mov ebx,DWORD PTR ds:0x4b0ef0
4a64b9: fld QWORD PTR [ebx]
4a64bb: call 0x402894
4a64c0: add eax,DWORD PTR [ebx+0x20]
4a64c3: mov edx,DWORD PTR ds:0x4b0f18
4a64c9: mov DWORD PTR [edx],eax
4a64cb: fld QWORD PTR [ebx+0x8]
4a64ce: call 0x402894
4a64d3: movsx edx,WORD PTR [ebx+0x7a]
4a64d7: sub eax,edx
4a64d9: add eax,DWORD PTR [ebx+0x24]
4a64dc: mov edx,DWORD PTR ds:0x4b0e80
4a64e2: mov DWORD PTR [edx],eax
4a64e4: fld QWORD PTR [ebx]
4a64e6: call 0x402894
4a64eb: add eax,DWORD PTR [ebx+0x28]
4a64ee: mov edx,DWORD PTR ds:0x4b0f50
4a64f4: mov DWORD PTR [edx],eax
4a64f6: fld QWORD PTR [ebx+0x8]
4a64f9: call 0x402894
4a64fe: movsx edx,WORD PTR [ebx+0x7a]
4a6502: sub eax,edx
4a6504: add eax,DWORD PTR [ebx+0x2c]
4a6507: mov edx,DWORD PTR ds:0x4b0ebc
4a650d: mov DWORD PTR [edx],eax
4a650f: cmp BYTE PTR [ebx+0x6b],0x13
4a6513: jne 0x4a6619
4a6519: mov eax,ds:0x4b1110
4a651e: mov eax,DWORD PTR [eax]
4a6520: mov edx,DWORD PTR ds:0x4b1110
4a6526: add eax,DWORD PTR [edx+0x10]
4a6529: mov edx,DWORD PTR ds:0x4b0f18
4a652f: cmp eax,DWORD PTR [edx]
4a6531: jl 0x4a6619
4a6537: mov eax,ds:0x4b1110
4a653c: mov eax,DWORD PTR [eax+0x4]
4a653f: mov edx,DWORD PTR ds:0x4b1110
4a6545: add eax,DWORD PTR [edx+0x14]
4a6548: mov edx,DWORD PTR ds:0x4b0e80
4a654e: cmp eax,DWORD PTR [edx]
4a6550: jl 0x4a6619
4a6556: mov eax,ds:0x4b1110
4a655b: mov eax,DWORD PTR [eax]
4a655d: mov edx,DWORD PTR ds:0x4b1110
4a6563: add eax,DWORD PTR [edx+0x8]
4a6566: mov edx,DWORD PTR ds:0x4b0f50
4a656c: cmp eax,DWORD PTR [edx]
4a656e: jg 0x4a6619
4a6574: mov eax,ds:0x4b1110
4a6579: mov eax,DWORD PTR [eax+0x4]
4a657c: mov edx,DWORD PTR ds:0x4b1110
4a6582: add eax,DWORD PTR [edx+0xc]
4a6585: mov edx,DWORD PTR ds:0x4b0ebc
4a658b: cmp eax,DWORD PTR [edx]
4a658d: jg 0x4a6619
4a6593: mov eax,ds:0x4b1110
4a6598: cmp BYTE PTR [eax+0x18],0x0
4a659c: je 0x4a6619
4a659e: mov eax,ds:0x4b1110
4a65a3: mov BYTE PTR [eax+0x18],0x0
4a65a7: mov eax,ds:0x4b1098
4a65ac: mov BYTE PTR [eax],0x9
4a65af: mov DWORD PTR [ebp-0x10],0x1
4a65b6: mov eax,0x28
4a65bb: call 0x402a1c
4a65c0: mov edx,DWORD PTR ds:0x4b1110
4a65c6: mov edx,DWORD PTR [edx]
4a65c8: add edx,0x14
4a65cb: add eax,edx
4a65cd: mov DWORD PTR [ebp-0x48],eax
4a65d0: fild DWORD PTR [ebp-0x48]
4a65d3: add esp,0xfffffff8
4a65d6: fstp QWORD PTR [esp]
4a65d9: fwait
4a65da: mov eax,0x14
4a65df: call 0x402a1c
4a65e4: mov edx,DWORD PTR ds:0x4b1110
4a65ea: mov edx,DWORD PTR [edx+0x4]
4a65ed: add edx,0x14
4a65f0: add eax,edx
4a65f2: mov DWORD PTR [ebp-0x1bc],eax
4a65f8: fild DWORD PTR [ebp-0x1bc]
4a65fe: add esp,0xfffffff8
4a6601: fstp QWORD PTR [esp]
4a6604: fwait
4a6605: xor ecx,ecx
4a6607: xor edx,edx
4a6609: mov al,0x15
4a660b: call 0x476a04
4a6610: inc DWORD PTR [ebp-0x10]
4a6613: cmp DWORD PTR [ebp-0x10],0x1f
4a6617: jne 0x4a65b6
4a6619: add ebx,0xb0
4a661f: dec DWORD PTR [ebp-0xc]
4a6622: jne 0x4a64b9
4a6628: mov eax,ds:0x4b0ef0
4a662d: cmp BYTE PTR [eax+0x91],0x1
4a6634: jne 0x4a66b1
4a6636: mov eax,ds:0x4b0ef0
4a663b: fld QWORD PTR [eax+0xb8]
4a6641: call 0x402894
4a6646: push eax
4a6647: mov eax,ds:0x4b0ef0
4a664c: mov al,BYTE PTR [eax+0x11b]
4a6652: push eax
4a6653: mov eax,ds:0x4b0ef0
4a6658: mov al,BYTE PTR [eax+0x124]
4a665e: push eax
4a665f: mov eax,ds:0x4b0ef0
4a6664: fld QWORD PTR [eax+0xb0]
4a666a: call 0x402894
4a666f: mov ecx,eax
4a6671: mov dl,0x2
4a6673: mov eax,esi
4a6675: call 0x490bb8
4a667a: mov eax,ds:0x4b0ef0
4a667f: fld QWORD PTR [eax+0x8]
4a6682: call 0x402894
4a6687: push eax
4a6688: mov eax,ds:0x4b0ef0
4a668d: mov al,BYTE PTR [eax+0x6b]
4a6690: push eax
4a6691: mov eax,ds:0x4b0ef0
4a6696: mov al,BYTE PTR [eax+0x74]
4a6699: push eax
4a669a: mov eax,ds:0x4b0ef0
4a669f: fld QWORD PTR [eax]
4a66a1: call 0x402894
4a66a6: mov ecx,eax
4a66a8: mov dl,0x1
4a66aa: mov eax,esi
4a66ac: call 0x490bb8
4a66b1: mov eax,ds:0x4b0ef0
4a66b6: cmp BYTE PTR [eax+0x141],0x1
4a66bd: jne 0x4a673a
4a66bf: mov eax,ds:0x4b0ef0
4a66c4: fld QWORD PTR [eax+0x8]
4a66c7: call 0x402894
4a66cc: push eax
4a66cd: mov eax,ds:0x4b0ef0
4a66d2: mov al,BYTE PTR [eax+0x6b]
4a66d5: push eax
4a66d6: mov eax,ds:0x4b0ef0
4a66db: mov al,BYTE PTR [eax+0x74]
4a66de: push eax
4a66df: mov eax,ds:0x4b0ef0
4a66e4: fld QWORD PTR [eax]
4a66e6: call 0x402894
4a66eb: mov ecx,eax
4a66ed: mov dl,0x1
4a66ef: mov eax,esi
4a66f1: call 0x490bb8
4a66f6: mov eax,ds:0x4b0ef0
4a66fb: fld QWORD PTR [eax+0xb8]
4a6701: call 0x402894
4a6706: push eax
4a6707: mov eax,ds:0x4b0ef0
4a670c: mov al,BYTE PTR [eax+0x11b]
4a6712: push eax
4a6713: mov eax,ds:0x4b0ef0
4a6718: mov al,BYTE PTR [eax+0x124]
4a671e: push eax
4a671f: mov eax,ds:0x4b0ef0
4a6724: fld QWORD PTR [eax+0xb0]
4a672a: call 0x402894
4a672f: mov ecx,eax
4a6731: mov dl,0x2
4a6733: mov eax,esi
4a6735: call 0x490bb8
4a673a: mov eax,ds:0x4b1074
4a673f: cmp BYTE PTR [eax],0x0
4a6742: jne 0x4a6774
4a6744: mov eax,ds:0x4b0e84
4a6749: cmp BYTE PTR [eax],0x0
4a674c: jne 0x4a6774
4a674e: mov eax,ds:0x4b1004
4a6753: cmp BYTE PTR [eax],0x0
4a6756: jne 0x4a6774
4a6758: mov eax,ds:0x4b110c
4a675d: cmp BYTE PTR [eax],0x0
4a6760: jne 0x4a6774
4a6762: mov dl,0x1
4a6764: mov eax,esi
4a6766: call 0x494bd8
4a676b: mov dl,0x2
4a676d: mov eax,esi
4a676f: call 0x494bd8
4a6774: mov eax,esi
4a6776: call 0x48edfc
4a677b: mov DWORD PTR [ebp-0xc],0x1
4a6782: mov ebx,DWORD PTR ds:0x4b0ef0
4a6788: add ebx,0x90
4a678e: cmp DWORD PTR [ebp-0xc],0x1
4a6792: jne 0x4a679b
4a6794: mov DWORD PTR [ebp-0x10],0xffffffff
4a679b: cmp DWORD PTR [ebp-0xc],0x2
4a679f: jne 0x4a67a8
4a67a1: mov DWORD PTR [ebp-0x10],0x1
4a67a8: cmp BYTE PTR [ebx],0x0
4a67ab: jbe 0x4a6856
4a67b1: lea ecx,[ebp-0x23c]
4a67b7: xor edx,edx
4a67b9: mov dl,BYTE PTR [ebx-0x1]
4a67bc: mov eax,DWORD PTR [esi+0x2f4]
4a67c2: mov eax,DWORD PTR [eax+0x208]
4a67c8: mov edi,DWORD PTR [eax]
4a67ca: call DWORD PTR [edi+0xc]
4a67cd: mov eax,DWORD PTR [ebp-0x23c]
4a67d3: push eax
4a67d4: push 0x63
4a67d6: push 0xf
4a67d8: mov cl,0x8c
4a67da: mov dl,0xff
4a67dc: mov al,0x50
4a67de: call 0x406de4
4a67e3: push eax
4a67e4: imul edx,DWORD PTR [ebp-0x10],0x64
4a67e8: add edx,0xc8
4a67ee: mov ecx,0x50
4a67f3: mov eax,esi
4a67f5: call 0x48e720
4a67fa: cmp BYTE PTR [ebx-0x1],0x1
4a67fe: jne 0x4a6854
4a6800: cmp BYTE PTR [ebx+0xe],0x1
4a6804: jne 0x4a6854
4a6806: lea ecx,[ebp-0x240]
4a680c: mov eax,DWORD PTR [esi+0x2f4]
4a6812: mov eax,DWORD PTR [eax+0x208]
4a6818: mov edx,0x2
4a681d: mov edi,DWORD PTR [eax]
4a681f: call DWORD PTR [edi+0xc]
4a6822: mov eax,DWORD PTR [ebp-0x240]
4a6828: push eax
4a6829: push 0x63
4a682b: push 0xa
4a682d: mov cl,0xff
4a682f: mov dl,0xff
4a6831: mov al,0xff
4a6833: call 0x406de4
4a6838: push eax
4a6839: mov edx,DWORD PTR [ebp-0x10]
4a683c: shl edx,0x4
4a683f: lea edx,[edx+edx*4]
4a6842: add edx,0xc8
4a6848: mov ecx,0x6e
4a684d: mov eax,esi
4a684f: call 0x48e720
4a6854: dec BYTE PTR [ebx]
4a6856: cmp BYTE PTR [ebx+0x6],0x0
4a685a: jbe 0x4a697b
4a6860: mov al,BYTE PTR [ebx+0x5]
4a6863: cmp al,BYTE PTR [ebx+0x7]
4a6866: jbe 0x4a686e
4a6868: mov al,BYTE PTR [ebx+0x5]
4a686b: mov BYTE PTR [ebx+0x7],al
4a686e: cmp BYTE PTR [ebx+0x5],0x1
4a6872: jbe 0x4a695a
4a6878: cmp BYTE PTR [ebx+0x6],0xf
4a687c: jbe 0x4a68ce
4a687e: lea edx,[ebp-0x244]
4a6884: xor eax,eax
4a6886: mov al,BYTE PTR [ebx+0x5]
4a6889: call 0x408190
4a688e: mov eax,DWORD PTR [ebp-0x244]
4a6894: push eax
4a6895: push 0x63
4a6897: push 0x19
4a6899: mov cl,0xff
4a689b: mov dl,0xff
4a689d: mov al,0xff
4a689f: call 0x406de4
4a68a4: push eax
4a68a5: mov eax,0xa
4a68aa: call 0x402a1c
4a68af: mov edx,eax
4a68b1: add edx,0xc3
4a68b7: imul eax,DWORD PTR [ebp-0x10],0xaa
4a68be: add edx,eax
4a68c0: mov ecx,0x6e
4a68c5: mov eax,esi
4a68c7: call 0x48e720
4a68cc: jmp 0x4a690e
4a68ce: lea edx,[ebp-0x248]
4a68d4: xor eax,eax
4a68d6: mov al,BYTE PTR [ebx+0x5]
4a68d9: call 0x408190
4a68de: mov eax,DWORD PTR [ebp-0x248]
4a68e4: push eax
4a68e5: push 0x63
4a68e7: push 0x19
4a68e9: mov cl,0xff
4a68eb: mov dl,0xff
4a68ed: mov al,0xff
4a68ef: call 0x406de4
4a68f4: push eax
4a68f5: imul edx,DWORD PTR [ebp-0x10],0xaa
4a68fc: add edx,0xc8
4a6902: mov ecx,0x6e
4a6907: mov eax,esi
4a6909: call 0x48e720
4a690e: lea ecx,[ebp-0x24c]
4a6914: mov eax,DWORD PTR [esi+0x2f4]
4a691a: mov eax,DWORD PTR [eax+0x208]
4a6920: mov edx,0x3
4a6925: mov edi,DWORD PTR [eax]
4a6927: call DWORD PTR [edi+0xc]
4a692a: mov eax,DWORD PTR [ebp-0x24c]
4a6930: push eax
4a6931: push 0x63
4a6933: push 0xc
4a6935: mov cl,0x8c
4a6937: mov dl,0xff
4a6939: mov al,0x50
4a693b: call 0x406de4
4a6940: push eax
4a6941: imul edx,DWORD PTR [ebp-0x10],0x96
4a6948: add edx,0xc8
4a694e: mov ecx,0x91
4a6953: mov eax,esi
4a6955: call 0x48e720
4a695a: mov eax,ds:0x4b1074
4a695f: cmp BYTE PTR [eax],0x0
4a6962: jne 0x4a6971
4a6964: mov eax,ds:0x4b0e84
4a6969: cmp BYTE PTR [eax],0x0
4a696c: jne 0x4a6971
4a696e: dec BYTE PTR [ebx+0x6]
4a6971: cmp BYTE PTR [ebx+0x6],0x0
4a6975: jne 0x4a697b
4a6977: mov BYTE PTR [ebx+0x5],0x0
4a697b: cmp WORD PTR [ebx-0x38],0x0
4a6980: jge 0x4a6988
4a6982: mov WORD PTR [ebx-0x38],0x0
4a6988: imul eax,DWORD PTR [ebp-0x10],0x16
4a698c: add eax,0xc8
4a6991: push eax
4a6992: mov eax,ds:0x4b0fb8
4a6997: movsx eax,WORD PTR [eax]
4a699a: add eax,0x120
4a699f: push eax
4a69a0: push 0x6
4a69a2: mov cl,0xff
4a69a4: mov dl,0xff
4a69a6: mov al,0xff
4a69a8: call 0x406de4
4a69ad: push eax
4a69ae: mov cl,0x1e
4a69b0: mov dl,0x14
4a69b2: mov al,0xa
4a69b4: call 0x406de4
4a69b9: push eax
4a69ba: mov ecx,DWORD PTR ds:0x4b0fb8
4a69c0: movsx ecx,WORD PTR [ecx]
4a69c3: add ecx,0x118
4a69c9: mov edx,DWORD PTR [ebp-0x10]
4a69cc: mov eax,edx
4a69ce: shl edx,0x6
4a69d1: add edx,eax
4a69d3: add edx,0xc8
4a69d9: mov eax,esi
4a69db: call 0x48e570
4a69e0: mov eax,ds:0x4b0f84
4a69e5: xor edx,edx
4a69e7: mov DWORD PTR [eax],edx
4a69e9: mov eax,ds:0x4b1094
4a69ee: movzx eax,BYTE PTR [eax]
4a69f1: mov DWORD PTR [ebp-0x48],eax
4a69f4: fild DWORD PTR [ebp-0x48]
4a69f7: fdiv DWORD PTR ds:0x4aec88
4a69fd: call 0x40287c
4a6a02: mov eax,ds:0x4b1094
4a6a07: movzx eax,BYTE PTR [eax]
4a6a0a: mov DWORD PTR [ebp-0x1bc],eax
4a6a10: fild DWORD PTR [ebp-0x1bc]
4a6a16: fdiv DWORD PTR ds:0x4aec88
4a6a1c: fcompp
4a6a1e: fnstsw ax
4a6a20: sahf
4a6a21: jne 0x4a6a35
4a6a23: cmp WORD PTR [ebx-0x38],0x0
4a6a28: jle 0x4a6a35
4a6a2a: mov eax,ds:0x4b0f84
4a6a2f: mov DWORD PTR [eax],0x64
4a6a35: movsx edi,WORD PTR [ebx-0x38]
4a6a39: test edi,edi
4a6a3b: jle 0x4a6acd
4a6a41: mov DWORD PTR [ebp-0x14],0x1
4a6a48: mov eax,DWORD PTR [ebp-0x14]
4a6a4b: dec eax
4a6a4c: add eax,eax
4a6a4e: lea eax,[eax+eax*4]
4a6a51: add eax,0x23
4a6a54: imul DWORD PTR [ebp-0x10]
4a6a57: add eax,0xc8
4a6a5c: push eax
4a6a5d: mov eax,ds:0x4b0fb8
4a6a62: movsx eax,WORD PTR [eax]
4a6a65: add eax,0x119
4a6a6a: push eax
4a6a6b: mov cl,0x14
4a6a6d: mov dl,0x14
4a6a6f: mov al,0xff
4a6a71: call 0x406de4
4a6a76: push eax
4a6a77: mov ecx,DWORD PTR ds:0x4b0f84
4a6a7d: mov cl,BYTE PTR [ecx]
4a6a7f: add cl,0x96
4a6a82: mov edx,DWORD PTR ds:0x4b0f84
4a6a88: mov dl,BYTE PTR [edx]
4a6a8a: add dl,0x96
4a6a8d: mov al,0xff
4a6a8f: call 0x406de4
4a6a94: push eax
4a6a95: mov ecx,DWORD PTR ds:0x4b0fb8
4a6a9b: movsx ecx,WORD PTR [ecx]
4a6a9e: add ecx,0x11e
4a6aa4: mov eax,DWORD PTR [ebp-0x14]
4a6aa7: dec eax
4a6aa8: mov edx,eax
4a6aaa: add edx,edx
4a6aac: lea edx,[edx+edx*4]
4a6aaf: add edx,0x1e
4a6ab2: imul edx,DWORD PTR [ebp-0x10]
4a6ab6: add edx,0xc8
4a6abc: mov eax,esi
4a6abe: call 0x48e69c
4a6ac3: inc DWORD PTR [ebp-0x14]
4a6ac6: dec edi
4a6ac7: jne 0x4a6a48
4a6acd: mov eax,ds:0x4b0f84
4a6ad2: xor edx,edx
4a6ad4: mov DWORD PTR [eax],edx
4a6ad6: mov eax,ds:0x4b1094
4a6adb: movzx eax,BYTE PTR [eax]
4a6ade: mov DWORD PTR [ebp-0x48],eax
4a6ae1: fild DWORD PTR [ebp-0x48]
4a6ae4: fdiv DWORD PTR ds:0x4aec88
4a6aea: call 0x40287c
4a6aef: mov eax,ds:0x4b1094
4a6af4: movzx eax,BYTE PTR [eax]
4a6af7: mov DWORD PTR [ebp-0x1bc],eax
4a6afd: fild DWORD PTR [ebp-0x1bc]
4a6b03: fdiv DWORD PTR ds:0x4aec88
4a6b09: fcompp
4a6b0b: fnstsw ax
4a6b0d: sahf
4a6b0e: jne 0x4a6b22
4a6b10: cmp WORD PTR [ebx-0x38],0x0
4a6b15: jle 0x4a6b22
4a6b17: mov eax,ds:0x4b0f84
4a6b1c: mov DWORD PTR [eax],0x32
4a6b22: lea edx,[ebp-0x250]
4a6b28: movsx eax,WORD PTR [ebx-0x38]
4a6b2c: call 0x408190
4a6b31: mov eax,DWORD PTR [ebp-0x250]
4a6b37: push eax
4a6b38: push 0x63
4a6b3a: push 0xc
4a6b3c: mov eax,ds:0x4b0f84
4a6b41: mov dl,0xff
4a6b43: sub dl,BYTE PTR [eax]
4a6b45: mov eax,ds:0x4b0f84
4a6b4a: push DWORD PTR [eax]
4a6b4c: mov al,0xff
4a6b4e: pop ecx
4a6b4f: sub al,cl
4a6b51: mov cl,0xff
4a6b53: call 0x406de4
4a6b58: push eax
4a6b59: mov ecx,DWORD PTR ds:0x4b0fb8
4a6b5f: movsx ecx,WORD PTR [ecx]
4a6b62: add ecx,0x10e
4a6b68: mov edx,DWORD PTR [ebp-0x10]
4a6b6b: add edx,edx
4a6b6d: lea edx,[edx+edx*8]
4a6b70: add edx,0xc8
4a6b76: mov eax,esi
4a6b78: call 0x48e720
4a6b7d: mov eax,ds:0x4b10b4
4a6b82: cmp BYTE PTR [eax],0x2
4a6b85: je 0x4a6b91
4a6b87: mov eax,ds:0x4b10b4
4a6b8c: cmp BYTE PTR [eax],0x4
4a6b8f: jne 0x4a6b9c
4a6b91: mov eax,ds:0x4b0ef0
4a6b96: mov WORD PTR [eax+0x58],0x3
4a6b9c: mov eax,ds:0x4b10b4
4a6ba1: cmp BYTE PTR [eax],0x3
4a6ba4: je 0x4a6bb0
4a6ba6: mov eax,ds:0x4b10b4
4a6bab: cmp BYTE PTR [eax],0x4
4a6bae: jne 0x4a6bbe
4a6bb0: mov eax,ds:0x4b0ef0
4a6bb5: mov WORD PTR [eax+0x108],0x3
4a6bbe: fld QWORD PTR [ebx-0x30]
4a6bc1: fcomp DWORD PTR ds:0x4aef80
4a6bc7: fnstsw ax
4a6bc9: sahf
4a6bca: jb 0x4a6be7
4a6bcc: cmp WORD PTR [ebx-0x38],0x3
4a6bd1: jge 0x4a6be7
4a6bd3: xor eax,eax
4a6bd5: mov DWORD PTR [ebx-0x30],eax
4a6bd8: mov DWORD PTR [ebx-0x2c],eax
4a6bdb: inc WORD PTR [ebx-0x38]
4a6bdf: mov eax,ds:0x4b1098
4a6be4: mov BYTE PTR [eax],0xd
4a6be7: cmp WORD PTR [ebx-0x38],0x3
4a6bec: jl 0x4a6c00
4a6bee: xor eax,eax
4a6bf0: mov DWORD PTR [ebx-0x30],eax
4a6bf3: mov DWORD PTR [ebx-0x2c],0x40598000
4a6bfa: mov WORD PTR [ebx-0x38],0x3
4a6c00: imul eax,DWORD PTR [ebp-0x10],0x3c
4a6c04: add eax,0xc8
4a6c09: push eax
4a6c0a: mov eax,ds:0x4b0fb8
4a6c0f: movsx eax,WORD PTR [eax]
4a6c12: add eax,0x11d
4a6c17: push eax
4a6c18: push 0x5
4a6c1a: mov cl,0xff
4a6c1c: mov dl,0xff
4a6c1e: mov al,0xff
4a6c20: call 0x406de4
4a6c25: push eax
4a6c26: mov cl,0xff
4a6c28: mov dl,0xff
4a6c2a: mov al,0xff
4a6c2c: call 0x406de4
4a6c31: push eax
4a6c32: mov ecx,DWORD PTR ds:0x4b0fb8
4a6c38: movsx ecx,WORD PTR [ecx]
4a6c3b: add ecx,0x113
4a6c41: imul edx,DWORD PTR [ebp-0x10],0xaa
4a6c48: add edx,0xc8
4a6c4e: mov eax,esi
4a6c50: call 0x48e570
4a6c55: imul eax,DWORD PTR [ebp-0x10],0x3d
4a6c59: add eax,0xc8
4a6c5e: push eax
4a6c5f: mov eax,ds:0x4b0fb8
4a6c64: movsx eax,WORD PTR [eax]
4a6c67: add eax,0x11c
4a6c6c: push eax
4a6c6d: push 0x5
4a6c6f: mov cl,0xaa
4a6c71: mov dl,0xaa
4a6c73: mov al,0xaa
4a6c75: call 0x406de4
4a6c7a: push eax
4a6c7b: mov cl,0xaa
4a6c7d: mov dl,0xaa
4a6c7f: mov al,0xaa
4a6c81: call 0x406de4
4a6c86: push eax
4a6c87: mov ecx,DWORD PTR ds:0x4b0fb8
4a6c8d: movsx ecx,WORD PTR [ecx]
4a6c90: add ecx,0x114
4a6c96: imul edx,DWORD PTR [ebp-0x10],0xa9
4a6c9d: add edx,0xc8
4a6ca3: mov eax,esi
4a6ca5: call 0x48e570
4a6caa: imul eax,DWORD PTR [ebp-0x10],0x3e
4a6cae: add eax,0xc8
4a6cb3: push eax
4a6cb4: mov eax,ds:0x4b0fb8
4a6cb9: movsx eax,WORD PTR [eax]
4a6cbc: add eax,0x11b
4a6cc1: push eax
4a6cc2: push 0x5
4a6cc4: xor ecx,ecx
4a6cc6: xor edx,edx
4a6cc8: xor eax,eax
4a6cca: call 0x406de4
4a6ccf: push eax
4a6cd0: xor ecx,ecx
4a6cd2: mov dl,0x1e
4a6cd4: mov al,0x3c
4a6cd6: call 0x406de4
4a6cdb: push eax
4a6cdc: mov ecx,DWORD PTR ds:0x4b0fb8
4a6ce2: movsx ecx,WORD PTR [ecx]
4a6ce5: add ecx,0x115
4a6ceb: imul edx,DWORD PTR [ebp-0x10],0xa8
4a6cf2: add edx,0xc8
4a6cf8: mov eax,esi
4a6cfa: call 0x48e570
4a6cff: fld QWORD PTR [ebx-0x30]
4a6d02: fcomp DWORD PTR ds:0x4aef80
4a6d08: fnstsw ax
4a6d0a: sahf
4a6d0b: jae 0x4a6dbf
4a6d11: mov eax,DWORD PTR [ebp-0x10]
4a6d14: shl eax,0x6
4a6d17: add eax,0xc8
4a6d1c: push eax
4a6d1d: mov eax,ds:0x4b0fb8
4a6d22: movsx eax,WORD PTR [eax]
4a6d25: add eax,0x11a
4a6d2a: push eax
4a6d2b: mov cl,0x1e
4a6d2d: mov dl,0xa0
4a6d2f: mov al,0xd2
4a6d31: call 0x406de4
4a6d36: push eax
4a6d37: fld DWORD PTR ds:0x4aef84
4a6d3d: fadd QWORD PTR [ebx-0x30]
4a6d40: fild DWORD PTR [ebp-0x10]
4a6d43: fmulp st(1),st
4a6d45: call 0x402894
4a6d4a: mov edx,eax
4a6d4c: add edx,0xc8
4a6d52: mov ecx,DWORD PTR ds:0x4b0fb8
4a6d58: movsx ecx,WORD PTR [ecx]
4a6d5b: add ecx,0x116
4a6d61: mov eax,esi
4a6d63: call 0x48e444
4a6d68: mov eax,DWORD PTR [ebp-0x10]
4a6d6b: shl eax,0x6
4a6d6e: add eax,0xc8
4a6d73: push eax
4a6d74: mov eax,ds:0x4b0fb8
4a6d79: movsx eax,WORD PTR [eax]
4a6d7c: add eax,0x119
4a6d81: push eax
4a6d82: mov cl,0x8c
4a6d84: mov dl,0xdc
4a6d86: mov al,0xfa
4a6d88: call 0x406de4
4a6d8d: push eax
4a6d8e: fld DWORD PTR ds:0x4aef84
4a6d94: fadd QWORD PTR [ebx-0x30]
4a6d97: fild DWORD PTR [ebp-0x10]
4a6d9a: fmulp st(1),st
4a6d9c: call 0x402894
4a6da1: mov edx,eax
4a6da3: add edx,0xc8
4a6da9: mov ecx,DWORD PTR ds:0x4b0fb8
4a6daf: movsx ecx,WORD PTR [ecx]
4a6db2: add ecx,0x117
4a6db8: mov eax,esi
4a6dba: call 0x48e444
4a6dbf: fld QWORD PTR [ebx-0x30]
4a6dc2: fcomp DWORD PTR ds:0x4aef80
4a6dc8: fnstsw ax
4a6dca: sahf
4a6dcb: jne 0x4a6ff2
4a6dd1: mov eax,ds:0x4b0f84
4a6dd6: xor edx,edx
4a6dd8: mov DWORD PTR [eax],edx
4a6dda: mov eax,ds:0x4b1094
4a6ddf: movzx eax,BYTE PTR [eax]
4a6de2: mov DWORD PTR [ebp-0x48],eax
4a6de5: fild DWORD PTR [ebp-0x48]
4a6de8: fdiv DWORD PTR ds:0x4aec88
4a6dee: call 0x40287c
4a6df3: mov eax,ds:0x4b1094
4a6df8: movzx eax,BYTE PTR [eax]
4a6dfb: mov DWORD PTR [ebp-0x1bc],eax
4a6e01: fild DWORD PTR [ebp-0x1bc]
4a6e07: fdiv DWORD PTR ds:0x4aec88
4a6e0d: fcompp
4a6e0f: fnstsw ax
4a6e11: sahf
4a6e12: jne 0x4a6e1f
4a6e14: mov eax,ds:0x4b0f84
4a6e19: mov DWORD PTR [eax],0x32
4a6e1f: mov eax,DWORD PTR [ebp-0x10]
4a6e22: shl eax,0x6
4a6e25: add eax,0xc8
4a6e2a: push eax
4a6e2b: mov eax,ds:0x4b0fb8
4a6e30: movsx eax,WORD PTR [eax]
4a6e33: add eax,0x11a
4a6e38: push eax
4a6e39: mov ecx,DWORD PTR ds:0x4b0f84
4a6e3f: mov cl,BYTE PTR [ecx]
4a6e41: add cl,0x3c
4a6e44: mov edx,DWORD PTR ds:0x4b0f84
4a6e4a: mov dl,BYTE PTR [edx]
4a6e4c: add dl,0xbe
4a6e4f: mov al,0xf0
4a6e51: call 0x406de4
4a6e56: push eax
4a6e57: fld DWORD PTR ds:0x4aef84
4a6e5d: fadd QWORD PTR [ebx-0x30]
4a6e60: fild DWORD PTR [ebp-0x10]
4a6e63: fmulp st(1),st
4a6e65: call 0x402894
4a6e6a: mov edx,eax
4a6e6c: add edx,0xc8
4a6e72: mov ecx,DWORD PTR ds:0x4b0fb8
4a6e78: movsx ecx,WORD PTR [ecx]
4a6e7b: add ecx,0x116
4a6e81: mov eax,esi
4a6e83: call 0x48e444
4a6e88: mov eax,DWORD PTR [ebp-0x10]
4a6e8b: shl eax,0x6
4a6e8e: add eax,0xc8
4a6e93: push eax
4a6e94: mov eax,ds:0x4b0fb8
4a6e99: movsx eax,WORD PTR [eax]
4a6e9c: add eax,0x119
4a6ea1: push eax
4a6ea2: mov ecx,DWORD PTR ds:0x4b0f84
4a6ea8: mov cl,BYTE PTR [ecx]
4a6eaa: add cl,0xaa
4a6ead: mov dl,0xfa
4a6eaf: mov al,0xff
4a6eb1: call 0x406de4
4a6eb6: push eax
4a6eb7: fld DWORD PTR ds:0x4aef84
4a6ebd: fadd QWORD PTR [ebx-0x30]
4a6ec0: fild DWORD PTR [ebp-0x10]
4a6ec3: fmulp st(1),st
4a6ec5: call 0x402894
4a6eca: mov edx,eax
4a6ecc: add edx,0xc8
4a6ed2: mov ecx,DWORD PTR ds:0x4b0fb8
4a6ed8: movsx ecx,WORD PTR [ecx]
4a6edb: add ecx,0x117
4a6ee1: mov eax,esi
4a6ee3: call 0x48e444
4a6ee8: mov eax,ds:0x4b1094
4a6eed: movzx eax,BYTE PTR [eax]
4a6ef0: mov DWORD PTR [ebp-0x48],eax
4a6ef3: fild DWORD PTR [ebp-0x48]
4a6ef6: fdiv DWORD PTR ds:0x4aec88
4a6efc: call 0x40287c
4a6f01: mov eax,ds:0x4b1094
4a6f06: movzx eax,BYTE PTR [eax]
4a6f09: mov DWORD PTR [ebp-0x1bc],eax
4a6f0f: fild DWORD PTR [ebp-0x1bc]
4a6f15: fdiv DWORD PTR ds:0x4aec88
4a6f1b: fcompp
4a6f1d: fnstsw ax
4a6f1f: sahf
4a6f20: jne 0x4a6f8b
4a6f22: lea ecx,[ebp-0x254]
4a6f28: mov eax,DWORD PTR [esi+0x2f4]
4a6f2e: mov eax,DWORD PTR [eax+0x208]
4a6f34: mov edx,0x4
4a6f39: mov edi,DWORD PTR [eax]
4a6f3b: call DWORD PTR [edi+0xc]
4a6f3e: mov eax,DWORD PTR [ebp-0x254]
4a6f44: push eax
4a6f45: push 0x63
4a6f47: push 0xf
4a6f49: mov dl,BYTE PTR [ebp-0x14]
4a6f4c: add dl,0x8c
4a6f4f: mov al,BYTE PTR [ebp-0x14]
4a6f52: add al,0x8c
4a6f54: mov cl,0xff
4a6f56: call 0x406de4
4a6f5b: push eax
4a6f5c: imul eax,DWORD PTR [ebp-0x10],0x73
4a6f60: mov DWORD PTR [ebp-0x48],eax
4a6f63: fild DWORD PTR [ebp-0x48]
4a6f66: call 0x402894
4a6f6b: mov edx,eax
4a6f6d: add edx,0xc8
4a6f73: mov ecx,DWORD PTR ds:0x4b0fb8
4a6f79: movsx ecx,WORD PTR [ecx]
4a6f7c: add ecx,0x106
4a6f82: mov eax,esi
4a6f84: call 0x48e720
4a6f89: jmp 0x4a6ff2
4a6f8b: lea ecx,[ebp-0x258]
4a6f91: mov eax,DWORD PTR [esi+0x2f4]
4a6f97: mov eax,DWORD PTR [eax+0x208]
4a6f9d: mov edx,0x4
4a6fa2: mov edi,DWORD PTR [eax]
4a6fa4: call DWORD PTR [edi+0xc]
4a6fa7: mov eax,DWORD PTR [ebp-0x258]
4a6fad: push eax
4a6fae: push 0x63
4a6fb0: push 0xf
4a6fb2: mov dl,BYTE PTR [ebp-0x14]
4a6fb5: add dl,0xaa
4a6fb8: mov al,BYTE PTR [ebp-0x14]
4a6fbb: add al,0xaa
4a6fbd: mov cl,0xff
4a6fbf: call 0x406de4
4a6fc4: push eax
4a6fc5: imul eax,DWORD PTR [ebp-0x10],0x73
4a6fc9: mov DWORD PTR [ebp-0x48],eax
4a6fcc: fild DWORD PTR [ebp-0x48]
4a6fcf: call 0x402894
4a6fd4: mov edx,eax
4a6fd6: add edx,0xc8
4a6fdc: mov ecx,DWORD PTR ds:0x4b0fb8
4a6fe2: movsx ecx,WORD PTR [ecx]
4a6fe5: add ecx,0x106
4a6feb: mov eax,esi
4a6fed: call 0x48e720
4a6ff2: inc DWORD PTR [ebp-0xc]
4a6ff5: add ebx,0xb0
4a6ffb: cmp DWORD PTR [ebp-0xc],0x3
4a6fff: jne 0x4a678e
4a7005: mov eax,ds:0x4b0eec
4a700a: cmp BYTE PTR [eax],0x0
4a700d: jne 0x4a71d0
4a7013: mov eax,ds:0x4b0fd4
4a7018: cmp BYTE PTR [eax],0x1e
4a701b: jae 0x4a702d
4a701d: mov eax,ds:0x4b0fd4
4a7022: mov BYTE PTR [eax],0x1e
4a7025: mov eax,ds:0x4b1098
4a702a: mov BYTE PTR [eax],0x4
4a702d: xor eax,eax
4a702f: mov DWORD PTR [ebp-0x10],eax
4a7032: mov eax,ds:0x4b1094
4a7037: movzx eax,BYTE PTR [eax]
4a703a: mov DWORD PTR [ebp-0x48],eax
4a703d: fild DWORD PTR [ebp-0x48]
4a7040: fdiv DWORD PTR ds:0x4aec88
4a7046: call 0x40287c
4a704b: mov eax,ds:0x4b1094
4a7050: movzx eax,BYTE PTR [eax]
4a7053: mov DWORD PTR [ebp-0x1bc],eax
4a7059: fild DWORD PTR [ebp-0x1bc]
4a705f: fdiv DWORD PTR ds:0x4aec88
4a7065: fcompp
4a7067: fnstsw ax
4a7069: sahf
4a706a: jne 0x4a7073
4a706c: mov DWORD PTR [ebp-0x10],0x50
4a7073: mov eax,ds:0x4b0fd4
4a7078: cmp BYTE PTR [eax],0x50
4a707b: jae 0x4a70c3
4a707d: lea ecx,[ebp-0x25c]
4a7083: mov eax,DWORD PTR [esi+0x2f4]
4a7089: mov eax,DWORD PTR [eax+0x208]
4a708f: mov edx,0x1b
4a7094: mov ebx,DWORD PTR [eax]
4a7096: call DWORD PTR [ebx+0xc]
4a7099: mov eax,DWORD PTR [ebp-0x25c]
4a709f: push eax
4a70a0: push 0x63
4a70a2: push 0x1c
4a70a4: mov cl,BYTE PTR [ebp-0x10]
4a70a7: mov dl,BYTE PTR [ebp-0x10]
4a70aa: mov al,0xff
4a70ac: call 0x406de4
4a70b1: push eax
4a70b2: mov ecx,0x28
4a70b7: mov edx,0xc8
4a70bc: mov eax,esi
4a70be: call 0x48e720
4a70c3: mov eax,ds:0x4b123c
4a70c8: cmp WORD PTR [eax],0xff88
4a70cc: jle 0x4a70d7
4a70ce: mov eax,ds:0x4b123c
4a70d3: sub WORD PTR [eax],0xa
4a70d7: mov eax,ds:0x4b0fb8
4a70dc: cmp WORD PTR [eax],0x1ea
4a70e1: jge 0x4a70ec
4a70e3: mov eax,ds:0x4b0fb8
4a70e8: add WORD PTR [eax],0xa
4a70ec: mov eax,ds:0x4b110c
4a70f1: mov BYTE PTR [eax],0x1
4a70f4: mov eax,ds:0x4b0ef0
4a70f9: fld QWORD PTR [eax+0x40]
4a70fc: mov eax,ds:0x4b0ef0
4a7101: fcomp QWORD PTR [eax+0xf0]
4a7107: fnstsw ax
4a7109: sahf
4a710a: jae 0x4a7119
4a710c: mov eax,ds:0x4b0ef0
4a7111: xor edx,edx
4a7113: mov DWORD PTR [eax+0x40],edx
4a7116: mov DWORD PTR [eax+0x44],edx
4a7119: mov eax,ds:0x4b0ef0
4a711e: fld QWORD PTR [eax+0xf0]
4a7124: mov eax,ds:0x4b0ef0
4a7129: fcomp QWORD PTR [eax+0x40]
4a712c: fnstsw ax
4a712e: sahf
4a712f: jae 0x4a7144
4a7131: mov eax,ds:0x4b0ef0
4a7136: xor edx,edx
4a7138: mov DWORD PTR [eax+0xf0],edx
4a713e: mov DWORD PTR [eax+0xf4],edx
4a7144: mov eax,ds:0x4b0ef0
4a7149: fld QWORD PTR [eax+0x40]
4a714c: mov eax,ds:0x4b0ef0
4a7151: fcomp QWORD PTR [eax+0xf0]
4a7157: fnstsw ax
4a7159: sahf
4a715a: jne 0x4a71d0
4a715c: mov eax,ds:0x4b0ef0
4a7161: xor edx,edx
4a7163: mov DWORD PTR [eax+0x40],edx
4a7166: mov DWORD PTR [eax+0x44],edx
4a7169: mov eax,ds:0x4b0ef0
4a716e: xor edx,edx
4a7170: mov DWORD PTR [eax+0xf0],edx
4a7176: mov DWORD PTR [eax+0xf4],edx
4a717c: mov eax,ds:0x4b0fd4
4a7181: cmp BYTE PTR [eax],0x5a
4a7184: jae 0x4a71d0
4a7186: lea ecx,[ebp-0x260]
4a718c: mov eax,DWORD PTR [esi+0x2f4]
4a7192: mov eax,DWORD PTR [eax+0x208]
4a7198: mov edx,0x1c
4a719d: mov ebx,DWORD PTR [eax]
4a719f: call DWORD PTR [ebx+0xc]
4a71a2: mov eax,DWORD PTR [ebp-0x260]
4a71a8: push eax
4a71a9: push 0x63
4a71ab: push 0x1d
4a71ad: mov cl,BYTE PTR [ebp-0x10]
4a71b0: add ecx,ecx
4a71b2: mov dl,BYTE PTR [ebp-0x10]
4a71b5: add edx,edx
4a71b7: mov al,0xff
4a71b9: call 0x406de4
4a71be: push eax
4a71bf: mov ecx,0x78
4a71c4: mov edx,0xc8
4a71c9: mov eax,esi
4a71cb: call 0x48e720
4a71d0: mov eax,ds:0x4b0db4
4a71d5: cmp BYTE PTR [eax],0x46
4a71d8: ja 0x4a7496
4a71de: mov eax,ds:0x4b117c
4a71e3: cmp WORD PTR [eax],0x0
4a71e7: jne 0x4a7496
4a71ed: mov eax,ds:0x4b0db4
4a71f2: inc BYTE PTR [eax]
4a71f4: mov eax,ds:0x4b0db4
4a71f9: cmp BYTE PTR [eax],0xa
4a71fc: jae 0x4a7206
4a71fe: mov eax,ds:0x4b110c
4a7203: mov BYTE PTR [eax],0x1
4a7206: mov eax,ds:0x4b123c
4a720b: mov WORD PTR [eax],0x0
4a7210: mov eax,ds:0x4b0fb8
4a7215: mov WORD PTR [eax],0x0
4a721a: mov eax,ds:0x4b0db4
4a721f: cmp BYTE PTR [eax],0x5
4a7222: jae 0x4a7274
4a7224: mov eax,ds:0x4b0ef0
4a7229: xor edx,edx
4a722b: mov DWORD PTR [eax+0x40],edx
4a722e: mov DWORD PTR [eax+0x44],0x3ff00000
4a7235: mov eax,ds:0x4b0ef0
4a723a: xor edx,edx
4a723c: mov DWORD PTR [eax+0x48],edx
4a723f: mov DWORD PTR [eax+0x4c],0x3ff00000
4a7246: mov eax,ds:0x4b0ef0
4a724b: xor edx,edx
4a724d: mov DWORD PTR [eax+0xf0],edx
4a7253: mov DWORD PTR [eax+0xf4],0x3ff00000
4a725d: mov eax,ds:0x4b0ef0
4a7262: xor edx,edx
4a7264: mov DWORD PTR [eax+0xf8],edx
4a726a: mov DWORD PTR [eax+0xfc],0x3ff00000
4a7274: mov eax,ds:0x4b0db4
4a7279: cmp BYTE PTR [eax],0x5
4a727c: jbe 0x4a72e5
4a727e: mov eax,ds:0x4b0db4
4a7283: cmp BYTE PTR [eax],0x37
4a7286: jae 0x4a72e5
4a7288: mov eax,ds:0x4b0ef0
4a728d: fld QWORD PTR [eax+0x40]
4a7290: fcomp DWORD PTR ds:0x4aef40
4a7296: fnstsw ax
4a7298: sahf
4a7299: jae 0x4a72b2
4a729b: mov eax,ds:0x4b0ef0
4a72a0: fld QWORD PTR [eax+0x40]
4a72a3: fadd DWORD PTR ds:0x4aef1c
4a72a9: mov eax,ds:0x4b0ef0
4a72ae: fstp QWORD PTR [eax+0x40]
4a72b1: fwait
4a72b2: mov eax,ds:0x4b0ef0
4a72b7: fld QWORD PTR [eax+0xf0]
4a72bd: fcomp DWORD PTR ds:0x4aef40
4a72c3: fnstsw ax
4a72c5: sahf
4a72c6: jae 0x4a72e5
4a72c8: mov eax,ds:0x4b0ef0
4a72cd: fld QWORD PTR [eax+0xf0]
4a72d3: fadd DWORD PTR ds:0x4aef1c
4a72d9: mov eax,ds:0x4b0ef0
4a72de: fstp QWORD PTR [eax+0xf0]
4a72e4: fwait
4a72e5: mov eax,ds:0x4b0db4
4a72ea: cmp BYTE PTR [eax],0x5
4a72ed: jbe 0x4a73b1
4a72f3: mov eax,ds:0x4b0db4
4a72f8: cmp BYTE PTR [eax],0x28
4a72fb: jae 0x4a73b1
4a7301: xor eax,eax
4a7303: mov DWORD PTR [ebp-0x10],eax
4a7306: mov eax,ds:0x4b1094
4a730b: movzx eax,BYTE PTR [eax]
4a730e: mov DWORD PTR [ebp-0x48],eax
4a7311: fild DWORD PTR [ebp-0x48]
4a7314: fdiv DWORD PTR ds:0x4aec88
4a731a: call 0x40287c
4a731f: mov eax,ds:0x4b1094
4a7324: movzx eax,BYTE PTR [eax]
4a7327: mov DWORD PTR [ebp-0x1bc],eax
4a732d: fild DWORD PTR [ebp-0x1bc]
4a7333: fdiv DWORD PTR ds:0x4aec88
4a7339: fcompp
4a733b: fnstsw ax
4a733d: sahf
4a733e: jne 0x4a7347
4a7340: mov DWORD PTR [ebp-0x10],0x1e
4a7347: lea edx,[ebp-0x264]
4a734d: mov eax,ds:0x4b11fc
4a7352: movzx eax,BYTE PTR [eax]
4a7355: call 0x408190
4a735a: mov eax,DWORD PTR [ebp-0x264]
4a7360: push eax
4a7361: push 0x63
4a7363: push 0x23
4a7365: mov cl,0xff
4a7367: sub cl,BYTE PTR [ebp-0x10]
4a736a: mov dl,0xff
4a736c: sub dl,BYTE PTR [ebp-0x10]
4a736f: mov al,0xff
4a7371: sub al,BYTE PTR [ebp-0x10]
4a7374: call 0x406de4
4a7379: push eax
4a737a: mov ecx,0x55
4a737f: mov edx,0x104
4a7384: mov eax,esi
4a7386: call 0x48e720
4a738b: push 0x4aef90
4a7390: push 0x63
4a7392: push 0x14
4a7394: mov cl,0xff
4a7396: mov dl,0xff
4a7398: mov al,0xff
4a739a: call 0x406de4
4a739f: push eax
4a73a0: mov ecx,0x64
4a73a5: mov edx,0xc8
4a73aa: mov eax,esi
4a73ac: call 0x48e720
4a73b1: mov eax,ds:0x4b0db4
4a73b6: cmp BYTE PTR [eax],0x2a
4a73b9: jbe 0x4a745c
4a73bf: mov eax,ds:0x4b0db4
4a73c4: cmp BYTE PTR [eax],0x3c
4a73c7: jae 0x4a745c
4a73cd: xor eax,eax
4a73cf: mov DWORD PTR [ebp-0x10],eax
4a73d2: mov eax,ds:0x4b1094
4a73d7: movzx eax,BYTE PTR [eax]
4a73da: mov DWORD PTR [ebp-0x48],eax
4a73dd: fild DWORD PTR [ebp-0x48]
4a73e0: fdiv DWORD PTR ds:0x4aec88
4a73e6: call 0x40287c
4a73eb: mov eax,ds:0x4b1094
4a73f0: movzx eax,BYTE PTR [eax]
4a73f3: mov DWORD PTR [ebp-0x1bc],eax
4a73f9: fild DWORD PTR [ebp-0x1bc]
4a73ff: fdiv DWORD PTR ds:0x4aec88
4a7405: fcompp
4a7407: fnstsw ax
4a7409: sahf
4a740a: jne 0x4a7413
4a740c: mov DWORD PTR [ebp-0x10],0x78
4a7413: lea ecx,[ebp-0x268]
4a7419: mov eax,DWORD PTR [esi+0x2f4]
4a741f: mov eax,DWORD PTR [eax+0x208]
4a7425: mov edx,0xf
4a742a: mov ebx,DWORD PTR [eax]
4a742c: call DWORD PTR [ebx+0xc]
4a742f: mov eax,DWORD PTR [ebp-0x268]
4a7435: push eax
4a7436: push 0x63
4a7438: push 0x19
4a743a: mov cl,BYTE PTR [ebp-0x10]
4a743d: mov dl,BYTE PTR [ebp-0x10]
4a7440: add dl,0x1e
4a7443: mov al,0xff
4a7445: call 0x406de4
4a744a: push eax
4a744b: mov ecx,0x78
4a7450: mov edx,0xc8
4a7455: mov eax,esi
4a7457: call 0x48e720
4a745c: mov eax,ds:0x4b0db4
4a7461: cmp BYTE PTR [eax],0x37
4a7464: jne 0x4a7496
4a7466: mov eax,ds:0x4b110c
4a746b: mov BYTE PTR [eax],0x0
4a746e: mov eax,ds:0x4b0ef0
4a7473: xor edx,edx
4a7475: mov DWORD PTR [eax+0x40],edx
4a7478: mov DWORD PTR [eax+0x44],0x405f4000
4a747f: mov eax,ds:0x4b0ef0
4a7484: xor edx,edx
4a7486: mov DWORD PTR [eax+0xf0],edx
4a748c: mov DWORD PTR [eax+0xf4],0x405f4000
4a7496: mov eax,ds:0x4b0ef0
4a749b: fld QWORD PTR [eax+0x40]
4a749e: fcomp DWORD PTR ds:0x4aef3c
4a74a4: fnstsw ax
4a74a6: sahf
4a74a7: jbe 0x4a74d1
4a74a9: mov eax,ds:0x4b0ef0
4a74ae: fld QWORD PTR [eax+0xf0]
4a74b4: fcomp DWORD PTR ds:0x4aef3c
4a74ba: fnstsw ax
4a74bc: sahf
4a74bd: ja 0x4a85ec
4a74c3: mov eax,ds:0x4b0fd4
4a74c8: cmp BYTE PTR [eax],0xe6
4a74cb: jae 0x4a85ec
4a74d1: mov eax,ds:0x4b0e84
4a74d6: cmp BYTE PTR [eax],0x0
4a74d9: jne 0x4a74ec
4a74db: mov eax,ds:0x4b1074
4a74e0: cmp BYTE PTR [eax],0x0
4a74e3: jne 0x4a74ec
4a74e5: mov eax,ds:0x4b0fd4
4a74ea: inc BYTE PTR [eax]
4a74ec: mov eax,ds:0x4b0fd4
4a74f1: cmp BYTE PTR [eax],0x28
4a74f4: jbe 0x4a74fe
4a74f6: mov eax,ds:0x4b110c
4a74fb: mov BYTE PTR [eax],0x1
4a74fe: mov eax,ds:0x4b0fd4
4a7503: cmp BYTE PTR [eax],0x1
4a7506: jne 0x4a7518
4a7508: mov eax,ds:0x4b0e84
4a750d: mov BYTE PTR [eax],0x1e
4a7510: mov eax,ds:0x4b0fd4
4a7515: mov BYTE PTR [eax],0x2
4a7518: mov eax,ds:0x4b0ef0
4a751d: fld QWORD PTR [eax+0x40]
4a7520: fcomp DWORD PTR ds:0x4aef3c
4a7526: fnstsw ax
4a7528: sahf
4a7529: ja 0x4a7537
4a752b: mov eax,ds:0x4b0ef0
4a7530: mov BYTE PTR [eax+0x142],0x1
4a7537: mov eax,ds:0x4b0ef0
4a753c: fld QWORD PTR [eax+0x40]
4a753f: fcomp DWORD PTR ds:0x4aef3c
4a7545: fnstsw ax
4a7547: sahf
4a7548: ja 0x4a7556
4a754a: mov eax,ds:0x4b0ef0
4a754f: mov BYTE PTR [eax+0x92],0x0
4a7556: mov eax,ds:0x4b0ef0
4a755b: fld QWORD PTR [eax+0xf0]
4a7561: fcomp DWORD PTR ds:0x4aef3c
4a7567: fnstsw ax
4a7569: sahf
4a756a: ja 0x4a7578
4a756c: mov eax,ds:0x4b0ef0
4a7571: mov BYTE PTR [eax+0x92],0x1
4a7578: mov eax,ds:0x4b0ef0
4a757d: fld QWORD PTR [eax+0xf0]
4a7583: fcomp DWORD PTR ds:0x4aef3c
4a7589: fnstsw ax
4a758b: sahf
4a758c: ja 0x4a759a
4a758e: mov eax,ds:0x4b0ef0
4a7593: mov BYTE PTR [eax+0x142],0x0
4a759a: mov eax,ds:0x4b0fd4
4a759f: cmp BYTE PTR [eax],0x0
4a75a2: jbe 0x4a7631
4a75a8: mov eax,ds:0x4b0fd4
4a75ad: cmp BYTE PTR [eax],0x1e
4a75b0: jae 0x4a7631
4a75b2: xor eax,eax
4a75b4: mov DWORD PTR [ebp-0x10],eax
4a75b7: mov eax,ds:0x4b1094
4a75bc: movzx eax,BYTE PTR [eax]
4a75bf: mov DWORD PTR [ebp-0x48],eax
4a75c2: fild DWORD PTR [ebp-0x48]
4a75c5: fdiv DWORD PTR ds:0x4aec88
4a75cb: call 0x40287c
4a75d0: mov eax,ds:0x4b1094
4a75d5: movzx eax,BYTE PTR [eax]
4a75d8: mov DWORD PTR [ebp-0x1bc],eax
4a75de: fild DWORD PTR [ebp-0x1bc]
4a75e4: fdiv DWORD PTR ds:0x4aec88
4a75ea: fcompp
4a75ec: fnstsw ax
4a75ee: sahf
4a75ef: jne 0x4a75f8
4a75f1: mov DWORD PTR [ebp-0x10],0x64
4a75f8: push 0x4aefa4
4a75fd: push 0x63
4a75ff: push 0x46
4a7601: mov dl,BYTE PTR [ebp-0x10]
4a7604: xor ecx,ecx
4a7606: mov al,0xff
4a7608: call 0x406de4
4a760d: push eax
4a760e: mov ecx,0x64
4a7613: mov edx,0xc8
4a7618: mov eax,esi
4a761a: call 0x48e720
4a761f: mov eax,ds:0x4b123c
4a7624: sub WORD PTR [eax],0x5
4a7628: mov eax,ds:0x4b0fb8
4a762d: add WORD PTR [eax],0x5
4a7631: mov eax,ds:0x4b0fd4
4a7636: cmp BYTE PTR [eax],0x1e
4a7639: jbe 0x4a7aa6
4a763f: mov eax,ds:0x4b0fd4
4a7644: cmp BYTE PTR [eax],0x5a
4a7647: jae 0x4a7aa6
4a764d: mov DWORD PTR [ebp-0xc],0x1
4a7654: mov ebx,DWORD PTR ds:0x4b0ef0
4a765a: add ebx,0x40
4a765d: fld QWORD PTR [ebx]
4a765f: fcomp DWORD PTR ds:0x4aef3c
4a7665: fnstsw ax
4a7667: sahf
4a7668: jbe 0x4a7a93
4a766e: mov eax,ds:0x4b110c
4a7673: cmp BYTE PTR [eax],0x1
4a7676: jne 0x4a7682
4a7678: mov al,BYTE PTR [ebp-0xc]
4a767b: mov dl,0xe
4a767d: call 0x4775fc
4a7682: xor eax,eax
4a7684: mov DWORD PTR [ebp-0x10],eax
4a7687: mov eax,ds:0x4b1094
4a768c: movzx eax,BYTE PTR [eax]
4a768f: mov DWORD PTR [ebp-0x48],eax
4a7692: fild DWORD PTR [ebp-0x48]
4a7695: fdiv DWORD PTR ds:0x4aec88
4a769b: call 0x40287c
4a76a0: mov eax,ds:0x4b1094
4a76a5: movzx eax,BYTE PTR [eax]
4a76a8: mov DWORD PTR [ebp-0x1bc],eax
4a76ae: fild DWORD PTR [ebp-0x1bc]
4a76b4: fdiv DWORD PTR ds:0x4aec88
4a76ba: fcompp
4a76bc: fnstsw ax
4a76be: sahf
4a76bf: jne 0x4a76c8
4a76c1: mov DWORD PTR [ebp-0x10],0x50
4a76c8: lea ecx,[ebp-0x26c]
4a76ce: movsx edx,BYTE PTR [ebx-0x30]
4a76d2: mov eax,DWORD PTR [esi+0x2f0]
4a76d8: mov eax,DWORD PTR [eax+0x208]
4a76de: mov edi,DWORD PTR [eax]
4a76e0: call DWORD PTR [edi+0xc]
4a76e3: mov eax,DWORD PTR [ebp-0x26c]
4a76e9: push eax
4a76ea: push 0x63
4a76ec: push 0x14
4a76ee: mov cl,BYTE PTR [ebp-0x10]
4a76f1: mov dl,BYTE PTR [ebp-0x10]
4a76f4: mov al,0xff
4a76f6: call 0x406de4
4a76fb: push eax
4a76fc: mov ecx,0x6e
4a7701: mov edx,0xc8
4a7706: mov eax,esi
4a7708: call 0x48e720
4a770d: lea ecx,[ebp-0x270]
4a7713: mov eax,DWORD PTR [esi+0x2f4]
4a7719: mov eax,DWORD PTR [eax+0x208]
4a771f: mov edx,0xe
4a7724: mov edi,DWORD PTR [eax]
4a7726: call DWORD PTR [edi+0xc]
4a7729: mov eax,DWORD PTR [ebp-0x270]
4a772f: push eax
4a7730: push 0x63
4a7732: push 0xe
4a7734: mov cl,0xff
4a7736: mov dl,0xff
4a7738: mov al,0xff
4a773a: call 0x406de4
4a773f: push eax
4a7740: mov ecx,0x8c
4a7745: mov edx,0xc8
4a774a: mov eax,esi
4a774c: call 0x48e720
4a7751: cmp BYTE PTR [ebx+0x5e],0x1
4a7755: jne 0x4a7825
4a775b: fld QWORD PTR [ebx]
4a775d: fcomp DWORD PTR ds:0x4aef40
4a7763: fnstsw ax
4a7765: sahf
4a7766: jae 0x4a7825
4a776c: lea ecx,[ebp-0x278]
4a7772: mov eax,DWORD PTR [esi+0x2f4]
4a7778: mov eax,DWORD PTR [eax+0x208]
4a777e: mov edx,0x5
4a7783: mov edi,DWORD PTR [eax]
4a7785: call DWORD PTR [edi+0xc]
4a7788: push DWORD PTR [ebp-0x278]
4a778e: push 0x4aefb0
4a7793: push 0x0
4a7795: push 0x5
4a7797: fld QWORD PTR [ebx]
4a7799: call 0x402894
4a779e: call 0x405f44
4a77a3: push edx
4a77a4: push eax
4a77a5: lea eax,[ebp-0x27c]
4a77ab: call 0x4081c0
4a77b0: push DWORD PTR [ebp-0x27c]
4a77b6: push 0x4aefbc
4a77bb: lea eax,[ebp-0x274]
4a77c1: mov edx,0x4
4a77c6: call 0x403d10
4a77cb: mov eax,DWORD PTR [ebp-0x274]
4a77d1: push eax
4a77d2: push 0x63
4a77d4: push 0xc
4a77d6: mov cl,0xff
4a77d8: mov dl,0xff
4a77da: mov al,0xff
4a77dc: call 0x406de4
4a77e1: push eax
4a77e2: mov ecx,0xd2
4a77e7: mov edx,0xc8
4a77ec: mov eax,esi
4a77ee: call 0x48e720
4a77f3: mov eax,ds:0x4b0fd4
4a77f8: cmp BYTE PTR [eax],0x23
4a77fb: jne 0x4a7825
4a77fd: mov eax,ds:0x4b0e84
4a7802: cmp BYTE PTR [eax],0x0
4a7805: jne 0x4a7825
4a7807: mov eax,ds:0x4b1074
4a780c: cmp BYTE PTR [eax],0x0
4a780f: jne 0x4a7825
4a7811: fld QWORD PTR [ebx]
4a7813: call 0x402894
4a7818: lea eax,[eax+eax*4]
4a781b: add DWORD PTR [ebx+0x48],eax
4a781e: mov eax,ds:0x4b0fd4
4a7823: inc BYTE PTR [eax]
4a7825: xor eax,eax
4a7827: mov DWORD PTR [ebp-0x10],eax
4a782a: mov eax,ds:0x4b1094
4a782f: movzx eax,BYTE PTR [eax]
4a7832: mov DWORD PTR [ebp-0x48],eax
4a7835: fild DWORD PTR [ebp-0x48]
4a7838: fdiv DWORD PTR ds:0x4aec88
4a783e: call 0x40287c
4a7843: mov eax,ds:0x4b1094
4a7848: movzx eax,BYTE PTR [eax]
4a784b: mov DWORD PTR [ebp-0x1bc],eax
4a7851: fild DWORD PTR [ebp-0x1bc]
4a7857: fdiv DWORD PTR ds:0x4aec88
4a785d: fcompp
4a785f: fnstsw ax
4a7861: sahf
4a7862: jne 0x4a786b
4a7864: mov DWORD PTR [ebp-0x10],0x78
4a786b: fld QWORD PTR [ebx]
4a786d: fcomp DWORD PTR ds:0x4aef40
4a7873: fnstsw ax
4a7875: sahf
4a7876: jne 0x4a78ce
4a7878: mov eax,ds:0x4b0fd4
4a787d: cmp BYTE PTR [eax],0x23
4a7880: jbe 0x4a78ce
4a7882: lea ecx,[ebp-0x280]
4a7888: mov eax,DWORD PTR [esi+0x2f4]
4a788e: mov eax,DWORD PTR [eax+0x208]
4a7894: mov edx,0x1e
4a7899: mov edi,DWORD PTR [eax]
4a789b: call DWORD PTR [edi+0xc]
4a789e: mov eax,DWORD PTR [ebp-0x280]
4a78a4: push eax
4a78a5: push 0x63
4a78a7: push 0x1c
4a78a9: mov cl,BYTE PTR [ebp-0x10]
4a78ac: add cl,0x1e
4a78af: mov dl,BYTE PTR [ebp-0x10]
4a78b2: add dl,0x78
4a78b5: mov al,0xff
4a78b7: call 0x406de4
4a78bc: push eax
4a78bd: mov ecx,0xaa
4a78c2: mov edx,0xc8
4a78c7: mov eax,esi
4a78c9: call 0x48e720
4a78ce: cmp BYTE PTR [ebx+0x5e],0x1
4a78d2: jne 0x4a796d
4a78d8: fld QWORD PTR [ebx]
4a78da: fcomp DWORD PTR ds:0x4aef40
4a78e0: fnstsw ax
4a78e2: sahf
4a78e3: jne 0x4a796d
4a78e9: push 0x4aefcc
4a78ee: lea edx,[ebp-0x288]
4a78f4: mov eax,0x3e8
4a78f9: call 0x408190
4a78fe: push DWORD PTR [ebp-0x288]
4a7904: push 0x4aefbc
4a7909: lea eax,[ebp-0x284]
4a790f: mov edx,0x3
4a7914: call 0x403d10
4a7919: mov eax,DWORD PTR [ebp-0x284]
4a791f: push eax
4a7920: push 0x63
4a7922: push 0xf
4a7924: mov cl,0xff
4a7926: mov dl,0xff
4a7928: mov al,0xff
4a792a: call 0x406de4
4a792f: push eax
4a7930: mov ecx,0xd2
4a7935: mov edx,0xc8
4a793a: mov eax,esi
4a793c: call 0x48e720
4a7941: mov eax,ds:0x4b0fd4
4a7946: cmp BYTE PTR [eax],0x2d
4a7949: jne 0x4a796d
4a794b: mov eax,ds:0x4b1074
4a7950: cmp BYTE PTR [eax],0x0
4a7953: jne 0x4a796d
4a7955: mov eax,ds:0x4b0e84
4a795a: cmp BYTE PTR [eax],0x0
4a795d: jne 0x4a796d
4a795f: add DWORD PTR [ebx+0x48],0x3e8
4a7966: mov eax,ds:0x4b0fd4
4a796b: inc BYTE PTR [eax]
4a796d: cmp BYTE PTR [ebx+0x5e],0x1
4a7971: jne 0x4a7a93
4a7977: mov eax,ds:0x4b113c
4a797c: mov al,BYTE PTR [eax]
4a797e: cmp al,BYTE PTR [ebx+0x4c]
4a7981: jne 0x4a7a93
4a7987: mov eax,0x3
4a798c: sub eax,DWORD PTR [ebp-0xc]
4a798f: imul eax,eax,0x16
4a7992: mov edx,DWORD PTR ds:0x4b0ef0
4a7998: cmp BYTE PTR [edx+eax*8-0x24],0x0
4a799d: jne 0x4a7a93
4a79a3: xor eax,eax
4a79a5: mov DWORD PTR [ebp-0x10],eax
4a79a8: mov eax,ds:0x4b1094
4a79ad: movzx eax,BYTE PTR [eax]
4a79b0: mov DWORD PTR [ebp-0x48],eax
4a79b3: fild DWORD PTR [ebp-0x48]
4a79b6: fdiv DWORD PTR ds:0x4aec88
4a79bc: call 0x40287c
4a79c1: mov eax,ds:0x4b1094
4a79c6: movzx eax,BYTE PTR [eax]
4a79c9: mov DWORD PTR [ebp-0x1bc],eax
4a79cf: fild DWORD PTR [ebp-0x1bc]
4a79d5: fdiv DWORD PTR ds:0x4aec88
4a79db: fcompp
4a79dd: fnstsw ax
4a79df: sahf
4a79e0: jne 0x4a79e9
4a79e2: mov DWORD PTR [ebp-0x10],0x14
4a79e9: lea ecx,[ebp-0x290]
4a79ef: mov eax,DWORD PTR [esi+0x2f4]
4a79f5: mov eax,DWORD PTR [eax+0x208]
4a79fb: mov edx,0x20
4a7a00: mov edi,DWORD PTR [eax]
4a7a02: call DWORD PTR [edi+0xc]
4a7a05: push DWORD PTR [ebp-0x290]
4a7a0b: push 0x4aefdc
4a7a10: lea edx,[ebp-0x294]
4a7a16: mov eax,0x3e8
4a7a1b: call 0x408190
4a7a20: push DWORD PTR [ebp-0x294]
4a7a26: push 0x4aefbc
4a7a2b: lea eax,[ebp-0x28c]
4a7a31: mov edx,0x4
4a7a36: call 0x403d10
4a7a3b: mov eax,DWORD PTR [ebp-0x28c]
4a7a41: push eax
4a7a42: push 0x63
4a7a44: push 0x14
4a7a46: mov cl,BYTE PTR [ebp-0x10]
4a7a49: add cl,0xeb
4a7a4c: mov dl,BYTE PTR [ebp-0x10]
4a7a4f: add dl,0xaa
4a7a52: mov al,BYTE PTR [ebp-0x10]
4a7a55: add al,0xaa
4a7a57: call 0x406de4
4a7a5c: push eax
4a7a5d: mov ecx,0xf0
4a7a62: mov edx,0xc8
4a7a67: mov eax,esi
4a7a69: call 0x48e720
4a7a6e: mov eax,ds:0x4b0fd4
4a7a73: cmp BYTE PTR [eax],0x2d
4a7a76: jne 0x4a7a93
4a7a78: mov eax,ds:0x4b1074
4a7a7d: cmp BYTE PTR [eax],0x0
4a7a80: jne 0x4a7a93
4a7a82: mov eax,ds:0x4b0e84
4a7a87: cmp BYTE PTR [eax],0x0
4a7a8a: jne 0x4a7a93
4a7a8c: add DWORD PTR [ebx+0x48],0x3e8
4a7a93: inc DWORD PTR [ebp-0xc]
4a7a96: add ebx,0xb0
4a7a9c: cmp DWORD PTR [ebp-0xc],0x3
4a7aa0: jne 0x4a765d
4a7aa6: mov eax,ds:0x4b0fd4
4a7aab: cmp BYTE PTR [eax],0x28
4a7aae: jne 0x4a7b5d
4a7ab4: mov DWORD PTR [ebp-0xc],0x2
4a7abb: mov ebx,DWORD PTR ds:0x4b0ef0
4a7ac1: add ebx,0x40
4a7ac4: fld QWORD PTR [ebx]
4a7ac6: fcomp DWORD PTR ds:0x4aef3c
4a7acc: fnstsw ax
4a7ace: sahf
4a7acf: jbe 0x4a7aef
4a7ad1: mov eax,ds:0x4b0e84
4a7ad6: cmp BYTE PTR [eax],0x0
4a7ad9: jne 0x4a7aef
4a7adb: mov eax,ds:0x4b1074
4a7ae0: cmp BYTE PTR [eax],0x0
4a7ae3: jne 0x4a7aef
4a7ae5: inc BYTE PTR [ebx+0x4c]
4a7ae8: mov eax,ds:0x4b0fd4
4a7aed: inc BYTE PTR [eax]
4a7aef: mov eax,0x28
4a7af4: call 0x402a1c
4a7af9: mov DWORD PTR [ebp-0x48],eax
4a7afc: fild DWORD PTR [ebp-0x48]
4a7aff: fdiv DWORD PTR ds:0x4aec94
4a7b05: call 0x402894
4a7b0a: inc eax
4a7b0b: mov edx,DWORD PTR ds:0x4b0f1c
4a7b11: mov BYTE PTR [edx],al
4a7b13: mov eax,ds:0x4b0f1c
4a7b18: cmp BYTE PTR [eax],0x4
4a7b1b: jbe 0x4a7b25
4a7b1d: mov eax,ds:0x4b0f1c
4a7b22: mov BYTE PTR [eax],0x4
4a7b25: mov eax,0x1e
4a7b2a: call 0x402a1c
4a7b2f: mov DWORD PTR [ebp-0x48],eax
4a7b32: fild DWORD PTR [ebp-0x48]
4a7b35: fdiv DWORD PTR ds:0x4aec94
4a7b3b: call 0x402894
4a7b40: inc eax
4a7b41: mov BYTE PTR [ebx+0x4d],al
4a7b44: cmp BYTE PTR [ebx+0x4d],0x3
4a7b48: jbe 0x4a7b4e
4a7b4a: mov BYTE PTR [ebx+0x4d],0x3
4a7b4e: add ebx,0xb0
4a7b54: dec DWORD PTR [ebp-0xc]
4a7b57: jne 0x4a7ac4
4a7b5d: mov DWORD PTR [ebp-0xc],0x1
4a7b64: mov ebx,DWORD PTR ds:0x4b0ef0
4a7b6a: add ebx,0x8c
4a7b70: mov eax,ds:0x4b113c
4a7b75: mov al,BYTE PTR [eax]
4a7b77: cmp al,BYTE PTR [ebx]
4a7b79: ja 0x4a8054
4a7b7f: mov eax,ds:0x4b0fd4
4a7b84: cmp BYTE PTR [eax],0x5a
4a7b87: jb 0x4a8054
4a7b8d: mov eax,ds:0x4b0fd4
4a7b92: cmp BYTE PTR [eax],0xd2
4a7b95: ja 0x4a8054
4a7b9b: xor eax,eax
4a7b9d: mov DWORD PTR [ebp-0x10],eax
4a7ba0: mov eax,ds:0x4b1094
4a7ba5: movzx eax,BYTE PTR [eax]
4a7ba8: mov DWORD PTR [ebp-0x48],eax
4a7bab: fild DWORD PTR [ebp-0x48]
4a7bae: fdiv DWORD PTR ds:0x4aec88
4a7bb4: call 0x40287c
4a7bb9: mov eax,ds:0x4b1094
4a7bbe: movzx eax,BYTE PTR [eax]
4a7bc1: mov DWORD PTR [ebp-0x1bc],eax
4a7bc7: fild DWORD PTR [ebp-0x1bc]
4a7bcd: fdiv DWORD PTR ds:0x4aec88
4a7bd3: fcompp
4a7bd5: fnstsw ax
4a7bd7: sahf
4a7bd8: jne 0x4a7be1
4a7bda: mov DWORD PTR [ebp-0x10],0x1e
4a7be1: mov eax,ds:0x4b110c
4a7be6: cmp BYTE PTR [eax],0x1
4a7be9: jne 0x4a7bf5
4a7beb: mov al,BYTE PTR [ebp-0xc]
4a7bee: mov dl,0xe
4a7bf0: call 0x4775fc
4a7bf5: mov eax,ds:0x4b0fd4
4a7bfa: cmp BYTE PTR [eax],0x64
4a7bfd: jne 0x4a7c34
4a7bff: mov eax,0x3
4a7c04: sub eax,DWORD PTR [ebp-0xc]
4a7c07: imul eax,eax,0x16
4a7c0a: mov edx,DWORD PTR ds:0x4b0ef0
4a7c10: cmp BYTE PTR [edx+eax*8-0x12],0x0
4a7c15: jne 0x4a7c1e
4a7c17: mov eax,ds:0x4b116c
4a7c1c: inc BYTE PTR [eax]
4a7c1e: mov eax,0x3
4a7c23: sub eax,DWORD PTR [ebp-0xc]
4a7c26: imul eax,eax,0x16
4a7c29: mov edx,DWORD PTR ds:0x4b0ef0
4a7c2f: mov BYTE PTR [edx+eax*8-0x12],0x0
4a7c34: mov eax,DWORD PTR [esi+0x2d8]
4a7c3a: mov eax,DWORD PTR [eax+0x38]
4a7c3d: test BYTE PTR [eax+0x2038],0x10
4a7c44: je 0x4a7c4c
4a7c46: cmp DWORD PTR [ebp-0xc],0x1
4a7c4a: je 0x4a7c64
4a7c4c: mov eax,DWORD PTR [esi+0x2d8]
4a7c52: mov eax,DWORD PTR [eax+0x34]
4a7c55: test BYTE PTR [eax+0x2038],0x10
4a7c5c: je 0x4a7c80
4a7c5e: cmp DWORD PTR [ebp-0xc],0x2
4a7c62: jne 0x4a7c80
4a7c64: mov eax,ds:0x4b0fd4
4a7c69: cmp BYTE PTR [eax],0x5a
4a7c6c: jb 0x4a7c78
4a7c6e: mov eax,ds:0x4b0fd4
4a7c73: cmp BYTE PTR [eax],0x64
4a7c76: jbe 0x4a7c80
4a7c78: mov eax,ds:0x4b0fd4
4a7c7d: add BYTE PTR [eax],0x2
4a7c80: mov eax,ds:0x4b0fd4
4a7c85: cmp BYTE PTR [eax],0x5f
4a7c88: jne 0x4a7d15
4a7c8e: mov eax,ds:0x4b0e84
4a7c93: cmp BYTE PTR [eax],0x0
4a7c96: jne 0x4a7d15
4a7c98: mov eax,ds:0x4b1074
4a7c9d: cmp BYTE PTR [eax],0x0
4a7ca0: jne 0x4a7d15
4a7ca2: mov eax,0xc8
4a7ca7: call 0x402a1c
4a7cac: mov DWORD PTR [ebp-0x48],eax
4a7caf: fild DWORD PTR [ebp-0x48]
4a7cb2: fdiv DWORD PTR ds:0x4aefe0
4a7cb8: call 0x402894
4a7cbd: mov DWORD PTR [ebp-0x10],eax
4a7cc0: cmp DWORD PTR [ebp-0x10],0x0
4a7cc4: jge 0x4a7ccb
4a7cc6: xor eax,eax
4a7cc8: mov DWORD PTR [ebp-0x10],eax
4a7ccb: cmp DWORD PTR [ebp-0x10],0x1
4a7ccf: jle 0x4a7cd8
4a7cd1: mov DWORD PTR [ebp-0x10],0x1
4a7cd8: mov eax,DWORD PTR [esi+0x31c]
4a7cde: mov eax,DWORD PTR [eax+0x28]
4a7ce1: call 0x40efcc
4a7ce6: movsx edx,BYTE PTR [ebx-0x7c]
4a7cea: dec edx
4a7ceb: add edx,edx
4a7ced: add edx,DWORD PTR [ebp-0x10]
4a7cf0: cmp eax,edx
4a7cf2: jle 0x4a7d15
4a7cf4: movsx eax,BYTE PTR [ebx-0x7c]
4a7cf8: dec eax
4a7cf9: mov edx,eax
4a7cfb: add edx,edx
4a7cfd: add edx,DWORD PTR [ebp-0x10]
4a7d00: mov eax,DWORD PTR [esi+0x31c]
4a7d06: mov eax,DWORD PTR [eax+0x28]
4a7d09: call 0x449f54
4a7d0e: xor edx,edx
4a7d10: call 0x449cac
4a7d15: mov eax,DWORD PTR [esi+0x304]
4a7d1b: mov eax,DWORD PTR [eax+0x28]
4a7d1e: call 0x40efcc
4a7d23: movsx edx,BYTE PTR [ebx-0x7c]
4a7d27: dec edx
4a7d28: lea edx,[edx+edx*4]
4a7d2b: add edx,0x4
4a7d2e: cmp eax,edx
4a7d30: jle 0x4a7e9f
4a7d36: mov eax,ds:0x4b0fd4
4a7d3b: cmp BYTE PTR [eax],0x64
4a7d3e: jae 0x4a7db5
4a7d40: push 0x0
4a7d42: push 0xff
4a7d47: push 0xda
4a7d4c: lea eax,[ebp-0x30]
4a7d4f: push eax
4a7d50: mov eax,ds:0x4b0fd4
4a7d55: movzx eax,BYTE PTR [eax]
4a7d58: sub eax,0x5a
4a7d5b: imul eax,eax,0x32
4a7d5e: mov ecx,0x368
4a7d63: sub ecx,eax
4a7d65: mov eax,ds:0x4b0fd4
4a7d6a: movzx eax,BYTE PTR [eax]
4a7d6d: sub eax,0x5a
4a7d70: imul eax,eax,0x32
4a7d73: push eax
4a7d74: mov eax,0x2d8
4a7d79: pop edx
4a7d7a: sub eax,edx
4a7d7c: mov edx,0x1d
4a7d81: call 0x40d760
4a7d86: lea eax,[ebp-0x30]
4a7d89: push eax
4a7d8a: movsx eax,BYTE PTR [ebx-0x7c]
4a7d8e: dec eax
4a7d8f: lea edx,[eax+eax*4]
4a7d92: add edx,0x4
4a7d95: mov eax,DWORD PTR [esi+0x304]
4a7d9b: mov eax,DWORD PTR [eax+0x28]
4a7d9e: call 0x461dcc
4a7da3: mov edx,DWORD PTR [esi+0x2d0]
4a7da9: mov edx,DWORD PTR [edx+0x270]
4a7daf: pop ecx
4a7db0: call 0x4616c0
4a7db5: mov eax,ds:0x4b0fd4
4a7dba: cmp BYTE PTR [eax],0x64
4a7dbd: jb 0x4a7e1c
4a7dbf: mov eax,ds:0x4b0fd4
4a7dc4: cmp BYTE PTR [eax],0xb4
4a7dc7: jae 0x4a7e1c
4a7dc9: push 0x0
4a7dcb: push 0xff
4a7dd0: push 0xda
4a7dd5: lea eax,[ebp-0x30]
4a7dd8: push eax
4a7dd9: mov ecx,0x110
4a7dde: mov edx,0x1d
4a7de3: mov eax,0x80
4a7de8: call 0x40d760
4a7ded: lea eax,[ebp-0x30]
4a7df0: push eax
4a7df1: movsx eax,BYTE PTR [ebx-0x7c]
4a7df5: dec eax
4a7df6: lea edx,[eax+eax*4]
4a7df9: add edx,0x4
4a7dfc: mov eax,DWORD PTR [esi+0x304]
4a7e02: mov eax,DWORD PTR [eax+0x28]
4a7e05: call 0x461dcc
4a7e0a: mov edx,DWORD PTR [esi+0x2d0]
4a7e10: mov edx,DWORD PTR [edx+0x270]
4a7e16: pop ecx
4a7e17: call 0x4616c0
4a7e1c: mov eax,ds:0x4b0fd4
4a7e21: cmp BYTE PTR [eax],0xb4
4a7e24: jb 0x4a7e9f
4a7e26: push 0x0
4a7e28: push 0xff
4a7e2d: push 0xda
4a7e32: lea eax,[ebp-0x30]
4a7e35: push eax
4a7e36: mov eax,ds:0x4b0fd4
4a7e3b: movzx eax,BYTE PTR [eax]
4a7e3e: sub eax,0xb4
4a7e43: imul eax,eax,0x32
4a7e46: mov ecx,0x110
4a7e4b: sub ecx,eax
4a7e4d: mov eax,ds:0x4b0fd4
4a7e52: movzx eax,BYTE PTR [eax]
4a7e55: sub eax,0xb4
4a7e5a: imul eax,eax,0x32
4a7e5d: push eax
4a7e5e: mov eax,0x80
4a7e63: pop edx
4a7e64: sub eax,edx
4a7e66: mov edx,0x1d
4a7e6b: call 0x40d760
4a7e70: lea eax,[ebp-0x30]
4a7e73: push eax
4a7e74: movsx eax,BYTE PTR [ebx-0x7c]
4a7e78: dec eax
4a7e79: lea edx,[eax+eax*4]
4a7e7c: add edx,0x4
4a7e7f: mov eax,DWORD PTR [esi+0x304]
4a7e85: mov eax,DWORD PTR [eax+0x28]
4a7e88: call 0x461dcc
4a7e8d: mov edx,DWORD PTR [esi+0x2d0]
4a7e93: mov edx,DWORD PTR [edx+0x270]
4a7e99: pop ecx
4a7e9a: call 0x4616c0
4a7e9f: cmp BYTE PTR [ebx+0x12],0x1
4a7ea3: jne 0x4a7fcf
4a7ea9: lea ecx,[ebp-0x298]
4a7eaf: mov eax,DWORD PTR [esi+0x2f4]
4a7eb5: mov eax,DWORD PTR [eax+0x208]
4a7ebb: mov edx,0x10
4a7ec0: mov edi,DWORD PTR [eax]
4a7ec2: call DWORD PTR [edi+0xc]
4a7ec5: mov eax,DWORD PTR [ebp-0x298]
4a7ecb: push eax
4a7ecc: push 0x2d
4a7ece: push 0xc
4a7ed0: mov cl,BYTE PTR [ebp-0x10]
4a7ed3: add cl,0x1e
4a7ed6: mov dl,BYTE PTR [ebp-0x10]
4a7ed9: add dl,0xdc
4a7edc: mov al,BYTE PTR [ebp-0x10]
4a7edf: add al,0x1e
4a7ee1: call 0x406de4
4a7ee6: push eax
4a7ee7: mov ecx,0x14
4a7eec: mov edx,0xa
4a7ef1: mov eax,esi
4a7ef3: call 0x48e720
4a7ef8: lea edx,[ebp-0x29c]
4a7efe: xor eax,eax
4a7f00: mov al,BYTE PTR [ebx+0xb]
4a7f03: call 0x408190
4a7f08: mov eax,DWORD PTR [ebp-0x29c]
4a7f0e: push eax
4a7f0f: push 0x2d
4a7f11: push 0xe
4a7f13: mov cl,0xff
4a7f15: sub cl,BYTE PTR [ebp-0x10]
4a7f18: mov al,0xff
4a7f1a: sub al,BYTE PTR [ebp-0x10]
4a7f1d: push eax
4a7f1e: mov al,0xff
4a7f20: sub al,BYTE PTR [ebp-0x10]
4a7f23: pop edx
4a7f24: call 0x406de4
4a7f29: push eax
4a7f2a: mov ecx,0x23
4a7f2f: mov edx,0xa
4a7f34: mov eax,esi
4a7f36: call 0x48e720
4a7f3b: lea ecx,[ebp-0x2a0]
4a7f41: mov eax,DWORD PTR [esi+0x2f4]
4a7f47: mov eax,DWORD PTR [eax+0x208]
4a7f4d: mov edx,0x11
4a7f52: mov edi,DWORD PTR [eax]
4a7f54: call DWORD PTR [edi+0xc]
4a7f57: mov eax,DWORD PTR [ebp-0x2a0]
4a7f5d: push eax
4a7f5e: push 0x2d
4a7f60: push 0xc
4a7f62: mov cl,BYTE PTR [ebp-0x10]
4a7f65: add cl,0x1e
4a7f68: mov dl,BYTE PTR [ebp-0x10]
4a7f6b: add dl,0xdc
4a7f6e: mov al,BYTE PTR [ebp-0x10]
4a7f71: add al,0x1e
4a7f73: call 0x406de4
4a7f78: push eax
4a7f79: mov ecx,0x3c
4a7f7e: mov edx,0xa
4a7f83: mov eax,esi
4a7f85: call 0x48e720
4a7f8a: mov eax,DWORD PTR [ebx-0x4]
4a7f8d: xor edx,edx
4a7f8f: push edx
4a7f90: push eax
4a7f91: lea eax,[ebp-0x2a4]
4a7f97: call 0x4081c0
4a7f9c: mov eax,DWORD PTR [ebp-0x2a4]
4a7fa2: push eax
4a7fa3: push 0x2d
4a7fa5: push 0xe
4a7fa7: mov cl,0xff
4a7fa9: sub cl,BYTE PTR [ebp-0x10]
4a7fac: mov al,0xff
4a7fae: sub al,BYTE PTR [ebp-0x10]
4a7fb1: push eax
4a7fb2: mov al,0xff
4a7fb4: sub al,BYTE PTR [ebp-0x10]
4a7fb7: pop edx
4a7fb8: call 0x406de4
4a7fbd: push eax
4a7fbe: mov ecx,0x4b
4a7fc3: mov edx,0xa
4a7fc8: mov eax,esi
4a7fca: call 0x48e720
4a7fcf: push 0x18b
4a7fd4: push 0x118
4a7fd9: push 0x5
4a7fdb: mov cl,0xff
4a7fdd: mov dl,0xff
4a7fdf: mov al,0xff
4a7fe1: call 0x406de4
4a7fe6: push eax
4a7fe7: xor ecx,ecx
4a7fe9: xor edx,edx
4a7feb: xor eax,eax
4a7fed: call 0x406de4
4a7ff2: push eax
4a7ff3: mov ecx,0xdc
4a7ff8: mov edx,0x5
4a7ffd: mov eax,esi
4a7fff: call 0x48e570
4a8004: movsx eax,BYTE PTR [ebx-0x7c]
4a8008: dec eax
4a8009: mov edx,eax
4a800b: shl edx,0x2
4a800e: xor eax,eax
4a8010: mov al,BYTE PTR [ebx+0x1]
4a8013: add edx,eax
4a8015: lea ecx,[ebp-0x2a8]
4a801b: mov eax,DWORD PTR [esi+0x2fc]
4a8021: mov eax,DWORD PTR [eax+0x208]
4a8027: mov edi,DWORD PTR [eax]
4a8029: call DWORD PTR [edi+0xc]
4a802c: mov eax,DWORD PTR [ebp-0x2a8]
4a8032: push eax
4a8033: push 0x63
4a8035: push 0xc
4a8037: mov cl,0xff
4a8039: mov dl,0xff
4a803b: mov al,0xff
4a803d: call 0x406de4
4a8042: push eax
4a8043: mov ecx,0xed
4a8048: mov edx,0xc8
4a804d: mov eax,esi
4a804f: call 0x48e720
4a8054: inc DWORD PTR [ebp-0xc]
4a8057: add ebx,0xb0
4a805d: cmp DWORD PTR [ebp-0xc],0x3
4a8061: jne 0x4a7b70
4a8067: mov eax,ds:0x4b0ef0
4a806c: mov al,BYTE PTR [eax+0x8c]
4a8072: mov edx,DWORD PTR ds:0x4b113c
4a8078: cmp al,BYTE PTR [edx]
4a807a: jae 0x4a82fd
4a8080: mov eax,ds:0x4b0ef0
4a8085: mov al,BYTE PTR [eax+0x13c]
4a808b: mov edx,DWORD PTR ds:0x4b113c
4a8091: cmp al,BYTE PTR [edx]
4a8093: jae 0x4a82fd
4a8099: mov eax,ds:0x4b0fd4
4a809e: cmp BYTE PTR [eax],0x5f
4a80a1: jbe 0x4a82fd
4a80a7: mov eax,ds:0x4b0f1c
4a80ac: cmp BYTE PTR [eax],0x1
4a80af: jne 0x4a8113
4a80b1: push 0x190
4a80b6: mov eax,ds:0x4b0fd4
4a80bb: movzx eax,BYTE PTR [eax]
4a80be: add eax,eax
4a80c0: lea eax,[eax+eax*4]
4a80c3: add eax,0xfffffc4a
4a80c8: push eax
4a80c9: xor ecx,ecx
4a80cb: xor edx,edx
4a80cd: xor eax,eax
4a80cf: call 0x406de4
4a80d4: push eax
4a80d5: xor ecx,ecx
4a80d7: xor edx,edx
4a80d9: mov eax,esi
4a80db: call 0x48e444
4a80e0: push 0x190
4a80e5: push 0x12c
4a80ea: xor ecx,ecx
4a80ec: xor edx,edx
4a80ee: xor eax,eax
4a80f0: call 0x406de4
4a80f5: push eax
4a80f6: mov eax,ds:0x4b0fd4
4a80fb: movzx eax,BYTE PTR [eax]
4a80fe: add eax,eax
4a8100: lea eax,[eax+eax*4]
4a8103: mov ecx,0x4e2
4a8108: sub ecx,eax
4a810a: xor edx,edx
4a810c: mov eax,esi
4a810e: call 0x48e444
4a8113: mov eax,ds:0x4b0f1c
4a8118: cmp BYTE PTR [eax],0x2
4a811b: jne 0x4a8184
4a811d: push 0xc8
4a8122: mov eax,ds:0x4b0fd4
4a8127: movzx eax,BYTE PTR [eax]
4a812a: shl eax,0x2
4a812d: lea eax,[eax+eax*2]
4a8130: add eax,0xfffffb82
4a8135: push eax
4a8136: xor ecx,ecx
4a8138: xor edx,edx
4a813a: xor eax,eax
4a813c: call 0x406de4
4a8141: push eax
4a8142: xor ecx,ecx
4a8144: xor edx,edx
4a8146: mov eax,esi
4a8148: call 0x48e444
4a814d: push 0x190
4a8152: push 0x12c
4a8157: xor ecx,ecx
4a8159: xor edx,edx
4a815b: xor eax,eax
4a815d: call 0x406de4
4a8162: push eax
4a8163: mov eax,ds:0x4b0fd4
4a8168: movzx eax,BYTE PTR [eax]
4a816b: shl eax,0x2
4a816e: lea eax,[eax+eax*2]
4a8171: mov ecx,0x5aa
4a8176: sub ecx,eax
4a8178: mov edx,0xc8
4a817d: mov eax,esi
4a817f: call 0x48e444
4a8184: mov eax,ds:0x4b0f1c
4a8189: cmp BYTE PTR [eax],0x3
4a818c: jne 0x4a822b
4a8192: xor eax,eax
4a8194: mov DWORD PTR [ebp-0x10],eax
4a8197: mov eax,ds:0x4b0fd4
4a819c: movzx eax,BYTE PTR [eax]
4a819f: mov edx,eax
4a81a1: shl eax,0x4
4a81a4: add eax,edx
4a81a6: add eax,0xfffff97a
4a81ab: push eax
4a81ac: mov eax,DWORD PTR [ebp-0x10]
4a81af: shl eax,0x4
4a81b2: lea eax,[eax+eax*4]
4a81b5: add eax,0x28
4a81b8: push eax
4a81b9: xor ecx,ecx
4a81bb: xor edx,edx
4a81bd: xor eax,eax
4a81bf: call 0x406de4
4a81c4: push eax
4a81c5: mov ecx,DWORD PTR [ebp-0x10]
4a81c8: shl ecx,0x4
4a81cb: lea ecx,[ecx+ecx*4]
4a81ce: xor edx,edx
4a81d0: mov eax,esi
4a81d2: call 0x48e444
4a81d7: push 0x190
4a81dc: mov eax,DWORD PTR [ebp-0x10]
4a81df: shl eax,0x4
4a81e2: lea eax,[eax+eax*4]
4a81e5: add eax,0x50
4a81e8: push eax
4a81e9: xor ecx,ecx
4a81eb: xor edx,edx
4a81ed: xor eax,eax
4a81ef: call 0x406de4
4a81f4: push eax
4a81f5: mov eax,ds:0x4b0fd4
4a81fa: movzx eax,BYTE PTR [eax]
4a81fd: mov edx,eax
4a81ff: shl eax,0x4
4a8202: add eax,edx
4a8204: mov edx,0x816
4a8209: sub edx,eax
4a820b: mov ecx,DWORD PTR [ebp-0x10]
4a820e: shl ecx,0x4
4a8211: lea ecx,[ecx+ecx*4]
4a8214: add ecx,0x28
4a8217: mov eax,esi
4a8219: call 0x48e444
4a821e: inc DWORD PTR [ebp-0x10]
4a8221: cmp DWORD PTR [ebp-0x10],0x4
4a8225: jne 0x4a8197
4a822b: mov eax,ds:0x4b0f1c
4a8230: cmp BYTE PTR [eax],0x4
4a8233: jne 0x4a82fd
4a8239: push 0x190
4a823e: mov eax,ds:0x4b0fd4
4a8243: movzx eax,BYTE PTR [eax]
4a8246: add eax,eax
4a8248: lea eax,[eax+eax*4]
4a824b: add eax,0xfffffc18
4a8250: push eax
4a8251: xor ecx,ecx
4a8253: xor edx,edx
4a8255: xor eax,eax
4a8257: call 0x406de4
4a825c: push eax
4a825d: xor ecx,ecx
4a825f: xor edx,edx
4a8261: mov eax,esi
4a8263: call 0x48e444
4a8268: push 0x190
4a826d: push 0x12c
4a8272: xor ecx,ecx
4a8274: xor edx,edx
4a8276: xor eax,eax
4a8278: call 0x406de4
4a827d: push eax
4a827e: mov eax,ds:0x4b0fd4
4a8283: movzx eax,BYTE PTR [eax]
4a8286: add eax,eax
4a8288: lea eax,[eax+eax*4]
4a828b: mov ecx,0x514
4a8290: sub ecx,eax
4a8292: xor edx,edx
4a8294: mov eax,esi
4a8296: call 0x48e444
4a829b: mov eax,ds:0x4b0fd4
4a82a0: movzx eax,BYTE PTR [eax]
4a82a3: add eax,eax
4a82a5: lea eax,[eax+eax*4]
4a82a8: add eax,0xfffffc18
4a82ad: push eax
4a82ae: push 0x12c
4a82b3: xor ecx,ecx
4a82b5: xor edx,edx
4a82b7: xor eax,eax
4a82b9: call 0x406de4
4a82be: push eax
4a82bf: xor ecx,ecx
4a82c1: xor edx,edx
4a82c3: mov eax,esi
4a82c5: call 0x48e444
4a82ca: push 0x190
4a82cf: push 0x12c
4a82d4: xor ecx,ecx
4a82d6: xor edx,edx
4a82d8: xor eax,eax
4a82da: call 0x406de4
4a82df: push eax
4a82e0: mov eax,ds:0x4b0fd4
4a82e5: movzx eax,BYTE PTR [eax]
4a82e8: add eax,eax
4a82ea: lea eax,[eax+eax*4]
4a82ed: mov edx,0x578
4a82f2: sub edx,eax
4a82f4: xor ecx,ecx
4a82f6: mov eax,esi
4a82f8: call 0x48e444
4a82fd: mov eax,ds:0x4b0ef0
4a8302: mov al,BYTE PTR [eax+0x8c]
4a8308: mov edx,DWORD PTR ds:0x4b113c
4a830e: cmp al,BYTE PTR [edx]
4a8310: jae 0x4a83bf
4a8316: mov eax,ds:0x4b0ef0
4a831b: mov al,BYTE PTR [eax+0x13c]
4a8321: mov edx,DWORD PTR ds:0x4b113c
4a8327: cmp al,BYTE PTR [edx]
4a8329: jae 0x4a83bf
4a832f: mov eax,ds:0x4b0fd4
4a8334: cmp BYTE PTR [eax],0x82
4a8337: jbe 0x4a83bf
4a833d: mov eax,ds:0x4b0db4
4a8342: mov BYTE PTR [eax],0x0
4a8345: mov eax,ds:0x4b0fd4
4a834a: mov BYTE PTR [eax],0x0
4a834d: mov eax,ds:0x4b0d58
4a8352: mov BYTE PTR [eax+0xc],0x0
4a8356: mov dl,0x1
4a8358: mov eax,esi
4a835a: call 0x49a218
4a835f: mov dl,0x2
4a8361: mov eax,esi
4a8363: call 0x49a218
4a8368: mov eax,ds:0x4b10b8
4a836d: cmp BYTE PTR [eax],0x1
4a8370: jne 0x4a837a
4a8372: mov eax,ds:0x4b0eec
4a8377: mov BYTE PTR [eax],0x1e
4a837a: mov eax,ds:0x4b10b8
4a837f: cmp BYTE PTR [eax],0x2
4a8382: jne 0x4a838c
4a8384: mov eax,ds:0x4b0eec
4a8389: mov BYTE PTR [eax],0x3c
4a838c: mov eax,ds:0x4b10b8
4a8391: cmp BYTE PTR [eax],0x3
4a8394: jne 0x4a839e
4a8396: mov eax,ds:0x4b0eec
4a839b: mov BYTE PTR [eax],0x5a
4a839e: mov eax,ds:0x4b10b8
4a83a3: cmp BYTE PTR [eax],0x4
4a83a6: jne 0x4a83b0
4a83a8: mov eax,ds:0x4b0eec
4a83ad: mov BYTE PTR [eax],0x63
4a83b0: mov eax,ds:0x4b0f3c
4a83b5: mov BYTE PTR [eax],0x19
4a83b8: mov eax,ds:0x4b11fc
4a83bd: inc BYTE PTR [eax]
4a83bf: mov eax,ds:0x4b0fd4
4a83c4: cmp BYTE PTR [eax],0xdc
4a83c7: jbe 0x4a85ec
4a83cd: mov eax,ds:0x4b111c
4a83d2: mov BYTE PTR [eax],0x5
4a83d5: mov eax,ds:0x4b1098
4a83da: mov BYTE PTR [eax],0x0
4a83dd: mov eax,ds:0x4b122c
4a83e2: mov BYTE PTR [eax],0x1
4a83e5: xor eax,eax
4a83e7: mov DWORD PTR [ebp-0x10],eax
4a83ea: mov eax,ds:0x4b0ef0
4a83ef: mov BYTE PTR [eax+0x9f],0x0
4a83f6: mov eax,ds:0x4b0ef0
4a83fb: mov BYTE PTR [eax+0x14f],0x0
4a8402: mov eax,ds:0x4b11fc
4a8407: mov BYTE PTR [eax],0x1
4a840a: mov eax,ds:0x4b0eec
4a840f: mov BYTE PTR [eax],0x14
4a8412: mov eax,ds:0x4b0f3c
4a8417: mov BYTE PTR [eax],0x19
4a841a: mov eax,ds:0x4b0ef0
4a841f: cmp BYTE PTR [eax+0x9e],0x1
4a8426: je 0x4a843a
4a8428: mov eax,ds:0x4b0ef0
4a842d: cmp BYTE PTR [eax+0x14e],0x1
4a8434: jne 0x4a84fc
4a843a: mov eax,ds:0x4b116c
4a843f: cmp BYTE PTR [eax],0x8
4a8442: jbe 0x4a84fc
4a8448: mov eax,ds:0x4b1210
4a844d: cmp BYTE PTR [eax],0x0
4a8450: je 0x4a8479
4a8452: mov eax,DWORD PTR [esi+0x318]
4a8458: mov eax,DWORD PTR [eax+0x28]
4a845b: call 0x40efcc
4a8460: test eax,eax
4a8462: jle 0x4a8479
4a8464: mov eax,DWORD PTR [esi+0x318]
4a846a: mov eax,DWORD PTR [eax+0x28]
4a846d: xor edx,edx
4a846f: call 0x449f54
4a8474: call 0x449e68
4a8479: mov eax,ds:0x4b1094
4a847e: mov BYTE PTR [eax],0x0
4a8481: mov eax,ds:0x4b0fb0
4a8486: mov WORD PTR [eax],0x0
4a848b: mov eax,ds:0x4b1080
4a8490: mov eax,DWORD PTR [eax+0x74]
4a8493: mov edx,DWORD PTR ds:0x4b0ef0
4a8499: cmp eax,DWORD PTR [edx+0x88]
4a849f: jb 0x4a84b7
4a84a1: mov eax,ds:0x4b1080
4a84a6: mov eax,DWORD PTR [eax+0x74]
4a84a9: mov edx,DWORD PTR ds:0x4b0ef0
4a84af: cmp eax,DWORD PTR [edx+0x138]
4a84b5: jae 0x4a84f4
4a84b7: mov eax,ds:0x4b111c
4a84bc: mov BYTE PTR [eax],0xc
4a84bf: mov eax,ds:0x4b0ef0
4a84c4: mov DWORD PTR [eax+0x11],0x41414103
4a84cb: mov eax,ds:0x4b0ef0
4a84d0: mov BYTE PTR [eax+0x8e],0x1
4a84d7: mov eax,ds:0x4b0ef0
4a84dc: mov DWORD PTR [eax+0xc1],0x41414103
4a84e6: mov eax,ds:0x4b0ef0
4a84eb: mov BYTE PTR [eax+0x13e],0x1
4a84f2: jmp 0x4a84fc
4a84f4: mov eax,ds:0x4b111c
4a84f9: mov BYTE PTR [eax],0xa
4a84fc: mov eax,ds:0x4b0ef0
4a8501: cmp BYTE PTR [eax+0x9e],0x0
4a8508: jne 0x4a85ec
4a850e: mov eax,ds:0x4b0ef0
4a8513: cmp BYTE PTR [eax+0x14e],0x0
4a851a: jne 0x4a85ec
4a8520: mov eax,ds:0x4b1210
4a8525: cmp BYTE PTR [eax],0x0
4a8528: je 0x4a8551
4a852a: mov eax,DWORD PTR [esi+0x318]
4a8530: mov eax,DWORD PTR [eax+0x28]
4a8533: call 0x40efcc
4a8538: test eax,eax
4a853a: jle 0x4a8551
4a853c: mov eax,DWORD PTR [esi+0x318]
4a8542: mov eax,DWORD PTR [eax+0x28]
4a8545: xor edx,edx
4a8547: call 0x449f54
4a854c: call 0x449e68
4a8551: mov eax,ds:0x4b1098
4a8556: mov BYTE PTR [eax],0x0
4a8559: mov eax,ds:0x4b1094
4a855e: mov BYTE PTR [eax],0x0
4a8561: mov eax,ds:0x4b0fb0
4a8566: mov WORD PTR [eax],0x0
4a856b: mov eax,ds:0x4b0eec
4a8570: mov BYTE PTR [eax],0x9
4a8573: mov eax,ds:0x4b0f3c
4a8578: mov BYTE PTR [eax],0x19
4a857b: mov eax,ds:0x4b1080
4a8580: mov eax,DWORD PTR [eax+0x74]
4a8583: mov edx,DWORD PTR ds:0x4b0ef0
4a8589: cmp eax,DWORD PTR [edx+0x88]
4a858f: jb 0x4a85a7
4a8591: mov eax,ds:0x4b1080
4a8596: mov eax,DWORD PTR [eax+0x74]
4a8599: mov edx,DWORD PTR ds:0x4b0ef0
4a859f: cmp eax,DWORD PTR [edx+0x138]
4a85a5: jae 0x4a85e4
4a85a7: mov eax,ds:0x4b111c
4a85ac: mov BYTE PTR [eax],0xc
4a85af: mov eax,ds:0x4b0ef0
4a85b4: mov DWORD PTR [eax+0x11],0x41414103
4a85bb: mov eax,ds:0x4b0ef0
4a85c0: mov BYTE PTR [eax+0x8e],0x1
4a85c7: mov eax,ds:0x4b0ef0
4a85cc: mov DWORD PTR [eax+0xc1],0x41414103
4a85d6: mov eax,ds:0x4b0ef0
4a85db: mov BYTE PTR [eax+0x13e],0x1
4a85e2: jmp 0x4a85ec
4a85e4: mov eax,ds:0x4b111c
4a85e9: mov BYTE PTR [eax],0x9
4a85ec: mov DWORD PTR [ebp-0xc],0x1
4a85f3: mov ebx,DWORD PTR ds:0x4b0ef0
4a85f9: add ebx,0x6b
4a85fc: cmp BYTE PTR [ebx],0x11
4a85ff: je 0x4a860a
4a8601: cmp BYTE PTR [ebx],0x12
4a8604: jne 0x4a86c3
4a860a: mov eax,ds:0x4b1074
4a860f: cmp BYTE PTR [eax],0x0
4a8612: jne 0x4a86c3
4a8618: mov eax,ds:0x4b0e84
4a861d: cmp BYTE PTR [eax],0x0
4a8620: jne 0x4a86c3
4a8626: cmp BYTE PTR [ebx+0x2],0x1
4a862a: jne 0x4a8648
4a862c: xor eax,eax
4a862e: mov al,BYTE PTR [ebx+0x7]
4a8631: neg eax
4a8633: mov DWORD PTR [ebp-0x48],eax
4a8636: fild DWORD PTR [ebp-0x48]
4a8639: add esp,0xfffffff8
4a863c: fstp QWORD PTR [esp]
4a863f: fwait
4a8640: mov al,BYTE PTR [ebp-0xc]
4a8643: call 0x47648c
4a8648: cmp BYTE PTR [ebx+0x2],0x2
4a864c: jne 0x4a8668
4a864e: xor eax,eax
4a8650: mov al,BYTE PTR [ebx+0x7]
4a8653: mov DWORD PTR [ebp-0x48],eax
4a8656: fild DWORD PTR [ebp-0x48]
4a8659: add esp,0xfffffff8
4a865c: fstp QWORD PTR [esp]
4a865f: fwait
4a8660: mov al,BYTE PTR [ebp-0xc]
4a8663: call 0x47648c
4a8668: mov eax,0x2
4a866d: call 0x402a1c
4a8672: test eax,eax
4a8674: jne 0x4a86c3
4a8676: mov eax,0x28
4a867b: call 0x402a1c
4a8680: mov DWORD PTR [ebp-0x48],eax
4a8683: fild DWORD PTR [ebp-0x48]
4a8686: fld QWORD PTR [ebx-0x6b]
4a8689: fsub DWORD PTR ds:0x4aeeec
4a868f: faddp st(1),st
4a8691: add esp,0xfffffff8
4a8694: fstp QWORD PTR [esp]
4a8697: fwait
4a8698: mov eax,0xa
4a869d: call 0x402a1c
4a86a2: mov DWORD PTR [ebp-0x1bc],eax
4a86a8: fild DWORD PTR [ebp-0x1bc]
4a86ae: fadd QWORD PTR [ebx-0x63]
4a86b1: add esp,0xfffffff8
4a86b4: fstp QWORD PTR [esp]
4a86b7: fwait
4a86b8: xor ecx,ecx
4a86ba: xor edx,edx
4a86bc: mov al,0x2
4a86be: call 0x476a04
4a86c3: fld QWORD PTR [ebx-0x6b]
4a86c6: call 0x402894
4a86cb: add eax,DWORD PTR [ebx-0x3b]
4a86ce: mov edx,DWORD PTR ds:0x4b1108
4a86d4: mov DWORD PTR [edx],eax
4a86d6: fld QWORD PTR [ebx-0x63]
4a86d9: call 0x402894
4a86de: movsx edx,WORD PTR [ebx+0xf]
4a86e2: sub eax,edx
4a86e4: add eax,DWORD PTR [ebx-0x37]
4a86e7: mov edx,DWORD PTR ds:0x4b108c
4a86ed: mov DWORD PTR [edx],eax
4a86ef: fld QWORD PTR [ebx-0x6b]
4a86f2: call 0x402894
4a86f7: add eax,DWORD PTR [ebx-0x33]
4a86fa: mov edx,DWORD PTR ds:0x4b1130
4a8700: mov DWORD PTR [edx],eax
4a8702: fld QWORD PTR [ebx-0x63]
4a8705: call 0x402894
4a870a: movsx edx,WORD PTR [ebx+0xf]
4a870e: sub eax,edx
4a8710: add eax,DWORD PTR [ebx-0x2f]
4a8713: mov edx,DWORD PTR ds:0x4b10c4
4a8719: mov DWORD PTR [edx],eax
4a871b: mov eax,0x3
4a8720: sub eax,DWORD PTR [ebp-0xc]
4a8723: imul eax,eax,0x16
4a8726: mov edx,DWORD PTR ds:0x4b0ef0
4a872c: fld QWORD PTR [edx+eax*8-0xb0]
4a8733: call 0x402894
4a8738: mov edx,0x3
4a873d: sub edx,DWORD PTR [ebp-0xc]
4a8740: imul edx,edx,0x16
4a8743: mov ecx,DWORD PTR ds:0x4b0ef0
4a8749: add eax,DWORD PTR [ecx+edx*8-0x90]
4a8750: mov edx,DWORD PTR ds:0x4b0f18
4a8756: mov DWORD PTR [edx],eax
4a8758: mov eax,0x3
4a875d: sub eax,DWORD PTR [ebp-0xc]
4a8760: imul eax,eax,0x16
4a8763: mov edx,DWORD PTR ds:0x4b0ef0
4a8769: fld QWORD PTR [edx+eax*8-0xa8]
4a8770: call 0x402894
4a8775: mov edx,0x3
4a877a: sub edx,DWORD PTR [ebp-0xc]
4a877d: imul edx,edx,0x16
4a8780: mov ecx,DWORD PTR ds:0x4b0ef0
4a8786: movsx edx,WORD PTR [ecx+edx*8-0x36]
4a878b: sub eax,edx
4a878d: mov edx,0x3
4a8792: sub edx,DWORD PTR [ebp-0xc]
4a8795: imul edx,edx,0x16
4a8798: mov ecx,DWORD PTR ds:0x4b0ef0
4a879e: add eax,DWORD PTR [ecx+edx*8-0x8c]
4a87a5: mov edx,DWORD PTR ds:0x4b0e80
4a87ab: mov DWORD PTR [edx],eax
4a87ad: mov eax,0x3
4a87b2: sub eax,DWORD PTR [ebp-0xc]
4a87b5: imul eax,eax,0x16
4a87b8: mov edx,DWORD PTR ds:0x4b0ef0
4a87be: fld QWORD PTR [edx+eax*8-0xb0]
4a87c5: call 0x402894
4a87ca: mov edx,0x3
4a87cf: sub edx,DWORD PTR [ebp-0xc]
4a87d2: imul edx,edx,0x16
4a87d5: mov ecx,DWORD PTR ds:0x4b0ef0
4a87db: add eax,DWORD PTR [ecx+edx*8-0x88]
4a87e2: mov edx,DWORD PTR ds:0x4b0f50
4a87e8: mov DWORD PTR [edx],eax
4a87ea: mov eax,0x3
4a87ef: sub eax,DWORD PTR [ebp-0xc]
4a87f2: imul eax,eax,0x16
4a87f5: mov edx,DWORD PTR ds:0x4b0ef0
4a87fb: fld QWORD PTR [edx+eax*8-0xa8]
4a8802: call 0x402894
4a8807: mov edx,0x3
4a880c: sub edx,DWORD PTR [ebp-0xc]
4a880f: imul edx,edx,0x16
4a8812: mov ecx,DWORD PTR ds:0x4b0ef0
4a8818: movsx edx,WORD PTR [ecx+edx*8-0x36]
4a881d: sub eax,edx
4a881f: mov edx,0x3
4a8824: sub edx,DWORD PTR [ebp-0xc]
4a8827: imul edx,edx,0x16
4a882a: mov ecx,DWORD PTR ds:0x4b0ef0
4a8830: add eax,DWORD PTR [ecx+edx*8-0x84]
4a8837: mov edx,DWORD PTR ds:0x4b0ebc
4a883d: mov DWORD PTR [edx],eax
4a883f: cmp BYTE PTR [ebx-0x3],0x1
4a8843: jne 0x4a9435
4a8849: mov eax,0x3
4a884e: sub eax,DWORD PTR [ebp-0xc]
4a8851: imul eax,eax,0x16
4a8854: mov edx,DWORD PTR ds:0x4b0ef0
4a885a: cmp BYTE PTR [edx+eax*8-0x1e],0x0
4a885f: jne 0x4a9435
4a8865: mov eax,ds:0x4b1108
4a886a: mov eax,DWORD PTR [eax]
4a886c: mov edx,DWORD PTR ds:0x4b0f50
4a8872: cmp eax,DWORD PTR [edx]
4a8874: jge 0x4a9435
4a887a: mov eax,ds:0x4b1130
4a887f: mov eax,DWORD PTR [eax]
4a8881: mov edx,DWORD PTR ds:0x4b0f18
4a8887: cmp eax,DWORD PTR [edx]
4a8889: jle 0x4a9435
4a888f: mov eax,ds:0x4b108c
4a8894: mov eax,DWORD PTR [eax]
4a8896: mov edx,DWORD PTR ds:0x4b0ebc
4a889c: cmp eax,DWORD PTR [edx]
4a889e: jge 0x4a9435
4a88a4: mov eax,ds:0x4b10c4
4a88a9: mov eax,DWORD PTR [eax]
4a88ab: mov edx,DWORD PTR ds:0x4b0e80
4a88b1: cmp eax,DWORD PTR [edx]
4a88b3: jle 0x4a9435
4a88b9: mov eax,ds:0x4b0e84
4a88be: cmp BYTE PTR [eax],0x0
4a88c1: jne 0x4a9435
4a88c7: mov eax,ds:0x4b1074
4a88cc: cmp BYTE PTR [eax],0x0
4a88cf: jne 0x4a9435
4a88d5: cmp BYTE PTR [ebx],0x9
4a88d8: je 0x4a88df
4a88da: cmp BYTE PTR [ebx],0xb
4a88dd: jne 0x4a890d
4a88df: mov eax,0x3
4a88e4: sub eax,DWORD PTR [ebp-0xc]
4a88e7: imul eax,eax,0x16
4a88ea: mov edx,DWORD PTR ds:0x4b0ef0
4a88f0: cmp BYTE PTR [edx+eax*8-0x45],0x15
4a88f5: jne 0x4a890d
4a88f7: mov eax,0x3
4a88fc: sub eax,DWORD PTR [ebp-0xc]
4a88ff: imul eax,eax,0x16
4a8902: mov edx,DWORD PTR ds:0x4b0ef0
4a8908: mov BYTE PTR [edx+eax*8-0x1d],0x0
4a890d: cmp BYTE PTR [ebx],0xd
4a8910: je 0x4a8921
4a8912: cmp BYTE PTR [ebx],0xe
4a8915: je 0x4a8921
4a8917: cmp BYTE PTR [ebx],0xf
4a891a: je 0x4a8921
4a891c: cmp BYTE PTR [ebx],0x10
4a891f: jne 0x4a894f
4a8921: mov eax,0x3
4a8926: sub eax,DWORD PTR [ebp-0xc]
4a8929: imul eax,eax,0x16
4a892c: mov edx,DWORD PTR ds:0x4b0ef0
4a8932: cmp BYTE PTR [edx+eax*8-0x45],0x16
4a8937: jne 0x4a894f
4a8939: mov eax,0x3
4a893e: sub eax,DWORD PTR [ebp-0xc]
4a8941: imul eax,eax,0x16
4a8944: mov edx,DWORD PTR ds:0x4b0ef0
4a894a: mov BYTE PTR [edx+eax*8-0x1d],0x0
4a894f: mov eax,0x3
4a8954: sub eax,DWORD PTR [ebp-0xc]
4a8957: imul eax,eax,0x16
4a895a: mov edx,DWORD PTR ds:0x4b0ef0
4a8960: cmp BYTE PTR [edx+eax*8-0x1d],0x1
4a8965: jne 0x4a8b55
4a896b: mov eax,0x3
4a8970: sub eax,DWORD PTR [ebp-0xc]
4a8973: imul eax,eax,0x16
4a8976: mov edx,DWORD PTR ds:0x4b0ef0
4a897c: mov WORD PTR [edx+eax*8-0x3c],0x1
4a8983: mov eax,ds:0x4b1098
4a8988: mov BYTE PTR [eax],0xa
4a898b: mov eax,DWORD PTR [ebx-0x3b]
4a898e: add eax,DWORD PTR [ebx-0x33]
4a8991: mov DWORD PTR [ebp-0x48],eax
4a8994: fild DWORD PTR [ebp-0x48]
4a8997: fdiv DWORD PTR ds:0x4aec88
4a899d: call 0x402894
4a89a2: mov DWORD PTR [ebp-0x2b0],eax
4a89a8: mov DWORD PTR [ebp-0x2ac],edx
4a89ae: fild QWORD PTR [ebp-0x2b0]
4a89b4: fadd QWORD PTR [ebx-0x6b]
4a89b7: add esp,0xfffffff8
4a89ba: fstp QWORD PTR [esp]
4a89bd: fwait
4a89be: mov eax,DWORD PTR [ebx-0x37]
4a89c1: add eax,DWORD PTR [ebx-0x2f]
4a89c4: mov DWORD PTR [ebp-0x1bc],eax
4a89ca: fild DWORD PTR [ebp-0x1bc]
4a89d0: fdiv DWORD PTR ds:0x4aec88
4a89d6: call 0x402894
4a89db: mov DWORD PTR [ebp-0x2b8],eax
4a89e1: mov DWORD PTR [ebp-0x2b4],edx
4a89e7: fild QWORD PTR [ebp-0x2b8]
4a89ed: fild WORD PTR [ebx+0xf]
4a89f0: fsubr QWORD PTR [ebx-0x63]
4a89f3: faddp st(1),st
4a89f5: add esp,0xfffffff8
4a89f8: fstp QWORD PTR [esp]
4a89fb: fwait
4a89fc: xor ecx,ecx
4a89fe: xor edx,edx
4a8a00: mov al,0xe
4a8a02: call 0x476a04
4a8a07: mov eax,0x3
4a8a0c: sub eax,DWORD PTR [ebp-0xc]
4a8a0f: imul eax,eax,0x16
4a8a12: mov edx,DWORD PTR ds:0x4b0ef0
4a8a18: cmp BYTE PTR [edx+eax*8-0x43],0x1
4a8a1d: jne 0x4a8a30
4a8a1f: push 0xc0240000
4a8a24: push 0x0
4a8a26: mov al,0x3
4a8a28: sub al,BYTE PTR [ebp-0xc]
4a8a2b: call 0x47648c
4a8a30: mov eax,0x3
4a8a35: sub eax,DWORD PTR [ebp-0xc]
4a8a38: imul eax,eax,0x16
4a8a3b: mov edx,DWORD PTR ds:0x4b0ef0
4a8a41: cmp BYTE PTR [edx+eax*8-0x43],0x2
4a8a46: jne 0x4a8a59
4a8a48: push 0x40240000
4a8a4d: push 0x0
4a8a4f: mov al,0x3
4a8a51: sub al,BYTE PTR [ebp-0xc]
4a8a54: call 0x47648c
4a8a59: mov eax,ds:0x4b1004
4a8a5e: cmp BYTE PTR [eax],0x0
4a8a61: jne 0x4a8ac9
4a8a63: mov eax,ds:0x4b110c
4a8a68: cmp BYTE PTR [eax],0x0
4a8a6b: jne 0x4a8ac9
4a8a6d: xor eax,eax
4a8a6f: mov al,BYTE PTR [ebx+0x6]
4a8a72: mov DWORD PTR [ebp-0x48],eax
4a8a75: fild DWORD PTR [ebp-0x48]
4a8a78: mov eax,ds:0x4b11f4
4a8a7d: fmul QWORD PTR [eax]
4a8a7f: mov eax,0x3
4a8a84: sub eax,DWORD PTR [ebp-0xc]
4a8a87: imul eax,eax,0x16
4a8a8a: mov edx,DWORD PTR ds:0x4b0ef0
4a8a90: fsubr QWORD PTR [edx+eax*8-0x70]
4a8a94: mov eax,0x3
4a8a99: sub eax,DWORD PTR [ebp-0xc]
4a8a9c: imul eax,eax,0x16
4a8a9f: mov edx,DWORD PTR ds:0x4b0ef0
4a8aa5: fstp QWORD PTR [edx+eax*8-0x70]
4a8aa9: fwait
4a8aaa: mov eax,0x3
4a8aaf: sub eax,DWORD PTR [ebp-0xc]
4a8ab2: imul eax,eax,0x16
4a8ab5: mov edx,DWORD PTR ds:0x4b0ef0
4a8abb: xor ecx,ecx
4a8abd: mov DWORD PTR [edx+eax*8-0x60],ecx
4a8ac1: mov DWORD PTR [edx+eax*8-0x5c],0x40340000
4a8ac9: mov eax,0x3
4a8ace: sub eax,DWORD PTR [ebp-0xc]
4a8ad1: imul eax,eax,0x16
4a8ad4: mov edx,DWORD PTR ds:0x4b0ef0
4a8ada: fld QWORD PTR [edx+eax*8-0x70]
4a8ade: fcomp DWORD PTR ds:0x4aef3c
4a8ae4: fnstsw ax
4a8ae6: sahf
4a8ae7: ja 0x4a8afd
4a8ae9: mov eax,ds:0x4b1098
4a8aee: mov BYTE PTR [eax],0x9
4a8af1: mov al,0x3
4a8af3: sub al,BYTE PTR [ebp-0xc]
4a8af6: mov dl,0xa
4a8af8: call 0x4775fc
4a8afd: mov BYTE PTR [ebx-0x3],0x0
4a8b01: mov eax,0x3
4a8b06: sub eax,DWORD PTR [ebp-0xc]
4a8b09: imul eax,eax,0x16
4a8b0c: mov edx,DWORD PTR ds:0x4b0ef0
4a8b12: fld QWORD PTR [edx+eax*8-0x70]
4a8b16: fcomp DWORD PTR ds:0x4aef3c
4a8b1c: fnstsw ax
4a8b1e: sahf
4a8b1f: jbe 0x4a8b55
4a8b21: cmp BYTE PTR [ebx+0x4],0x1
4a8b25: jne 0x4a8b3b
4a8b27: mov eax,0x4
4a8b2c: call 0x402a1c
4a8b31: add al,0x2
4a8b33: mov edx,DWORD PTR ds:0x4b0e84
4a8b39: mov BYTE PTR [edx],al
4a8b3b: cmp BYTE PTR [ebx+0x4],0x2
4a8b3f: jne 0x4a8b55
4a8b41: mov eax,0x4
4a8b46: call 0x402a1c
4a8b4b: add al,0x4
4a8b4d: mov edx,DWORD PTR ds:0x4b0e84
4a8b53: mov BYTE PTR [edx],al
4a8b55: mov eax,0x3
4a8b5a: sub eax,DWORD PTR [ebp-0xc]
4a8b5d: imul eax,eax,0x16
4a8b60: mov edx,DWORD PTR ds:0x4b0ef0
4a8b66: cmp BYTE PTR [edx+eax*8-0x1d],0x0
4a8b6b: jne 0x4a93b1
4a8b71: mov eax,0x3
4a8b76: sub eax,DWORD PTR [ebp-0xc]
4a8b79: imul eax,eax,0x16
4a8b7c: mov edx,DWORD PTR ds:0x4b0ef0
4a8b82: fld QWORD PTR [edx+eax*8-0xb0]
4a8b89: fcomp QWORD PTR [ebx-0x6b]
4a8b8c: fnstsw ax
4a8b8e: sahf
4a8b8f: jae 0x4a8ba7
4a8b91: mov eax,0x3
4a8b96: sub eax,DWORD PTR [ebp-0xc]
4a8b99: imul eax,eax,0x16
4a8b9c: mov edx,DWORD PTR ds:0x4b0ef0
4a8ba2: mov BYTE PTR [edx+eax*8-0x43],0x1
4a8ba7: mov eax,0x3
4a8bac: sub eax,DWORD PTR [ebp-0xc]
4a8baf: imul eax,eax,0x16
4a8bb2: mov edx,DWORD PTR ds:0x4b0ef0
4a8bb8: fld QWORD PTR [edx+eax*8-0xb0]
4a8bbf: fcomp QWORD PTR [ebx-0x6b]
4a8bc2: fnstsw ax
4a8bc4: sahf
4a8bc5: jb 0x4a8bdd
4a8bc7: mov eax,0x3
4a8bcc: sub eax,DWORD PTR [ebp-0xc]
4a8bcf: imul eax,eax,0x16
4a8bd2: mov edx,DWORD PTR ds:0x4b0ef0
4a8bd8: mov BYTE PTR [edx+eax*8-0x43],0x2
4a8bdd: cmp BYTE PTR [ebx+0x33],0x1
4a8be1: jne 0x4a8c1b
4a8be3: mov eax,0x3
4a8be8: sub eax,DWORD PTR [ebp-0xc]
4a8beb: imul eax,eax,0x16
4a8bee: mov edx,DWORD PTR ds:0x4b0ef0
4a8bf4: fld QWORD PTR [edx+eax*8-0x70]
4a8bf8: fcomp DWORD PTR ds:0x4aef3c
4a8bfe: fnstsw ax
4a8c00: sahf
4a8c01: jbe 0x4a8c1b
4a8c03: mov eax,ds:0x4b0e84
4a8c08: cmp BYTE PTR [eax],0x0
4a8c0b: jne 0x4a8c1b
4a8c0d: mov eax,ds:0x4b1074
4a8c12: cmp BYTE PTR [eax],0x0
4a8c15: jne 0x4a8c1b
4a8c17: add DWORD PTR [ebx+0x1d],0x5
4a8c1b: fld QWORD PTR [ebx-0xb]
4a8c1e: fcomp DWORD PTR ds:0x4aef80
4a8c24: fnstsw ax
4a8c26: sahf
4a8c27: jae 0x4a8c3d
4a8c29: fld DWORD PTR ds:0x4aec88
4a8c2f: mov eax,ds:0x4b0fe8
4a8c34: fmul QWORD PTR [eax]
4a8c36: fadd QWORD PTR [ebx-0xb]
4a8c39: fstp QWORD PTR [ebx-0xb]
4a8c3c: fwait
4a8c3d: mov eax,0x3
4a8c42: sub eax,DWORD PTR [ebp-0xc]
4a8c45: imul eax,eax,0x16
4a8c48: mov edx,DWORD PTR ds:0x4b0ef0
4a8c4e: fld QWORD PTR [edx+eax*8-0x50]
4a8c52: fcomp DWORD PTR ds:0x4aef80
4a8c58: fnstsw ax
4a8c5a: sahf
4a8c5b: jae 0x4a8c95
4a8c5d: fld DWORD PTR ds:0x4aef54
4a8c63: mov eax,ds:0x4b0fe8
4a8c68: fmul QWORD PTR [eax]
4a8c6a: mov eax,0x3
4a8c6f: sub eax,DWORD PTR [ebp-0xc]
4a8c72: imul eax,eax,0x16
4a8c75: mov edx,DWORD PTR ds:0x4b0ef0
4a8c7b: fadd QWORD PTR [edx+eax*8-0x50]
4a8c7f: mov eax,0x3
4a8c84: sub eax,DWORD PTR [ebp-0xc]
4a8c87: imul eax,eax,0x16
4a8c8a: mov edx,DWORD PTR ds:0x4b0ef0
4a8c90: fstp QWORD PTR [edx+eax*8-0x50]
4a8c94: fwait
4a8c95: cmp BYTE PTR [ebx+0x2b],0x23
4a8c99: ja 0x4a8c9f
4a8c9b: mov BYTE PTR [ebx+0x2a],0x0
4a8c9f: inc BYTE PTR [ebx+0x2a]
4a8ca2: mov BYTE PTR [ebx+0x2b],0x2c
4a8ca6: cmp BYTE PTR [ebx],0xb
4a8ca9: jne 0x4a8caf
4a8cab: mov BYTE PTR [ebx+0x2b],0x32
4a8caf: cmp BYTE PTR [ebx],0x10
4a8cb2: jne 0x4a8cb8
4a8cb4: mov BYTE PTR [ebx+0x2b],0x32
4a8cb8: cmp BYTE PTR [ebx-0x5b],0x4
4a8cbc: jne 0x4a8cc7
4a8cbe: cmp BYTE PTR [ebx],0x1a
4a8cc1: jne 0x4a8cc7
4a8cc3: mov BYTE PTR [ebx+0x2b],0x2e
4a8cc7: cmp BYTE PTR [ebx-0x5b],0x4
4a8ccb: jne 0x4a8cd6
4a8ccd: cmp BYTE PTR [ebx],0x1b
4a8cd0: jne 0x4a8cd6
4a8cd2: mov BYTE PTR [ebx+0x2b],0x2f
4a8cd6: cmp BYTE PTR [ebx-0x5b],0x6
4a8cda: jne 0x4a8ce5
4a8cdc: cmp BYTE PTR [ebx],0x1d
4a8cdf: jne 0x4a8ce5
4a8ce1: mov BYTE PTR [ebx+0x2b],0x32
4a8ce5: cmp BYTE PTR [ebx-0x5b],0xf
4a8ce9: jne 0x4a8cf4
4a8ceb: cmp BYTE PTR [ebx],0x1b
4a8cee: jne 0x4a8cf4
4a8cf0: mov BYTE PTR [ebx+0x2b],0x32
4a8cf4: mov eax,ds:0x4b1004
4a8cf9: cmp BYTE PTR [eax],0x0
4a8cfc: jne 0x4a8d64
4a8cfe: mov eax,ds:0x4b110c
4a8d03: cmp BYTE PTR [eax],0x0
4a8d06: jne 0x4a8d64
4a8d08: xor eax,eax
4a8d0a: mov al,BYTE PTR [ebx+0x5]
4a8d0d: mov DWORD PTR [ebp-0x48],eax
4a8d10: fild DWORD PTR [ebp-0x48]
4a8d13: mov eax,ds:0x4b11f4
4a8d18: fmul QWORD PTR [eax]
4a8d1a: mov eax,0x3
4a8d1f: sub eax,DWORD PTR [ebp-0xc]
4a8d22: imul eax,eax,0x16
4a8d25: mov edx,DWORD PTR ds:0x4b0ef0
4a8d2b: fsubr QWORD PTR [edx+eax*8-0x70]
4a8d2f: mov eax,0x3
4a8d34: sub eax,DWORD PTR [ebp-0xc]
4a8d37: imul eax,eax,0x16
4a8d3a: mov edx,DWORD PTR ds:0x4b0ef0
4a8d40: fstp QWORD PTR [edx+eax*8-0x70]
4a8d44: fwait
4a8d45: mov eax,0x3
4a8d4a: sub eax,DWORD PTR [ebp-0xc]
4a8d4d: imul eax,eax,0x16
4a8d50: mov edx,DWORD PTR ds:0x4b0ef0
4a8d56: xor ecx,ecx
4a8d58: mov DWORD PTR [edx+eax*8-0x60],ecx
4a8d5c: mov DWORD PTR [edx+eax*8-0x5c],0x40340000
4a8d64: mov eax,ds:0x4b0d98
4a8d69: cmp BYTE PTR [eax],0x1
4a8d6c: jne 0x4a8da6
4a8d6e: cmp BYTE PTR [ebx+0x4],0x1
4a8d72: jne 0x4a8d8a
4a8d74: mov eax,0x5
4a8d79: call 0x402a1c
4a8d7e: test eax,eax
4a8d80: jne 0x4a8d8a
4a8d82: mov eax,ds:0x4b0fc8
4a8d87: mov BYTE PTR [eax],0x6
4a8d8a: cmp BYTE PTR [ebx+0x4],0x2
4a8d8e: jne 0x4a8da6
4a8d90: mov eax,0x2
4a8d95: call 0x402a1c
4a8d9a: test eax,eax
4a8d9c: jne 0x4a8da6
4a8d9e: mov eax,ds:0x4b0fc8
4a8da3: mov BYTE PTR [eax],0x6
4a8da6: mov eax,0x3
4a8dab: sub eax,DWORD PTR [ebp-0xc]
4a8dae: imul eax,eax,0x16
4a8db1: mov edx,DWORD PTR ds:0x4b0ef0
4a8db7: fld QWORD PTR [edx+eax*8-0x70]
4a8dbb: fcomp DWORD PTR ds:0x4aef3c
4a8dc1: fnstsw ax
4a8dc3: sahf
4a8dc4: ja 0x4a8dda
4a8dc6: mov eax,ds:0x4b1098
4a8dcb: mov BYTE PTR [eax],0x8
4a8dce: mov al,0x3
4a8dd0: sub al,BYTE PTR [ebp-0xc]
4a8dd3: mov dl,0xa
4a8dd5: call 0x4775fc
4a8dda: cmp BYTE PTR [ebx-0x5b],0x4
4a8dde: jne 0x4a8de5
4a8de0: cmp BYTE PTR [ebx],0x1d
4a8de3: je 0x4a8e51
4a8de5: cmp BYTE PTR [ebx-0x5b],0x5
4a8de9: jne 0x4a8df7
4a8deb: cmp BYTE PTR [ebx],0x1d
4a8dee: jne 0x4a8df7
4a8df0: cmp WORD PTR [ebx+0x9],0xf
4a8df5: jge 0x4a8e51
4a8df7: cmp BYTE PTR [ebx-0x5b],0x6
4a8dfb: jne 0x4a8e09
4a8dfd: cmp BYTE PTR [ebx],0x1d
4a8e00: jne 0x4a8e09
4a8e02: cmp WORD PTR [ebx+0x9],0x16
4a8e07: jge 0x4a8e51
4a8e09: cmp BYTE PTR [ebx-0x5b],0x9
4a8e0d: jne 0x4a8e1b
4a8e0f: cmp BYTE PTR [ebx],0x1d
4a8e12: jne 0x4a8e1b
4a8e14: cmp WORD PTR [ebx+0x9],0xe
4a8e19: jge 0x4a8e51
4a8e1b: cmp BYTE PTR [ebx-0x5b],0xa
4a8e1f: jne 0x4a8e2d
4a8e21: cmp BYTE PTR [ebx],0x1d
4a8e24: jne 0x4a8e2d
4a8e26: cmp WORD PTR [ebx+0x9],0xf
4a8e2b: jge 0x4a8e51
4a8e2d: cmp BYTE PTR [ebx-0x5b],0xb
4a8e31: jne 0x4a8e3f
4a8e33: cmp BYTE PTR [ebx],0x1d
4a8e36: jne 0x4a8e3f
4a8e38: cmp WORD PTR [ebx+0x9],0x14
4a8e3d: jge 0x4a8e51
4a8e3f: cmp BYTE PTR [ebx-0x5b],0xc
4a8e43: jne 0x4a8eb7
4a8e45: cmp BYTE PTR [ebx],0x1c
4a8e48: jne 0x4a8eb7
4a8e4a: cmp WORD PTR [ebx+0x9],0x16
4a8e4f: jl 0x4a8eb7
4a8e51: mov eax,0x3
4a8e56: sub eax,DWORD PTR [ebp-0xc]
4a8e59: imul eax,eax,0x16
4a8e5c: mov edx,DWORD PTR ds:0x4b0ef0
4a8e62: cmp BYTE PTR [edx+eax*8-0x43],0x1
4a8e67: jne 0x4a8e84
4a8e69: mov eax,0x3
4a8e6e: sub eax,DWORD PTR [ebp-0xc]
4a8e71: imul eax,eax,0x16
4a8e74: mov edx,DWORD PTR ds:0x4b0ef0
4a8e7a: mov WORD PTR [edx+eax*8-0x98],0xffec
4a8e84: mov eax,0x3
4a8e89: sub eax,DWORD PTR [ebp-0xc]
4a8e8c: imul eax,eax,0x16
4a8e8f: mov edx,DWORD PTR ds:0x4b0ef0
4a8e95: cmp BYTE PTR [edx+eax*8-0x43],0x2
4a8e9a: jne 0x4a8eb7
4a8e9c: mov eax,0x3
4a8ea1: sub eax,DWORD PTR [ebp-0xc]
4a8ea4: imul eax,eax,0x16
4a8ea7: mov edx,DWORD PTR ds:0x4b0ef0
4a8ead: mov WORD PTR [edx+eax*8-0x98],0x14
4a8eb7: mov eax,DWORD PTR [ebx-0x3b]
4a8eba: add eax,DWORD PTR [ebx-0x33]
4a8ebd: mov DWORD PTR [ebp-0x48],eax
4a8ec0: fild DWORD PTR [ebp-0x48]
4a8ec3: fdiv DWORD PTR ds:0x4aec88
4a8ec9: call 0x402894
4a8ece: mov DWORD PTR [ebp-0x2b0],eax
4a8ed4: mov DWORD PTR [ebp-0x2ac],edx
4a8eda: fild QWORD PTR [ebp-0x2b0]
4a8ee0: fadd QWORD PTR [ebx-0x6b]
4a8ee3: add esp,0xfffffff8
4a8ee6: fstp QWORD PTR [esp]
4a8ee9: fwait
4a8eea: mov eax,DWORD PTR [ebx-0x37]
4a8eed: add eax,DWORD PTR [ebx-0x2f]
4a8ef0: mov DWORD PTR [ebp-0x1bc],eax
4a8ef6: fild DWORD PTR [ebp-0x1bc]
4a8efc: fdiv DWORD PTR ds:0x4aec88
4a8f02: call 0x402894
4a8f07: mov DWORD PTR [ebp-0x2b8],eax
4a8f0d: mov DWORD PTR [ebp-0x2b4],edx
4a8f13: fild QWORD PTR [ebp-0x2b8]
4a8f19: fild WORD PTR [ebx+0xf]
4a8f1c: fsubr QWORD PTR [ebx-0x63]
4a8f1f: faddp st(1),st
4a8f21: add esp,0xfffffff8
4a8f24: fstp QWORD PTR [esp]
4a8f27: fwait
4a8f28: xor ecx,ecx
4a8f2a: xor edx,edx
4a8f2c: mov al,0x1
4a8f2e: call 0x476a04
4a8f33: mov eax,ds:0x4b1024
4a8f38: cmp BYTE PTR [eax],0x1
4a8f3b: jne 0x4a8f51
4a8f3d: cmp BYTE PTR [ebx+0x4],0x2
4a8f41: jne 0x4a8f51
4a8f43: mov eax,0x5
4a8f48: call 0x402a1c
4a8f4d: test eax,eax
4a8f4f: je 0x4a8f5b
4a8f51: mov eax,ds:0x4b1058
4a8f56: cmp BYTE PTR [eax],0x1
4a8f59: jne 0x4a8fc3
4a8f5b: mov eax,0x3
4a8f60: sub eax,DWORD PTR [ebp-0xc]
4a8f63: imul eax,eax,0x16
4a8f66: mov edx,DWORD PTR ds:0x4b0ef0
4a8f6c: push DWORD PTR [edx+eax*8-0xac]
4a8f73: push DWORD PTR [edx+eax*8-0xb0]
4a8f7a: mov eax,0x3
4a8f7f: sub eax,DWORD PTR [ebp-0xc]
4a8f82: imul eax,eax,0x16
4a8f85: mov edx,DWORD PTR ds:0x4b0ef0
4a8f8b: movsx eax,WORD PTR [edx+eax*8-0x36]
4a8f90: sub eax,0x28
4a8f93: mov DWORD PTR [ebp-0x48],eax
4a8f96: fild DWORD PTR [ebp-0x48]
4a8f99: mov eax,0x3
4a8f9e: sub eax,DWORD PTR [ebp-0xc]
4a8fa1: imul eax,eax,0x16
4a8fa4: mov edx,DWORD PTR ds:0x4b0ef0
4a8faa: fsubr QWORD PTR [edx+eax*8-0xa8]
4a8fb1: add esp,0xfffffff8
4a8fb4: fstp QWORD PTR [esp]
4a8fb7: fwait
4a8fb8: xor ecx,ecx
4a8fba: xor edx,edx
4a8fbc: mov al,0xa
4a8fbe: call 0x476a04
4a8fc3: cmp BYTE PTR [ebx],0x4
4a8fc6: je 0x4a8fdc
4a8fc8: cmp BYTE PTR [ebx],0x6
4a8fcb: je 0x4a8fdc
4a8fcd: cmp BYTE PTR [ebx],0x8
4a8fd0: je 0x4a8fdc
4a8fd2: cmp BYTE PTR [ebx],0x9
4a8fd5: je 0x4a8fdc
4a8fd7: cmp BYTE PTR [ebx],0xa
4a8fda: jne 0x4a8fea
4a8fdc: mov al,0x3
4a8fde: sub al,BYTE PTR [ebp-0xc]
4a8fe1: mov dl,0x9
4a8fe3: call 0x4775fc
4a8fe8: jmp 0x4a8ff6
4a8fea: mov al,0x3
4a8fec: sub al,BYTE PTR [ebp-0xc]
4a8fef: mov dl,0x8
4a8ff1: call 0x4775fc
4a8ff6: cmp BYTE PTR [ebx-0x2],0x1
4a8ffa: je 0x4a9038
4a8ffc: mov eax,0x3
4a9001: sub eax,DWORD PTR [ebp-0xc]
4a9004: imul eax,eax,0x16
4a9007: mov edx,DWORD PTR ds:0x4b0ef0
4a900d: cmp BYTE PTR [edx+eax*8-0x38],0x0
4a9012: jne 0x4a9038
4a9014: mov eax,ds:0x4b11f8
4a9019: fild WORD PTR [eax]
4a901b: mov eax,0x3
4a9020: sub eax,DWORD PTR [ebp-0xc]
4a9023: imul eax,eax,0x16
4a9026: mov edx,DWORD PTR ds:0x4b0ef0
4a902c: fcomp QWORD PTR [edx+eax*8-0xa8]
4a9033: fnstsw ax
4a9035: sahf
4a9036: jbe 0x4a9044
4a9038: mov al,0x3
4a903a: sub al,BYTE PTR [ebp-0xc]
4a903d: mov dl,0xa
4a903f: call 0x4775fc
4a9044: mov eax,0x3
4a9049: sub eax,DWORD PTR [ebp-0xc]
4a904c: imul eax,eax,0x16
4a904f: mov edx,DWORD PTR ds:0x4b0ef0
4a9055: mov BYTE PTR [edx+eax*8-0x3e],0x4
4a905a: cmp BYTE PTR [ebx-0x5b],0x1
4a905e: jne 0x4a9081
4a9060: cmp BYTE PTR [ebx],0x1a
4a9063: jne 0x4a9081
4a9065: cmp BYTE PTR [ebx+0x4],0x2
4a9069: jne 0x4a9081
4a906b: mov eax,0x3
4a9070: sub eax,DWORD PTR [ebp-0xc]
4a9073: imul eax,eax,0x16
4a9076: mov edx,DWORD PTR ds:0x4b0ef0
4a907c: mov BYTE PTR [edx+eax*8-0x3e],0x14
4a9081: cmp BYTE PTR [ebx-0x5b],0x2
4a9085: jne 0x4a90a8
4a9087: cmp BYTE PTR [ebx],0x1a
4a908a: jne 0x4a90a8
4a908c: cmp BYTE PTR [ebx+0x4],0x2
4a9090: jne 0x4a90a8
4a9092: mov eax,0x3
4a9097: sub eax,DWORD PTR [ebp-0xc]
4a909a: imul eax,eax,0x16
4a909d: mov edx,DWORD PTR ds:0x4b0ef0
4a90a3: mov BYTE PTR [edx+eax*8-0x3e],0xd
4a90a8: cmp BYTE PTR [ebx-0x5b],0x4
4a90ac: jne 0x4a90c9
4a90ae: cmp BYTE PTR [ebx],0x1d
4a90b1: jne 0x4a90c9
4a90b3: mov eax,0x3
4a90b8: sub eax,DWORD PTR [ebp-0xc]
4a90bb: imul eax,eax,0x16
4a90be: mov edx,DWORD PTR ds:0x4b0ef0
4a90c4: mov BYTE PTR [edx+eax*8-0x3e],0x14
4a90c9: cmp BYTE PTR [ebx-0x5b],0x6
4a90cd: jne 0x4a90f0
4a90cf: cmp BYTE PTR [ebx],0x1b
4a90d2: jne 0x4a90f0
4a90d4: cmp BYTE PTR [ebx+0x4],0x2
4a90d8: jne 0x4a90f0
4a90da: mov eax,0x3
4a90df: sub eax,DWORD PTR [ebp-0xc]
4a90e2: imul eax,eax,0x16
4a90e5: mov edx,DWORD PTR ds:0x4b0ef0
4a90eb: mov BYTE PTR [edx+eax*8-0x3e],0x19
4a90f0: cmp BYTE PTR [ebx-0x5b],0x7
4a90f4: jne 0x4a9117
4a90f6: cmp BYTE PTR [ebx],0x1b
4a90f9: jne 0x4a9117
4a90fb: cmp BYTE PTR [ebx+0x4],0x2
4a90ff: jne 0x4a9117
4a9101: mov eax,0x3
4a9106: sub eax,DWORD PTR [ebp-0xc]
4a9109: imul eax,eax,0x16
4a910c: mov edx,DWORD PTR ds:0x4b0ef0
4a9112: mov BYTE PTR [edx+eax*8-0x3e],0x12
4a9117: cmp BYTE PTR [ebx-0x5b],0x9
4a911b: jne 0x4a913f
4a911d: cmp BYTE PTR [ebx],0x1d
4a9120: jne 0x4a913f
4a9122: cmp WORD PTR [ebx+0x9],0xf
4a9127: jl 0x4a913f
4a9129: mov eax,0x3
4a912e: sub eax,DWORD PTR [ebp-0xc]
4a9131: imul eax,eax,0x16
4a9134: mov edx,DWORD PTR ds:0x4b0ef0
4a913a: mov BYTE PTR [edx+eax*8-0x3e],0x19
4a913f: cmp BYTE PTR [ebx-0x5b],0xa
4a9143: jne 0x4a9166
4a9145: cmp BYTE PTR [ebx],0x1c
4a9148: jne 0x4a9166
4a914a: cmp BYTE PTR [ebx+0x4],0x2
4a914e: jne 0x4a9166
4a9150: mov eax,0x3
4a9155: sub eax,DWORD PTR [ebp-0xc]
4a9158: imul eax,eax,0x16
4a915b: mov edx,DWORD PTR ds:0x4b0ef0
4a9161: mov BYTE PTR [edx+eax*8-0x3e],0xd
4a9166: cmp BYTE PTR [ebx-0x5b],0xc
4a916a: jne 0x4a918d
4a916c: cmp BYTE PTR [ebx],0x1a
4a916f: jne 0x4a918d
4a9171: cmp BYTE PTR [ebx+0x4],0x2
4a9175: jne 0x4a918d
4a9177: mov eax,0x3
4a917c: sub eax,DWORD PTR [ebp-0xc]
4a917f: imul eax,eax,0x16
4a9182: mov edx,DWORD PTR ds:0x4b0ef0
4a9188: mov BYTE PTR [edx+eax*8-0x3e],0x19
4a918d: cmp BYTE PTR [ebx-0x5b],0x4
4a9191: jne 0x4a91ae
4a9193: cmp BYTE PTR [ebx],0x1d
4a9196: jne 0x4a91ae
4a9198: mov eax,0x3
4a919d: sub eax,DWORD PTR [ebp-0xc]
4a91a0: imul eax,eax,0x16
4a91a3: mov edx,DWORD PTR ds:0x4b0ef0
4a91a9: mov BYTE PTR [edx+eax*8-0x38],0xe2
4a91ae: cmp BYTE PTR [ebx-0x5b],0x5
4a91b2: jne 0x4a91d6
4a91b4: cmp BYTE PTR [ebx],0x1d
4a91b7: jne 0x4a91d6
4a91b9: cmp WORD PTR [ebx+0x9],0xf
4a91be: jl 0x4a91d6
4a91c0: mov eax,0x3
4a91c5: sub eax,DWORD PTR [ebp-0xc]
4a91c8: imul eax,eax,0x16
4a91cb: mov edx,DWORD PTR ds:0x4b0ef0
4a91d1: mov BYTE PTR [edx+eax*8-0x38],0xe2
4a91d6: cmp BYTE PTR [ebx-0x5b],0xf
4a91da: jne 0x4a91f7
4a91dc: cmp BYTE PTR [ebx],0x1b
4a91df: jne 0x4a91f7
4a91e1: mov eax,0x3
4a91e6: sub eax,DWORD PTR [ebp-0xc]
4a91e9: imul eax,eax,0x16
4a91ec: mov edx,DWORD PTR ds:0x4b0ef0
4a91f2: mov BYTE PTR [edx+eax*8-0x38],0xe6
4a91f7: cmp BYTE PTR [ebx+0x4],0x1
4a91fb: jne 0x4a9205
4a91fd: mov eax,ds:0x4b1098
4a9202: mov BYTE PTR [eax],0x7
4a9205: cmp BYTE PTR [ebx+0x4],0x2
4a9209: jne 0x4a9213
4a920b: mov eax,ds:0x4b1098
4a9210: mov BYTE PTR [eax],0x8
4a9213: cmp BYTE PTR [ebx+0x4],0x3
4a9217: jne 0x4a9221
4a9219: mov eax,ds:0x4b1098
4a921e: mov BYTE PTR [eax],0x9
4a9221: mov eax,ds:0x4b0d4c
4a9226: cmp BYTE PTR [eax],0x0
4a9229: jne 0x4a925c
4a922b: mov BYTE PTR [ebx+0x24],0x1
4a922f: mov BYTE PTR [ebx+0x25],0x32
4a9233: cmp BYTE PTR [ebx+0x33],0x1
4a9237: jne 0x4a9254
4a9239: mov eax,ds:0x4b0e84
4a923e: cmp BYTE PTR [eax],0x0
4a9241: jne 0x4a9254
4a9243: mov eax,ds:0x4b1074
4a9248: cmp BYTE PTR [eax],0x0
4a924b: jne 0x4a9254
4a924d: add DWORD PTR [ebx+0x1d],0x12c
4a9254: mov eax,ds:0x4b0d4c
4a9259: mov BYTE PTR [eax],0x1
4a925c: mov BYTE PTR [ebx+0x26],0x1
4a9260: mov eax,0x3
4a9265: sub eax,DWORD PTR [ebp-0xc]
4a9268: imul eax,eax,0x16
4a926b: mov edx,DWORD PTR ds:0x4b0ef0
4a9271: mov BYTE PTR [edx+eax*8-0x1f],0x0
4a9276: mov BYTE PTR [ebx-0x3],0x0
4a927a: mov eax,0x3
4a927f: sub eax,DWORD PTR [ebp-0xc]
4a9282: imul eax,eax,0x16
4a9285: mov edx,DWORD PTR ds:0x4b0ef0
4a928b: mov BYTE PTR [edx+eax*8-0x48],0x0
4a9290: cmp BYTE PTR [ebx-0x5b],0x2
4a9294: jne 0x4a92c0
4a9296: cmp BYTE PTR [ebx],0x1c
4a9299: jne 0x4a92c0
4a929b: mov BYTE PTR [ebx],0x1d
4a929e: mov WORD PTR [ebx+0x9],0x0
4a92a4: mov WORD PTR [ebx+0xb],0x1e
4a92aa: mov eax,0x3
4a92af: sub eax,DWORD PTR [ebp-0xc]
4a92b2: imul eax,eax,0x16
4a92b5: mov edx,DWORD PTR ds:0x4b0ef0
4a92bb: mov BYTE PTR [edx+eax*8-0x48],0x0
4a92c0: cmp BYTE PTR [ebx-0x5b],0x2
4a92c4: jne 0x4a92f3
4a92c6: cmp BYTE PTR [ebx],0x1e
4a92c9: jne 0x4a92f3
4a92cb: mov BYTE PTR [ebx],0x1f
4a92ce: mov WORD PTR [ebx+0x9],0x0
4a92d4: mov WORD PTR [ebx+0xb],0x28
4a92da: inc BYTE PTR [ebx+0x2a]
4a92dd: mov eax,0x3
4a92e2: sub eax,DWORD PTR [ebp-0xc]
4a92e5: imul eax,eax,0x16
4a92e8: mov edx,DWORD PTR ds:0x4b0ef0
4a92ee: mov BYTE PTR [edx+eax*8-0x48],0x0
4a92f3: cmp BYTE PTR [ebx-0x5b],0x3
4a92f7: jne 0x4a9323
4a92f9: cmp BYTE PTR [ebx],0x1d
4a92fc: jne 0x4a9323
4a92fe: mov BYTE PTR [ebx],0x1e
4a9301: mov WORD PTR [ebx+0x9],0x0
4a9307: mov WORD PTR [ebx+0xb],0x1e
4a930d: mov eax,0x3
4a9312: sub eax,DWORD PTR [ebp-0xc]
4a9315: imul eax,eax,0x16
4a9318: mov edx,DWORD PTR ds:0x4b0ef0
4a931e: mov BYTE PTR [edx+eax*8-0x48],0x0
4a9323: cmp BYTE PTR [ebx-0x5b],0x7
4a9327: jne 0x4a9353
4a9329: cmp BYTE PTR [ebx],0x1d
4a932c: jne 0x4a9353
4a932e: mov BYTE PTR [ebx],0x1e
4a9331: mov WORD PTR [ebx+0x9],0x0
4a9337: mov WORD PTR [ebx+0xb],0xf
4a933d: mov eax,0x3
4a9342: sub eax,DWORD PTR [ebp-0xc]
4a9345: imul eax,eax,0x16
4a9348: mov edx,DWORD PTR ds:0x4b0ef0
4a934e: mov BYTE PTR [edx+eax*8-0x48],0x0
4a9353: mov eax,0x3
4a9358: sub eax,DWORD PTR [ebp-0xc]
4a935b: imul eax,eax,0x16
4a935e: mov edx,DWORD PTR ds:0x4b0ef0
4a9364: fld QWORD PTR [edx+eax*8-0x70]
4a9368: fcomp DWORD PTR ds:0x4aef3c
4a936e: fnstsw ax
4a9370: sahf
4a9371: jbe 0x4a93a7
4a9373: cmp BYTE PTR [ebx+0x4],0x1
4a9377: jne 0x4a938d
4a9379: mov eax,0x4
4a937e: call 0x402a1c
4a9383: add al,0x5
4a9385: mov edx,DWORD PTR ds:0x4b0e84
4a938b: mov BYTE PTR [edx],al
4a938d: cmp BYTE PTR [ebx+0x4],0x2
4a9391: jne 0x4a93a7
4a9393: mov eax,0x4
4a9398: call 0x402a1c
4a939d: add al,0x7
4a939f: mov edx,DWORD PTR ds:0x4b0e84
4a93a5: mov BYTE PTR [edx],al
4a93a7: mov al,0x3
4a93a9: sub al,BYTE PTR [ebp-0xc]
4a93ac: call 0x47d21c
4a93b1: mov eax,ds:0x4b110c
4a93b6: cmp BYTE PTR [eax],0x0
4a93b9: jne 0x4a9435
4a93bb: mov eax,ds:0x4b11b4
4a93c0: mov eax,DWORD PTR [eax]
4a93c2: add eax,0x172
4a93c7: mov DWORD PTR [ebp-0x48],eax
4a93ca: fild DWORD PTR [ebp-0x48]
4a93cd: mov eax,0x3
4a93d2: sub eax,DWORD PTR [ebp-0xc]
4a93d5: imul eax,eax,0x16
4a93d8: mov edx,DWORD PTR ds:0x4b0ef0
4a93de: fcomp QWORD PTR [edx+eax*8-0xb0]
4a93e5: fnstsw ax
4a93e7: sahf
4a93e8: ja 0x4a93f9
4a93ea: push 0xc0280000
4a93ef: push 0x0
4a93f1: mov al,BYTE PTR [ebp-0xc]
4a93f4: call 0x47648c
4a93f9: mov eax,ds:0x4b11b4
4a93fe: mov eax,DWORD PTR [eax]
4a9400: add eax,0x1e
4a9403: mov DWORD PTR [ebp-0x48],eax
4a9406: fild DWORD PTR [ebp-0x48]
4a9409: mov eax,0x3
4a940e: sub eax,DWORD PTR [ebp-0xc]
4a9411: imul eax,eax,0x16
4a9414: mov edx,DWORD PTR ds:0x4b0ef0
4a941a: fcomp QWORD PTR [edx+eax*8-0xb0]
4a9421: fnstsw ax
4a9423: sahf
4a9424: jb 0x4a9435
4a9426: push 0x40280000
4a942b: push 0x0
4a942d: mov al,BYTE PTR [ebp-0xc]
4a9430: call 0x47648c
4a9435: inc DWORD PTR [ebp-0xc]
4a9438: add ebx,0xb0
4a943e: cmp DWORD PTR [ebp-0xc],0x3
4a9442: jne 0x4a85fc
4a9448: mov eax,ds:0x4b0e84
4a944d: cmp BYTE PTR [eax],0x0
4a9450: jbe 0x4a9459
4a9452: mov eax,ds:0x4b0e84
4a9457: dec BYTE PTR [eax]
4a9459: mov DWORD PTR [ebp-0xc],0x1
4a9460: mov ebx,DWORD PTR ds:0x4b0ef0
4a9466: add ebx,0x76
4a9469: cmp WORD PTR [ebx],0x63
4a946d: je 0x4a9487
4a946f: mov eax,ds:0x4b1074
4a9474: cmp BYTE PTR [eax],0x0
4a9477: jne 0x4a9487
4a9479: mov eax,ds:0x4b0e84
4a947e: cmp BYTE PTR [eax],0x0
4a9481: jne 0x4a9487
4a9483: inc WORD PTR [ebx-0x2]
4a9487: mov ax,WORD PTR [ebx-0x2]
4a948b: cmp ax,WORD PTR [ebx]
4a948e: jl 0x4a9539
4a9494: mov BYTE PTR [ebx-0xb],0x1
4a9498: mov BYTE PTR [ebx-0xe],0x0
4a949c: mov BYTE PTR [ebx-0x6],0x0
4a94a0: mov WORD PTR [ebx-0x2],0x0
4a94a6: mov BYTE PTR [ebx+0x1c],0x0
4a94aa: mov BYTE PTR [ebx+0x1d],0x0
4a94ae: mov BYTE PTR [ebx-0xd],0x0
4a94b2: mov BYTE PTR [ebx-0x7],0x0
4a94b6: mov eax,ds:0x4b11f8
4a94bb: fild WORD PTR [eax]
4a94bd: fcomp QWORD PTR [ebx-0x6e]
4a94c0: fnstsw ax
4a94c2: sahf
4a94c3: jbe 0x4a94cd
4a94c5: mov BYTE PTR [ebx-0xc],0x1
4a94c9: mov BYTE PTR [ebx-0xb],0xc
4a94cd: fld QWORD PTR [ebx-0x76]
4a94d0: mov eax,0x3
4a94d5: sub eax,DWORD PTR [ebp-0xc]
4a94d8: imul eax,eax,0x16
4a94db: mov edx,DWORD PTR ds:0x4b0ef0
4a94e1: fcomp QWORD PTR [edx+eax*8-0xb0]
4a94e8: fnstsw ax
4a94ea: sahf
4a94eb: jae 0x4a94f1
4a94ed: mov BYTE PTR [ebx-0x9],0x1
4a94f1: fld QWORD PTR [ebx-0x76]
4a94f4: mov eax,0x3
4a94f9: sub eax,DWORD PTR [ebp-0xc]
4a94fc: imul eax,eax,0x16
4a94ff: mov edx,DWORD PTR ds:0x4b0ef0
4a9505: fcomp QWORD PTR [edx+eax*8-0xb0]
4a950c: fnstsw ax
4a950e: sahf
4a950f: jb 0x4a9515
4a9511: mov BYTE PTR [ebx-0x9],0x2
4a9515: mov eax,ds:0x4b11f8
4a951a: fild WORD PTR [eax]
4a951c: fcomp QWORD PTR [ebx-0x6e]
4a951f: fnstsw ax
4a9521: sahf
4a9522: jae 0x4a952f
4a9524: mov eax,ds:0x4b11f8
4a9529: fild WORD PTR [eax]
4a952b: fstp QWORD PTR [ebx-0x6e]
4a952e: fwait
4a952f: cmp BYTE PTR [ebx+0x2],0x0
4a9533: je 0x4a9539
4a9535: mov BYTE PTR [ebx-0xb],0xc
4a9539: inc DWORD PTR [ebp-0xc]
4a953c: add ebx,0xb0
4a9542: cmp DWORD PTR [ebp-0xc],0x3
4a9546: jne 0x4a9469
4a954c: mov DWORD PTR [ebp-0xc],0x2
4a9553: mov ebx,DWORD PTR ds:0x4b0ef0
4a9559: add ebx,0x8
4a955c: mov eax,ds:0x4b11f8
4a9561: fild WORD PTR [eax]
4a9563: fcomp QWORD PTR [ebx]
4a9565: fnstsw ax
4a9567: sahf
4a9568: jae 0x4a959a
4a956a: mov eax,ds:0x4b11f8
4a956f: fild WORD PTR [eax]
4a9571: fstp QWORD PTR [ebx]
4a9573: fwait
4a9574: mov WORD PTR [ebx+0xe],0x0
4a957a: mov WORD PTR [ebx+0x10],0x0
4a9580: mov BYTE PTR [ebx+0x70],0x0
4a9584: mov BYTE PTR [ebx+0x62],0x0
4a9588: mov BYTE PTR [ebx+0x63],0x1
4a958c: mov WORD PTR [ebx+0x6c],0x0
4a9592: mov BYTE PTR [ebx+0x60],0x0
4a9596: mov BYTE PTR [ebx+0x61],0x0
4a959a: add ebx,0xb0
4a95a0: dec DWORD PTR [ebp-0xc]
4a95a3: jne 0x4a955c
4a95a5: mov DWORD PTR [ebp-0xc],0x1
4a95ac: mov ebx,DWORD PTR ds:0x4b0ef0
4a95b2: add ebx,0x6a
4a95b5: cmp BYTE PTR [ebx],0x1
4a95b8: jne 0x4a9961
4a95be: mov eax,ds:0x4b1074
4a95c3: cmp BYTE PTR [eax],0x0
4a95c6: jne 0x4a9961
4a95cc: mov eax,ds:0x4b0e84
4a95d1: cmp BYTE PTR [eax],0x0
4a95d4: jne 0x4a9961
4a95da: movsx eax,BYTE PTR [ebx+0xe]
4a95de: mov DWORD PTR [ebp-0x48],eax
4a95e1: fild DWORD PTR [ebp-0x48]
4a95e4: fadd QWORD PTR [ebx-0x62]
4a95e7: fstp QWORD PTR [ebx-0x62]
4a95ea: fwait
4a95eb: mov eax,ds:0x4b1214
4a95f0: mov al,BYTE PTR [eax]
4a95f2: add BYTE PTR [ebx+0xe],al
4a95f5: cmp BYTE PTR [ebx+0x4],0x2
4a95f9: jne 0x4a960a
4a95fb: push 0xc0200000
4a9600: push 0x0
4a9602: mov al,BYTE PTR [ebp-0xc]
4a9605: call 0x47648c
4a960a: cmp BYTE PTR [ebx+0x4],0x3
4a960e: jne 0x4a961f
4a9610: push 0x40200000
4a9615: push 0x0
4a9617: mov al,BYTE PTR [ebp-0xc]
4a961a: call 0x47648c
4a961f: cmp BYTE PTR [ebx+0x1],0x13
4a9623: jne 0x4a9769
4a9629: cmp BYTE PTR [ebx+0x3],0x1
4a962d: jne 0x4a9641
4a962f: xor eax,eax
4a9631: mov al,BYTE PTR [ebx+0x8]
4a9634: mov DWORD PTR [ebp-0x48],eax
4a9637: fild DWORD PTR [ebp-0x48]
4a963a: fsubr QWORD PTR [ebx-0x6a]
4a963d: fstp QWORD PTR [ebx-0x6a]
4a9640: fwait
4a9641: cmp BYTE PTR [ebx+0x3],0x2
4a9645: jne 0x4a9659
4a9647: xor eax,eax
4a9649: mov al,BYTE PTR [ebx+0x8]
4a964c: mov DWORD PTR [ebp-0x48],eax
4a964f: fild DWORD PTR [ebp-0x48]
4a9652: fadd QWORD PTR [ebx-0x6a]
4a9655: fstp QWORD PTR [ebx-0x6a]
4a9658: fwait
4a9659: mov eax,ds:0x4b11f8
4a965e: fild WORD PTR [eax]
4a9660: fcomp QWORD PTR [ebx-0x62]
4a9663: fnstsw ax
4a9665: sahf
4a9666: ja 0x4a9769
4a966c: mov al,BYTE PTR [ebp-0xc]
4a966f: mov dl,0xb
4a9671: call 0x4775fc
4a9676: mov eax,ds:0x4b11f8
4a967b: movsx eax,WORD PTR [eax]
4a967e: sub eax,0xa
4a9681: mov DWORD PTR [ebp-0x48],eax
4a9684: fild DWORD PTR [ebp-0x48]
4a9687: fstp QWORD PTR [ebx-0x62]
4a968a: fwait
4a968b: mov WORD PTR [ebx-0x54],0x0
4a9691: mov WORD PTR [ebx-0x52],0x0
4a9697: mov eax,ds:0x4b1098
4a969c: mov BYTE PTR [eax],0xc
4a969f: cmp BYTE PTR [ebx-0x5a],0x7
4a96a3: je 0x4a96ab
4a96a5: cmp BYTE PTR [ebx-0x5a],0xa
4a96a9: jne 0x4a970c
4a96ab: mov eax,ds:0x4b0d68
4a96b0: mov BYTE PTR [eax],0x14
4a96b3: mov DWORD PTR [ebp-0x10],0x14
4a96ba: mov eax,0x3c
4a96bf: call 0x402a1c
4a96c4: mov DWORD PTR [ebp-0x48],eax
4a96c7: fild DWORD PTR [ebp-0x48]
4a96ca: fld QWORD PTR [ebx-0x6a]
4a96cd: fsub DWORD PTR ds:0x4aef48
4a96d3: faddp st(1),st
4a96d5: add esp,0xfffffff8
4a96d8: fstp QWORD PTR [esp]
4a96db: fwait
4a96dc: mov eax,0xa
4a96e1: call 0x402a1c
4a96e6: mov DWORD PTR [ebp-0x1bc],eax
4a96ec: fild DWORD PTR [ebp-0x1bc]
4a96f2: fadd QWORD PTR [ebx-0x62]
4a96f5: add esp,0xfffffff8
4a96f8: fstp QWORD PTR [esp]
4a96fb: fwait
4a96fc: xor ecx,ecx
4a96fe: xor edx,edx
4a9700: mov al,0x2
4a9702: call 0x476a04
4a9707: dec DWORD PTR [ebp-0x10]
4a970a: jne 0x4a96ba
4a970c: mov DWORD PTR [ebp-0x10],0x1
4a9713: mov eax,0x28
4a9718: call 0x402a1c
4a971d: mov DWORD PTR [ebp-0x48],eax
4a9720: fild DWORD PTR [ebp-0x48]
4a9723: fld QWORD PTR [ebx-0x6a]
4a9726: fsub DWORD PTR ds:0x4aeeec
4a972c: faddp st(1),st
4a972e: add esp,0xfffffff8
4a9731: fstp QWORD PTR [esp]
4a9734: fwait
4a9735: mov eax,0xa
4a973a: call 0x402a1c
4a973f: mov DWORD PTR [ebp-0x1bc],eax
4a9745: fild DWORD PTR [ebp-0x1bc]
4a974b: fadd QWORD PTR [ebx-0x62]
4a974e: add esp,0xfffffff8
4a9751: fstp QWORD PTR [esp]
4a9754: fwait
4a9755: xor ecx,ecx
4a9757: xor edx,edx
4a9759: mov al,0x2
4a975b: call 0x476a04
4a9760: inc DWORD PTR [ebp-0x10]
4a9763: cmp DWORD PTR [ebp-0x10],0x6
4a9767: jne 0x4a9713
4a9769: cmp BYTE PTR [ebx+0x1],0x14
4a976d: jne 0x4a9871
4a9773: cmp BYTE PTR [ebx+0x3],0x1
4a9777: jne 0x4a9795
4a9779: xor eax,eax
4a977b: mov al,BYTE PTR [ebx+0x8]
4a977e: neg eax
4a9780: mov DWORD PTR [ebp-0x48],eax
4a9783: fild DWORD PTR [ebp-0x48]
4a9786: add esp,0xfffffff8
4a9789: fstp QWORD PTR [esp]
4a978c: fwait
4a978d: mov al,BYTE PTR [ebp-0xc]
4a9790: call 0x47648c
4a9795: cmp BYTE PTR [ebx+0x3],0x2
4a9799: jne 0x4a97b5
4a979b: xor eax,eax
4a979d: mov al,BYTE PTR [ebx+0x8]
4a97a0: mov DWORD PTR [ebp-0x48],eax
4a97a3: fild DWORD PTR [ebp-0x48]
4a97a6: add esp,0xfffffff8
4a97a9: fstp QWORD PTR [esp]
4a97ac: fwait
4a97ad: mov al,BYTE PTR [ebp-0xc]
4a97b0: call 0x47648c
4a97b5: mov eax,ds:0x4b1024
4a97ba: cmp BYTE PTR [eax],0x1
4a97bd: jne 0x4a97cd
4a97bf: mov eax,0x4
4a97c4: call 0x402a1c
4a97c9: test eax,eax
4a97cb: je 0x4a97d7
4a97cd: mov eax,ds:0x4b1058
4a97d2: cmp BYTE PTR [eax],0x1
4a97d5: jne 0x4a9840
4a97d7: cmp WORD PTR [ebx+0xa],0x5
4a97dc: jne 0x4a9840
4a97de: cmp BYTE PTR [ebx+0x3],0x1
4a97e2: jne 0x4a980f
4a97e4: fld QWORD PTR [ebx-0x6a]
4a97e7: fsub DWORD PTR ds:0x4aef48
4a97ed: add esp,0xfffffff8
4a97f0: fstp QWORD PTR [esp]
4a97f3: fld QWORD PTR [ebx-0x62]
4a97f7: fsub DWORD PTR ds:0x4aefe4
4a97fd: add esp,0xfffffff8
4a9800: fstp QWORD PTR [esp]
4a9803: fwait
4a9804: xor ecx,ecx
4a9806: xor edx,edx
4a9808: mov al,0xa
4a980a: call 0x476a04
4a980f: cmp BYTE PTR [ebx+0x3],0x2
4a9813: jne 0x4a9840
4a9815: fld QWORD PTR [ebx-0x6a]
4a9818: fadd DWORD PTR ds:0x4aef48
4a981e: add esp,0xfffffff8
4a9821: fstp QWORD PTR [esp]
4a9824: fld QWORD PTR [ebx-0x62]
4a9828: fsub DWORD PTR ds:0x4aefe4
4a982e: add esp,0xfffffff8
4a9831: fstp QWORD PTR [esp]
4a9834: fwait
4a9835: xor ecx,ecx
4a9837: xor edx,edx
4a9839: mov al,0xa
4a983b: call 0x476a04
4a9840: mov eax,ds:0x4b11f8
4a9845: fild WORD PTR [eax]
4a9847: fcomp QWORD PTR [ebx-0x62]
4a984a: fnstsw ax
4a984c: sahf
4a984d: jae 0x4a9871
4a984f: mov eax,ds:0x4b11f8
4a9854: fild WORD PTR [eax]
4a9856: fstp QWORD PTR [ebx-0x62]
4a9859: fwait
4a985a: mov BYTE PTR [ebx],0x0
4a985d: mov WORD PTR [ebx-0x54],0x0
4a9863: mov WORD PTR [ebx-0x52],0x0
4a9869: mov BYTE PTR [ebx+0xe],0x0
4a986d: mov BYTE PTR [ebx+0x8],0x0
4a9871: mov eax,ds:0x4b11f8
4a9876: fild WORD PTR [eax]
4a9878: fcomp QWORD PTR [ebx-0x62]
4a987b: fnstsw ax
4a987d: sahf
4a987e: jae 0x4a9961
4a9884: mov BYTE PTR [ebx+0xe],0x0
4a9888: mov BYTE PTR [ebx],0x0
4a988b: mov eax,ds:0x4b11f8
4a9890: fild WORD PTR [eax]
4a9892: fstp QWORD PTR [ebx-0x62]
4a9895: fwait
4a9896: mov WORD PTR [ebx-0x54],0x0
4a989c: mov WORD PTR [ebx-0x52],0x0
4a98a2: mov BYTE PTR [ebx+0x1],0x1
4a98a6: mov WORD PTR [ebx+0xa],0x0
4a98ac: mov BYTE PTR [ebx-0x2],0x0
4a98b0: mov BYTE PTR [ebx+0x6],0x0
4a98b4: mov BYTE PTR [ebx-0x1],0x0
4a98b8: mov BYTE PTR [ebx+0x4],0x0
4a98bc: fld QWORD PTR [ebx-0x6a]
4a98bf: mov eax,0x3
4a98c4: sub eax,DWORD PTR [ebp-0xc]
4a98c7: imul eax,eax,0x16
4a98ca: mov edx,DWORD PTR ds:0x4b0ef0
4a98d0: fcomp QWORD PTR [edx+eax*8-0xb0]
4a98d7: fnstsw ax
4a98d9: sahf
4a98da: jae 0x4a98e0
4a98dc: mov BYTE PTR [ebx+0x3],0x1
4a98e0: fld QWORD PTR [ebx-0x6a]
4a98e3: mov eax,0x3
4a98e8: sub eax,DWORD PTR [ebp-0xc]
4a98eb: imul eax,eax,0x16
4a98ee: mov edx,DWORD PTR ds:0x4b0ef0
4a98f4: fcomp QWORD PTR [edx+eax*8-0xb0]
4a98fb: fnstsw ax
4a98fd: sahf
4a98fe: jb 0x4a9904
4a9900: mov BYTE PTR [ebx+0x3],0x2
4a9904: mov DWORD PTR [ebp-0x10],0x1
4a990b: mov eax,0x28
4a9910: call 0x402a1c
4a9915: mov DWORD PTR [ebp-0x48],eax
4a9918: fild DWORD PTR [ebp-0x48]
4a991b: fld QWORD PTR [ebx-0x6a]
4a991e: fsub DWORD PTR ds:0x4aeeec
4a9924: faddp st(1),st
4a9926: add esp,0xfffffff8
4a9929: fstp QWORD PTR [esp]
4a992c: fwait
4a992d: mov eax,0xa
4a9932: call 0x402a1c
4a9937: mov DWORD PTR [ebp-0x1bc],eax
4a993d: fild DWORD PTR [ebp-0x1bc]
4a9943: fadd QWORD PTR [ebx-0x62]
4a9946: add esp,0xfffffff8
4a9949: fstp QWORD PTR [esp]
4a994c: fwait
4a994d: xor ecx,ecx
4a994f: xor edx,edx
4a9951: mov al,0x2
4a9953: call 0x476a04
4a9958: inc DWORD PTR [ebp-0x10]
4a995b: cmp DWORD PTR [ebp-0x10],0x6
4a995f: jne 0x4a990b
4a9961: fld QWORD PTR [ebx-0x2a]
4a9964: fcomp DWORD PTR ds:0x4aef3c
4a996a: fnstsw ax
4a996c: sahf
4a996d: jbe 0x4a99cb
4a996f: mov eax,ds:0x4b11b4
4a9974: mov eax,DWORD PTR [eax]
4a9976: add eax,0x1e
4a9979: mov DWORD PTR [ebp-0x48],eax
4a997c: fild DWORD PTR [ebp-0x48]
4a997f: fcomp QWORD PTR [ebx-0x6a]
4a9982: fnstsw ax
4a9984: sahf
4a9985: jbe 0x4a999b
4a9987: mov eax,ds:0x4b11b4
4a998c: mov eax,DWORD PTR [eax]
4a998e: add eax,0x1e
4a9991: mov DWORD PTR [ebp-0x48],eax
4a9994: fild DWORD PTR [ebp-0x48]
4a9997: fstp QWORD PTR [ebx-0x6a]
4a999a: fwait
4a999b: mov eax,ds:0x4b11b4
4a99a0: mov eax,DWORD PTR [eax]
4a99a2: add eax,0x172
4a99a7: mov DWORD PTR [ebp-0x48],eax
4a99aa: fild DWORD PTR [ebp-0x48]
4a99ad: fcomp QWORD PTR [ebx-0x6a]
4a99b0: fnstsw ax
4a99b2: sahf
4a99b3: jae 0x4a99cb
4a99b5: mov eax,ds:0x4b11b4
4a99ba: mov eax,DWORD PTR [eax]
4a99bc: add eax,0x172
4a99c1: mov DWORD PTR [ebp-0x48],eax
4a99c4: fild DWORD PTR [ebp-0x48]
4a99c7: fstp QWORD PTR [ebx-0x6a]
4a99ca: fwait
4a99cb: inc DWORD PTR [ebp-0xc]
4a99ce: add ebx,0xb0
4a99d4: cmp DWORD PTR [ebp-0xc],0x3
4a99d8: jne 0x4a95b5
4a99de: mov eax,ds:0x4b117c
4a99e3: cmp WORD PTR [eax],0x0
4a99e7: jbe 0x4a9fe2
4a99ed: mov eax,ds:0x4b0ef0
4a99f2: cmp BYTE PTR [eax+0x9e],0x1
4a99f9: jne 0x4a9a02
4a99fb: mov DWORD PTR [ebp-0xc],0x1
4a9a02: mov eax,ds:0x4b0ef0
4a9a07: cmp BYTE PTR [eax+0x14e],0x1
4a9a0e: jne 0x4a9a17
4a9a10: mov DWORD PTR [ebp-0xc],0x2
4a9a17: mov eax,ds:0x4b0ef0
4a9a1c: cmp BYTE PTR [eax+0x9e],0x0
4a9a23: jne 0x4a9a2c
4a9a25: mov DWORD PTR [ebp-0x10],0x1
4a9a2c: mov eax,ds:0x4b0ef0
4a9a31: cmp BYTE PTR [eax+0x14e],0x0
4a9a38: jne 0x4a9a41
4a9a3a: mov DWORD PTR [ebp-0x10],0x2
4a9a41: push 0x122
4a9a46: push 0xd7
4a9a4b: push 0x14
4a9a4d: mov cl,0xff
4a9a4f: mov dl,0xff
4a9a51: mov al,0xff
4a9a53: call 0x406de4
4a9a58: push eax
4a9a59: xor ecx,ecx
4a9a5b: xor edx,edx
4a9a5d: xor eax,eax
4a9a5f: call 0x406de4
4a9a64: push eax
4a9a65: mov ecx,0xa5
4a9a6a: mov edx,0x5
4a9a6f: mov eax,esi
4a9a71: call 0x48e570
4a9a76: mov eax,DWORD PTR [esi+0x304]
4a9a7c: mov eax,DWORD PTR [eax+0x28]
4a9a7f: call 0x40efcc
4a9a84: imul edx,DWORD PTR [ebp-0xc],0x16
4a9a88: mov ecx,DWORD PTR ds:0x4b0ef0
4a9a8e: movsx edx,BYTE PTR [ecx+edx*8-0xa0]
4a9a96: dec edx
4a9a97: lea edx,[edx+edx*4]
4a9a9a: add edx,0x4
4a9a9d: cmp eax,edx
4a9a9f: jle 0x4a9b55
4a9aa5: mov eax,ds:0x4b117c
4a9aaa: cmp WORD PTR [eax],0x244
4a9aaf: jbe 0x4a9b08
4a9ab1: push 0x55
4a9ab3: push 0x0
4a9ab5: imul eax,DWORD PTR [ebp-0xc],0x16
4a9ab9: mov edx,DWORD PTR ds:0x4b0ef0
4a9abf: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9ac7: dec eax
4a9ac8: lea edx,[eax+eax*4]
4a9acb: add edx,0x4
4a9ace: mov eax,DWORD PTR [esi+0x304]
4a9ad4: mov eax,DWORD PTR [eax+0x28]
4a9ad7: call 0x461dcc
4a9adc: mov edx,DWORD PTR ds:0x4b117c
4a9ae2: movzx edx,WORD PTR [edx]
4a9ae5: sub edx,0x244
4a9aeb: add edx,edx
4a9aed: lea edx,[edx+edx*4]
4a9af0: mov ecx,0xf
4a9af5: sub ecx,edx
4a9af7: mov edx,DWORD PTR [esi+0x2d0]
4a9afd: mov edx,DWORD PTR [edx+0x270]
4a9b03: call 0x46161c
4a9b08: mov eax,ds:0x4b117c
4a9b0d: cmp WORD PTR [eax],0x244
4a9b12: ja 0x4a9b55
4a9b14: push 0x55
4a9b16: push 0x0
4a9b18: imul eax,DWORD PTR [ebp-0xc],0x16
4a9b1c: mov edx,DWORD PTR ds:0x4b0ef0
4a9b22: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9b2a: dec eax
4a9b2b: lea edx,[eax+eax*4]
4a9b2e: add edx,0x4
4a9b31: mov eax,DWORD PTR [esi+0x304]
4a9b37: mov eax,DWORD PTR [eax+0x28]
4a9b3a: call 0x461dcc
4a9b3f: mov edx,DWORD PTR [esi+0x2d0]
4a9b45: mov edx,DWORD PTR [edx+0x270]
4a9b4b: mov ecx,0xf
4a9b50: call 0x46161c
4a9b55: push 0x18b
4a9b5a: push 0x10e
4a9b5f: push 0x14
4a9b61: mov cl,0xff
4a9b63: mov dl,0xff
4a9b65: mov al,0xff
4a9b67: call 0x406de4
4a9b6c: push eax
4a9b6d: xor ecx,ecx
4a9b6f: xor edx,edx
4a9b71: xor eax,eax
4a9b73: call 0x406de4
4a9b78: push eax
4a9b79: mov ecx,0xdc
4a9b7e: mov edx,0x6e
4a9b83: mov eax,esi
4a9b85: call 0x48e570
4a9b8a: mov eax,DWORD PTR [esi+0x304]
4a9b90: mov eax,DWORD PTR [eax+0x28]
4a9b93: call 0x40efcc
4a9b98: imul edx,DWORD PTR [ebp-0x10],0x16
4a9b9c: mov ecx,DWORD PTR ds:0x4b0ef0
4a9ba2: movsx edx,BYTE PTR [ecx+edx*8-0xa0]
4a9baa: dec edx
4a9bab: lea edx,[edx+edx*4]
4a9bae: add edx,0x4
4a9bb1: cmp eax,edx
4a9bb3: jle 0x4a9c70
4a9bb9: mov eax,ds:0x4b117c
4a9bbe: cmp WORD PTR [eax],0x244
4a9bc3: jbe 0x4a9c20
4a9bc5: push 0x8c
4a9bca: push 0x0
4a9bcc: imul eax,DWORD PTR [ebp-0x10],0x16
4a9bd0: mov edx,DWORD PTR ds:0x4b0ef0
4a9bd6: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9bde: dec eax
4a9bdf: lea edx,[eax+eax*4]
4a9be2: add edx,0x4
4a9be5: mov eax,DWORD PTR [esi+0x304]
4a9beb: mov eax,DWORD PTR [eax+0x28]
4a9bee: call 0x461dcc
4a9bf3: mov edx,DWORD PTR ds:0x4b117c
4a9bf9: movzx edx,WORD PTR [edx]
4a9bfc: sub edx,0x244
4a9c02: mov ecx,edx
4a9c04: add ecx,ecx
4a9c06: lea ecx,[ecx+ecx*4]
4a9c09: add ecx,0x120
4a9c0f: mov edx,DWORD PTR [esi+0x2d0]
4a9c15: mov edx,DWORD PTR [edx+0x270]
4a9c1b: call 0x46161c
4a9c20: mov eax,ds:0x4b117c
4a9c25: cmp WORD PTR [eax],0x244
4a9c2a: ja 0x4a9c70
4a9c2c: push 0x8c
4a9c31: push 0x0
4a9c33: imul eax,DWORD PTR [ebp-0x10],0x16
4a9c37: mov edx,DWORD PTR ds:0x4b0ef0
4a9c3d: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9c45: dec eax
4a9c46: lea edx,[eax+eax*4]
4a9c49: add edx,0x4
4a9c4c: mov eax,DWORD PTR [esi+0x304]
4a9c52: mov eax,DWORD PTR [eax+0x28]
4a9c55: call 0x461dcc
4a9c5a: mov edx,DWORD PTR [esi+0x2d0]
4a9c60: mov edx,DWORD PTR [edx+0x270]
4a9c66: mov ecx,0x120
4a9c6b: call 0x46161c
4a9c70: mov eax,ds:0x4b117c
4a9c75: cmp WORD PTR [eax],0x1c2
4a9c7a: jbe 0x4a9ca4
4a9c7c: mov eax,ds:0x4b117c
4a9c81: cmp WORD PTR [eax],0x258
4a9c86: jae 0x4a9ca4
4a9c88: imul eax,DWORD PTR [ebp-0xc],0x16
4a9c8c: mov edx,DWORD PTR ds:0x4b0ef0
4a9c92: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9c9a: dec eax
4a9c9b: shl eax,0x2
4a9c9e: lea eax,[eax+eax*2]
4a9ca1: mov DWORD PTR [ebp-0x14],eax
4a9ca4: mov eax,ds:0x4b117c
4a9ca9: cmp WORD PTR [eax],0x12c
4a9cae: jbe 0x4a9cdb
4a9cb0: mov eax,ds:0x4b117c
4a9cb5: cmp WORD PTR [eax],0x1c2
4a9cba: jae 0x4a9cdb
4a9cbc: imul eax,DWORD PTR [ebp-0xc],0x16
4a9cc0: mov edx,DWORD PTR ds:0x4b0ef0
4a9cc6: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9cce: dec eax
4a9ccf: shl eax,0x2
4a9cd2: lea eax,[eax+eax*2]
4a9cd5: add eax,0x3
4a9cd8: mov DWORD PTR [ebp-0x14],eax
4a9cdb: mov eax,ds:0x4b117c
4a9ce0: cmp WORD PTR [eax],0x96
4a9ce5: jbe 0x4a9d12
4a9ce7: mov eax,ds:0x4b117c
4a9cec: cmp WORD PTR [eax],0x12c
4a9cf1: jae 0x4a9d12
4a9cf3: imul eax,DWORD PTR [ebp-0xc],0x16
4a9cf7: mov edx,DWORD PTR ds:0x4b0ef0
4a9cfd: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9d05: dec eax
4a9d06: shl eax,0x2
4a9d09: lea eax,[eax+eax*2]
4a9d0c: add eax,0x6
4a9d0f: mov DWORD PTR [ebp-0x14],eax
4a9d12: mov eax,ds:0x4b117c
4a9d17: cmp WORD PTR [eax],0x0
4a9d1b: jbe 0x4a9d48
4a9d1d: mov eax,ds:0x4b117c
4a9d22: cmp WORD PTR [eax],0x96
4a9d27: jae 0x4a9d48
4a9d29: imul eax,DWORD PTR [ebp-0xc],0x16
4a9d2d: mov edx,DWORD PTR ds:0x4b0ef0
4a9d33: movsx eax,BYTE PTR [edx+eax*8-0xa0]
4a9d3b: dec eax
4a9d3c: shl eax,0x2
4a9d3f: lea eax,[eax+eax*2]
4a9d42: add eax,0x9
4a9d45: mov DWORD PTR [ebp-0x14],eax
4a9d48: mov eax,ds:0x4b117c
4a9d4d: cmp WORD PTR [eax],0x1c2
4a9d52: jbe 0x4a9d6b
4a9d54: mov eax,ds:0x4b117c
4a9d59: cmp WORD PTR [eax],0x258
4a9d5e: jae 0x4a9d6b
4a9d60: mov eax,ds:0x4b0f84
4a9d65: mov DWORD PTR [eax],0x1
4a9d6b: mov eax,ds:0x4b117c
4a9d70: cmp WORD PTR [eax],0x12c
4a9d75: jbe 0x4a9d8e
4a9d77: mov eax,ds:0x4b117c
4a9d7c: cmp WORD PTR [eax],0x1c2
4a9d81: jae 0x4a9d8e
4a9d83: mov eax,ds:0x4b0f84
4a9d88: mov DWORD PTR [eax],0x2
4a9d8e: mov eax,ds:0x4b117c
4a9d93: cmp WORD PTR [eax],0x96
4a9d98: jbe 0x4a9db1
4a9d9a: mov eax,ds:0x4b117c
4a9d9f: cmp WORD PTR [eax],0x12c
4a9da4: jae 0x4a9db1
4a9da6: mov eax,ds:0x4b0f84
4a9dab: mov DWORD PTR [eax],0x1
4a9db1: mov eax,ds:0x4b117c
4a9db6: cmp WORD PTR [eax],0x0
4a9dba: jbe 0x4a9dd3
4a9dbc: mov eax,ds:0x4b117c
4a9dc1: cmp WORD PTR [eax],0x96
4a9dc6: jae 0x4a9dd3
4a9dc8: mov eax,ds:0x4b0f84
4a9dcd: mov DWORD PTR [eax],0x2
4a9dd3: mov eax,ds:0x4b0f84
4a9dd8: cmp DWORD PTR [eax],0x1
4a9ddb: jne 0x4a9eab
4a9de1: lea ecx,[ebp-0x2bc]
4a9de7: mov eax,DWORD PTR [esi+0x300]
4a9ded: mov eax,DWORD PTR [eax+0x208]
4a9df3: mov edx,DWORD PTR [ebp-0x14]
4a9df6: mov ebx,DWORD PTR [eax]
4a9df8: call DWORD PTR [ebx+0xc]
4a9dfb: mov eax,DWORD PTR [ebp-0x2bc]
4a9e01: push eax
4a9e02: push 0x2d
4a9e04: push 0xa
4a9e06: mov cl,0xff
4a9e08: mov dl,0xff
4a9e0a: mov al,0xff
4a9e0c: call 0x406de4
4a9e11: push eax
4a9e12: mov ecx,0xa8
4a9e17: mov edx,0x73
4a9e1c: mov eax,esi
4a9e1e: call 0x48e720
4a9e23: lea ecx,[ebp-0x2c0]
4a9e29: mov edx,DWORD PTR [ebp-0x14]
4a9e2c: inc edx
4a9e2d: mov eax,DWORD PTR [esi+0x300]
4a9e33: mov eax,DWORD PTR [eax+0x208]
4a9e39: mov ebx,DWORD PTR [eax]
4a9e3b: call DWORD PTR [ebx+0xc]
4a9e3e: mov eax,DWORD PTR [ebp-0x2c0]
4a9e44: push eax
4a9e45: push 0x2d
4a9e47: push 0xa
4a9e49: mov cl,0xff
4a9e4b: mov dl,0xff
4a9e4d: mov al,0xff
4a9e4f: call 0x406de4
4a9e54: push eax
4a9e55: mov ecx,0xb6
4a9e5a: mov edx,0x73
4a9e5f: mov eax,esi
4a9e61: call 0x48e720
4a9e66: lea ecx,[ebp-0x2c4]
4a9e6c: mov edx,DWORD PTR [ebp-0x14]
4a9e6f: add edx,0x2
4a9e72: mov eax,DWORD PTR [esi+0x300]
4a9e78: mov eax,DWORD PTR [eax+0x208]
4a9e7e: mov ebx,DWORD PTR [eax]
4a9e80: call DWORD PTR [ebx+0xc]
4a9e83: mov eax,DWORD PTR [ebp-0x2c4]
4a9e89: push eax
4a9e8a: push 0x2d
4a9e8c: push 0xa
4a9e8e: mov cl,0xff
4a9e90: mov dl,0xff
4a9e92: mov al,0xff
4a9e94: call 0x406de4
4a9e99: push eax
4a9e9a: mov ecx,0xc4
4a9e9f: mov edx,0x73
4a9ea4: mov eax,esi
4a9ea6: call 0x48e720
4a9eab: mov eax,ds:0x4b0f84
4a9eb0: cmp DWORD PTR [eax],0x2
4a9eb3: jne 0x4a9f83
4a9eb9: lea ecx,[ebp-0x2c8]
4a9ebf: mov eax,DWORD PTR [esi+0x300]
4a9ec5: mov eax,DWORD PTR [eax+0x208]
4a9ecb: mov edx,DWORD PTR [ebp-0x14]
4a9ece: mov ebx,DWORD PTR [eax]
4a9ed0: call DWORD PTR [ebx+0xc]
4a9ed3: mov eax,DWORD PTR [ebp-0x2c8]
4a9ed9: push eax
4a9eda: push 0x2d
4a9edc: push 0xa
4a9ede: mov cl,0xff
4a9ee0: mov dl,0xff
4a9ee2: mov al,0xff
4a9ee4: call 0x406de4
4a9ee9: push eax
4a9eea: mov ecx,0xdf
4a9eef: mov edx,0x78
4a9ef4: mov eax,esi
4a9ef6: call 0x48e720
4a9efb: lea ecx,[ebp-0x2cc]
4a9f01: mov edx,DWORD PTR [ebp-0x14]
4a9f04: inc edx
4a9f05: mov eax,DWORD PTR [esi+0x300]
4a9f0b: mov eax,DWORD PTR [eax+0x208]
4a9f11: mov ebx,DWORD PTR [eax]
4a9f13: call DWORD PTR [ebx+0xc]
4a9f16: mov eax,DWORD PTR [ebp-0x2cc]
4a9f1c: push eax
4a9f1d: push 0x2d
4a9f1f: push 0xa
4a9f21: mov cl,0xff
4a9f23: mov dl,0xff
4a9f25: mov al,0xff
4a9f27: call 0x406de4
4a9f2c: push eax
4a9f2d: mov ecx,0xed
4a9f32: mov edx,0x78
4a9f37: mov eax,esi
4a9f39: call 0x48e720
4a9f3e: lea ecx,[ebp-0x2d0]
4a9f44: mov edx,DWORD PTR [ebp-0x14]
4a9f47: add edx,0x2
4a9f4a: mov eax,DWORD PTR [esi+0x300]
4a9f50: mov eax,DWORD PTR [eax+0x208]
4a9f56: mov ebx,DWORD PTR [eax]
4a9f58: call DWORD PTR [ebx+0xc]
4a9f5b: mov eax,DWORD PTR [ebp-0x2d0]
4a9f61: push eax
4a9f62: push 0x2d
4a9f64: push 0xa
4a9f66: mov cl,0xff
4a9f68: mov dl,0xff
4a9f6a: mov al,0xff
4a9f6c: call 0x406de4
4a9f71: push eax
4a9f72: mov ecx,0xfb
4a9f77: mov edx,0x78
4a9f7c: mov eax,esi
4a9f7e: call 0x48e720
4a9f83: mov eax,DWORD PTR [esi+0x2d8]
4a9f89: call 0x44dee8
4a9f8e: mov eax,DWORD PTR [esi+0x2d8]
4a9f94: mov eax,DWORD PTR [eax+0x38]
4a9f97: test BYTE PTR [eax+0x2038],0x10
4a9f9e: je 0x4a9fae
4a9fa0: mov eax,ds:0x4b0ef0
4a9fa5: cmp BYTE PTR [eax+0x9e],0x1
4a9fac: je 0x4a9fce
4a9fae: mov eax,DWORD PTR [esi+0x2d8]
4a9fb4: mov eax,DWORD PTR [eax+0x34]
4a9fb7: test BYTE PTR [eax+0x2038],0x10
4a9fbe: je 0x4a9fe2
4a9fc0: mov eax,ds:0x4b0ef0
4a9fc5: cmp BYTE PTR [eax+0x14e],0x1
4a9fcc: jne 0x4a9fe2
4a9fce: mov eax,ds:0x4b117c
4a9fd3: cmp WORD PTR [eax],0xa
4a9fd7: jbe 0x4a9fe2
4a9fd9: mov eax,ds:0x4b117c
4a9fde: sub WORD PTR [eax],0x5
4a9fe2: mov eax,ds:0x4b1074
4a9fe7: cmp BYTE PTR [eax],0x0
4a9fea: jne 0x4a9ffd
4a9fec: mov eax,ds:0x4b0e84
4a9ff1: cmp BYTE PTR [eax],0x0
4a9ff4: jne 0x4a9ffd
4a9ff6: mov eax,ds:0x4b1094
4a9ffb: inc BYTE PTR [eax]
4a9ffd: mov eax,ds:0x4b1094
4aa002: cmp BYTE PTR [eax],0x1e
4aa005: jbe 0x4aa00f
4aa007: mov eax,ds:0x4b1094
4aa00c: mov BYTE PTR [eax],0x0
4aa00f: mov eax,ds:0x4b0f64
4aa014: cmp WORD PTR [eax],0x0
4aa018: jle 0x4aa29a
4aa01e: mov eax,ds:0x4b0f64
4aa023: dec WORD PTR [eax]
4aa026: mov eax,ds:0x4b10b8
4aa02b: mov al,BYTE PTR [eax]
4aa02d: mov edx,DWORD PTR ds:0x4b0eec
4aa033: mov BYTE PTR [edx],al
4aa035: mov eax,ds:0x4b0f3c
4aa03a: mov BYTE PTR [eax],0x19
4aa03d: mov eax,ds:0x4b0f64
4aa042: cmp WORD PTR [eax],0x28
4aa046: jge 0x4aa094
4aa048: xor eax,eax
4aa04a: mov DWORD PTR [ebp-0xc],eax
4aa04d: push 0x190
4aa052: mov eax,ds:0x4b0f64
4aa057: movsx eax,WORD PTR [eax]
4aa05a: mov edx,0x28
4aa05f: sub edx,eax
4aa061: mov eax,DWORD PTR [ebp-0xc]
4aa064: shl eax,0x2
4aa067: lea eax,[eax+eax*4]
4aa06a: add edx,eax
4aa06c: push edx
4aa06d: xor ecx,ecx
4aa06f: xor edx,edx
4aa071: xor eax,eax
4aa073: call 0x406de4
4aa078: push eax
4aa079: mov ecx,DWORD PTR [ebp-0xc]
4aa07c: shl ecx,0x2
4aa07f: lea ecx,[ecx+ecx*4]
4aa082: xor edx,edx
4aa084: mov eax,esi
4aa086: call 0x48e444
4aa08b: inc DWORD PTR [ebp-0xc]
4aa08e: cmp DWORD PTR [ebp-0xc],0x10
4aa092: jne 0x4aa04d
4aa094: mov eax,ds:0x4b1094
4aa099: cmp BYTE PTR [eax],0x14
4aa09c: jae 0x4aa0e2
4aa09e: lea ecx,[ebp-0x2d4]
4aa0a4: mov eax,DWORD PTR [esi+0x2f4]
4aa0aa: mov eax,DWORD PTR [eax+0x208]
4aa0b0: mov edx,0x6
4aa0b5: mov ebx,DWORD PTR [eax]
4aa0b7: call DWORD PTR [ebx+0xc]
4aa0ba: mov eax,DWORD PTR [ebp-0x2d4]
4aa0c0: push eax
4aa0c1: push 0x63
4aa0c3: push 0xa
4aa0c5: mov cl,0xff
4aa0c7: mov dl,0xff
4aa0c9: mov al,0xff
4aa0cb: call 0x406de4
4aa0d0: push eax
4aa0d1: mov ecx,0xf0
4aa0d6: mov edx,0xc8
4aa0db: mov eax,esi
4aa0dd: call 0x48e720
4aa0e2: mov eax,ds:0x4b0f64
4aa0e7: cmp WORD PTR [eax],0x1f4
4aa0ec: jge 0x4aa264
4aa0f2: mov eax,ds:0x4b0fd0
4aa0f7: cmp BYTE PTR [eax],0x1
4aa0fa: jne 0x4aa1ab
4aa100: mov eax,DWORD PTR [esi+0x328]
4aa106: mov eax,DWORD PTR [eax+0x28]
4aa109: mov edx,0xc
4aa10e: call 0x461dcc
4aa113: call 0x461608
4aa118: mov DWORD PTR [ebp-0x48],eax
4aa11b: fild DWORD PTR [ebp-0x48]
4aa11e: fdiv DWORD PTR ds:0x4aec88
4aa124: call 0x402894
4aa129: mov DWORD PTR [ebp-0xc],eax
4aa12c: mov eax,DWORD PTR [esi+0x328]
4aa132: mov eax,DWORD PTR [eax+0x28]
4aa135: mov edx,0xc
4aa13a: call 0x461dcc
4aa13f: call 0x4615e0
4aa144: mov DWORD PTR [ebp-0x48],eax
4aa147: fild DWORD PTR [ebp-0x48]
4aa14a: fdiv DWORD PTR ds:0x4aec88
4aa150: call 0x402894
4aa155: mov DWORD PTR [ebp-0x10],eax
4aa158: push 0x0
4aa15a: push 0xff
4aa15f: push 0x118
4aa164: lea eax,[ebp-0x30]
4aa167: push eax
4aa168: mov edx,0x118
4aa16d: sub edx,DWORD PTR [ebp-0x10]
4aa170: mov eax,0x186
4aa175: sub eax,DWORD PTR [ebp-0xc]
4aa178: mov ecx,0x186
4aa17d: call 0x40d760
4aa182: lea eax,[ebp-0x30]
4aa185: push eax
4aa186: mov eax,DWORD PTR [esi+0x328]
4aa18c: mov eax,DWORD PTR [eax+0x28]
4aa18f: mov edx,0xc
4aa194: call 0x461dcc
4aa199: mov edx,DWORD PTR [esi+0x2d0]
4aa19f: mov edx,DWORD PTR [edx+0x270]
4aa1a5: pop ecx
4aa1a6: call 0x4616c0
4aa1ab: mov eax,ds:0x4b0fd0
4aa1b0: cmp BYTE PTR [eax],0x2
4aa1b3: jne 0x4aa264
4aa1b9: mov eax,DWORD PTR [esi+0x328]
4aa1bf: mov eax,DWORD PTR [eax+0x28]
4aa1c2: mov edx,0xd
4aa1c7: call 0x461dcc
4aa1cc: call 0x461608
4aa1d1: mov DWORD PTR [ebp-0x48],eax
4aa1d4: fild DWORD PTR [ebp-0x48]
4aa1d7: fdiv DWORD PTR ds:0x4aec88
4aa1dd: call 0x402894
4aa1e2: mov DWORD PTR [ebp-0xc],eax
4aa1e5: mov eax,DWORD PTR [esi+0x328]
4aa1eb: mov eax,DWORD PTR [eax+0x28]
4aa1ee: mov edx,0xd
4aa1f3: call 0x461dcc
4aa1f8: call 0x4615e0
4aa1fd: mov DWORD PTR [ebp-0x48],eax
4aa200: fild DWORD PTR [ebp-0x48]
4aa203: fdiv DWORD PTR ds:0x4aec88
4aa209: call 0x402894
4aa20e: mov DWORD PTR [ebp-0x10],eax
4aa211: push 0x0
4aa213: push 0xff
4aa218: push 0x118
4aa21d: lea eax,[ebp-0x30]
4aa220: push eax
4aa221: mov edx,0x118
4aa226: sub edx,DWORD PTR [ebp-0x10]
4aa229: mov eax,0x186
4aa22e: sub eax,DWORD PTR [ebp-0xc]
4aa231: mov ecx,0x186
4aa236: call 0x40d760
4aa23b: lea eax,[ebp-0x30]
4aa23e: push eax
4aa23f: mov eax,DWORD PTR [esi+0x328]
4aa245: mov eax,DWORD PTR [eax+0x28]
4aa248: mov edx,0xd
4aa24d: call 0x461dcc
4aa252: mov edx,DWORD PTR [esi+0x2d0]
4aa258: mov edx,DWORD PTR [edx+0x270]
4aa25e: pop ecx
4aa25f: call 0x4616c0
4aa264: mov eax,ds:0x4b0f64
4aa269: cmp WORD PTR [eax],0x5
4aa26d: jg 0x4aa29a
4aa26f: mov eax,ds:0x4b111c
4aa274: mov BYTE PTR [eax],0x8
4aa277: mov eax,ds:0x4b1098
4aa27c: mov BYTE PTR [eax],0x0
4aa27f: mov eax,ds:0x4b1144
4aa284: xor edx,edx
4aa286: mov DWORD PTR [eax],edx
4aa288: mov eax,ds:0x4b1094
4aa28d: mov BYTE PTR [eax],0x0
4aa290: mov eax,ds:0x4b0fb0
4aa295: mov WORD PTR [eax],0x0
4aa29a: mov eax,ds:0x4b0fc8
4aa29f: cmp BYTE PTR [eax],0x0
4aa2a2: jbe 0x4aa306
4aa2a4: mov eax,ds:0x4b1094
4aa2a9: movzx eax,BYTE PTR [eax]
4aa2ac: mov DWORD PTR [ebp-0x48],eax
4aa2af: fild DWORD PTR [ebp-0x48]
4aa2b2: fdiv DWORD PTR ds:0x4aec88
4aa2b8: call 0x40287c
4aa2bd: mov eax,ds:0x4b1094
4aa2c2: movzx eax,BYTE PTR [eax]
4aa2c5: mov DWORD PTR [ebp-0x1bc],eax
4aa2cb: fild DWORD PTR [ebp-0x1bc]
4aa2d1: fdiv DWORD PTR ds:0x4aec88
4aa2d7: fcompp
4aa2d9: fnstsw ax
4aa2db: sahf
4aa2dc: jne 0x4aa2ff
4aa2de: push 0x190
4aa2e3: push 0x12c
4aa2e8: xor ecx,ecx
4aa2ea: xor edx,edx
4aa2ec: mov al,0xff
4aa2ee: call 0x406de4
4aa2f3: push eax
4aa2f4: xor ecx,ecx
4aa2f6: xor edx,edx
4aa2f8: mov eax,esi
4aa2fa: call 0x48e444
4aa2ff: mov eax,ds:0x4b0fc8
4aa304: dec BYTE PTR [eax]
4aa306: mov eax,ds:0x4b111c
4aa30b: cmp BYTE PTR [eax],0x7
4aa30e: jne 0x4aa321
4aa310: mov eax,ds:0x4b0d94
4aa315: cmp BYTE PTR [eax],0x1
4aa318: jne 0x4aa321
4aa31a: mov eax,esi
4aa31c: call 0x491edc
4aa321: mov eax,ds:0x4b0f24
4aa326: cmp BYTE PTR [eax],0x1
4aa329: jne 0x4ab259
4aa32f: mov eax,ds:0x4b111c
4aa334: cmp BYTE PTR [eax],0x7
4aa337: jne 0x4ab259
4aa33d: lea edx,[ebp-0x2d8]
4aa343: mov eax,ds:0x4b0eec
4aa348: movzx eax,BYTE PTR [eax]
4aa34b: call 0x408190
4aa350: mov eax,DWORD PTR [ebp-0x2d8]
4aa356: push eax
4aa357: push 0x63
4aa359: push 0x7
4aa35b: mov cl,0xff
4aa35d: mov dl,0xff
4aa35f: mov al,0xff
4aa361: call 0x406de4
4aa366: push eax
4aa367: mov ecx,0x28
4aa36c: mov edx,0xc8
4aa371: mov eax,esi
4aa373: call 0x48e720
4aa378: lea edx,[ebp-0x2dc]
4aa37e: mov eax,ds:0x4b0f3c
4aa383: movzx eax,BYTE PTR [eax]
4aa386: call 0x408190
4aa38b: mov eax,DWORD PTR [ebp-0x2dc]
4aa391: push eax
4aa392: push 0x63
4aa394: push 0x7
4aa396: mov cl,0xff
4aa398: mov dl,0xff
4aa39a: mov al,0xff
4aa39c: call 0x406de4
4aa3a1: push eax
4aa3a2: mov ecx,0x30
4aa3a7: mov edx,0xc8
4aa3ac: mov eax,esi
4aa3ae: call 0x48e720
4aa3b3: lea edx,[ebp-0x2e4]
4aa3b9: mov eax,ds:0x4b11b4
4aa3be: mov eax,DWORD PTR [eax]
4aa3c0: call 0x408190
4aa3c5: mov ecx,DWORD PTR [ebp-0x2e4]
4aa3cb: lea eax,[ebp-0x2e0]
4aa3d1: mov edx,0x4aeff0
4aa3d6: call 0x403c9c
4aa3db: mov eax,DWORD PTR [ebp-0x2e0]
4aa3e1: push eax
4aa3e2: push 0x63
4aa3e4: push 0x7
4aa3e6: mov cl,0xff
4aa3e8: mov dl,0xff
4aa3ea: mov al,0xff
4aa3ec: call 0x406de4
4aa3f1: push eax
4aa3f2: mov ecx,0x3c
4aa3f7: mov edx,0xc8
4aa3fc: mov eax,esi
4aa3fe: call 0x48e720
4aa403: lea edx,[ebp-0x2ec]
4aa409: mov eax,ds:0x4b1144
4aa40e: mov eax,DWORD PTR [eax]
4aa410: call 0x408190
4aa415: mov ecx,DWORD PTR [ebp-0x2ec]
4aa41b: lea eax,[ebp-0x2e8]
4aa421: mov edx,0x4af000
4aa426: call 0x403c9c
4aa42b: mov eax,DWORD PTR [ebp-0x2e8]
4aa431: push eax
4aa432: push 0x63
4aa434: push 0x7
4aa436: mov cl,0xff
4aa438: mov dl,0xff
4aa43a: mov al,0xff
4aa43c: call 0x406de4
4aa441: push eax
4aa442: mov ecx,0x44
4aa447: mov edx,0xc8
4aa44c: mov eax,esi
4aa44e: call 0x48e720
4aa453: push 0x4af010
4aa458: lea edx,[ebp-0x2f4]
4aa45e: mov eax,ds:0x4b0f54
4aa463: movzx eax,WORD PTR [eax]
4aa466: call 0x408190
4aa46b: push DWORD PTR [ebp-0x2f4]
4aa471: push 0x4af020
4aa476: lea edx,[ebp-0x2f8]
4aa47c: mov eax,DWORD PTR [esi+0x2d4]
4aa482: mov eax,DWORD PTR [eax+0x28]
4aa485: call 0x408190
4aa48a: push DWORD PTR [ebp-0x2f8]
4aa490: lea eax,[ebp-0x2f0]
4aa496: mov edx,0x4
4aa49b: call 0x403d10
4aa4a0: mov eax,DWORD PTR [ebp-0x2f0]
4aa4a6: push eax
4aa4a7: push 0x63
4aa4a9: push 0x7
4aa4ab: mov cl,0xff
4aa4ad: mov dl,0xff
4aa4af: mov al,0xff
4aa4b1: call 0x406de4
4aa4b6: push eax
4aa4b7: mov ecx,0x54
4aa4bc: mov edx,0xc8
4aa4c1: mov eax,esi
4aa4c3: call 0x48e720
4aa4c8: mov eax,ds:0x4b11f4
4aa4cd: fld QWORD PTR [eax]
4aa4cf: add esp,0xfffffff4
4aa4d2: fstp TBYTE PTR [esp]
4aa4d5: fwait
4aa4d6: lea eax,[ebp-0x300]
4aa4dc: call 0x408ddc
4aa4e1: mov ecx,DWORD PTR [ebp-0x300]
4aa4e7: lea eax,[ebp-0x2fc]
4aa4ed: mov edx,0x4af030
4aa4f2: call 0x403c9c
4aa4f7: mov eax,DWORD PTR [ebp-0x2fc]
4aa4fd: push eax
4aa4fe: push 0x63
4aa500: push 0x7
4aa502: mov cl,0xff
4aa504: mov dl,0xff
4aa506: mov al,0xff
4aa508: call 0x406de4
4aa50d: push eax
4aa50e: mov ecx,0x64
4aa513: mov edx,0xc8
4aa518: mov eax,esi
4aa51a: call 0x48e720
4aa51f: lea edx,[ebp-0x308]
4aa525: mov eax,ds:0x4b0e3c
4aa52a: mov eax,DWORD PTR [eax]
4aa52c: call 0x408190
4aa531: mov ecx,DWORD PTR [ebp-0x308]
4aa537: lea eax,[ebp-0x304]
4aa53d: mov edx,0x4af048
4aa542: call 0x403c9c
4aa547: mov eax,DWORD PTR [ebp-0x304]
4aa54d: push eax
4aa54e: push 0x63
4aa550: push 0x7
4aa552: mov cl,0xff
4aa554: mov dl,0xff
4aa556: mov al,0xff
4aa558: call 0x406de4
4aa55d: push eax
4aa55e: mov ecx,0x74
4aa563: mov edx,0xc8
4aa568: mov eax,esi
4aa56a: call 0x48e720
4aa56f: lea edx,[ebp-0x310]
4aa575: mov eax,ds:0x4b0df0
4aa57a: mov eax,DWORD PTR [eax]
4aa57c: call 0x408190
4aa581: mov ecx,DWORD PTR [ebp-0x310]
4aa587: lea eax,[ebp-0x30c]
4aa58d: mov edx,0x4af058
4aa592: call 0x403c9c
4aa597: mov eax,DWORD PTR [ebp-0x30c]
4aa59d: push eax
4aa59e: push 0x63
4aa5a0: push 0x7
4aa5a2: mov cl,0xff
4aa5a4: mov dl,0xff
4aa5a6: mov al,0xff
4aa5a8: call 0x406de4
4aa5ad: push eax
4aa5ae: mov ecx,0x7c
4aa5b3: mov edx,0xc8
4aa5b8: mov eax,esi
4aa5ba: call 0x48e720
4aa5bf: lea edx,[ebp-0x318]
4aa5c5: mov eax,ds:0x4b11f8
4aa5ca: movsx eax,WORD PTR [eax]
4aa5cd: call 0x408190
4aa5d2: mov ecx,DWORD PTR [ebp-0x318]
4aa5d8: lea eax,[ebp-0x314]
4aa5de: mov edx,0x4af068
4aa5e3: call 0x403c9c
4aa5e8: mov eax,DWORD PTR [ebp-0x314]
4aa5ee: push eax
4aa5ef: push 0x63
4aa5f1: push 0x7
4aa5f3: mov cl,0xff
4aa5f5: mov dl,0xff
4aa5f7: mov al,0xff
4aa5f9: call 0x406de4
4aa5fe: push eax
4aa5ff: mov ecx,0x8c
4aa604: mov edx,0xc8
4aa609: mov eax,esi
4aa60b: call 0x48e720
4aa610: lea edx,[ebp-0x320]
4aa616: mov eax,ds:0x4b1124
4aa61b: movzx eax,BYTE PTR [eax]
4aa61e: call 0x408190
4aa623: mov ecx,DWORD PTR [ebp-0x320]
4aa629: lea eax,[ebp-0x31c]
4aa62f: mov edx,0x4af078
4aa634: call 0x403c9c
4aa639: mov eax,DWORD PTR [ebp-0x31c]
4aa63f: push eax
4aa640: push 0x63
4aa642: push 0x7
4aa644: mov cl,0xff
4aa646: mov dl,0xff
4aa648: mov al,0xff
4aa64a: call 0x406de4
4aa64f: push eax
4aa650: mov ecx,0x9c
4aa655: mov edx,0xc8
4aa65a: mov eax,esi
4aa65c: call 0x48e720
4aa661: lea edx,[ebp-0x328]
4aa667: mov eax,ds:0x4b0db4
4aa66c: movzx eax,BYTE PTR [eax]
4aa66f: call 0x408190
4aa674: mov ecx,DWORD PTR [ebp-0x328]
4aa67a: lea eax,[ebp-0x324]
4aa680: mov edx,0x4af08c
4aa685: call 0x403c9c
4aa68a: mov eax,DWORD PTR [ebp-0x324]
4aa690: push eax
4aa691: push 0x63
4aa693: push 0x7
4aa695: mov cl,0xff
4aa697: mov dl,0xff
4aa699: mov al,0xff
4aa69b: call 0x406de4
4aa6a0: push eax
4aa6a1: mov ecx,0xac
4aa6a6: mov edx,0xc8
4aa6ab: mov eax,esi
4aa6ad: call 0x48e720
4aa6b2: lea edx,[ebp-0x330]
4aa6b8: mov eax,ds:0x4b0fd4
4aa6bd: movzx eax,BYTE PTR [eax]
4aa6c0: call 0x408190
4aa6c5: mov ecx,DWORD PTR [ebp-0x330]
4aa6cb: lea eax,[ebp-0x32c]
4aa6d1: mov edx,0x4af0a4
4aa6d6: call 0x403c9c
4aa6db: mov eax,DWORD PTR [ebp-0x32c]
4aa6e1: push eax
4aa6e2: push 0x63
4aa6e4: push 0x7
4aa6e6: mov cl,0xff
4aa6e8: mov dl,0xff
4aa6ea: mov al,0xff
4aa6ec: call 0x406de4
4aa6f1: push eax
4aa6f2: mov ecx,0xb4
4aa6f7: mov edx,0xc8
4aa6fc: mov eax,esi
4aa6fe: call 0x48e720
4aa703: lea edx,[ebp-0x338]
4aa709: mov eax,ds:0x4b0e84
4aa70e: movzx eax,BYTE PTR [eax]
4aa711: call 0x408190
4aa716: mov ecx,DWORD PTR [ebp-0x338]
4aa71c: lea eax,[ebp-0x334]
4aa722: mov edx,0x4af0b8
4aa727: call 0x403c9c
4aa72c: mov eax,DWORD PTR [ebp-0x334]
4aa732: push eax
4aa733: push 0x63
4aa735: push 0x7
4aa737: mov cl,0xff
4aa739: mov dl,0xff
4aa73b: mov al,0xff
4aa73d: call 0x406de4
4aa742: push eax
4aa743: mov ecx,0xc4
4aa748: mov edx,0xc8
4aa74d: mov eax,esi
4aa74f: call 0x48e720
4aa754: lea edx,[ebp-0x340]
4aa75a: mov eax,ds:0x4b1074
4aa75f: movzx eax,BYTE PTR [eax]
4aa762: call 0x408190
4aa767: mov ecx,DWORD PTR [ebp-0x340]
4aa76d: lea eax,[ebp-0x33c]
4aa773: mov edx,0x4af0d0
4aa778: call 0x403c9c
4aa77d: mov eax,DWORD PTR [ebp-0x33c]
4aa783: push eax
4aa784: push 0x63
4aa786: push 0x7
4aa788: mov cl,0xff
4aa78a: mov dl,0xff
4aa78c: mov al,0xff
4aa78e: call 0x406de4
4aa793: push eax
4aa794: mov ecx,0xcc
4aa799: mov edx,0xc8
4aa79e: mov eax,esi
4aa7a0: call 0x48e720
4aa7a5: lea edx,[ebp-0x348]
4aa7ab: mov eax,ds:0x4b0f64
4aa7b0: movsx eax,WORD PTR [eax]
4aa7b3: call 0x408190
4aa7b8: mov ecx,DWORD PTR [ebp-0x348]
4aa7be: lea eax,[ebp-0x344]
4aa7c4: mov edx,0x4af0e8
4aa7c9: call 0x403c9c
4aa7ce: mov eax,DWORD PTR [ebp-0x344]
4aa7d4: push eax
4aa7d5: push 0x63
4aa7d7: push 0x7
4aa7d9: mov cl,0xff
4aa7db: mov dl,0xff
4aa7dd: mov al,0xff
4aa7df: call 0x406de4
4aa7e4: push eax
4aa7e5: mov ecx,0xdc
4aa7ea: mov edx,0xc8
4aa7ef: mov eax,esi
4aa7f1: call 0x48e720
4aa7f6: lea edx,[ebp-0x350]
4aa7fc: mov eax,ds:0x4b117c
4aa801: movzx eax,WORD PTR [eax]
4aa804: call 0x408190
4aa809: mov ecx,DWORD PTR [ebp-0x350]
4aa80f: lea eax,[ebp-0x34c]
4aa815: mov edx,0x4af0f8
4aa81a: call 0x403c9c
4aa81f: mov eax,DWORD PTR [ebp-0x34c]
4aa825: push eax
4aa826: push 0x63
4aa828: push 0x7
4aa82a: mov cl,0xff
4aa82c: mov dl,0xff
4aa82e: mov al,0xff
4aa830: call 0x406de4
4aa835: push eax
4aa836: mov ecx,0xe4
4aa83b: mov edx,0xc8
4aa840: mov eax,esi
4aa842: call 0x48e720
4aa847: lea edx,[ebp-0x358]
4aa84d: mov eax,ds:0x4b1094
4aa852: movzx eax,BYTE PTR [eax]
4aa855: call 0x408190
4aa85a: mov ecx,DWORD PTR [ebp-0x358]
4aa860: lea eax,[ebp-0x354]
4aa866: mov edx,0x4af10c
4aa86b: call 0x403c9c
4aa870: mov eax,DWORD PTR [ebp-0x354]
4aa876: push eax
4aa877: push 0x63
4aa879: push 0x7
4aa87b: mov cl,0xff
4aa87d: mov dl,0xff
4aa87f: mov al,0xff
4aa881: call 0x406de4
4aa886: push eax
4aa887: mov ecx,0xf0
4aa88c: mov edx,0xc8
4aa891: mov eax,esi
4aa893: call 0x48e720
4aa898: mov eax,ds:0x4b0ef0
4aa89d: fld QWORD PTR [eax]
4aa89f: mov eax,ds:0x4b0ef0
4aa8a4: fsub QWORD PTR [eax+0xb0]
4aa8aa: fabs
4aa8ac: call 0x402894
4aa8b1: push edx
4aa8b2: push eax
4aa8b3: lea eax,[ebp-0x360]
4aa8b9: call 0x4081c0
4aa8be: mov ecx,DWORD PTR [ebp-0x360]
4aa8c4: lea eax,[ebp-0x35c]
4aa8ca: mov edx,0x4af11c
4aa8cf: call 0x403c9c
4aa8d4: mov eax,DWORD PTR [ebp-0x35c]
4aa8da: push eax
4aa8db: push 0x63
4aa8dd: push 0x7
4aa8df: mov cl,0xff
4aa8e1: mov dl,0xff
4aa8e3: mov al,0xff
4aa8e5: call 0x406de4
4aa8ea: push eax
4aa8eb: mov ecx,0xf8
4aa8f0: mov edx,0xc8
4aa8f5: mov eax,esi
4aa8f7: call 0x48e720
4aa8fc: mov DWORD PTR [ebp-0xc],0x1
4aa903: mov ebx,DWORD PTR ds:0x4b0ef0
4aa909: add ebx,0x10
4aa90c: cmp DWORD PTR [ebp-0xc],0x1
4aa910: jne 0x4aa919
4aa912: mov DWORD PTR [ebp-0x10],0xffffffff
4aa919: cmp DWORD PTR [ebp-0xc],0x2
4aa91d: jne 0x4aa926
4aa91f: mov DWORD PTR [ebp-0x10],0x1
4aa926: lea edx,[ebp-0x364]
4aa92c: movsx eax,BYTE PTR [ebx]
4aa92f: call 0x408190
4aa934: mov eax,DWORD PTR [ebp-0x364]
4aa93a: push eax
4aa93b: push 0x63
4aa93d: push 0xa
4aa93f: mov cl,0xff
4aa941: mov dl,0xff
4aa943: mov al,0xff
4aa945: call 0x406de4
4aa94a: push eax
4aa94b: imul edx,DWORD PTR [ebp-0x10],0x96
4aa952: add edx,0xc8
4aa958: mov ecx,0x2
4aa95d: mov eax,esi
4aa95f: call 0x48e720
4aa964: fld QWORD PTR [ebx+0x30]
4aa967: add esp,0xfffffff4
4aa96a: fstp TBYTE PTR [esp]
4aa96d: fwait
4aa96e: lea eax,[ebp-0x36c]
4aa974: call 0x408ddc
4aa979: mov ecx,DWORD PTR [ebp-0x36c]
4aa97f: lea eax,[ebp-0x368]
4aa985: mov edx,0x4af130
4aa98a: call 0x403c9c
4aa98f: mov eax,DWORD PTR [ebp-0x368]
4aa995: push eax
4aa996: push 0x63
4aa998: push 0x7
4aa99a: mov cl,0xff
4aa99c: mov dl,0xff
4aa99e: mov al,0xff
4aa9a0: call 0x406de4
4aa9a5: push eax
4aa9a6: imul edx,DWORD PTR [ebp-0x10],0x5a
4aa9aa: add edx,0xc8
4aa9b0: mov ecx,0x21
4aa9b5: mov eax,esi
4aa9b7: call 0x48e720
4aa9bc: fld QWORD PTR [ebx+0x50]
4aa9bf: add esp,0xfffffff4
4aa9c2: fstp TBYTE PTR [esp]
4aa9c5: fwait
4aa9c6: lea eax,[ebp-0x374]
4aa9cc: call 0x408ddc
4aa9d1: mov ecx,DWORD PTR [ebp-0x374]
4aa9d7: lea eax,[ebp-0x370]
4aa9dd: mov edx,0x4af13c
4aa9e2: call 0x403c9c
4aa9e7: mov eax,DWORD PTR [ebp-0x370]
4aa9ed: push eax
4aa9ee: push 0x63
4aa9f0: push 0x7
4aa9f2: mov cl,0xff
4aa9f4: mov dl,0xff
4aa9f6: mov al,0xff
4aa9f8: call 0x406de4
4aa9fd: push eax
4aa9fe: imul edx,DWORD PTR [ebp-0x10],0x6e
4aaa02: add edx,0xc8
4aaa08: mov ecx,0x112
4aaa0d: mov eax,esi
4aaa0f: call 0x48e720
4aaa14: fld QWORD PTR [ebx-0x10]
4aaa17: call 0x402894
4aaa1c: push edx
4aaa1d: push eax
4aaa1e: lea eax,[ebp-0x37c]
4aaa24: call 0x4081c0
4aaa29: mov ecx,DWORD PTR [ebp-0x37c]
4aaa2f: lea eax,[ebp-0x378]
4aaa35: mov edx,0x4af150
4aaa3a: call 0x403c9c
4aaa3f: mov eax,DWORD PTR [ebp-0x378]
4aaa45: push eax
4aaa46: push 0x63
4aaa48: push 0x7
4aaa4a: mov cl,0xff
4aaa4c: mov dl,0xff
4aaa4e: mov al,0xff
4aaa50: call 0x406de4
4aaa55: push eax
4aaa56: imul edx,DWORD PTR [ebp-0x10],0x96
4aaa5d: add edx,0xc8
4aaa63: mov ecx,0x55
4aaa68: mov eax,esi
4aaa6a: call 0x48e720
4aaa6f: fld QWORD PTR [ebx-0x8]
4aaa72: call 0x402894
4aaa77: push edx
4aaa78: push eax
4aaa79: lea eax,[ebp-0x384]
4aaa7f: call 0x4081c0
4aaa84: mov ecx,DWORD PTR [ebp-0x384]
4aaa8a: lea eax,[ebp-0x380]
4aaa90: mov edx,0x4af15c
4aaa95: call 0x403c9c
4aaa9a: mov eax,DWORD PTR [ebp-0x380]
4aaaa0: push eax
4aaaa1: push 0x63
4aaaa3: push 0x7
4aaaa5: mov cl,0xff
4aaaa7: mov dl,0xff
4aaaa9: mov al,0xff
4aaaab: call 0x406de4
4aaab0: push eax
4aaab1: imul edx,DWORD PTR [ebp-0x10],0x96
4aaab8: add edx,0xc8
4aaabe: mov ecx,0x5d
4aaac3: mov eax,esi
4aaac5: call 0x48e720
4aaaca: lea edx,[ebp-0x38c]
4aaad0: xor eax,eax
4aaad2: mov al,BYTE PTR [ebx+0x5b]
4aaad5: call 0x408190
4aaada: mov ecx,DWORD PTR [ebp-0x38c]
4aaae0: lea eax,[ebp-0x388]
4aaae6: mov edx,0x4af168
4aaaeb: call 0x403c9c
4aaaf0: mov eax,DWORD PTR [ebp-0x388]
4aaaf6: push eax
4aaaf7: push 0x63
4aaaf9: push 0x7
4aaafb: mov cl,0xff
4aaafd: mov dl,0xff
4aaaff: mov al,0xff
4aab01: call 0x406de4
4aab06: push eax
4aab07: imul edx,DWORD PTR [ebp-0x10],0x96
4aab0e: add edx,0xc8
4aab14: mov ecx,0x65
4aab19: mov eax,esi
4aab1b: call 0x48e720
4aab20: push 0x4af10c
4aab25: lea edx,[ebp-0x394]
4aab2b: movsx eax,WORD PTR [ebx+0x64]
4aab2f: call 0x408190
4aab34: push DWORD PTR [ebp-0x394]
4aab3a: push 0x4aeeb4
4aab3f: lea edx,[ebp-0x398]
4aab45: movsx eax,WORD PTR [ebx+0x66]
4aab49: call 0x408190
4aab4e: push DWORD PTR [ebp-0x398]
4aab54: lea eax,[ebp-0x390]
4aab5a: mov edx,0x4
4aab5f: call 0x403d10
4aab64: mov eax,DWORD PTR [ebp-0x390]
4aab6a: push eax
4aab6b: push 0x63
4aab6d: push 0x7
4aab6f: mov cl,0xff
4aab71: mov dl,0xff
4aab73: mov al,0xff
4aab75: call 0x406de4
4aab7a: push eax
4aab7b: imul edx,DWORD PTR [ebp-0x10],0x96
4aab82: add edx,0xc8
4aab88: mov ecx,0x6d
4aab8d: mov eax,esi
4aab8f: call 0x48e720
4aab94: lea edx,[ebp-0x3a0]
4aab9a: xor eax,eax
4aab9c: mov al,BYTE PTR [ebx+0x5c]
4aab9f: call 0x408190
4aaba4: mov ecx,DWORD PTR [ebp-0x3a0]
4aabaa: lea eax,[ebp-0x39c]
4aabb0: mov edx,0x4af178
4aabb5: call 0x403c9c
4aabba: mov eax,DWORD PTR [ebp-0x39c]
4aabc0: push eax
4aabc1: push 0x63
4aabc3: push 0x7
4aabc5: mov cl,0xff
4aabc7: mov dl,0xff
4aabc9: mov al,0xff
4aabcb: call 0x406de4
4aabd0: push eax
4aabd1: imul edx,DWORD PTR [ebp-0x10],0x96
4aabd8: add edx,0xc8
4aabde: mov ecx,0x75
4aabe3: mov eax,esi
4aabe5: call 0x48e720
4aabea: cmp BYTE PTR [ebx+0x5a],0x1
4aabee: jne 0x4aac1e
4aabf0: push 0x4af18c
4aabf5: push 0x63
4aabf7: push 0x7
4aabf9: mov cl,0xff
4aabfb: mov dl,0xff
4aabfd: mov al,0xff
4aabff: call 0x406de4
4aac04: push eax
4aac05: imul edx,DWORD PTR [ebp-0x10],0x96
4aac0c: add edx,0xc8
4aac12: mov ecx,0x85
4aac17: mov eax,esi
4aac19: call 0x48e720
4aac1e: cmp BYTE PTR [ebx+0x58],0x1
4aac22: jne 0x4aac52
4aac24: push 0x4af19c
4aac29: push 0x63
4aac2b: push 0x7
4aac2d: mov cl,0xff
4aac2f: mov dl,0xff
4aac31: mov al,0xff
4aac33: call 0x406de4
4aac38: push eax
4aac39: imul edx,DWORD PTR [ebp-0x10],0xaf
4aac40: add edx,0xc8
4aac46: mov ecx,0x8d
4aac4b: mov eax,esi
4aac4d: call 0x48e720
4aac52: cmp BYTE PTR [ebx+0x83],0x1
4aac59: jne 0x4aac89
4aac5b: push 0x4af1ac
4aac60: push 0x63
4aac62: push 0x7
4aac64: mov cl,0xff
4aac66: mov dl,0xff
4aac68: mov al,0xff
4aac6a: call 0x406de4
4aac6f: push eax
4aac70: imul edx,DWORD PTR [ebp-0x10],0x96
4aac77: add edx,0xc8
4aac7d: mov ecx,0x95
4aac82: mov eax,esi
4aac84: call 0x48e720
4aac89: cmp BYTE PTR [ebx+0x82],0x1
4aac90: jne 0x4aacc0
4aac92: push 0x4af1bc
4aac97: push 0x63
4aac99: push 0x7
4aac9b: mov cl,0xff
4aac9d: mov dl,0xff
4aac9f: mov al,0xff
4aaca1: call 0x406de4
4aaca6: push eax
4aaca7: imul edx,DWORD PTR [ebp-0x10],0x96
4aacae: add edx,0xc8
4aacb4: mov ecx,0x9d
4aacb9: mov eax,esi
4aacbb: call 0x48e720
4aacc0: lea edx,[ebp-0x3a8]
4aacc6: xor eax,eax
4aacc8: mov al,BYTE PTR [ebx+0x60]
4aaccb: call 0x408190
4aacd0: mov ecx,DWORD PTR [ebp-0x3a8]
4aacd6: lea eax,[ebp-0x3a4]
4aacdc: mov edx,0x4af1d0
4aace1: call 0x403c9c
4aace6: mov eax,DWORD PTR [ebp-0x3a4]
4aacec: push eax
4aaced: push 0x63
4aacef: push 0x7
4aacf1: mov cl,0xff
4aacf3: mov dl,0xff
4aacf5: mov al,0xff
4aacf7: call 0x406de4
4aacfc: push eax
4aacfd: imul edx,DWORD PTR [ebp-0x10],0x8c
4aad04: add edx,0xc8
4aad0a: mov ecx,0x8d
4aad0f: mov eax,esi
4aad11: call 0x48e720
4aad16: lea edx,[ebp-0x3b0]
4aad1c: xor eax,eax
4aad1e: mov al,BYTE PTR [ebx+0x5f]
4aad21: call 0x408190
4aad26: mov ecx,DWORD PTR [ebp-0x3b0]
4aad2c: lea eax,[ebp-0x3ac]
4aad32: mov edx,0x4af1dc
4aad37: call 0x403c9c
4aad3c: mov eax,DWORD PTR [ebp-0x3ac]
4aad42: push eax
4aad43: push 0x63
4aad45: push 0x7
4aad47: mov cl,0xff
4aad49: mov dl,0xff
4aad4b: mov al,0xff
4aad4d: call 0x406de4
4aad52: push eax
4aad53: imul edx,DWORD PTR [ebp-0x10],0x73
4aad57: add edx,0xc8
4aad5d: mov ecx,0x8d
4aad62: mov eax,esi
4aad64: call 0x48e720
4aad69: cmp BYTE PTR [ebx+0x59],0x1
4aad6d: jne 0x4aad9a
4aad6f: push 0x4af1e8
4aad74: push 0x63
4aad76: push 0x7
4aad78: mov cl,0xff
4aad7a: mov dl,0xff
4aad7c: mov al,0xff
4aad7e: call 0x406de4
4aad83: push eax
4aad84: imul edx,DWORD PTR [ebp-0x10],0x4b
4aad88: add edx,0xc8
4aad8e: mov ecx,0x8d
4aad93: mov eax,esi
4aad95: call 0x48e720
4aad9a: lea edx,[ebp-0x3b8]
4aada0: movsx eax,BYTE PTR [ebx+0x68]
4aada4: call 0x408190
4aada9: mov ecx,DWORD PTR [ebp-0x3b8]
4aadaf: lea eax,[ebp-0x3b4]
4aadb5: mov edx,0x4af1f8
4aadba: call 0x403c9c
4aadbf: mov eax,DWORD PTR [ebp-0x3b4]
4aadc5: push eax
4aadc6: push 0x63
4aadc8: push 0x7
4aadca: mov cl,0xff
4aadcc: mov dl,0xff
4aadce: mov al,0xff
4aadd0: call 0x406de4
4aadd5: push eax
4aadd6: imul edx,DWORD PTR [ebp-0x10],0x96
4aaddd: add edx,0xc8
4aade3: mov ecx,0xad
4aade8: mov eax,esi
4aadea: call 0x48e720
4aadef: lea edx,[ebp-0x3c0]
4aadf5: xor eax,eax
4aadf7: mov al,BYTE PTR [ebx+0x88]
4aadfd: call 0x408190
4aae02: mov ecx,DWORD PTR [ebp-0x3c0]
4aae08: lea eax,[ebp-0x3bc]
4aae0e: mov edx,0x4af208
4aae13: call 0x403c9c
4aae18: mov eax,DWORD PTR [ebp-0x3bc]
4aae1e: push eax
4aae1f: push 0x63
4aae21: push 0x7
4aae23: mov cl,0xff
4aae25: mov dl,0xff
4aae27: mov al,0xff
4aae29: call 0x406de4
4aae2e: push eax
4aae2f: imul edx,DWORD PTR [ebp-0x10],0x96
4aae36: add edx,0xc8
4aae3c: mov ecx,0xbd
4aae41: mov eax,esi
4aae43: call 0x48e720
4aae48: lea edx,[ebp-0x3c8]
4aae4e: xor eax,eax
4aae50: mov al,BYTE PTR [ebx+0x89]
4aae56: call 0x408190
4aae5b: mov ecx,DWORD PTR [ebp-0x3c8]
4aae61: lea eax,[ebp-0x3c4]
4aae67: mov edx,0x4af21c
4aae6c: call 0x403c9c
4aae71: mov eax,DWORD PTR [ebp-0x3c4]
4aae77: push eax
4aae78: push 0x63
4aae7a: push 0x7
4aae7c: mov cl,0xff
4aae7e: mov dl,0xff
4aae80: mov al,0xff
4aae82: call 0x406de4
4aae87: push eax
4aae88: imul edx,DWORD PTR [ebp-0x10],0x96
4aae8f: add edx,0xc8
4aae95: mov ecx,0xc5
4aae9a: mov eax,esi
4aae9c: call 0x48e720
4aaea1: lea edx,[ebp-0x3d0]
4aaea7: xor eax,eax
4aaea9: mov al,BYTE PTR [ebx+0x8a]
4aaeaf: call 0x408190
4aaeb4: mov ecx,DWORD PTR [ebp-0x3d0]
4aaeba: lea eax,[ebp-0x3cc]
4aaec0: mov edx,0x4af230
4aaec5: call 0x403c9c
4aaeca: mov eax,DWORD PTR [ebp-0x3cc]
4aaed0: push eax
4aaed1: push 0x63
4aaed3: push 0x7
4aaed5: mov cl,0xff
4aaed7: mov dl,0xff
4aaed9: mov al,0xff
4aaedb: call 0x406de4
4aaee0: push eax
4aaee1: imul edx,DWORD PTR [ebp-0x10],0x96
4aaee8: add edx,0xc8
4aaeee: mov ecx,0xdd
4aaef3: mov eax,esi
4aaef5: call 0x48e720
4aaefa: lea edx,[ebp-0x3d8]
4aaf00: xor eax,eax
4aaf02: mov al,BYTE PTR [ebx+0x8b]
4aaf08: call 0x408190
4aaf0d: mov ecx,DWORD PTR [ebp-0x3d8]
4aaf13: lea eax,[ebp-0x3d4]
4aaf19: mov edx,0x4af248
4aaf1e: call 0x403c9c
4aaf23: mov eax,DWORD PTR [ebp-0x3d4]
4aaf29: push eax
4aaf2a: push 0x63
4aaf2c: push 0x7
4aaf2e: mov cl,0xff
4aaf30: mov dl,0xff
4aaf32: mov al,0xff
4aaf34: call 0x406de4
4aaf39: push eax
4aaf3a: imul edx,DWORD PTR [ebp-0x10],0x96
4aaf41: add edx,0xc8
4aaf47: mov ecx,0xe5
4aaf4c: mov eax,esi
4aaf4e: call 0x48e720
4aaf53: lea edx,[ebp-0x3e0]
4aaf59: xor eax,eax
4aaf5b: mov al,BYTE PTR [ebx+0x8c]
4aaf61: call 0x408190
4aaf66: mov ecx,DWORD PTR [ebp-0x3e0]
4aaf6c: lea eax,[ebp-0x3dc]
4aaf72: mov edx,0x4af25c
4aaf77: call 0x403c9c
4aaf7c: mov eax,DWORD PTR [ebp-0x3dc]
4aaf82: push eax
4aaf83: push 0x63
4aaf85: push 0x7
4aaf87: mov cl,0xff
4aaf89: mov dl,0xff
4aaf8b: mov al,0xff
4aaf8d: call 0x406de4
4aaf92: push eax
4aaf93: imul edx,DWORD PTR [ebp-0x10],0x96
4aaf9a: add edx,0xc8
4aafa0: mov ecx,0xed
4aafa5: mov eax,esi
4aafa7: call 0x48e720
4aafac: lea edx,[ebp-0x3e8]
4aafb2: xor eax,eax
4aafb4: mov al,BYTE PTR [ebx+0x8d]
4aafba: call 0x408190
4aafbf: mov ecx,DWORD PTR [ebp-0x3e8]
4aafc5: lea eax,[ebp-0x3e4]
4aafcb: mov edx,0x4af270
4aafd0: call 0x403c9c
4aafd5: mov eax,DWORD PTR [ebp-0x3e4]
4aafdb: push eax
4aafdc: push 0x63
4aafde: push 0x7
4aafe0: mov cl,0xff
4aafe2: mov dl,0xff
4aafe4: mov al,0xff
4aafe6: call 0x406de4
4aafeb: push eax
4aafec: imul edx,DWORD PTR [ebp-0x10],0x96
4aaff3: add edx,0xc8
4aaff9: mov ecx,0xf5
4aaffe: mov eax,esi
4ab000: call 0x48e720
4ab005: push 0x4af288
4ab00a: lea edx,[ebp-0x3f0]
4ab010: xor eax,eax
4ab012: mov al,BYTE PTR [ebx+0x85]
4ab018: call 0x408190
4ab01d: push DWORD PTR [ebp-0x3f0]
4ab023: push 0x4af298
4ab028: lea edx,[ebp-0x3f4]
4ab02e: xor eax,eax
4ab030: mov al,BYTE PTR [ebx+0x87]
4ab036: call 0x408190
4ab03b: push DWORD PTR [ebp-0x3f4]
4ab041: lea eax,[ebp-0x3ec]
4ab047: mov edx,0x4
4ab04c: call 0x403d10
4ab051: mov eax,DWORD PTR [ebp-0x3ec]
4ab057: push eax
4ab058: push 0x63
4ab05a: push 0x7
4ab05c: mov cl,0xff
4ab05e: mov dl,0xff
4ab060: mov al,0xff
4ab062: call 0x406de4
4ab067: push eax
4ab068: imul edx,DWORD PTR [ebp-0x10],0x96
4ab06f: add edx,0xc8
4ab075: mov ecx,0xff
4ab07a: mov eax,esi
4ab07c: call 0x48e720
4ab081: lea edx,[ebp-0x3fc]
4ab087: xor eax,eax
4ab089: mov al,BYTE PTR [ebx+0x86]
4ab08f: call 0x408190
4ab094: mov ecx,DWORD PTR [ebp-0x3fc]
4ab09a: lea eax,[ebp-0x3f8]
4ab0a0: mov edx,0x4af2a4
4ab0a5: call 0x403c9c
4ab0aa: mov eax,DWORD PTR [ebp-0x3f8]
4ab0b0: push eax
4ab0b1: push 0x63
4ab0b3: push 0x7
4ab0b5: mov cl,0xff
4ab0b7: mov dl,0xff
4ab0b9: mov al,0xff
4ab0bb: call 0x406de4
4ab0c0: push eax
4ab0c1: imul edx,DWORD PTR [ebp-0x10],0x96
4ab0c8: add edx,0xc8
4ab0ce: mov ecx,0x107
4ab0d3: mov eax,esi
4ab0d5: call 0x48e720
4ab0da: lea edx,[ebp-0x404]
4ab0e0: movsx eax,WORD PTR [ebx+0x6]
4ab0e4: call 0x408190
4ab0e9: mov ecx,DWORD PTR [ebp-0x404]
4ab0ef: lea eax,[ebp-0x400]
4ab0f5: mov edx,0x4af2b8
4ab0fa: call 0x403c9c
4ab0ff: mov eax,DWORD PTR [ebp-0x400]
4ab105: push eax
4ab106: push 0x63
4ab108: push 0x7
4ab10a: mov cl,0xff
4ab10c: mov dl,0xff
4ab10e: mov al,0xff
4ab110: call 0x406de4
4ab115: push eax
4ab116: imul edx,DWORD PTR [ebp-0x10],0x5a
4ab11a: add edx,0xc8
4ab120: mov ecx,0x55
4ab125: mov eax,esi
4ab127: call 0x48e720
4ab12c: lea edx,[ebp-0x40c]
4ab132: movsx eax,WORD PTR [ebx+0x8]
4ab136: call 0x408190
4ab13b: mov ecx,DWORD PTR [ebp-0x40c]
4ab141: lea eax,[ebp-0x408]
4ab147: mov edx,0x4af2c8
4ab14c: call 0x403c9c
4ab151: mov eax,DWORD PTR [ebp-0x408]
4ab157: push eax
4ab158: push 0x63
4ab15a: push 0x7
4ab15c: mov cl,0xff
4ab15e: mov dl,0xff
4ab160: mov al,0xff
4ab162: call 0x406de4
4ab167: push eax
4ab168: imul edx,DWORD PTR [ebp-0x10],0x5a
4ab16c: add edx,0xc8
4ab172: mov ecx,0x5d
4ab177: mov eax,esi
4ab179: call 0x48e720
4ab17e: lea edx,[ebp-0x414]
4ab184: xor eax,eax
4ab186: mov al,BYTE PTR [ebx+0x5d]
4ab189: call 0x408190
4ab18e: mov ecx,DWORD PTR [ebp-0x414]
4ab194: lea eax,[ebp-0x410]
4ab19a: mov edx,0x4af2dc
4ab19f: call 0x403c9c
4ab1a4: mov eax,DWORD PTR [ebp-0x410]
4ab1aa: push eax
4ab1ab: push 0x63
4ab1ad: push 0x7
4ab1af: mov cl,0xff
4ab1b1: mov dl,0xff
4ab1b3: mov al,0xff
4ab1b5: call 0x406de4
4ab1ba: push eax
4ab1bb: imul edx,DWORD PTR [ebp-0x10],0x6e
4ab1bf: add edx,0xc8
4ab1c5: mov ecx,0x41
4ab1ca: mov eax,esi
4ab1cc: call 0x48e720
4ab1d1: inc DWORD PTR [ebp-0xc]
4ab1d4: add ebx,0xb0
4ab1da: cmp DWORD PTR [ebp-0xc],0x3
4ab1de: jne 0x4aa90c
4ab1e4: mov eax,ds:0x4b1110
4ab1e9: mov eax,DWORD PTR [eax]
4ab1eb: mov edx,DWORD PTR ds:0x4b1110
4ab1f1: add eax,DWORD PTR [edx+0x10]
4ab1f4: mov edx,DWORD PTR ds:0x4b11b4
4ab1fa: sub eax,DWORD PTR [edx]
4ab1fc: push eax
4ab1fd: mov eax,ds:0x4b1110
4ab202: mov eax,DWORD PTR [eax+0x4]
4ab205: mov edx,DWORD PTR ds:0x4b1110
4ab20b: add eax,DWORD PTR [edx+0x14]
4ab20e: mov edx,DWORD PTR ds:0x4b1144
4ab214: sub eax,DWORD PTR [edx]
4ab216: push eax
4ab217: mov cl,0xff
4ab219: mov dl,0xff
4ab21b: mov al,0xff
4ab21d: call 0x406de4
4ab222: push eax
4ab223: mov ecx,DWORD PTR ds:0x4b1110
4ab229: mov ecx,DWORD PTR [ecx+0x4]
4ab22c: mov eax,ds:0x4b1110
4ab231: add ecx,DWORD PTR [eax+0xc]
4ab234: mov eax,ds:0x4b1144
4ab239: sub ecx,DWORD PTR [eax]
4ab23b: mov edx,DWORD PTR ds:0x4b1110
4ab241: mov edx,DWORD PTR [edx]
4ab243: mov eax,ds:0x4b1110
4ab248: add edx,DWORD PTR [eax+0x8]
4ab24b: mov eax,ds:0x4b11b4
4ab250: sub edx,DWORD PTR [eax]
4ab252: mov eax,esi
4ab254: call 0x48e4c0
.data 4b111c d6444b0040b64000d844
.data 4b11f8 98444b00db444b004027
.data 4b11fc db444b0040274b00a758
.data 4b0db4 de444b00106244002c71
.data 4b0ef0 e8444b000c204b0030b8
.data 4b110c e0444b00d8574b00ec70
.data 4aef18 00000041000040400000
.data 4b1144 cc444b0004004b0098b8
.data 4b116c dd444b00c8b740000862
.data 4b117c f6574b0088b6400028b7
.data 4b123c d2444b00cc274b0050b8
.data 4b0fb8 d4444b0030204b00b471
.data 4b1210 0a584b009c444b00f061
.data 4b0f6c 08584b0058b6400050b6
.data 4b1098 09584b0078b640005472
.data 4b1074 f8574b00c8274b00d470
.data 4aec88 0000004000005f430000
.data 4aef1c 000040400000a040ffff
.data 4aeee8 000080400000a041ffff
.data 4aef20 0000a040ffffffff0100
.data 4b11b4 c8444b00a0b640003470
.data 4b0d68 9a444b0020b840002420
.data 4b10b8 a0584b0088b74000fc70
.data 4b0f3c e4444b003c704000da44
.data 4b0eec e3444b00e8444b000c20
.data 4b0e84 f9574b00c8b64000f0b6
.data 4aef3c 000000000000fa420000
.data 4b1268 98584b00b0254b00cc70
.data 4b0f64 0c584b009c7140000858
.data 4aef40 0000fa42000098400000
.data 4b1094 c0444b0009584b0078b6
.data 4aef44 000098400000f0410000
.data 4aef48 0000f041000070410000
.data 4b0f84 94444b0044274b0088b8
.data 4aef4c 000070410000c8410000
.data 4aef50 0000c8410000803f3d0a
.data 4aef54 0000803f3d0ad7a3703d
.data 4aef58 3d0ad7a3703d0aaf0040
.data 4aef64 00007042ffffffff0200
.data 4b113c dc444b0040624400cc44
.data 4b0f44 da444b00e0b74000ac70
.data 4aeeec 0000a041ffffffff0100
.data 4b1004 fa574b00447140008471
.data 4b1124 d8444b0024714000580a
.data 4b0d58 c8574b00a4714000e471
.data 4b1110 d8574b00ec7040004846
.data 4b0f18 a0444b009d444b00380a
.data 4b0e80 a4444b00f9574b00c8b6
.data 4b0f50 a8444b00d0444b0050b7
.data 4b0ebc ac444b00cc264b00b0b6
.data 4b10b4 e2444b00a0584b0088b7
.data 4aef80 0000cc4200008042ffff
.data 4aef84 00008042ffffffff0800
.data 4b0fd4 df444b00d4714000a258
.data 4aec94 00002041ffffffff1200
.data 4b0f1c 9d444b00380a4b00a458
.data 4aefe0 0000484300004842ffff
.data 4b122c d7444b0014264b006c70
.data 4b0fb0 c4444b0070b64000d444
.data 4b1080 10584b0080624400d8b6
.data 4b1108 b0444b00e0444b00d857
.data 4b108c b4444b00f8b64000c044
.data 4b1130 b8444b00a3584b00f8b5
.data 4b10c4 bc444b00c00a4b0030b7
.data 4b11f4 88584b0098444b00db44
.data 4b0fe8 90584b00d0264b00e061
.data 4b0d98 a8584b0004204b000024
.data 4b0fc8 9b444b00a5584b00a158
.data 4b1024 e1444b00547040005062
.data 4b1058 ad584b0080b64000fc71
.data 4b0d4c f4574b00d9444b000470
.data 4b1214 9c444b00f0614400d8b7
.data 4aefe4 00004842ffffffff0600
.data 4b0fd0 a1584b00df444b00d471
.data 4b0d94 a6584b00a8584b000420
.data 4b0f24 a4584b0084704000080a
.data 4b0f54 d0444b0050b7400000b9
.data 4b0e3c 00584b00b8b8400078b7
.data 4b0df0 04584b00e0b64000a8b7
.string 4aef2c 20
.string 4aef38 30
.string 4aef70 3150
.string 4aef7c 3250
.string 4aef90 524f554e44202020
.string 4aefa4 4b4f
.string 4aefb0 78353d
.string 4aefbc 205054532e
.string 4aefcc 424f4e555320
.string 4aefdc 2020
.string 4aeff0 54454c41583d
.string 4af000 54454c41593d
.string 4af010 56454c3d
.string 4af020 20204650533d
.string 4af030 4e4956454c2044452044414e4f3d
.string 4af048 4d4f555345583d
.string 4af058 4d4f555345593d
.string 4af068 4348c34f3d
.string 4af078 4e554d43454e4152494f3d
.string 4af08c 494e4943494f20524f554e443d
.string 4af0a4 46494d20524f554e443d
.string 4af0b8 474f4c50452050415553413d
.string 4af0d0 504155534120455350454349414c3d
.string 4af0e8 44454d4f3d
.string 4af0f8 4449414c4f474f3d
.string 4af10c 4349434c4f3d
.string 4af11c 44495354414e4349413d
.string 4af130 48503d
.string 4af13c 455350454349414c3d
.string 4af150 583d
.string 4af15c 593d
.string 4af168 504f533d
.string 4aeeb4 202f20
.string 4af178 444553454e484f3d
.string 4af18c 50554c4f
.string 4af19c 415441515545
.string 4af1ac 444546455341
.string 4af1bc 494e56454e434956454c
.string 4af1d0 463d
.string 4af1dc 543d
.string 4af1e8 44455252554241
.string 4af1f8 475241562e3d
.string 4af208 53455155454e4349413d
.string 4af21c 5345512e2054454d504f3d
.string 4af230 414741434841522054454d503d
.string 4af248 545241532054454d503d
.string 4af25c 534f434f2052455045543d
.string 4af270 43485554452052455045543d
.string 4af288 484954533d
.string 4af298 2f
.string 4af2a4 484954532054454d504f3d
.string 4af2b8 524f543d
.string 4af2c8 56454c20524f543d
.string 4af2dc 4449523d
