; entry 4775fc
4775fc: push ebx
4775fd: push esi
4775fe: push edi
4775ff: push ebp
477600: add esp,0xfffffff4
477603: mov BYTE PTR [esp],dl
477606: mov ebx,eax
477608: mov esi,DWORD PTR ds:0x4b0ef0
47760e: mov edi,DWORD PTR ds:0x4b1098
477614: cmp bl,0x1
477617: jne 0x47761e
477619: mov BYTE PTR [esp+0x2],0x0
47761e: cmp bl,0x2
477621: jne 0x477628
477623: mov BYTE PTR [esp+0x2],0x32
477628: xor eax,eax
47762a: mov al,bl
47762c: imul eax,eax,0x16
47762f: mov BYTE PTR [esi+eax*8-0x1d],0x0
477634: cmp BYTE PTR [esp],0x1
477638: jne 0x47768e
47763a: xor eax,eax
47763c: mov al,bl
47763e: imul eax,eax,0x16
477641: cmp BYTE PTR [esi+eax*8-0x45],0x1
477646: je 0x477656
477648: xor eax,eax
47764a: mov al,bl
47764c: imul eax,eax,0x16
47764f: cmp BYTE PTR [esi+eax*8-0x45],0x2
477654: jne 0x47768e
477656: xor eax,eax
477658: mov al,bl
47765a: imul ebp,eax,0x16
47765d: fld QWORD PTR [esi+ebp*8-0x30]
477661: fchs
477663: add esp,0xfffffff8
477666: fstp QWORD PTR [esp]
477669: fwait
47766a: mov eax,ebx
47766c: call 0x47648c
477671: mov BYTE PTR [esi+ebp*8-0x45],0x2
477676: mov WORD PTR [esi+ebp*8-0x3a],0x63
47767d: mov BYTE PTR [esi+ebp*8-0x1c],0x0
477682: cmp BYTE PTR [esi+ebp*8-0x43],0x2
477687: jne 0x47768e
477689: mov BYTE PTR [esi+ebp*8-0x1c],0x1
47768e: cmp BYTE PTR [esp],0x2
477692: jne 0x4776e3
477694: xor eax,eax
477696: mov al,bl
477698: imul eax,eax,0x16
47769b: cmp BYTE PTR [esi+eax*8-0x45],0x1
4776a0: je 0x4776b0
4776a2: xor eax,eax
4776a4: mov al,bl
4776a6: imul eax,eax,0x16
4776a9: cmp BYTE PTR [esi+eax*8-0x45],0x2
4776ae: jne 0x4776e3
4776b0: xor eax,eax
4776b2: mov al,bl
4776b4: imul ebp,eax,0x16
4776b7: push DWORD PTR [esi+ebp*8-0x2c]
4776bb: push DWORD PTR [esi+ebp*8-0x30]
4776bf: mov eax,ebx
4776c1: call 0x47648c
4776c6: mov BYTE PTR [esi+ebp*8-0x45],0x2
4776cb: mov WORD PTR [esi+ebp*8-0x3a],0x63
4776d2: mov BYTE PTR [esi+ebp*8-0x1c],0x0
4776d7: cmp BYTE PTR [esi+ebp*8-0x43],0x1
4776dc: jne 0x4776e3
4776de: mov BYTE PTR [esi+ebp*8-0x1c],0x1
4776e3: cmp BYTE PTR [esp],0x3
4776e7: jne 0x477785
4776ed: xor eax,eax
4776ef: mov al,bl
4776f1: imul eax,eax,0x16
4776f4: mov al,BYTE PTR [esi+eax*8-0x45]
4776f8: cmp al,0x1
4776fa: je 0x477712
4776fc: xor edx,edx
4776fe: mov dl,bl
477700: imul edx,edx,0x16
477703: cmp al,0x2
477705: je 0x477712
477707: xor edx,edx
477709: mov dl,bl
47770b: imul edx,edx,0x16
47770e: cmp al,0x15
477710: jne 0x477785
477712: xor eax,eax
477714: mov al,bl
477716: imul eax,eax,0x16
477719: cmp BYTE PTR [esi+eax*8-0x38],0x0
47771e: jne 0x477785
477720: xor eax,eax
477722: mov al,bl
477724: imul eax,eax,0x16
477727: mov BYTE PTR [esi+eax*8-0x45],0x3
47772c: xor eax,eax
47772e: mov al,bl
477730: imul eax,eax,0x16
477733: mov WORD PTR [esi+eax*8-0x3c],0x0
47773a: xor eax,eax
47773c: mov al,bl
47773e: imul eax,eax,0x16
477741: mov WORD PTR [esi+eax*8-0x3a],0x6
477748: xor eax,eax
47774a: mov al,bl
47774c: imul eax,eax,0x16
47774f: fld QWORD PTR [esi+eax*8-0x50]
477753: fcomp DWORD PTR ds:0x47d1f8
477759: fnstsw ax
47775b: sahf
47775c: jae 0x477782
47775e: fld DWORD PTR ds:0x47d1fc
477764: mov eax,ds:0x4b0fe8
477769: fmul QWORD PTR [eax]
47776b: xor eax,eax
47776d: mov al,bl
47776f: imul eax,eax,0x16
477772: fadd QWORD PTR [esi+eax*8-0x50]
477776: xor eax,eax
477778: mov al,bl
47777a: imul eax,eax,0x16
47777d: fstp QWORD PTR [esi+eax*8-0x50]
477781: fwait
477782: mov BYTE PTR [edi],0x5
477785: cmp BYTE PTR [esp],0x4
477789: jne 0x477849
47778f: xor eax,eax
477791: mov al,bl
477793: imul eax,eax,0x16
477796: cmp BYTE PTR [esi+eax*8-0x45],0x1
47779b: je 0x4777d6
47779d: xor eax,eax
47779f: mov al,bl
4777a1: imul eax,eax,0x16
4777a4: cmp BYTE PTR [esi+eax*8-0x45],0x2
4777a9: je 0x4777d6
4777ab: xor eax,eax
4777ad: mov al,bl
4777af: imul eax,eax,0x16
4777b2: cmp BYTE PTR [esi+eax*8-0x45],0x3
4777b7: jne 0x4777c8
4777b9: xor eax,eax
4777bb: mov al,bl
4777bd: imul eax,eax,0x16
4777c0: cmp WORD PTR [esi+eax*8-0x3c],0x2
4777c6: jge 0x4777d6
4777c8: xor eax,eax
4777ca: mov al,bl
4777cc: imul eax,eax,0x16
4777cf: cmp BYTE PTR [esi+eax*8-0x45],0x15
4777d4: jne 0x477849
4777d6: xor eax,eax
4777d8: mov al,bl
4777da: imul eax,eax,0x16
4777dd: cmp BYTE PTR [esi+eax*8-0x38],0x0
4777e2: jne 0x477849
4777e4: xor eax,eax
4777e6: mov al,bl
4777e8: imul eax,eax,0x16
4777eb: mov BYTE PTR [esi+eax*8-0x45],0x4
4777f0: xor eax,eax
4777f2: mov al,bl
4777f4: imul eax,eax,0x16
4777f7: mov WORD PTR [esi+eax*8-0x3c],0x0
4777fe: xor eax,eax
477800: mov al,bl
477802: imul eax,eax,0x16
477805: mov WORD PTR [esi+eax*8-0x3a],0x6
47780c: xor eax,eax
47780e: mov al,bl
477810: imul eax,eax,0x16
477813: fld QWORD PTR [esi+eax*8-0x50]
477817: fcomp DWORD PTR ds:0x47d1f8
47781d: fnstsw ax
47781f: sahf
477820: jae 0x477846
477822: fld DWORD PTR ds:0x47d1fc
477828: mov eax,ds:0x4b0fe8
47782d: fmul QWORD PTR [eax]
47782f: xor eax,eax
477831: mov al,bl
477833: imul eax,eax,0x16
477836: fadd QWORD PTR [esi+eax*8-0x50]
47783a: xor eax,eax
47783c: mov al,bl
47783e: imul eax,eax,0x16
477841: fstp QWORD PTR [esi+eax*8-0x50]
477845: fwait
477846: mov BYTE PTR [edi],0x5
477849: cmp BYTE PTR [esp],0x5
47784d: jne 0x47792a
477853: xor eax,eax
477855: mov al,bl
477857: imul eax,eax,0x16
47785a: cmp BYTE PTR [esi+eax*8-0x45],0x1
47785f: je 0x4778b7
477861: xor eax,eax
477863: mov al,bl
477865: imul eax,eax,0x16
477868: cmp BYTE PTR [esi+eax*8-0x45],0x2
47786d: je 0x4778b7
47786f: xor eax,eax
477871: mov al,bl
477873: imul eax,eax,0x16
477876: cmp BYTE PTR [esi+eax*8-0x45],0x3
47787b: jne 0x47788c
47787d: xor eax,eax
47787f: mov al,bl
477881: imul eax,eax,0x16
477884: cmp WORD PTR [esi+eax*8-0x3c],0x2
47788a: jge 0x4778b7
47788c: xor eax,eax
47788e: mov al,bl
477890: imul eax,eax,0x16
477893: cmp BYTE PTR [esi+eax*8-0x45],0x4
477898: jne 0x4778a9
47789a: xor eax,eax
47789c: mov al,bl
47789e: imul eax,eax,0x16
4778a1: cmp WORD PTR [esi+eax*8-0x3c],0x2
4778a7: jge 0x4778b7
4778a9: xor eax,eax
4778ab: mov al,bl
4778ad: imul eax,eax,0x16
4778b0: cmp BYTE PTR [esi+eax*8-0x45],0x15
4778b5: jne 0x47792a
4778b7: xor eax,eax
4778b9: mov al,bl
4778bb: imul eax,eax,0x16
4778be: cmp BYTE PTR [esi+eax*8-0x38],0x0
4778c3: jne 0x47792a
4778c5: xor eax,eax
4778c7: mov al,bl
4778c9: imul eax,eax,0x16
4778cc: mov BYTE PTR [esi+eax*8-0x45],0x5
4778d1: xor eax,eax
4778d3: mov al,bl
4778d5: imul eax,eax,0x16
4778d8: mov WORD PTR [esi+eax*8-0x3c],0x0
4778df: xor eax,eax
4778e1: mov al,bl
4778e3: imul eax,eax,0x16
4778e6: mov WORD PTR [esi+eax*8-0x3a],0xb
4778ed: xor eax,eax
4778ef: mov al,bl
4778f1: imul eax,eax,0x16
4778f4: fld QWORD PTR [esi+eax*8-0x50]
4778f8: fcomp DWORD PTR ds:0x47d1f8
4778fe: fnstsw ax
477900: sahf
477901: jae 0x477927
477903: fld DWORD PTR ds:0x47d200
477909: mov eax,ds:0x4b0fe8
47790e: fmul QWORD PTR [eax]
477910: xor eax,eax
477912: mov al,bl
477914: imul eax,eax,0x16
477917: fadd QWORD PTR [esi+eax*8-0x50]
47791b: xor eax,eax
47791d: mov al,bl
47791f: imul eax,eax,0x16
477922: fstp QWORD PTR [esi+eax*8-0x50]
477926: fwait
477927: mov BYTE PTR [edi],0x6
47792a: cmp BYTE PTR [esp],0x6
47792e: jne 0x4779de
477934: xor eax,eax
477936: mov al,bl
477938: imul eax,eax,0x16
47793b: mov al,BYTE PTR [esi+eax*8-0x45]
47793f: cmp al,0x1
477941: je 0x47795d
477943: xor edx,edx
477945: mov dl,bl
477947: imul edx,edx,0x16
47794a: cmp al,0x2
47794c: je 0x47795d
47794e: xor edx,edx
477950: mov dl,bl
477952: imul edx,edx,0x16
477955: cmp al,0x15
477957: jne 0x4779de
47795d: xor eax,eax
47795f: mov al,bl
477961: imul eax,eax,0x16
477964: cmp BYTE PTR [esi+eax*8-0x38],0x0
477969: jne 0x4779de
47796b: xor eax,eax
47796d: mov al,bl
47796f: imul eax,eax,0x16
477972: cmp BYTE PTR [esi+eax*8-0x46],0x0
477977: jne 0x4779de
477979: xor eax,eax
47797b: mov al,bl
47797d: imul eax,eax,0x16
477980: mov BYTE PTR [esi+eax*8-0x45],0x6
477985: xor eax,eax
477987: mov al,bl
477989: imul eax,eax,0x16
47798c: mov WORD PTR [esi+eax*8-0x3c],0x0
477993: xor eax,eax
477995: mov al,bl
477997: imul eax,eax,0x16
47799a: mov WORD PTR [esi+eax*8-0x3a],0xb
4779a1: xor eax,eax
4779a3: mov al,bl
4779a5: imul eax,eax,0x16
4779a8: fld QWORD PTR [esi+eax*8-0x50]
4779ac: fcomp DWORD PTR ds:0x47d1f8
4779b2: fnstsw ax
4779b4: sahf
4779b5: jae 0x4779db
4779b7: fld DWORD PTR ds:0x47d200
4779bd: mov eax,ds:0x4b0fe8
4779c2: fmul QWORD PTR [eax]
4779c4: xor eax,eax
4779c6: mov al,bl
4779c8: imul eax,eax,0x16
4779cb: fadd QWORD PTR [esi+eax*8-0x50]
4779cf: xor eax,eax
4779d1: mov al,bl
4779d3: imul eax,eax,0x16
4779d6: fstp QWORD PTR [esi+eax*8-0x50]
4779da: fwait
4779db: mov BYTE PTR [edi],0x6
4779de: cmp BYTE PTR [esp],0x7
4779e2: jne 0x477a1a
4779e4: xor eax,eax
4779e6: mov al,bl
4779e8: imul eax,eax,0x16
4779eb: cmp BYTE PTR [esi+eax*8-0x45],0x1
4779f0: je 0x477a00
4779f2: xor eax,eax
4779f4: mov al,bl
4779f6: imul eax,eax,0x16
4779f9: cmp BYTE PTR [esi+eax*8-0x45],0x2
4779fe: jne 0x477a1a
477a00: xor eax,eax
477a02: mov al,bl
477a04: imul eax,eax,0x16
477a07: mov BYTE PTR [esi+eax*8-0x45],0x7
477a0c: xor eax,eax
477a0e: mov al,bl
477a10: imul eax,eax,0x16
477a13: mov WORD PTR [esi+eax*8-0x3a],0x63
477a1a: cmp BYTE PTR [esp],0x3
477a1e: jne 0x477aa5
477a24: xor eax,eax
477a26: mov al,bl
477a28: imul eax,eax,0x16
477a2b: cmp BYTE PTR [esi+eax*8-0x45],0x7
477a30: je 0x477a40
477a32: xor eax,eax
477a34: mov al,bl
477a36: imul eax,eax,0x16
477a39: cmp BYTE PTR [esi+eax*8-0x45],0x16
477a3e: jne 0x477aa5
477a40: xor eax,eax
477a42: mov al,bl
477a44: imul eax,eax,0x16
477a47: mov BYTE PTR [esi+eax*8-0x45],0x8
477a4c: xor eax,eax
477a4e: mov al,bl
477a50: imul eax,eax,0x16
477a53: mov WORD PTR [esi+eax*8-0x3c],0x0
477a5a: xor eax,eax
477a5c: mov al,bl
477a5e: imul eax,eax,0x16
477a61: mov WORD PTR [esi+eax*8-0x3a],0x6
477a68: xor eax,eax
477a6a: mov al,bl
477a6c: imul eax,eax,0x16
477a6f: fld QWORD PTR [esi+eax*8-0x50]
477a73: fcomp DWORD PTR ds:0x47d1f8
477a79: fnstsw ax
477a7b: sahf
477a7c: jae 0x477aa2
477a7e: fld DWORD PTR ds:0x47d1fc
477a84: mov eax,ds:0x4b0fe8
477a89: fmul QWORD PTR [eax]
477a8b: xor eax,eax
477a8d: mov al,bl
477a8f: imul eax,eax,0x16
477a92: fadd QWORD PTR [esi+eax*8-0x50]
477a96: xor eax,eax
477a98: mov al,bl
477a9a: imul eax,eax,0x16
477a9d: fstp QWORD PTR [esi+eax*8-0x50]
477aa1: fwait
477aa2: mov BYTE PTR [edi],0x5
477aa5: cmp BYTE PTR [esp],0x4
477aa9: jne 0x477b4d
477aaf: xor eax,eax
477ab1: mov al,bl
477ab3: imul eax,eax,0x16
477ab6: cmp BYTE PTR [esi+eax*8-0x45],0x7
477abb: je 0x477ae8
477abd: xor eax,eax
477abf: mov al,bl
477ac1: imul eax,eax,0x16
477ac4: cmp BYTE PTR [esi+eax*8-0x45],0x8
477ac9: jne 0x477ada
477acb: xor eax,eax
477acd: mov al,bl
477acf: imul eax,eax,0x16
477ad2: cmp WORD PTR [esi+eax*8-0x3c],0x2
477ad8: jge 0x477ae8
477ada: xor eax,eax
477adc: mov al,bl
477ade: imul eax,eax,0x16
477ae1: cmp BYTE PTR [esi+eax*8-0x45],0x16
477ae6: jne 0x477b4d
477ae8: xor eax,eax
477aea: mov al,bl
477aec: imul eax,eax,0x16
477aef: mov BYTE PTR [esi+eax*8-0x45],0x9
477af4: xor eax,eax
477af6: mov al,bl
477af8: imul eax,eax,0x16
477afb: mov WORD PTR [esi+eax*8-0x3c],0x0
477b02: xor eax,eax
477b04: mov al,bl
477b06: imul eax,eax,0x16
477b09: mov WORD PTR [esi+eax*8-0x3a],0x6
477b10: xor eax,eax
477b12: mov al,bl
477b14: imul eax,eax,0x16
477b17: fld QWORD PTR [esi+eax*8-0x50]
477b1b: fcomp DWORD PTR ds:0x47d1f8
477b21: fnstsw ax
477b23: sahf
477b24: jae 0x477b4a
477b26: fld DWORD PTR ds:0x47d1fc
477b2c: mov eax,ds:0x4b0fe8
477b31: fmul QWORD PTR [eax]
477b33: xor eax,eax
477b35: mov al,bl
477b37: imul eax,eax,0x16
477b3a: fadd QWORD PTR [esi+eax*8-0x50]
477b3e: xor eax,eax
477b40: mov al,bl
477b42: imul eax,eax,0x16
477b45: fstp QWORD PTR [esi+eax*8-0x50]
477b49: fwait
477b4a: mov BYTE PTR [edi],0x5
477b4d: cmp BYTE PTR [esp],0x5
477b51: jne 0x477c12
477b57: xor eax,eax
477b59: mov al,bl
477b5b: imul eax,eax,0x16
477b5e: cmp BYTE PTR [esi+eax*8-0x45],0x7
477b63: je 0x477bad
477b65: xor eax,eax
477b67: mov al,bl
477b69: imul eax,eax,0x16
477b6c: cmp BYTE PTR [esi+eax*8-0x45],0x8
477b71: jne 0x477b82
477b73: xor eax,eax
477b75: mov al,bl
477b77: imul eax,eax,0x16
477b7a: cmp WORD PTR [esi+eax*8-0x3c],0x2
477b80: jge 0x477bad
477b82: xor eax,eax
477b84: mov al,bl
477b86: imul eax,eax,0x16
477b89: cmp BYTE PTR [esi+eax*8-0x45],0x9
477b8e: jne 0x477b9f
477b90: xor eax,eax
477b92: mov al,bl
477b94: imul eax,eax,0x16
477b97: cmp WORD PTR [esi+eax*8-0x3c],0x2
477b9d: jge 0x477bad
477b9f: xor eax,eax
477ba1: mov al,bl
477ba3: imul eax,eax,0x16
477ba6: cmp BYTE PTR [esi+eax*8-0x45],0x16
477bab: jne 0x477c12
477bad: xor eax,eax
477baf: mov al,bl
477bb1: imul eax,eax,0x16
477bb4: mov BYTE PTR [esi+eax*8-0x45],0xa
477bb9: xor eax,eax
477bbb: mov al,bl
477bbd: imul eax,eax,0x16
477bc0: mov WORD PTR [esi+eax*8-0x3c],0x0
477bc7: xor eax,eax
477bc9: mov al,bl
477bcb: imul eax,eax,0x16
477bce: mov WORD PTR [esi+eax*8-0x3a],0xb
477bd5: xor eax,eax
477bd7: mov al,bl
477bd9: imul eax,eax,0x16
477bdc: fld QWORD PTR [esi+eax*8-0x50]
477be0: fcomp DWORD PTR ds:0x47d1f8
477be6: fnstsw ax
477be8: sahf
477be9: jae 0x477c0f
477beb: fld DWORD PTR ds:0x47d200
477bf1: mov eax,ds:0x4b0fe8
477bf6: fmul QWORD PTR [eax]
477bf8: xor eax,eax
477bfa: mov al,bl
477bfc: imul eax,eax,0x16
477bff: fadd QWORD PTR [esi+eax*8-0x50]
477c03: xor eax,eax
477c05: mov al,bl
477c07: imul eax,eax,0x16
477c0a: fstp QWORD PTR [esi+eax*8-0x50]
477c0e: fwait
477c0f: mov BYTE PTR [edi],0x6
477c12: cmp BYTE PTR [esp],0x6
477c16: jne 0x477cb4
477c1c: xor eax,eax
477c1e: mov al,bl
477c20: imul eax,eax,0x16
477c23: cmp BYTE PTR [esi+eax*8-0x45],0x7
477c28: je 0x477c55
477c2a: xor eax,eax
477c2c: mov al,bl
477c2e: imul eax,eax,0x16
477c31: cmp BYTE PTR [esi+eax*8-0x45],0x9
477c36: jne 0x477c47
477c38: xor eax,eax
477c3a: mov al,bl
477c3c: imul eax,eax,0x16
477c3f: cmp WORD PTR [esi+eax*8-0x3c],0x2
477c45: jge 0x477c55
477c47: xor eax,eax
477c49: mov al,bl
477c4b: imul eax,eax,0x16
477c4e: cmp BYTE PTR [esi+eax*8-0x45],0x16
477c53: jne 0x477cb4
477c55: xor eax,eax
477c57: mov al,bl
477c59: imul edx,eax,0x16
477c5c: mov BYTE PTR [esi+edx*8-0x45],0xb
477c61: mov WORD PTR [esi+edx*8-0x3c],0x0
477c68: mov WORD PTR [esi+edx*8-0x3a],0xb
477c6f: mov BYTE PTR [esi+edx*8-0x47],0x1
477c74: fld QWORD PTR [esi+edx*8-0x50]
477c78: fcomp DWORD PTR ds:0x47d1f8
477c7e: fnstsw ax
477c80: sahf
477c81: jae 0x477ca0
477c83: fld DWORD PTR ds:0x47d200
477c89: mov eax,ds:0x4b0fe8
477c8e: fmul QWORD PTR [eax]
477c90: xor eax,eax
477c92: mov al,bl
477c94: imul eax,eax,0x16
477c97: fadd QWORD PTR [esi+eax*8-0x50]
477c9b: fstp QWORD PTR [esi+edx*8-0x50]
477c9f: fwait
477ca0: mov BYTE PTR [edi],0x6
477ca3: cmp BYTE PTR [esi+edx*8-0xa0],0xd
477cab: jne 0x477cb4
477cad: mov WORD PTR [esi+edx*8-0x3a],0x12
477cb4: cmp BYTE PTR [esp],0x3
477cb8: jne 0x477d2d
477cba: xor eax,eax
477cbc: mov al,bl
477cbe: imul eax,eax,0x16
477cc1: cmp BYTE PTR [esi+eax*8-0x45],0xc
477cc6: jne 0x477d2d
477cc8: xor eax,eax
477cca: mov al,bl
477ccc: imul eax,eax,0x16
477ccf: mov BYTE PTR [esi+eax*8-0x45],0xd
477cd4: xor eax,eax
477cd6: mov al,bl
477cd8: imul eax,eax,0x16
477cdb: mov WORD PTR [esi+eax*8-0x3c],0x0
477ce2: xor eax,eax
477ce4: mov al,bl
477ce6: imul eax,eax,0x16
477ce9: mov WORD PTR [esi+eax*8-0x3a],0xf
477cf0: xor eax,eax
477cf2: mov al,bl
477cf4: imul eax,eax,0x16
477cf7: fld QWORD PTR [esi+eax*8-0x50]
477cfb: fcomp DWORD PTR ds:0x47d1f8
477d01: fnstsw ax
477d03: sahf
477d04: jae 0x477d2a
477d06: fld DWORD PTR ds:0x47d1fc
477d0c: mov eax,ds:0x4b0fe8
477d11: fmul QWORD PTR [eax]
477d13: xor eax,eax
477d15: mov al,bl
477d17: imul eax,eax,0x16
477d1a: fadd QWORD PTR [esi+eax*8-0x50]
477d1e: xor eax,eax
477d20: mov al,bl
477d22: imul eax,eax,0x16
477d25: fstp QWORD PTR [esi+eax*8-0x50]
477d29: fwait
477d2a: mov BYTE PTR [edi],0x5
477d2d: cmp BYTE PTR [esp],0x4
477d31: jne 0x477da6
477d33: xor eax,eax
477d35: mov al,bl
477d37: imul eax,eax,0x16
477d3a: cmp BYTE PTR [esi+eax*8-0x45],0xc
477d3f: jne 0x477da6
477d41: xor eax,eax
477d43: mov al,bl
477d45: imul eax,eax,0x16
477d48: mov BYTE PTR [esi+eax*8-0x45],0xe
477d4d: xor eax,eax
477d4f: mov al,bl
477d51: imul eax,eax,0x16
477d54: mov WORD PTR [esi+eax*8-0x3c],0x0
477d5b: xor eax,eax
477d5d: mov al,bl
477d5f: imul eax,eax,0x16
477d62: mov WORD PTR [esi+eax*8-0x3a],0xf
477d69: xor eax,eax
477d6b: mov al,bl
477d6d: imul eax,eax,0x16
477d70: fld QWORD PTR [esi+eax*8-0x50]
477d74: fcomp DWORD PTR ds:0x47d1f8
477d7a: fnstsw ax
477d7c: sahf
477d7d: jae 0x477da3
477d7f: fld DWORD PTR ds:0x47d1fc
477d85: mov eax,ds:0x4b0fe8
477d8a: fmul QWORD PTR [eax]
477d8c: xor eax,eax
477d8e: mov al,bl
477d90: imul eax,eax,0x16
477d93: fadd QWORD PTR [esi+eax*8-0x50]
477d97: xor eax,eax
477d99: mov al,bl
477d9b: imul eax,eax,0x16
477d9e: fstp QWORD PTR [esi+eax*8-0x50]
477da2: fwait
477da3: mov BYTE PTR [edi],0x5
477da6: cmp BYTE PTR [esp],0x5
477daa: jne 0x477e1f
477dac: xor eax,eax
477dae: mov al,bl
477db0: imul eax,eax,0x16
477db3: cmp BYTE PTR [esi+eax*8-0x45],0xc
477db8: jne 0x477e1f
477dba: xor eax,eax
477dbc: mov al,bl
477dbe: imul eax,eax,0x16
477dc1: mov BYTE PTR [esi+eax*8-0x45],0xf
477dc6: xor eax,eax
477dc8: mov al,bl
477dca: imul eax,eax,0x16
477dcd: mov WORD PTR [esi+eax*8-0x3c],0x0
477dd4: xor eax,eax
477dd6: mov al,bl
477dd8: imul eax,eax,0x16
477ddb: mov WORD PTR [esi+eax*8-0x3a],0xb
477de2: xor eax,eax
477de4: mov al,bl
477de6: imul eax,eax,0x16
477de9: fld QWORD PTR [esi+eax*8-0x50]
477ded: fcomp DWORD PTR ds:0x47d1f8
477df3: fnstsw ax
477df5: sahf
477df6: jae 0x477e1c
477df8: fld DWORD PTR ds:0x47d200
477dfe: mov eax,ds:0x4b0fe8
477e03: fmul QWORD PTR [eax]
477e05: xor eax,eax
477e07: mov al,bl
477e09: imul eax,eax,0x16
477e0c: fadd QWORD PTR [esi+eax*8-0x50]
477e10: xor eax,eax
477e12: mov al,bl
477e14: imul eax,eax,0x16
477e17: fstp QWORD PTR [esi+eax*8-0x50]
477e1b: fwait
477e1c: mov BYTE PTR [edi],0x6
477e1f: cmp BYTE PTR [esp],0x6
477e23: jne 0x477e98
477e25: xor eax,eax
477e27: mov al,bl
477e29: imul eax,eax,0x16
477e2c: cmp BYTE PTR [esi+eax*8-0x45],0xc
477e31: jne 0x477e98
477e33: xor eax,eax
477e35: mov al,bl
477e37: imul eax,eax,0x16
477e3a: mov BYTE PTR [esi+eax*8-0x45],0x10
477e3f: xor eax,eax
477e41: mov al,bl
477e43: imul eax,eax,0x16
477e46: mov WORD PTR [esi+eax*8-0x3c],0x0
477e4d: xor eax,eax
477e4f: mov al,bl
477e51: imul eax,eax,0x16
477e54: mov WORD PTR [esi+eax*8-0x3a],0xb
477e5b: xor eax,eax
477e5d: mov al,bl
477e5f: imul eax,eax,0x16
477e62: fld QWORD PTR [esi+eax*8-0x50]
477e66: fcomp DWORD PTR ds:0x47d1f8
477e6c: fnstsw ax
477e6e: sahf
477e6f: jae 0x477e95
477e71: fld DWORD PTR ds:0x47d200
477e77: mov eax,ds:0x4b0fe8
477e7c: fmul QWORD PTR [eax]
477e7e: xor eax,eax
477e80: mov al,bl
477e82: imul eax,eax,0x16
477e85: fadd QWORD PTR [esi+eax*8-0x50]
477e89: xor eax,eax
477e8b: mov al,bl
477e8d: imul eax,eax,0x16
477e90: fstp QWORD PTR [esi+eax*8-0x50]
477e94: fwait
477e95: mov BYTE PTR [edi],0x6
477e98: cmp BYTE PTR [esp],0x8
477e9c: jne 0x477ed4
477e9e: xor eax,eax
477ea0: mov al,bl
477ea2: imul eax,eax,0x16
477ea5: cmp BYTE PTR [esi+eax*8-0x38],0x0
477eaa: jne 0x477ed4
477eac: xor eax,eax
477eae: mov al,bl
477eb0: imul eax,eax,0x16
477eb3: mov BYTE PTR [esi+eax*8-0x45],0x11
477eb8: xor eax,eax
477eba: mov al,bl
477ebc: imul eax,eax,0x16
477ebf: mov WORD PTR [esi+eax*8-0x3c],0x0
477ec6: xor eax,eax
477ec8: mov al,bl
477eca: imul eax,eax,0x16
477ecd: mov WORD PTR [esi+eax*8-0x3a],0x8
477ed4: cmp BYTE PTR [esp],0x9
477ed8: jne 0x477f10
477eda: xor eax,eax
477edc: mov al,bl
477ede: imul eax,eax,0x16
477ee1: cmp BYTE PTR [esi+eax*8-0x38],0x0
477ee6: jne 0x477f10
477ee8: xor eax,eax
477eea: mov al,bl
477eec: imul eax,eax,0x16
477eef: mov BYTE PTR [esi+eax*8-0x45],0x12
477ef4: xor eax,eax
477ef6: mov al,bl
477ef8: imul eax,eax,0x16
477efb: mov WORD PTR [esi+eax*8-0x3c],0x0
477f02: xor eax,eax
477f04: mov al,bl
477f06: imul eax,eax,0x16
477f09: mov WORD PTR [esi+eax*8-0x3a],0x8
477f10: cmp BYTE PTR [esp],0xa
477f14: jne 0x477f49
477f16: xor eax,eax
477f18: mov al,bl
477f1a: imul eax,eax,0x16
477f1d: mov BYTE PTR [esi+eax*8-0x45],0x13
477f22: mov WORD PTR [esi+eax*8-0x3c],0x0
477f29: mov WORD PTR [esi+eax*8-0x3a],0x32
477f30: mov BYTE PTR [esi+eax*8-0x38],0xed
477f35: mov BYTE PTR [esi+eax*8-0x46],0x1
477f3a: mov BYTE PTR [esi+eax*8-0x42],0x0
477f3f: mov BYTE PTR [esi+eax*8-0x1e],0x1
477f44: mov BYTE PTR [esi+eax*8-0x48],0x0
477f49: cmp BYTE PTR [esp],0xb
477f4d: jne 0x477f78
477f4f: xor eax,eax
477f51: mov al,bl
477f53: imul eax,eax,0x16
477f56: mov BYTE PTR [esi+eax*8-0x45],0x14
477f5b: mov WORD PTR [esi+eax*8-0x3c],0x0
477f62: mov WORD PTR [esi+eax*8-0x3a],0x19
477f69: mov BYTE PTR [esi+eax*8-0x38],0xf3
477f6e: mov BYTE PTR [esi+eax*8-0x46],0x1
477f73: mov BYTE PTR [esi+eax*8-0x1e],0x1
477f78: cmp BYTE PTR [esp],0xc
477f7c: jne 0x478019
477f82: xor eax,eax
477f84: mov al,bl
477f86: imul eax,eax,0x16
477f89: mov al,BYTE PTR [esi+eax*8-0x45]
477f8d: cmp al,0x1
477f8f: je 0x477fea
477f91: xor edx,edx
477f93: mov dl,bl
477f95: imul edx,edx,0x16
477f98: cmp al,0x2
477f9a: je 0x477fea
477f9c: xor edx,edx
477f9e: mov dl,bl
477fa0: imul edx,edx,0x16
477fa3: cmp al,0x7
477fa5: je 0x477fea
477fa7: xor edx,edx
477fa9: mov dl,bl
477fab: imul edx,edx,0x16
477fae: cmp al,0x15
477fb0: je 0x477fea
477fb2: xor edx,edx
477fb4: mov dl,bl
477fb6: imul edx,edx,0x16
477fb9: cmp al,0x16
477fbb: je 0x477fea
477fbd: xor eax,eax
477fbf: mov al,bl
477fc1: imul eax,eax,0x16
477fc4: cmp BYTE PTR [esi+eax*8-0x45],0x14
477fc9: jne 0x478019
477fcb: xor eax,eax
477fcd: mov al,bl
477fcf: imul eax,eax,0x16
477fd2: movsx eax,WORD PTR [esi+eax*8-0x3c]
477fd7: xor edx,edx
477fd9: mov dl,bl
477fdb: imul edx,edx,0x16
477fde: movsx edx,WORD PTR [esi+edx*8-0x3a]
477fe3: sub edx,0x3
477fe6: cmp eax,edx
477fe8: jl 0x478019
477fea: xor eax,eax
477fec: mov al,bl
477fee: imul eax,eax,0x16
477ff1: mov BYTE PTR [esi+eax*8-0x45],0x15
477ff6: mov BYTE PTR [esi+eax*8-0x1e],0x0
477ffb: mov WORD PTR [esi+eax*8-0x3c],0x0
478002: mov WORD PTR [esi+eax*8-0x3a],0xb
478009: mov BYTE PTR [esi+eax*8-0x1d],0x1
47800e: mov dl,BYTE PTR [esp+0x2]
478012: add dl,0x1f
478015: mov BYTE PTR [esi+eax*8-0x44],dl
478019: cmp BYTE PTR [esp],0xd
47801d: jne 0x4780ba
478023: xor eax,eax
478025: mov al,bl
478027: imul eax,eax,0x16
47802a: mov al,BYTE PTR [esi+eax*8-0x45]
47802e: cmp al,0x1
478030: je 0x47808b
478032: xor edx,edx
478034: mov dl,bl
478036: imul edx,edx,0x16
478039: cmp al,0x2
47803b: je 0x47808b
47803d: xor edx,edx
47803f: mov dl,bl
478041: imul edx,edx,0x16
478044: cmp al,0x7
478046: je 0x47808b
478048: xor edx,edx
47804a: mov dl,bl
47804c: imul edx,edx,0x16
47804f: cmp al,0x15
478051: je 0x47808b
478053: xor edx,edx
478055: mov dl,bl
478057: imul edx,edx,0x16
47805a: cmp al,0x16
47805c: je 0x47808b
47805e: xor eax,eax
478060: mov al,bl
478062: imul eax,eax,0x16
478065: cmp BYTE PTR [esi+eax*8-0x45],0x14
47806a: jne 0x4780ba
47806c: xor eax,eax
47806e: mov al,bl
478070: imul eax,eax,0x16
478073: movsx eax,WORD PTR [esi+eax*8-0x3c]
478078: xor edx,edx
47807a: mov dl,bl
47807c: imul edx,edx,0x16
47807f: movsx edx,WORD PTR [esi+edx*8-0x3a]
478084: sub edx,0x3
478087: cmp eax,edx
478089: jl 0x4780ba
47808b: xor eax,eax
47808d: mov al,bl
47808f: imul eax,eax,0x16
478092: mov BYTE PTR [esi+eax*8-0x45],0x16
478097: mov BYTE PTR [esi+eax*8-0x1e],0x0
47809c: mov WORD PTR [esi+eax*8-0x3c],0x0
4780a3: mov WORD PTR [esi+eax*8-0x3a],0xb
4780aa: mov BYTE PTR [esi+eax*8-0x1d],0x1
4780af: mov dl,BYTE PTR [esp+0x2]
4780b3: add dl,0x20
4780b6: mov BYTE PTR [esi+eax*8-0x44],dl
4780ba: xor eax,eax
4780bc: mov al,bl
4780be: imul eax,eax,0x16
4780c1: cmp BYTE PTR [esi+eax*8-0xa0],0x1
4780c9: jne 0x478623
4780cf: cmp BYTE PTR [esp],0xe
4780d3: jne 0x478127
4780d5: xor eax,eax
4780d7: mov al,bl
4780d9: imul eax,eax,0x16
4780dc: cmp BYTE PTR [esi+eax*8-0x45],0x1
4780e1: je 0x4780ff
4780e3: xor eax,eax
4780e5: mov al,bl
4780e7: imul eax,eax,0x16
4780ea: cmp BYTE PTR [esi+eax*8-0x45],0x2
4780ef: je 0x4780ff
4780f1: xor eax,eax
4780f3: mov al,bl
4780f5: imul eax,eax,0x16
4780f8: cmp BYTE PTR [esi+eax*8-0x45],0x7
4780fd: jne 0x478127
4780ff: xor eax,eax
478101: mov al,bl
478103: imul eax,eax,0x16
478106: mov BYTE PTR [esi+eax*8-0x45],0x17
47810b: xor eax,eax
47810d: mov al,bl
47810f: imul eax,eax,0x16
478112: mov WORD PTR [esi+eax*8-0x3c],0x0
478119: xor eax,eax
47811b: mov al,bl
47811d: imul eax,eax,0x16
478120: mov WORD PTR [esi+eax*8-0x3a],0xfa
478127: cmp BYTE PTR [esp],0xf
47812b: jne 0x478171
47812d: xor eax,eax
47812f: mov al,bl
478131: imul eax,eax,0x16
478134: cmp BYTE PTR [esi+eax*8-0x45],0x1
478139: je 0x478149
47813b: xor eax,eax
47813d: mov al,bl
47813f: imul eax,eax,0x16
478142: cmp BYTE PTR [esi+eax*8-0x45],0x2
478147: jne 0x478171
478149: xor eax,eax
47814b: mov al,bl
47814d: imul eax,eax,0x16
478150: mov BYTE PTR [esi+eax*8-0x45],0x18
478155: xor eax,eax
478157: mov al,bl
478159: imul eax,eax,0x16
47815c: mov WORD PTR [esi+eax*8-0x3c],0x0
478163: xor eax,eax
478165: mov al,bl
478167: imul eax,eax,0x16
47816a: mov WORD PTR [esi+eax*8-0x3a],0x14
478171: cmp BYTE PTR [esp],0x10
478175: je 0x478181
478177: cmp BYTE PTR [esp],0x11
47817b: jne 0x478254
478181: xor eax,eax
478183: mov al,bl
478185: imul eax,eax,0x16
478188: cmp BYTE PTR [esi+eax*8-0x45],0x1
47818d: je 0x4781bd
47818f: xor eax,eax
478191: mov al,bl
478193: imul eax,eax,0x16
478196: cmp BYTE PTR [esi+eax*8-0x45],0x2
47819b: je 0x4781bd
47819d: xor eax,eax
47819f: mov al,bl
4781a1: imul eax,eax,0x16
4781a4: cmp BYTE PTR [esi+eax*8-0x45],0x15
4781a9: je 0x4781bd
4781ab: xor eax,eax
4781ad: mov al,bl
4781af: imul eax,eax,0x16
4781b2: cmp BYTE PTR [esi+eax*8-0x45],0x16
4781b7: jne 0x478254
4781bd: mov edx,ebx
4781bf: mov al,0x7
4781c1: call 0x476454
4781c6: test al,al
4781c8: jne 0x478254
4781ce: xor eax,eax
4781d0: mov al,bl
4781d2: imul eax,eax,0x16
4781d5: mov BYTE PTR [esi+eax*8-0x45],0x19
4781da: xor eax,eax
4781dc: mov al,bl
4781de: imul eax,eax,0x16
4781e1: mov WORD PTR [esi+eax*8-0x3c],0x0
4781e8: xor eax,eax
4781ea: mov al,bl
4781ec: imul eax,eax,0x16
4781ef: mov WORD PTR [esi+eax*8-0x3a],0x1c
4781f6: xor eax,eax
4781f8: mov al,bl
4781fa: imul eax,eax,0x16
4781fd: fld QWORD PTR [esi+eax*8-0x50]
478201: fcomp DWORD PTR ds:0x47d1f8
478207: fnstsw ax
478209: sahf
47820a: jae 0x478230
47820c: fld DWORD PTR ds:0x47d204
478212: mov eax,ds:0x4b0fe8
478217: fmul QWORD PTR [eax]
478219: xor eax,eax
47821b: mov al,bl
47821d: imul eax,eax,0x16
478220: fadd QWORD PTR [esi+eax*8-0x50]
478224: xor eax,eax
478226: mov al,bl
478228: imul eax,eax,0x16
47822b: fstp QWORD PTR [esi+eax*8-0x50]
47822f: fwait
478230: cmp BYTE PTR [esp],0x10
478234: jne 0x478242
478236: xor eax,eax
478238: mov al,bl
47823a: imul eax,eax,0x16
47823d: mov BYTE PTR [esi+eax*8-0x41],0x1
478242: cmp BYTE PTR [esp],0x11
478246: jne 0x478254
478248: xor eax,eax
47824a: mov al,bl
47824c: imul eax,eax,0x16
47824f: mov BYTE PTR [esi+eax*8-0x41],0x2
478254: cmp BYTE PTR [esp],0x12
478258: je 0x478264
47825a: cmp BYTE PTR [esp],0x13
47825e: jne 0x478340
478264: xor eax,eax
478266: mov al,bl
478268: imul eax,eax,0x16
47826b: cmp BYTE PTR [esi+eax*8-0x45],0x1
478270: je 0x4782a0
478272: xor eax,eax
478274: mov al,bl
478276: imul eax,eax,0x16
478279: cmp BYTE PTR [esi+eax*8-0x45],0x2
47827e: je 0x4782a0
478280: xor eax,eax
478282: mov al,bl
478284: imul eax,eax,0x16
478287: cmp BYTE PTR [esi+eax*8-0x45],0x15
47828c: je 0x4782a0
47828e: xor eax,eax
478290: mov al,bl
478292: imul eax,eax,0x16
478295: cmp BYTE PTR [esi+eax*8-0x45],0x16
47829a: jne 0x478340
4782a0: xor eax,eax
4782a2: mov al,bl
4782a4: imul eax,eax,0x16
4782a7: mov BYTE PTR [esi+eax*8-0x45],0x1a
4782ac: xor eax,eax
4782ae: mov al,bl
4782b0: imul eax,eax,0x16
4782b3: mov WORD PTR [esi+eax*8-0x3c],0x0
4782ba: xor eax,eax
4782bc: mov al,bl
4782be: imul eax,eax,0x16
4782c1: fld QWORD PTR [esi+eax*8-0x50]
4782c5: fcomp DWORD PTR ds:0x47d1f8
4782cb: fnstsw ax
4782cd: sahf
4782ce: jae 0x4782f4
4782d0: fld DWORD PTR ds:0x47d204
4782d6: mov eax,ds:0x4b0fe8
4782db: fmul QWORD PTR [eax]
4782dd: xor eax,eax
4782df: mov al,bl
4782e1: imul eax,eax,0x16
4782e4: fadd QWORD PTR [esi+eax*8-0x50]
4782e8: xor eax,eax
4782ea: mov al,bl
4782ec: imul eax,eax,0x16
4782ef: fstp QWORD PTR [esi+eax*8-0x50]
4782f3: fwait
4782f4: cmp BYTE PTR [esp],0x12
4782f8: jne 0x478308
4782fa: xor eax,eax
4782fc: mov al,bl
4782fe: imul eax,eax,0x16
478301: mov WORD PTR [esi+eax*8-0x3a],0x10
478308: cmp BYTE PTR [esp],0x13
47830c: jne 0x47831c
47830e: xor eax,eax
478310: mov al,bl
478312: imul eax,eax,0x16
478315: mov WORD PTR [esi+eax*8-0x3a],0x1b
47831c: cmp BYTE PTR [esp],0x12
478320: jne 0x47832e
478322: xor eax,eax
478324: mov al,bl
478326: imul eax,eax,0x16
478329: mov BYTE PTR [esi+eax*8-0x41],0x1
47832e: cmp BYTE PTR [esp],0x13
478332: jne 0x478340
478334: xor eax,eax
478336: mov al,bl
478338: imul eax,eax,0x16
47833b: mov BYTE PTR [esi+eax*8-0x41],0x2
478340: cmp BYTE PTR [esp],0x14
478344: je 0x478350
478346: cmp BYTE PTR [esp],0x15
47834a: jne 0x478455
478350: xor eax,eax
478352: mov al,bl
478354: imul eax,eax,0x16
478357: mov dl,BYTE PTR [esi+eax*8-0x45]
47835b: cmp dl,0x1
47835e: je 0x478394
478360: xor eax,eax
478362: mov al,bl
478364: imul eax,eax,0x16
478367: cmp dl,0x2
47836a: je 0x478394
47836c: xor eax,eax
47836e: mov al,bl
478370: imul eax,eax,0x16
478373: cmp dl,0xc
478376: je 0x478394
478378: xor eax,eax
47837a: mov al,bl
47837c: imul eax,eax,0x16
47837f: cmp dl,0x16
478382: je 0x478394
478384: xor eax,eax
478386: mov al,bl
478388: imul eax,eax,0x16
47838b: cmp dl,0x1a
47838e: jne 0x478455
478394: mov eax,ds:0x4b11f8
478399: movsx eax,WORD PTR [eax]
47839c: sub eax,0x5a
47839f: mov DWORD PTR [esp+0x4],eax
4783a3: fild DWORD PTR [esp+0x4]
4783a7: xor eax,eax
4783a9: mov al,bl
4783ab: imul eax,eax,0x16
4783ae: fcomp QWORD PTR [esi+eax*8-0xa8]
4783b5: fnstsw ax
4783b7: sahf
4783b8: ja 0x478455
4783be: xor eax,eax
4783c0: mov al,bl
4783c2: imul edx,eax,0x16
4783c5: mov BYTE PTR [esi+edx*8-0x45],0x1b
4783ca: fld QWORD PTR [esi+edx*8-0x50]
4783ce: fcomp DWORD PTR ds:0x47d1f8
4783d4: fnstsw ax
4783d6: sahf
4783d7: jae 0x4783f6
4783d9: fld DWORD PTR ds:0x47d208
4783df: mov eax,ds:0x4b0fe8
4783e4: fmul QWORD PTR [eax]
4783e6: xor eax,eax
4783e8: mov al,bl
4783ea: imul eax,eax,0x16
4783ed: fadd QWORD PTR [esi+eax*8-0x50]
4783f1: fstp QWORD PTR [esi+edx*8-0x50]
4783f5: fwait
4783f6: mov eax,ds:0x4b11f8
4783fb: fild WORD PTR [eax]
4783fd: fstp QWORD PTR [esi+edx*8-0xa8]
478404: fwait
478405: mov BYTE PTR [esi+edx*8-0x46],0x0
47840a: mov WORD PTR [esi+edx*8-0x3c],0x0
478411: mov BYTE PTR [esi+edx*8-0x38],0x0
478416: mov BYTE PTR [esi+edx*8-0x42],0x0
47841b: mov BYTE PTR [esi+edx*8-0x16],0x0
478420: mov BYTE PTR [esi+edx*8-0x18],0x0
478425: cmp BYTE PTR [esp],0x14
478429: jne 0x478432
47842b: mov WORD PTR [esi+edx*8-0x3a],0xa
478432: cmp BYTE PTR [esp],0x15
478436: jne 0x47843f
478438: mov WORD PTR [esi+edx*8-0x3a],0x10
47843f: cmp BYTE PTR [esp],0x14
478443: jne 0x47844a
478445: mov BYTE PTR [esi+edx*8-0x41],0x1
47844a: cmp BYTE PTR [esp],0x15
47844e: jne 0x478455
478450: mov BYTE PTR [esi+edx*8-0x41],0x2
478455: cmp BYTE PTR [esp],0x16
478459: je 0x478465
47845b: cmp BYTE PTR [esp],0x17
47845f: jne 0x478527
478465: xor eax,eax
478467: mov al,bl
478469: imul eax,eax,0x16
47846c: cmp BYTE PTR [esi+eax*8-0x45],0x1
478471: je 0x4784a1
478473: xor eax,eax
478475: mov al,bl
478477: imul eax,eax,0x16
47847a: cmp BYTE PTR [esi+eax*8-0x45],0x2
47847f: je 0x4784a1
478481: xor eax,eax
478483: mov al,bl
478485: imul eax,eax,0x16
478488: cmp BYTE PTR [esi+eax*8-0x45],0x15
47848d: je 0x4784a1
47848f: xor eax,eax
478491: mov al,bl
478493: imul eax,eax,0x16
478496: cmp BYTE PTR [esi+eax*8-0x45],0x16
47849b: jne 0x478527
4784a1: xor eax,eax
4784a3: mov al,bl
4784a5: imul eax,eax,0x16
4784a8: mov BYTE PTR [esi+eax*8-0x45],0x1c
4784ad: xor eax,eax
4784af: mov al,bl
4784b1: imul eax,eax,0x16
4784b4: mov WORD PTR [esi+eax*8-0x3c],0x0
4784bb: xor eax,eax
4784bd: mov al,bl
4784bf: imul eax,eax,0x16
4784c2: fld QWORD PTR [esi+eax*8-0x50]
4784c6: fcomp DWORD PTR ds:0x47d1f8
4784cc: fnstsw ax
4784ce: sahf
4784cf: jae 0x4784f5
4784d1: fld DWORD PTR ds:0x47d204
4784d7: mov eax,ds:0x4b0fe8
4784dc: fmul QWORD PTR [eax]
4784de: xor eax,eax
4784e0: mov al,bl
4784e2: imul eax,eax,0x16
4784e5: fadd QWORD PTR [esi+eax*8-0x50]
4784e9: xor eax,eax
4784eb: mov al,bl
4784ed: imul eax,eax,0x16
4784f0: fstp QWORD PTR [esi+eax*8-0x50]
4784f4: fwait
4784f5: xor eax,eax
4784f7: mov al,bl
4784f9: imul eax,eax,0x16
4784fc: mov WORD PTR [esi+eax*8-0x3a],0x16
478503: cmp BYTE PTR [esp],0x16
478507: jne 0x478515
478509: xor eax,eax
47850b: mov al,bl
47850d: imul eax,eax,0x16
478510: mov BYTE PTR [esi+eax*8-0x41],0x1
478515: cmp BYTE PTR [esp],0x17
478519: jne 0x478527
47851b: xor eax,eax
47851d: mov al,bl
47851f: imul eax,eax,0x16
478522: mov BYTE PTR [esi+eax*8-0x41],0x2
478527: cmp BYTE PTR [esp],0x18
47852b: jne 0x478623
478531: xor eax,eax
478533: mov al,bl
478535: imul eax,eax,0x16
478538: mov dl,BYTE PTR [esi+eax*8-0x45]
47853c: cmp dl,0x1
47853f: je 0x478581
478541: xor eax,eax
478543: mov al,bl
478545: imul eax,eax,0x16
478548: cmp dl,0x2
47854b: je 0x478581
47854d: xor eax,eax
47854f: mov al,bl
478551: imul eax,eax,0x16
478554: cmp dl,0x7
478557: je 0x478581
478559: xor eax,eax
47855b: mov al,bl
47855d: imul eax,eax,0x16
478560: cmp dl,0x5
478563: je 0x478581
478565: xor eax,eax
478567: mov al,bl
478569: imul eax,eax,0x16
47856c: cmp dl,0x15
47856f: je 0x478581
478571: xor eax,eax
478573: mov al,bl
478575: imul eax,eax,0x16
478578: cmp dl,0x16
47857b: jne 0x478623
478581: xor eax,eax
478583: mov al,bl
478585: imul eax,eax,0x16
478588: fld QWORD PTR [esi+eax*8-0x70]
47858c: fcomp DWORD PTR ds:0x47d20c
478592: fnstsw ax
478594: sahf
478595: jbe 0x4785a6
478597: xor eax,eax
478599: mov al,bl
47859b: imul eax,eax,0x16
47859e: cmp WORD PTR [esi+eax*8-0x58],0x0
4785a4: jle 0x478623
4785a6: xor eax,eax
4785a8: mov al,bl
4785aa: imul eax,eax,0x16
4785ad: mov BYTE PTR [esi+eax*8-0x45],0x1d
4785b2: xor eax,eax
4785b4: mov al,bl
4785b6: imul eax,eax,0x16
4785b9: mov WORD PTR [esi+eax*8-0x3c],0x0
4785c0: xor eax,eax
4785c2: mov al,bl
4785c4: imul eax,eax,0x16
4785c7: mov WORD PTR [esi+eax*8-0x3a],0x26
4785ce: xor eax,eax
4785d0: mov al,bl
4785d2: imul eax,eax,0x16
4785d5: cmp WORD PTR [esi+eax*8-0x58],0x3
4785db: jne 0x4785ee
4785dd: xor eax,eax
4785df: mov al,bl
4785e1: imul eax,eax,0x16
4785e4: xor edx,edx
4785e6: mov DWORD PTR [esi+eax*8-0x50],edx
4785ea: mov DWORD PTR [esi+eax*8-0x4c],edx
4785ee: xor eax,eax
4785f0: mov al,bl
4785f2: imul eax,eax,0x16
4785f5: dec WORD PTR [esi+eax*8-0x58]
4785fa: xor eax,eax
4785fc: mov al,bl
4785fe: imul eax,eax,0x16
478601: mov dl,BYTE PTR [esp+0x2]
478605: add dl,0x24
478608: mov BYTE PTR [esi+eax*8-0x44],dl
47860c: xor eax,eax
47860e: mov al,bl
478610: imul eax,eax,0x16
478613: mov BYTE PTR [esi+eax*8-0x41],0x3
478618: mov eax,ds:0x4b1074
47861d: mov BYTE PTR [eax],0x16
478620: mov BYTE PTR [edi],0x13
478623: xor eax,eax
478625: mov al,bl
478627: imul eax,eax,0x16
47862a: cmp BYTE PTR [esi+eax*8-0xa0],0x2
478632: jne 0x478b92
478638: cmp BYTE PTR [esp],0xe
47863c: jne 0x478690
47863e: xor eax,eax
478640: mov al,bl
478642: imul eax,eax,0x16
478645: cmp BYTE PTR [esi+eax*8-0x45],0x1
47864a: je 0x478668
47864c: xor eax,eax
47864e: mov al,bl
478650: imul eax,eax,0x16
478653: cmp BYTE PTR [esi+eax*8-0x45],0x2
478658: je 0x478668
47865a: xor eax,eax
47865c: mov al,bl
47865e: imul eax,eax,0x16
478661: cmp BYTE PTR [esi+eax*8-0x45],0x7
478666: jne 0x478690
478668: xor eax,eax
47866a: mov al,bl
47866c: imul eax,eax,0x16
47866f: mov BYTE PTR [esi+eax*8-0x45],0x17
478674: xor eax,eax
478676: mov al,bl
478678: imul eax,eax,0x16
47867b: mov WORD PTR [esi+eax*8-0x3c],0x0
478682: xor eax,eax
478684: mov al,bl
478686: imul eax,eax,0x16
478689: mov WORD PTR [esi+eax*8-0x3a],0xfa
478690: cmp BYTE PTR [esp],0xf
478694: jne 0x4786da
478696: xor eax,eax
478698: mov al,bl
47869a: imul eax,eax,0x16
47869d: cmp BYTE PTR [esi+eax*8-0x45],0x1
4786a2: je 0x4786b2
4786a4: xor eax,eax
4786a6: mov al,bl
4786a8: imul eax,eax,0x16
4786ab: cmp BYTE PTR [esi+eax*8-0x45],0x2
4786b0: jne 0x4786da
4786b2: xor eax,eax
4786b4: mov al,bl
4786b6: imul eax,eax,0x16
4786b9: mov BYTE PTR [esi+eax*8-0x45],0x18
4786be: xor eax,eax
4786c0: mov al,bl
4786c2: imul eax,eax,0x16
4786c5: mov WORD PTR [esi+eax*8-0x3c],0x0
4786cc: xor eax,eax
4786ce: mov al,bl
4786d0: imul eax,eax,0x16
4786d3: mov WORD PTR [esi+eax*8-0x3a],0x14
4786da: cmp BYTE PTR [esp],0x10
4786de: je 0x4786ea
4786e0: cmp BYTE PTR [esp],0x11
4786e4: jne 0x4787bd
4786ea: xor eax,eax
4786ec: mov al,bl
4786ee: imul eax,eax,0x16
4786f1: cmp BYTE PTR [esi+eax*8-0x45],0x1
4786f6: je 0x478726
4786f8: xor eax,eax
4786fa: mov al,bl
4786fc: imul eax,eax,0x16
4786ff: cmp BYTE PTR [esi+eax*8-0x45],0x2
478704: je 0x478726
478706: xor eax,eax
478708: mov al,bl
47870a: imul eax,eax,0x16
47870d: cmp BYTE PTR [esi+eax*8-0x45],0x15
478712: je 0x478726
478714: xor eax,eax
478716: mov al,bl
478718: imul eax,eax,0x16
47871b: cmp BYTE PTR [esi+eax*8-0x45],0x16
478720: jne 0x4787bd
478726: mov edx,ebx
478728: mov al,0x9
47872a: call 0x476454
47872f: test al,al
478731: jne 0x4787bd
478737: xor eax,eax
478739: mov al,bl
47873b: imul eax,eax,0x16
47873e: mov BYTE PTR [esi+eax*8-0x45],0x19
478743: xor eax,eax
478745: mov al,bl
478747: imul eax,eax,0x16
47874a: mov WORD PTR [esi+eax*8-0x3c],0x0
478751: xor eax,eax
478753: mov al,bl
478755: imul eax,eax,0x16
478758: mov WORD PTR [esi+eax*8-0x3a],0x1c
47875f: xor eax,eax
478761: mov al,bl
478763: imul eax,eax,0x16
478766: fld QWORD PTR [esi+eax*8-0x50]
47876a: fcomp DWORD PTR ds:0x47d1f8
478770: fnstsw ax
478772: sahf
478773: jae 0x478799
478775: fld DWORD PTR ds:0x47d204
47877b: mov eax,ds:0x4b0fe8
478780: fmul QWORD PTR [eax]
478782: xor eax,eax
478784: mov al,bl
478786: imul eax,eax,0x16
478789: fadd QWORD PTR [esi+eax*8-0x50]
47878d: xor eax,eax
47878f: mov al,bl
478791: imul eax,eax,0x16
478794: fstp QWORD PTR [esi+eax*8-0x50]
478798: fwait
478799: cmp BYTE PTR [esp],0x10
47879d: jne 0x4787ab
47879f: xor eax,eax
4787a1: mov al,bl
4787a3: imul eax,eax,0x16
4787a6: mov BYTE PTR [esi+eax*8-0x41],0x1
4787ab: cmp BYTE PTR [esp],0x11
4787af: jne 0x4787bd
4787b1: xor eax,eax
4787b3: mov al,bl
4787b5: imul eax,eax,0x16
4787b8: mov BYTE PTR [esi+eax*8-0x41],0x2
4787bd: cmp BYTE PTR [esp],0x12
4787c1: je 0x4787cd
4787c3: cmp BYTE PTR [esp],0x13
4787c7: jne 0x478900
4787cd: xor eax,eax
4787cf: mov al,bl
4787d1: imul eax,eax,0x16
4787d4: cmp BYTE PTR [esi+eax*8-0x45],0x1
4787d9: je 0x47887a
4787df: xor eax,eax
4787e1: mov al,bl
4787e3: imul eax,eax,0x16
4787e6: cmp BYTE PTR [esi+eax*8-0x45],0x2
4787eb: je 0x47887a
4787f1: xor eax,eax
4787f3: mov al,bl
4787f5: imul eax,eax,0x16
4787f8: cmp BYTE PTR [esi+eax*8-0x45],0x3
4787fd: jne 0x47880e
4787ff: xor eax,eax
478801: mov al,bl
478803: imul eax,eax,0x16
478806: cmp WORD PTR [esi+eax*8-0x3c],0x4
47880c: jge 0x47887a
47880e: xor eax,eax
478810: mov al,bl
478812: imul eax,eax,0x16
478815: cmp BYTE PTR [esi+eax*8-0x45],0x5
47881a: jne 0x47882b
47881c: xor eax,eax
47881e: mov al,bl
478820: imul eax,eax,0x16
478823: cmp WORD PTR [esi+eax*8-0x3c],0x5
478829: jge 0x47887a
47882b: xor eax,eax
47882d: mov al,bl
47882f: imul eax,eax,0x16
478832: cmp BYTE PTR [esi+eax*8-0x45],0x7
478837: je 0x47887a
478839: xor eax,eax
47883b: mov al,bl
47883d: imul eax,eax,0x16
478840: cmp BYTE PTR [esi+eax*8-0x45],0x15
478845: je 0x47887a
478847: xor eax,eax
478849: mov al,bl
47884b: imul eax,eax,0x16
47884e: cmp BYTE PTR [esi+eax*8-0x45],0x16
478853: je 0x47887a
478855: xor eax,eax
478857: mov al,bl
478859: imul eax,eax,0x16
47885c: cmp BYTE PTR [esi+eax*8-0x45],0x1e
478861: jne 0x478900
478867: xor eax,eax
478869: mov al,bl
47886b: imul eax,eax,0x16
47886e: cmp WORD PTR [esi+eax*8-0x3c],0xa
478874: jle 0x478900
47887a: xor eax,eax
47887c: mov al,bl
47887e: imul eax,eax,0x16
478881: mov BYTE PTR [esi+eax*8-0x45],0x1a
478886: xor eax,eax
478888: mov al,bl
47888a: imul eax,eax,0x16
47888d: mov WORD PTR [esi+eax*8-0x3c],0x0
478894: xor eax,eax
478896: mov al,bl
478898: imul eax,eax,0x16
47889b: mov WORD PTR [esi+eax*8-0x3a],0x1e
4788a2: xor eax,eax
4788a4: mov al,bl
4788a6: imul eax,eax,0x16
4788a9: fld QWORD PTR [esi+eax*8-0x50]
4788ad: fcomp DWORD PTR ds:0x47d1f8
4788b3: fnstsw ax
4788b5: sahf
4788b6: jae 0x4788dc
4788b8: fld DWORD PTR ds:0x47d208
4788be: mov eax,ds:0x4b0fe8
4788c3: fmul QWORD PTR [eax]
4788c5: xor eax,eax
4788c7: mov al,bl
4788c9: imul eax,eax,0x16
4788cc: fadd QWORD PTR [esi+eax*8-0x50]
4788d0: xor eax,eax
4788d2: mov al,bl
4788d4: imul eax,eax,0x16
4788d7: fstp QWORD PTR [esi+eax*8-0x50]
4788db: fwait
4788dc: cmp BYTE PTR [esp],0x12
4788e0: jne 0x4788ee
4788e2: xor eax,eax
4788e4: mov al,bl
4788e6: imul eax,eax,0x16
4788e9: mov BYTE PTR [esi+eax*8-0x41],0x1
4788ee: cmp BYTE PTR [esp],0x13
4788f2: jne 0x478900
4788f4: xor eax,eax
4788f6: mov al,bl
4788f8: imul eax,eax,0x16
4788fb: mov BYTE PTR [esi+eax*8-0x41],0x2
478900: cmp BYTE PTR [esp],0x14
478904: je 0x478910
478906: cmp BYTE PTR [esp],0x15
47890a: jne 0x4789d1
478910: xor eax,eax
478912: mov al,bl
478914: imul eax,eax,0x16
478917: cmp BYTE PTR [esi+eax*8-0x45],0xc
47891c: je 0x478930
47891e: xor eax,eax
478920: mov al,bl
478922: imul eax,eax,0x16
478925: cmp BYTE PTR [esi+eax*8-0x45],0xe
47892a: jne 0x4789d1
478930: xor eax,eax
478932: mov al,bl
478934: imul eax,eax,0x16
478937: mov BYTE PTR [esi+eax*8-0x45],0x1b
47893c: xor eax,eax
47893e: mov al,bl
478940: imul eax,eax,0x16
478943: mov WORD PTR [esi+eax*8-0x3c],0x0
47894a: xor eax,eax
47894c: mov al,bl
47894e: imul eax,eax,0x16
478951: mov WORD PTR [esi+eax*8-0x3a],0x14
478958: xor eax,eax
47895a: mov al,bl
47895c: imul eax,eax,0x16
47895f: mov BYTE PTR [esi+eax*8-0x47],0x1
478964: xor eax,eax
478966: mov al,bl
478968: imul eax,eax,0x16
47896b: mov BYTE PTR [esi+eax*8-0x46],0x0
478970: xor eax,eax
478972: mov al,bl
478974: imul eax,eax,0x16
478977: fld QWORD PTR [esi+eax*8-0x50]
47897b: fcomp DWORD PTR ds:0x47d1f8
478981: fnstsw ax
478983: sahf
478984: jae 0x4789aa
478986: fld DWORD PTR ds:0x47d204
47898c: mov eax,ds:0x4b0fe8
478991: fmul QWORD PTR [eax]
478993: xor eax,eax
478995: mov al,bl
478997: imul eax,eax,0x16
47899a: fadd QWORD PTR [esi+eax*8-0x50]
47899e: xor eax,eax
4789a0: mov al,bl
4789a2: imul eax,eax,0x16
4789a5: fstp QWORD PTR [esi+eax*8-0x50]
4789a9: fwait
4789aa: cmp BYTE PTR [esp],0x14
4789ae: jne 0x4789bc
4789b0: xor eax,eax
4789b2: mov al,bl
4789b4: imul eax,eax,0x16
4789b7: mov BYTE PTR [esi+eax*8-0x41],0x1
4789bc: cmp BYTE PTR [esp],0x15
4789c0: jne 0x4789ce
4789c2: xor eax,eax
4789c4: mov al,bl
4789c6: imul eax,eax,0x16
4789c9: mov BYTE PTR [esi+eax*8-0x41],0x2
4789ce: mov BYTE PTR [edi],0x15
4789d1: cmp BYTE PTR [esp],0x16
4789d5: jne 0x478a75
4789db: xor eax,eax
4789dd: mov al,bl
4789df: imul eax,eax,0x16
4789e2: cmp BYTE PTR [esi+eax*8-0x45],0x1
4789e7: je 0x478a13
4789e9: xor eax,eax
4789eb: mov al,bl
4789ed: imul eax,eax,0x16
4789f0: cmp BYTE PTR [esi+eax*8-0x45],0x2
4789f5: je 0x478a13
4789f7: xor eax,eax
4789f9: mov al,bl
4789fb: imul eax,eax,0x16
4789fe: cmp BYTE PTR [esi+eax*8-0x45],0x15
478a03: je 0x478a13
478a05: xor eax,eax
478a07: mov al,bl
478a09: imul eax,eax,0x16
478a0c: cmp BYTE PTR [esi+eax*8-0x45],0x16
478a11: jne 0x478a75
478a13: xor eax,eax
478a15: mov al,bl
478a17: imul eax,eax,0x16
478a1a: mov BYTE PTR [esi+eax*8-0x45],0x1c
478a1f: xor eax,eax
478a21: mov al,bl
478a23: imul eax,eax,0x16
478a26: mov WORD PTR [esi+eax*8-0x3c],0x0
478a2d: xor eax,eax
478a2f: mov al,bl
478a31: imul eax,eax,0x16
478a34: mov WORD PTR [esi+eax*8-0x3a],0x2d
478a3b: xor eax,eax
478a3d: mov al,bl
478a3f: imul eax,eax,0x16
478a42: fld QWORD PTR [esi+eax*8-0x50]
478a46: fcomp DWORD PTR ds:0x47d1f8
478a4c: fnstsw ax
478a4e: sahf
478a4f: jae 0x478a75
478a51: fld DWORD PTR ds:0x47d210
478a57: mov eax,ds:0x4b0fe8
478a5c: fmul QWORD PTR [eax]
478a5e: xor eax,eax
478a60: mov al,bl
478a62: imul eax,eax,0x16
478a65: fadd QWORD PTR [esi+eax*8-0x50]
478a69: xor eax,eax
478a6b: mov al,bl
478a6d: imul eax,eax,0x16
478a70: fstp QWORD PTR [esi+eax*8-0x50]
478a74: fwait
478a75: cmp BYTE PTR [esp],0x17
478a79: jne 0x478b92
478a7f: xor eax,eax
478a81: mov al,bl
478a83: imul eax,eax,0x16
478a86: mov dl,BYTE PTR [esi+eax*8-0x45]
478a8a: cmp dl,0x1
478a8d: je 0x478af0
478a8f: xor eax,eax
478a91: mov al,bl
478a93: imul eax,eax,0x16
478a96: cmp dl,0x2
478a99: je 0x478af0
478a9b: xor eax,eax
478a9d: mov al,bl
478a9f: imul eax,eax,0x16
478aa2: cmp dl,0x5
478aa5: je 0x478af0
478aa7: xor eax,eax
478aa9: mov al,bl
478aab: imul eax,eax,0x16
478aae: cmp dl,0x7
478ab1: je 0x478af0
478ab3: xor eax,eax
478ab5: mov al,bl
478ab7: imul eax,eax,0x16
478aba: cmp dl,0x15
478abd: je 0x478af0
478abf: xor eax,eax
478ac1: mov al,bl
478ac3: imul eax,eax,0x16
478ac6: cmp dl,0x16
478ac9: je 0x478af0
478acb: xor eax,eax
478acd: mov al,bl
478acf: imul eax,eax,0x16
478ad2: cmp BYTE PTR [esi+eax*8-0x45],0x19
478ad7: jne 0x478b92
478add: xor eax,eax
478adf: mov al,bl
478ae1: imul eax,eax,0x16
478ae4: cmp WORD PTR [esi+eax*8-0x3c],0xc
478aea: jle 0x478b92
478af0: xor eax,eax
478af2: mov al,bl
478af4: imul eax,eax,0x16
478af7: fld QWORD PTR [esi+eax*8-0x70]
478afb: fcomp DWORD PTR ds:0x47d20c
478b01: fnstsw ax
478b03: sahf
478b04: jbe 0x478b15
478b06: xor eax,eax
478b08: mov al,bl
478b0a: imul eax,eax,0x16
478b0d: cmp WORD PTR [esi+eax*8-0x58],0x0
478b13: jle 0x478b92
478b15: xor eax,eax
478b17: mov al,bl
478b19: imul eax,eax,0x16
478b1c: mov BYTE PTR [esi+eax*8-0x45],0x1e
478b21: xor eax,eax
478b23: mov al,bl
478b25: imul eax,eax,0x16
478b28: mov WORD PTR [esi+eax*8-0x3c],0x0
478b2f: xor eax,eax
478b31: mov al,bl
478b33: imul eax,eax,0x16
478b36: mov WORD PTR [esi+eax*8-0x3a],0xd
478b3d: xor eax,eax
478b3f: mov al,bl
478b41: imul eax,eax,0x16
478b44: mov BYTE PTR [esi+eax*8-0x41],0x2
478b49: xor eax,eax
478b4b: mov al,bl
478b4d: imul eax,eax,0x16
478b50: cmp WORD PTR [esi+eax*8-0x58],0x3
478b56: jne 0x478b69
478b58: xor eax,eax
478b5a: mov al,bl
478b5c: imul eax,eax,0x16
478b5f: xor edx,edx
478b61: mov DWORD PTR [esi+eax*8-0x50],edx
478b65: mov DWORD PTR [esi+eax*8-0x4c],edx
478b69: xor eax,eax
478b6b: mov al,bl
478b6d: imul eax,eax,0x16
478b70: dec WORD PTR [esi+eax*8-0x58]
478b75: xor eax,eax
478b77: mov al,bl
478b79: imul eax,eax,0x16
478b7c: mov dl,BYTE PTR [esp+0x2]
478b80: add dl,0x2c
478b83: mov BYTE PTR [esi+eax*8-0x44],dl
478b87: mov eax,ds:0x4b1074
478b8c: mov BYTE PTR [eax],0x16
478b8f: mov BYTE PTR [edi],0x13
478b92: xor eax,eax
478b94: mov al,bl
478b96: imul eax,eax,0x16
478b99: cmp BYTE PTR [esi+eax*8-0xa0],0x3
478ba1: jne 0x479140
478ba7: cmp BYTE PTR [esp],0xe
478bab: jne 0x478bff
478bad: xor eax,eax
478baf: mov al,bl
478bb1: imul eax,eax,0x16
478bb4: cmp BYTE PTR [esi+eax*8-0x45],0x1
478bb9: je 0x478bd7
478bbb: xor eax,eax
478bbd: mov al,bl
478bbf: imul eax,eax,0x16
478bc2: cmp BYTE PTR [esi+eax*8-0x45],0x2
478bc7: je 0x478bd7
478bc9: xor eax,eax
478bcb: mov al,bl
478bcd: imul eax,eax,0x16
478bd0: cmp BYTE PTR [esi+eax*8-0x45],0x7
478bd5: jne 0x478bff
478bd7: xor eax,eax
478bd9: mov al,bl
478bdb: imul eax,eax,0x16
478bde: mov BYTE PTR [esi+eax*8-0x45],0x17
478be3: xor eax,eax
478be5: mov al,bl
478be7: imul eax,eax,0x16
478bea: mov WORD PTR [esi+eax*8-0x3c],0x0
478bf1: xor eax,eax
478bf3: mov al,bl
478bf5: imul eax,eax,0x16
478bf8: mov WORD PTR [esi+eax*8-0x3a],0xfa
478bff: cmp BYTE PTR [esp],0xf
478c03: jne 0x478c49
478c05: xor eax,eax
478c07: mov al,bl
478c09: imul eax,eax,0x16
478c0c: cmp BYTE PTR [esi+eax*8-0x45],0x1
478c11: je 0x478c21
478c13: xor eax,eax
478c15: mov al,bl
478c17: imul eax,eax,0x16
478c1a: cmp BYTE PTR [esi+eax*8-0x45],0x2
478c1f: jne 0x478c49
478c21: xor eax,eax
478c23: mov al,bl
478c25: imul eax,eax,0x16
478c28: mov BYTE PTR [esi+eax*8-0x45],0x18
478c2d: xor eax,eax
478c2f: mov al,bl
478c31: imul eax,eax,0x16
478c34: mov WORD PTR [esi+eax*8-0x3c],0x0
478c3b: xor eax,eax
478c3d: mov al,bl
478c3f: imul eax,eax,0x16
478c42: mov WORD PTR [esi+eax*8-0x3a],0x14
478c49: cmp BYTE PTR [esp],0x10
478c4d: je 0x478c59
478c4f: cmp BYTE PTR [esp],0x11
478c53: jne 0x478d2f
478c59: xor eax,eax
478c5b: mov al,bl
478c5d: imul eax,eax,0x16
478c60: cmp BYTE PTR [esi+eax*8-0x45],0x1
478c65: je 0x478c95
478c67: xor eax,eax
478c69: mov al,bl
478c6b: imul eax,eax,0x16
478c6e: cmp BYTE PTR [esi+eax*8-0x45],0x2
478c73: je 0x478c95
478c75: xor eax,eax
478c77: mov al,bl
478c79: imul eax,eax,0x16
478c7c: cmp BYTE PTR [esi+eax*8-0x45],0x15
478c81: je 0x478c95
478c83: xor eax,eax
478c85: mov al,bl
478c87: imul eax,eax,0x16
478c8a: cmp BYTE PTR [esi+eax*8-0x45],0x16
478c8f: jne 0x478d2f
478c95: mov edx,ebx
478c97: mov al,0x9
478c99: call 0x476454
478c9e: test al,al
478ca0: jne 0x478d2f
478ca6: xor eax,eax
478ca8: mov al,bl
478caa: imul eax,eax,0x16
478cad: mov BYTE PTR [esi+eax*8-0x45],0x19
478cb2: xor eax,eax
478cb4: mov al,bl
478cb6: imul eax,eax,0x16
478cb9: mov WORD PTR [esi+eax*8-0x3c],0x0
478cc0: xor eax,eax
478cc2: mov al,bl
478cc4: imul eax,eax,0x16
478cc7: mov WORD PTR [esi+eax*8-0x3a],0x1c
478cce: xor eax,eax
478cd0: mov al,bl
478cd2: imul eax,eax,0x16
478cd5: fld QWORD PTR [esi+eax*8-0x50]
478cd9: fcomp DWORD PTR ds:0x47d1f8
478cdf: fnstsw ax
478ce1: sahf
478ce2: jae 0x478d08
478ce4: fld DWORD PTR ds:0x47d204
478cea: mov eax,ds:0x4b0fe8
478cef: fmul QWORD PTR [eax]
478cf1: xor eax,eax
478cf3: mov al,bl
478cf5: imul eax,eax,0x16
478cf8: fadd QWORD PTR [esi+eax*8-0x50]
478cfc: xor eax,eax
478cfe: mov al,bl
478d00: imul eax,eax,0x16
478d03: fstp QWORD PTR [esi+eax*8-0x50]
478d07: fwait
478d08: cmp BYTE PTR [esp],0x10
478d0c: jne 0x478d1a
478d0e: xor eax,eax
478d10: mov al,bl
478d12: imul eax,eax,0x16
478d15: mov BYTE PTR [esi+eax*8-0x41],0x1
478d1a: cmp BYTE PTR [esp],0x11
478d1e: jne 0x478d2c
478d20: xor eax,eax
478d22: mov al,bl
478d24: imul eax,eax,0x16
478d27: mov BYTE PTR [esi+eax*8-0x41],0x2
478d2c: mov BYTE PTR [edi],0x17
478d2f: cmp BYTE PTR [esp],0x12
478d33: je 0x478d3f
478d35: cmp BYTE PTR [esp],0x13
478d39: jne 0x478e43
478d3f: xor eax,eax
478d41: mov al,bl
478d43: imul eax,eax,0x16
478d46: mov al,BYTE PTR [esi+eax*8-0x45]
478d4a: cmp al,0x1
478d4c: je 0x478d7e
478d4e: xor edx,edx
478d50: mov dl,bl
478d52: imul edx,edx,0x16
478d55: cmp al,0x2
478d57: je 0x478d7e
478d59: xor edx,edx
478d5b: mov dl,bl
478d5d: imul edx,edx,0x16
478d60: cmp al,0x7
478d62: je 0x478d7e
478d64: xor edx,edx
478d66: mov dl,bl
478d68: imul edx,edx,0x16
478d6b: cmp al,0x15
478d6d: je 0x478d7e
478d6f: xor edx,edx
478d71: mov dl,bl
478d73: imul edx,edx,0x16
478d76: cmp al,0x16
478d78: jne 0x478e43
478d7e: xor eax,eax
478d80: mov al,bl
478d82: imul eax,eax,0x16
478d85: mov BYTE PTR [esi+eax*8-0x45],0x1a
478d8a: xor eax,eax
478d8c: mov al,bl
478d8e: imul eax,eax,0x16
478d91: mov WORD PTR [esi+eax*8-0x3c],0x0
478d98: xor eax,eax
478d9a: mov al,bl
478d9c: imul eax,eax,0x16
478d9f: mov WORD PTR [esi+eax*8-0x3a],0xf
478da6: xor eax,eax
478da8: mov al,bl
478daa: imul eax,eax,0x16
478dad: mov BYTE PTR [esi+eax*8-0x47],0x1
478db2: cmp BYTE PTR [esp],0x12
478db6: jne 0x478dc4
478db8: xor eax,eax
478dba: mov al,bl
478dbc: imul eax,eax,0x16
478dbf: mov BYTE PTR [esi+eax*8-0x38],0xe9
478dc4: cmp BYTE PTR [esp],0x13
478dc8: jne 0x478dd6
478dca: xor eax,eax
478dcc: mov al,bl
478dce: imul eax,eax,0x16
478dd1: mov BYTE PTR [esi+eax*8-0x38],0xe3
478dd6: xor eax,eax
478dd8: mov al,bl
478dda: imul eax,eax,0x16
478ddd: mov BYTE PTR [esi+eax*8-0x46],0x1
478de2: xor eax,eax
478de4: mov al,bl
478de6: imul eax,eax,0x16
478de9: fld QWORD PTR [esi+eax*8-0x50]
478ded: fcomp DWORD PTR ds:0x47d1f8
478df3: fnstsw ax
478df5: sahf
478df6: jae 0x478e1c
478df8: fld DWORD PTR ds:0x47d204
478dfe: mov eax,ds:0x4b0fe8
478e03: fmul QWORD PTR [eax]
478e05: xor eax,eax
478e07: mov al,bl
478e09: imul eax,eax,0x16
478e0c: fadd QWORD PTR [esi+eax*8-0x50]
478e10: xor eax,eax
478e12: mov al,bl
478e14: imul eax,eax,0x16
478e17: fstp QWORD PTR [esi+eax*8-0x50]
478e1b: fwait
478e1c: cmp BYTE PTR [esp],0x12
478e20: jne 0x478e2e
478e22: xor eax,eax
478e24: mov al,bl
478e26: imul eax,eax,0x16
478e29: mov BYTE PTR [esi+eax*8-0x41],0x1
478e2e: cmp BYTE PTR [esp],0x13
478e32: jne 0x478e40
478e34: xor eax,eax
478e36: mov al,bl
478e38: imul eax,eax,0x16
478e3b: mov BYTE PTR [esi+eax*8-0x41],0x2
478e40: mov BYTE PTR [edi],0x18
478e43: cmp BYTE PTR [esp],0x14
478e47: je 0x478e53
478e49: cmp BYTE PTR [esp],0x15
478e4d: jne 0x478f4e
478e53: xor eax,eax
478e55: mov al,bl
478e57: imul eax,eax,0x16
478e5a: cmp BYTE PTR [esi+eax*8-0x45],0x1
478e5f: je 0x478e8f
478e61: xor eax,eax
478e63: mov al,bl
478e65: imul eax,eax,0x16
478e68: cmp BYTE PTR [esi+eax*8-0x45],0x2
478e6d: je 0x478e8f
478e6f: xor eax,eax
478e71: mov al,bl
478e73: imul eax,eax,0x16
478e76: cmp BYTE PTR [esi+eax*8-0x45],0x15
478e7b: je 0x478e8f
478e7d: xor eax,eax
478e7f: mov al,bl
478e81: imul eax,eax,0x16
478e84: cmp BYTE PTR [esi+eax*8-0x45],0x16
478e89: jne 0x478f4e
478e8f: xor eax,eax
478e91: mov al,bl
478e93: imul eax,eax,0x16
478e96: mov BYTE PTR [esi+eax*8-0x45],0x1b
478e9b: xor eax,eax
478e9d: mov al,bl
478e9f: imul eax,eax,0x16
478ea2: mov WORD PTR [esi+eax*8-0x3c],0x0
478ea9: xor eax,eax
478eab: mov al,bl
478ead: imul eax,eax,0x16
478eb0: mov BYTE PTR [esi+eax*8-0x47],0x1
478eb5: xor eax,eax
478eb7: mov al,bl
478eb9: imul eax,eax,0x16
478ebc: fld QWORD PTR [esi+eax*8-0x50]
478ec0: fcomp DWORD PTR ds:0x47d1f8
478ec6: fnstsw ax
478ec8: sahf
478ec9: jae 0x478eef
478ecb: fld DWORD PTR ds:0x47d204
478ed1: mov eax,ds:0x4b0fe8
478ed6: fmul QWORD PTR [eax]
478ed8: xor eax,eax
478eda: mov al,bl
478edc: imul eax,eax,0x16
478edf: fadd QWORD PTR [esi+eax*8-0x50]
478ee3: xor eax,eax
478ee5: mov al,bl
478ee7: imul eax,eax,0x16
478eea: fstp QWORD PTR [esi+eax*8-0x50]
478eee: fwait
478eef: cmp BYTE PTR [esp],0x14
478ef3: jne 0x478f01
478ef5: xor eax,eax
478ef7: mov al,bl
478ef9: imul eax,eax,0x16
478efc: mov BYTE PTR [esi+eax*8-0x41],0x1
478f01: cmp BYTE PTR [esp],0x15
478f05: jne 0x478f13
478f07: xor eax,eax
478f09: mov al,bl
478f0b: imul eax,eax,0x16
478f0e: mov BYTE PTR [esi+eax*8-0x41],0x2
478f13: xor eax,eax
478f15: mov al,bl
478f17: imul eax,eax,0x16
478f1a: cmp BYTE PTR [esi+eax*8-0x41],0x1
478f1f: jne 0x478f2f
478f21: xor eax,eax
478f23: mov al,bl
478f25: imul eax,eax,0x16
478f28: mov WORD PTR [esi+eax*8-0x3a],0xe
478f2f: xor eax,eax
478f31: mov al,bl
478f33: imul eax,eax,0x16
478f36: cmp BYTE PTR [esi+eax*8-0x41],0x2
478f3b: jne 0x478f4b
478f3d: xor eax,eax
478f3f: mov al,bl
478f41: imul eax,eax,0x16
478f44: mov WORD PTR [esi+eax*8-0x3a],0x13
478f4b: mov BYTE PTR [edi],0x18
478f4e: cmp BYTE PTR [esp],0x16
478f52: je 0x478f5e
478f54: cmp BYTE PTR [esp],0x17
478f58: jne 0x479050
478f5e: xor eax,eax
478f60: mov al,bl
478f62: imul eax,eax,0x16
478f65: cmp BYTE PTR [esi+eax*8-0x45],0x1
478f6a: je 0x478f9a
478f6c: xor eax,eax
478f6e: mov al,bl
478f70: imul eax,eax,0x16
478f73: cmp BYTE PTR [esi+eax*8-0x45],0x2
478f78: je 0x478f9a
478f7a: xor eax,eax
478f7c: mov al,bl
478f7e: imul eax,eax,0x16
478f81: cmp BYTE PTR [esi+eax*8-0x45],0x15
478f86: je 0x478f9a
478f88: xor eax,eax
478f8a: mov al,bl
478f8c: imul eax,eax,0x16
478f8f: cmp BYTE PTR [esi+eax*8-0x45],0x16
478f94: jne 0x479050
478f9a: xor eax,eax
478f9c: mov al,bl
478f9e: imul eax,eax,0x16
478fa1: mov BYTE PTR [esi+eax*8-0x45],0x1c
478fa6: xor eax,eax
478fa8: mov al,bl
478faa: imul eax,eax,0x16
478fad: mov WORD PTR [esi+eax*8-0x3c],0x0
478fb4: xor eax,eax
478fb6: mov al,bl
478fb8: imul eax,eax,0x16
478fbb: mov WORD PTR [esi+eax*8-0x3a],0xf
478fc2: cmp BYTE PTR [esp],0x16
478fc6: jne 0x478fd4
478fc8: xor eax,eax
478fca: mov al,bl
478fcc: imul eax,eax,0x16
478fcf: mov BYTE PTR [esi+eax*8-0x38],0xea
478fd4: cmp BYTE PTR [esp],0x17
478fd8: jne 0x478fe6
478fda: xor eax,eax
478fdc: mov al,bl
478fde: imul eax,eax,0x16
478fe1: mov BYTE PTR [esi+eax*8-0x38],0xe9
478fe6: xor eax,eax
478fe8: mov al,bl
478fea: imul eax,eax,0x16
478fed: mov BYTE PTR [esi+eax*8-0x46],0x1
478ff2: xor eax,eax
478ff4: mov al,bl
478ff6: imul eax,eax,0x16
478ff9: fld QWORD PTR [esi+eax*8-0x50]
478ffd: fcomp DWORD PTR ds:0x47d1f8
479003: fnstsw ax
479005: sahf
479006: jae 0x47902c
479008: fld DWORD PTR ds:0x47d208
47900e: mov eax,ds:0x4b0fe8
479013: fmul QWORD PTR [eax]
479015: xor eax,eax
479017: mov al,bl
479019: imul eax,eax,0x16
47901c: fadd QWORD PTR [esi+eax*8-0x50]
479020: xor eax,eax
479022: mov al,bl
479024: imul eax,eax,0x16
479027: fstp QWORD PTR [esi+eax*8-0x50]
47902b: fwait
47902c: cmp BYTE PTR [esp],0x16
479030: jne 0x47903e
479032: xor eax,eax
479034: mov al,bl
479036: imul eax,eax,0x16
479039: mov BYTE PTR [esi+eax*8-0x41],0x1
47903e: cmp BYTE PTR [esp],0x17
479042: jne 0x479050
479044: xor eax,eax
479046: mov al,bl
479048: imul eax,eax,0x16
47904b: mov BYTE PTR [esi+eax*8-0x41],0x2
479050: cmp BYTE PTR [esp],0x18
479054: jne 0x479140
47905a: xor eax,eax
47905c: mov al,bl
47905e: imul eax,eax,0x16
479061: mov dl,BYTE PTR [esi+eax*8-0x45]
479065: cmp dl,0x1
479068: je 0x4790aa
47906a: xor eax,eax
47906c: mov al,bl
47906e: imul eax,eax,0x16
479071: cmp dl,0x2
479074: je 0x4790aa
479076: xor eax,eax
479078: mov al,bl
47907a: imul eax,eax,0x16
47907d: cmp dl,0x7
479080: je 0x4790aa
479082: xor eax,eax
479084: mov al,bl
479086: imul eax,eax,0x16
479089: cmp dl,0x6
47908c: je 0x4790aa
47908e: xor eax,eax
479090: mov al,bl
479092: imul eax,eax,0x16
479095: cmp dl,0x15
479098: je 0x4790aa
47909a: xor eax,eax
47909c: mov al,bl
47909e: imul eax,eax,0x16
4790a1: cmp dl,0x16
4790a4: jne 0x479140
4790aa: xor eax,eax
4790ac: mov al,bl
4790ae: imul eax,eax,0x16
4790b1: fld QWORD PTR [esi+eax*8-0x70]
4790b5: fcomp DWORD PTR ds:0x47d20c
4790bb: fnstsw ax
4790bd: sahf
4790be: jbe 0x4790cf
4790c0: xor eax,eax
4790c2: mov al,bl
4790c4: imul eax,eax,0x16
4790c7: cmp WORD PTR [esi+eax*8-0x58],0x0
4790cd: jle 0x479140
4790cf: xor eax,eax
4790d1: mov al,bl
4790d3: imul eax,eax,0x16
4790d6: mov BYTE PTR [esi+eax*8-0x45],0x1d
4790db: xor eax,eax
4790dd: mov al,bl
4790df: imul eax,eax,0x16
4790e2: mov dl,BYTE PTR [esp+0x2]
4790e6: add dl,0x30
4790e9: mov BYTE PTR [esi+eax*8-0x44],dl
4790ed: xor eax,eax
4790ef: mov al,bl
4790f1: imul eax,eax,0x16
4790f4: mov WORD PTR [esi+eax*8-0x3c],0x0
4790fb: xor eax,eax
4790fd: mov al,bl
4790ff: imul eax,eax,0x16
479102: mov WORD PTR [esi+eax*8-0x3a],0xf
479109: xor eax,eax
47910b: mov al,bl
47910d: imul eax,eax,0x16
479110: cmp WORD PTR [esi+eax*8-0x58],0x3
479116: jne 0x479129
479118: xor eax,eax
47911a: mov al,bl
47911c: imul eax,eax,0x16
47911f: xor edx,edx
479121: mov DWORD PTR [esi+eax*8-0x50],edx
479125: mov DWORD PTR [esi+eax*8-0x4c],edx
479129: xor eax,eax
47912b: mov al,bl
47912d: imul eax,eax,0x16
479130: dec WORD PTR [esi+eax*8-0x58]
479135: mov eax,ds:0x4b1074
47913a: mov BYTE PTR [eax],0x16
47913d: mov BYTE PTR [edi],0x13
479140: xor eax,eax
479142: mov al,bl
479144: imul eax,eax,0x16
479147: cmp BYTE PTR [esi+eax*8-0xa0],0x4
47914f: jne 0x4796a9
479155: cmp BYTE PTR [esp],0xe
479159: jne 0x4791ad
47915b: xor eax,eax
47915d: mov al,bl
47915f: imul eax,eax,0x16
479162: cmp BYTE PTR [esi+eax*8-0x45],0x1
479167: je 0x479185
479169: xor eax,eax
47916b: mov al,bl
47916d: imul eax,eax,0x16
479170: cmp BYTE PTR [esi+eax*8-0x45],0x2
479175: je 0x479185
479177: xor eax,eax
479179: mov al,bl
47917b: imul eax,eax,0x16
47917e: cmp BYTE PTR [esi+eax*8-0x45],0x7
479183: jne 0x4791ad
479185: xor eax,eax
479187: mov al,bl
479189: imul eax,eax,0x16
47918c: mov BYTE PTR [esi+eax*8-0x45],0x17
479191: xor eax,eax
479193: mov al,bl
479195: imul eax,eax,0x16
479198: mov WORD PTR [esi+eax*8-0x3c],0x0
47919f: xor eax,eax
4791a1: mov al,bl
4791a3: imul eax,eax,0x16
4791a6: mov WORD PTR [esi+eax*8-0x3a],0xfa
4791ad: cmp BYTE PTR [esp],0xf
4791b1: jne 0x4791f7
4791b3: xor eax,eax
4791b5: mov al,bl
4791b7: imul eax,eax,0x16
4791ba: cmp BYTE PTR [esi+eax*8-0x45],0x1
4791bf: je 0x4791cf
4791c1: xor eax,eax
4791c3: mov al,bl
4791c5: imul eax,eax,0x16
4791c8: cmp BYTE PTR [esi+eax*8-0x45],0x2
4791cd: jne 0x4791f7
4791cf: xor eax,eax
4791d1: mov al,bl
4791d3: imul eax,eax,0x16
4791d6: mov BYTE PTR [esi+eax*8-0x45],0x18
4791db: xor eax,eax
4791dd: mov al,bl
4791df: imul eax,eax,0x16
4791e2: mov WORD PTR [esi+eax*8-0x3c],0x0
4791e9: xor eax,eax
4791eb: mov al,bl
4791ed: imul eax,eax,0x16
4791f0: mov WORD PTR [esi+eax*8-0x3a],0x14
4791f7: cmp BYTE PTR [esp],0x10
4791fb: je 0x479207
4791fd: cmp BYTE PTR [esp],0x11
479201: jne 0x4792dd
479207: xor eax,eax
479209: mov al,bl
47920b: imul eax,eax,0x16
47920e: cmp BYTE PTR [esi+eax*8-0x45],0x1
479213: je 0x479243
479215: xor eax,eax
479217: mov al,bl
479219: imul eax,eax,0x16
47921c: cmp BYTE PTR [esi+eax*8-0x45],0x2
479221: je 0x479243
479223: xor eax,eax
479225: mov al,bl
479227: imul eax,eax,0x16
47922a: cmp BYTE PTR [esi+eax*8-0x45],0x15
47922f: je 0x479243
479231: xor eax,eax
479233: mov al,bl
479235: imul eax,eax,0x16
479238: cmp BYTE PTR [esi+eax*8-0x45],0x16
47923d: jne 0x4792dd
479243: mov edx,ebx
479245: mov al,0xc
479247: call 0x476454
47924c: test al,al
47924e: jne 0x4792dd
479254: xor eax,eax
479256: mov al,bl
479258: imul eax,eax,0x16
47925b: mov BYTE PTR [esi+eax*8-0x45],0x19
479260: xor eax,eax
479262: mov al,bl
479264: imul eax,eax,0x16
479267: mov WORD PTR [esi+eax*8-0x3c],0x0
47926e: xor eax,eax
479270: mov al,bl
479272: imul eax,eax,0x16
479275: mov WORD PTR [esi+eax*8-0x3a],0x1c
47927c: xor eax,eax
47927e: mov al,bl
479280: imul eax,eax,0x16
479283: fld QWORD PTR [esi+eax*8-0x50]
479287: fcomp DWORD PTR ds:0x47d1f8
47928d: fnstsw ax
47928f: sahf
479290: jae 0x4792b6
479292: fld DWORD PTR ds:0x47d204
479298: mov eax,ds:0x4b0fe8
47929d: fmul QWORD PTR [eax]
47929f: xor eax,eax
4792a1: mov al,bl
4792a3: imul eax,eax,0x16
4792a6: fadd QWORD PTR [esi+eax*8-0x50]
4792aa: xor eax,eax
4792ac: mov al,bl
4792ae: imul eax,eax,0x16
4792b1: fstp QWORD PTR [esi+eax*8-0x50]
4792b5: fwait
4792b6: cmp BYTE PTR [esp],0x10
4792ba: jne 0x4792c8
4792bc: xor eax,eax
4792be: mov al,bl
4792c0: imul eax,eax,0x16
4792c3: mov BYTE PTR [esi+eax*8-0x41],0x1
4792c8: cmp BYTE PTR [esp],0x11
4792cc: jne 0x4792da
4792ce: xor eax,eax
4792d0: mov al,bl
4792d2: imul eax,eax,0x16
4792d5: mov BYTE PTR [esi+eax*8-0x41],0x2
4792da: mov BYTE PTR [edi],0x19
4792dd: cmp BYTE PTR [esp],0x12
4792e1: je 0x4792ed
4792e3: cmp BYTE PTR [esp],0x13
4792e7: jne 0x4793e8
4792ed: xor eax,eax
4792ef: mov al,bl
4792f1: imul eax,eax,0x16
4792f4: cmp BYTE PTR [esi+eax*8-0x45],0x1
4792f9: je 0x479329
4792fb: xor eax,eax
4792fd: mov al,bl
4792ff: imul eax,eax,0x16
479302: cmp BYTE PTR [esi+eax*8-0x45],0x2
479307: je 0x479329
479309: xor eax,eax
47930b: mov al,bl
47930d: imul eax,eax,0x16
479310: cmp BYTE PTR [esi+eax*8-0x45],0x15
479315: je 0x479329
479317: xor eax,eax
479319: mov al,bl
47931b: imul eax,eax,0x16
47931e: cmp BYTE PTR [esi+eax*8-0x45],0x16
479323: jne 0x4793e8
479329: xor eax,eax
47932b: mov al,bl
47932d: imul eax,eax,0x16
479330: mov BYTE PTR [esi+eax*8-0x45],0x1a
479335: xor eax,eax
479337: mov al,bl
479339: imul eax,eax,0x16
47933c: mov WORD PTR [esi+eax*8-0x3c],0x0
479343: xor eax,eax
479345: mov al,bl
479347: imul eax,eax,0x16
47934a: mov BYTE PTR [esi+eax*8-0x47],0x1
47934f: xor eax,eax
479351: mov al,bl
479353: imul eax,eax,0x16
479356: fld QWORD PTR [esi+eax*8-0x50]
47935a: fcomp DWORD PTR ds:0x47d1f8
479360: fnstsw ax
479362: sahf
479363: jae 0x479389
479365: fld DWORD PTR ds:0x47d204
47936b: mov eax,ds:0x4b0fe8
479370: fmul QWORD PTR [eax]
479372: xor eax,eax
479374: mov al,bl
479376: imul eax,eax,0x16
479379: fadd QWORD PTR [esi+eax*8-0x50]
47937d: xor eax,eax
47937f: mov al,bl
479381: imul eax,eax,0x16
479384: fstp QWORD PTR [esi+eax*8-0x50]
479388: fwait
479389: cmp BYTE PTR [esp],0x12
47938d: jne 0x47939b
47938f: xor eax,eax
479391: mov al,bl
479393: imul eax,eax,0x16
479396: mov BYTE PTR [esi+eax*8-0x41],0x1
47939b: cmp BYTE PTR [esp],0x13
47939f: jne 0x4793ad
4793a1: xor eax,eax
4793a3: mov al,bl
4793a5: imul eax,eax,0x16
4793a8: mov BYTE PTR [esi+eax*8-0x41],0x2
4793ad: xor eax,eax
4793af: mov al,bl
4793b1: imul eax,eax,0x16
4793b4: cmp BYTE PTR [esi+eax*8-0x41],0x1
4793b9: jne 0x4793c9
4793bb: xor eax,eax
4793bd: mov al,bl
4793bf: imul eax,eax,0x16
4793c2: mov WORD PTR [esi+eax*8-0x3a],0xd
4793c9: xor eax,eax
4793cb: mov al,bl
4793cd: imul eax,eax,0x16
4793d0: cmp BYTE PTR [esi+eax*8-0x41],0x2
4793d5: jne 0x4793e5
4793d7: xor eax,eax
4793d9: mov al,bl
4793db: imul eax,eax,0x16
4793de: mov WORD PTR [esi+eax*8-0x3a],0x10
4793e5: mov BYTE PTR [edi],0x1a
4793e8: cmp BYTE PTR [esp],0x14
4793ec: je 0x4793f8
4793ee: cmp BYTE PTR [esp],0x15
4793f2: jne 0x4794bd
4793f8: xor eax,eax
4793fa: mov al,bl
4793fc: imul eax,eax,0x16
4793ff: mov al,BYTE PTR [esi+eax*8-0x45]
479403: cmp al,0x1
479405: je 0x479437
479407: xor edx,edx
479409: mov dl,bl
47940b: imul edx,edx,0x16
47940e: cmp al,0x2
479410: je 0x479437
479412: xor edx,edx
479414: mov dl,bl
479416: imul edx,edx,0x16
479419: cmp al,0x7
47941b: je 0x479437
47941d: xor edx,edx
47941f: mov dl,bl
479421: imul edx,edx,0x16
479424: cmp al,0x15
479426: je 0x479437
479428: xor edx,edx
47942a: mov dl,bl
47942c: imul edx,edx,0x16
47942f: cmp al,0x16
479431: jne 0x4794bd
479437: xor eax,eax
479439: mov al,bl
47943b: imul eax,eax,0x16
47943e: mov BYTE PTR [esi+eax*8-0x45],0x1b
479443: xor eax,eax
479445: mov al,bl
479447: imul eax,eax,0x16
47944a: mov WORD PTR [esi+eax*8-0x3c],0x0
479451: xor eax,eax
479453: mov al,bl
479455: imul eax,eax,0x16
479458: mov WORD PTR [esi+eax*8-0x3a],0xf
47945f: xor eax,eax
479461: mov al,bl
479463: imul eax,eax,0x16
479466: fld QWORD PTR [esi+eax*8-0x50]
47946a: fcomp DWORD PTR ds:0x47d1f8
479470: fnstsw ax
479472: sahf
479473: jae 0x479499
479475: fld DWORD PTR ds:0x47d208
47947b: mov eax,ds:0x4b0fe8
479480: fmul QWORD PTR [eax]
479482: xor eax,eax
479484: mov al,bl
479486: imul eax,eax,0x16
479489: fadd QWORD PTR [esi+eax*8-0x50]
47948d: xor eax,eax
47948f: mov al,bl
479491: imul eax,eax,0x16
479494: fstp QWORD PTR [esi+eax*8-0x50]
479498: fwait
479499: cmp BYTE PTR [esp],0x14
47949d: jne 0x4794ab
47949f: xor eax,eax
4794a1: mov al,bl
4794a3: imul eax,eax,0x16
4794a6: mov BYTE PTR [esi+eax*8-0x41],0x1
4794ab: cmp BYTE PTR [esp],0x15
4794af: jne 0x4794bd
4794b1: xor eax,eax
4794b3: mov al,bl
4794b5: imul eax,eax,0x16
4794b8: mov BYTE PTR [esi+eax*8-0x41],0x2
4794bd: cmp BYTE PTR [esp],0x16
4794c1: je 0x4794cd
4794c3: cmp BYTE PTR [esp],0x17
4794c7: jne 0x47958a
4794cd: xor eax,eax
4794cf: mov al,bl
4794d1: imul eax,eax,0x16
4794d4: cmp BYTE PTR [esi+eax*8-0x45],0x1
4794d9: je 0x479509
4794db: xor eax,eax
4794dd: mov al,bl
4794df: imul eax,eax,0x16
4794e2: cmp BYTE PTR [esi+eax*8-0x45],0x2
4794e7: je 0x479509
4794e9: xor eax,eax
4794eb: mov al,bl
4794ed: imul eax,eax,0x16
4794f0: cmp BYTE PTR [esi+eax*8-0x45],0x15
4794f5: je 0x479509
4794f7: xor eax,eax
4794f9: mov al,bl
4794fb: imul eax,eax,0x16
4794fe: cmp BYTE PTR [esi+eax*8-0x45],0x16
479503: jne 0x47958a
479509: xor eax,eax
47950b: mov al,bl
47950d: imul edx,eax,0x16
479510: mov BYTE PTR [esi+edx*8-0x45],0x1c
479515: mov WORD PTR [esi+edx*8-0x3c],0x0
47951c: mov WORD PTR [esi+edx*8-0x3a],0xf
479523: mov BYTE PTR [esi+edx*8-0x47],0x1
479528: fld QWORD PTR [esi+edx*8-0x50]
47952c: fcomp DWORD PTR ds:0x47d1f8
479532: fnstsw ax
479534: sahf
479535: jae 0x479554
479537: fld DWORD PTR ds:0x47d204
47953d: mov eax,ds:0x4b0fe8
479542: fmul QWORD PTR [eax]
479544: xor eax,eax
479546: mov al,bl
479548: imul eax,eax,0x16
47954b: fadd QWORD PTR [esi+eax*8-0x50]
47954f: fstp QWORD PTR [esi+edx*8-0x50]
479553: fwait
479554: cmp BYTE PTR [esp],0x16
479558: jne 0x47955f
47955a: mov BYTE PTR [esi+edx*8-0x41],0x1
47955f: cmp BYTE PTR [esp],0x17
479563: jne 0x47956a
479565: mov BYTE PTR [esi+edx*8-0x41],0x2
47956a: cmp BYTE PTR [esi+edx*8-0x41],0x1
47956f: jne 0x479576
479571: mov BYTE PTR [esi+edx*8-0x38],0xe6
479576: cmp BYTE PTR [esi+edx*8-0x41],0x2
47957b: jne 0x479582
47957d: mov BYTE PTR [esi+edx*8-0x38],0xe0
479582: mov BYTE PTR [esi+edx*8-0x46],0x1
479587: mov BYTE PTR [edi],0x1b
47958a: cmp BYTE PTR [esp],0x18
47958e: jne 0x4796a9
479594: xor eax,eax
479596: mov al,bl
479598: imul eax,eax,0x16
47959b: mov dl,BYTE PTR [esi+eax*8-0x45]
47959f: cmp dl,0x1
4795a2: je 0x4795e4
4795a4: xor eax,eax
4795a6: mov al,bl
4795a8: imul eax,eax,0x16
4795ab: cmp dl,0x2
4795ae: je 0x4795e4
4795b0: xor eax,eax
4795b2: mov al,bl
4795b4: imul eax,eax,0x16
4795b7: cmp dl,0x7
4795ba: je 0x4795e4
4795bc: xor eax,eax
4795be: mov al,bl
4795c0: imul eax,eax,0x16
4795c3: cmp dl,0x15
4795c6: je 0x4795e4
4795c8: xor eax,eax
4795ca: mov al,bl
4795cc: imul eax,eax,0x16
4795cf: cmp dl,0x16
4795d2: je 0x4795e4
4795d4: xor eax,eax
4795d6: mov al,bl
4795d8: imul eax,eax,0x16
4795db: cmp dl,0x1a
4795de: jne 0x4796a9
4795e4: xor eax,eax
4795e6: mov al,bl
4795e8: imul eax,eax,0x16
4795eb: fld QWORD PTR [esi+eax*8-0x70]
4795ef: fcomp DWORD PTR ds:0x47d20c
4795f5: fnstsw ax
4795f7: sahf
4795f8: jbe 0x47960d
4795fa: xor eax,eax
4795fc: mov al,bl
4795fe: imul eax,eax,0x16
479601: cmp WORD PTR [esi+eax*8-0x58],0x0
479607: jle 0x4796a9
47960d: xor eax,eax
47960f: mov al,bl
479611: imul eax,eax,0x16
479614: mov BYTE PTR [esi+eax*8-0x45],0x1d
479619: xor eax,eax
47961b: mov al,bl
47961d: imul eax,eax,0x16
479620: mov WORD PTR [esi+eax*8-0x3c],0x0
479627: xor eax,eax
479629: mov al,bl
47962b: imul eax,eax,0x16
47962e: mov WORD PTR [esi+eax*8-0x3a],0xd
479635: xor eax,eax
479637: mov al,bl
479639: imul eax,eax,0x16
47963c: mov BYTE PTR [esi+eax*8-0x41],0x2
479641: xor eax,eax
479643: mov al,bl
479645: imul eax,eax,0x16
479648: mov BYTE PTR [esi+eax*8-0x47],0x1
47964d: xor eax,eax
47964f: mov al,bl
479651: imul eax,eax,0x16
479654: cmp WORD PTR [esi+eax*8-0x58],0x3
47965a: jne 0x47966d
47965c: xor eax,eax
47965e: mov al,bl
479660: imul eax,eax,0x16
479663: xor edx,edx
479665: mov DWORD PTR [esi+eax*8-0x50],edx
479669: mov DWORD PTR [esi+eax*8-0x4c],edx
47966d: xor eax,eax
47966f: mov al,bl
479671: imul eax,eax,0x16
479674: dec WORD PTR [esi+eax*8-0x58]
479679: xor eax,eax
47967b: mov al,bl
47967d: imul eax,eax,0x16
479680: mov dl,BYTE PTR [esp+0x2]
479684: add dl,0xc
479687: mov BYTE PTR [esi+eax*8-0x44],dl
47968b: xor eax,eax
47968d: mov al,bl
47968f: mov edx,0x3
479694: sub edx,eax
479696: imul eax,edx,0x16
479699: mov BYTE PTR [esi+eax*8-0x1e],0x0
47969e: mov eax,ds:0x4b1074
4796a3: mov BYTE PTR [eax],0x16
4796a6: mov BYTE PTR [edi],0x13
4796a9: xor eax,eax
4796ab: mov al,bl
4796ad: imul eax,eax,0x16
4796b0: cmp BYTE PTR [esi+eax*8-0xa0],0x5
4796b8: jne 0x479bf7
4796be: cmp BYTE PTR [esp],0xe
4796c2: jne 0x479716
4796c4: xor eax,eax
4796c6: mov al,bl
4796c8: imul eax,eax,0x16
4796cb: cmp BYTE PTR [esi+eax*8-0x45],0x1
4796d0: je 0x4796ee
4796d2: xor eax,eax
4796d4: mov al,bl
4796d6: imul eax,eax,0x16
4796d9: cmp BYTE PTR [esi+eax*8-0x45],0x2
4796de: je 0x4796ee
4796e0: xor eax,eax
4796e2: mov al,bl
4796e4: imul eax,eax,0x16
4796e7: cmp BYTE PTR [esi+eax*8-0x45],0x7
4796ec: jne 0x479716
4796ee: xor eax,eax
4796f0: mov al,bl
4796f2: imul eax,eax,0x16
4796f5: mov BYTE PTR [esi+eax*8-0x45],0x17
4796fa: xor eax,eax
4796fc: mov al,bl
4796fe: imul eax,eax,0x16
479701: mov WORD PTR [esi+eax*8-0x3c],0x0
479708: xor eax,eax
47970a: mov al,bl
47970c: imul eax,eax,0x16
47970f: mov WORD PTR [esi+eax*8-0x3a],0xfa
479716: cmp BYTE PTR [esp],0xf
47971a: jne 0x479760
47971c: xor eax,eax
47971e: mov al,bl
479720: imul eax,eax,0x16
479723: cmp BYTE PTR [esi+eax*8-0x45],0x1
479728: je 0x479738
47972a: xor eax,eax
47972c: mov al,bl
47972e: imul eax,eax,0x16
479731: cmp BYTE PTR [esi+eax*8-0x45],0x2
479736: jne 0x479760
479738: xor eax,eax
47973a: mov al,bl
47973c: imul eax,eax,0x16
47973f: mov BYTE PTR [esi+eax*8-0x45],0x18
479744: xor eax,eax
479746: mov al,bl
479748: imul eax,eax,0x16
47974b: mov WORD PTR [esi+eax*8-0x3c],0x0
479752: xor eax,eax
479754: mov al,bl
479756: imul eax,eax,0x16
479759: mov WORD PTR [esi+eax*8-0x3a],0x14
479760: cmp BYTE PTR [esp],0x10
479764: je 0x479770
479766: cmp BYTE PTR [esp],0x11
47976a: jne 0x479846
479770: xor eax,eax
479772: mov al,bl
479774: imul eax,eax,0x16
479777: cmp BYTE PTR [esi+eax*8-0x45],0x1
47977c: je 0x4797ac
47977e: xor eax,eax
479780: mov al,bl
479782: imul eax,eax,0x16
479785: cmp BYTE PTR [esi+eax*8-0x45],0x2
47978a: je 0x4797ac
47978c: xor eax,eax
47978e: mov al,bl
479790: imul eax,eax,0x16
479793: cmp BYTE PTR [esi+eax*8-0x45],0x15
479798: je 0x4797ac
47979a: xor eax,eax
47979c: mov al,bl
47979e: imul eax,eax,0x16
4797a1: cmp BYTE PTR [esi+eax*8-0x45],0x16
4797a6: jne 0x479846
4797ac: mov edx,ebx
4797ae: mov al,0xd
4797b0: call 0x476454
4797b5: test al,al
4797b7: jne 0x479846
4797bd: xor eax,eax
4797bf: mov al,bl
4797c1: imul eax,eax,0x16
4797c4: mov BYTE PTR [esi+eax*8-0x45],0x19
4797c9: xor eax,eax
4797cb: mov al,bl
4797cd: imul eax,eax,0x16
4797d0: mov WORD PTR [esi+eax*8-0x3c],0x0
4797d7: xor eax,eax
4797d9: mov al,bl
4797db: imul eax,eax,0x16
4797de: mov WORD PTR [esi+eax*8-0x3a],0x1c
4797e5: xor eax,eax
4797e7: mov al,bl
4797e9: imul eax,eax,0x16
4797ec: fld QWORD PTR [esi+eax*8-0x50]
4797f0: fcomp DWORD PTR ds:0x47d1f8
4797f6: fnstsw ax
4797f8: sahf
4797f9: jae 0x47981f
4797fb: fld DWORD PTR ds:0x47d204
479801: mov eax,ds:0x4b0fe8
479806: fmul QWORD PTR [eax]
479808: xor eax,eax
47980a: mov al,bl
47980c: imul eax,eax,0x16
47980f: fadd QWORD PTR [esi+eax*8-0x50]
479813: xor eax,eax
479815: mov al,bl
479817: imul eax,eax,0x16
47981a: fstp QWORD PTR [esi+eax*8-0x50]
47981e: fwait
47981f: cmp BYTE PTR [esp],0x10
479823: jne 0x479831
479825: xor eax,eax
479827: mov al,bl
479829: imul eax,eax,0x16
47982c: mov BYTE PTR [esi+eax*8-0x41],0x1
479831: cmp BYTE PTR [esp],0x11
479835: jne 0x479843
479837: xor eax,eax
479839: mov al,bl
47983b: imul eax,eax,0x16
47983e: mov BYTE PTR [esi+eax*8-0x41],0x2
479843: mov BYTE PTR [edi],0x1d
479846: cmp BYTE PTR [esp],0x12
47984a: je 0x479856
47984c: cmp BYTE PTR [esp],0x13
479850: jne 0x47991b
479856: xor eax,eax
479858: mov al,bl
47985a: imul eax,eax,0x16
47985d: cmp BYTE PTR [esi+eax*8-0x45],0x1
479862: je 0x479892
479864: xor eax,eax
479866: mov al,bl
479868: imul eax,eax,0x16
47986b: cmp BYTE PTR [esi+eax*8-0x45],0x2
479870: je 0x479892
479872: xor eax,eax
479874: mov al,bl
479876: imul eax,eax,0x16
479879: cmp BYTE PTR [esi+eax*8-0x45],0x15
47987e: je 0x479892
479880: xor eax,eax
479882: mov al,bl
479884: imul eax,eax,0x16
479887: cmp BYTE PTR [esi+eax*8-0x45],0x16
47988c: jne 0x47991b
479892: xor eax,eax
479894: mov al,bl
479896: imul eax,eax,0x16
479899: mov BYTE PTR [esi+eax*8-0x45],0x1a
47989e: xor eax,eax
4798a0: mov al,bl
4798a2: imul eax,eax,0x16
4798a5: mov WORD PTR [esi+eax*8-0x3c],0x0
4798ac: xor eax,eax
4798ae: mov al,bl
4798b0: imul eax,eax,0x16
4798b3: mov WORD PTR [esi+eax*8-0x3a],0x17
4798ba: xor eax,eax
4798bc: mov al,bl
4798be: imul eax,eax,0x16
4798c1: fld QWORD PTR [esi+eax*8-0x50]
4798c5: fcomp DWORD PTR ds:0x47d1f8
4798cb: fnstsw ax
4798cd: sahf
4798ce: jae 0x4798f4
4798d0: fld DWORD PTR ds:0x47d204
4798d6: mov eax,ds:0x4b0fe8
4798db: fmul QWORD PTR [eax]
4798dd: xor eax,eax
4798df: mov al,bl
4798e1: imul eax,eax,0x16
4798e4: fadd QWORD PTR [esi+eax*8-0x50]
4798e8: xor eax,eax
4798ea: mov al,bl
4798ec: imul eax,eax,0x16
4798ef: fstp QWORD PTR [esi+eax*8-0x50]
4798f3: fwait
4798f4: cmp BYTE PTR [esp],0x12
4798f8: jne 0x479906
4798fa: xor eax,eax
4798fc: mov al,bl
4798fe: imul eax,eax,0x16
479901: mov BYTE PTR [esi+eax*8-0x41],0x1
479906: cmp BYTE PTR [esp],0x13
47990a: jne 0x479918
47990c: xor eax,eax
47990e: mov al,bl
479910: imul eax,eax,0x16
479913: mov BYTE PTR [esi+eax*8-0x41],0x2
479918: mov BYTE PTR [edi],0x1e
47991b: cmp BYTE PTR [esp],0x14
47991f: je 0x47992b
479921: cmp BYTE PTR [esp],0x15
479925: jne 0x479a23
47992b: xor eax,eax
47992d: mov al,bl
47992f: imul eax,eax,0x16
479932: cmp BYTE PTR [esi+eax*8-0x45],0x1
479937: je 0x479967
479939: xor eax,eax
47993b: mov al,bl
47993d: imul eax,eax,0x16
479940: cmp BYTE PTR [esi+eax*8-0x45],0x2
479945: je 0x479967
479947: xor eax,eax
479949: mov al,bl
47994b: imul eax,eax,0x16
47994e: cmp BYTE PTR [esi+eax*8-0x45],0xc
479953: je 0x479967
479955: xor eax,eax
479957: mov al,bl
479959: imul eax,eax,0x16
47995c: cmp BYTE PTR [esi+eax*8-0x45],0x16
479961: jne 0x479a23
479967: mov eax,ds:0x4b11f8
47996c: movsx eax,WORD PTR [eax]
47996f: sub eax,0x5a
479972: mov DWORD PTR [esp+0x4],eax
479976: fild DWORD PTR [esp+0x4]
47997a: xor eax,eax
47997c: mov al,bl
47997e: imul eax,eax,0x16
479981: fcomp QWORD PTR [esi+eax*8-0xa8]
479988: fnstsw ax
47998a: sahf
47998b: ja 0x479a23
479991: xor eax,eax
479993: mov al,bl
479995: imul edx,eax,0x16
479998: mov BYTE PTR [esi+edx*8-0x45],0x1b
47999d: mov eax,ds:0x4b11f8
4799a2: fild WORD PTR [eax]
4799a4: fstp QWORD PTR [esi+edx*8-0xa8]
4799ab: fwait
4799ac: mov BYTE PTR [esi+edx*8-0x38],0x0
4799b1: mov BYTE PTR [esi+edx*8-0x46],0x0
4799b6: mov BYTE PTR [esi+edx*8-0x16],0x0
4799bb: mov WORD PTR [esi+edx*8-0x3c],0x0
4799c2: fld QWORD PTR [esi+edx*8-0x50]
4799c6: fcomp DWORD PTR ds:0x47d1f8
4799cc: fnstsw ax
4799ce: sahf
4799cf: jae 0x4799ee
4799d1: fld DWORD PTR ds:0x47d208
4799d7: mov eax,ds:0x4b0fe8
4799dc: fmul QWORD PTR [eax]
4799de: xor eax,eax
4799e0: mov al,bl
4799e2: imul eax,eax,0x16
4799e5: fadd QWORD PTR [esi+eax*8-0x50]
4799e9: fstp QWORD PTR [esi+edx*8-0x50]
4799ed: fwait
4799ee: cmp BYTE PTR [esp],0x14
4799f2: jne 0x4799f9
4799f4: mov BYTE PTR [esi+edx*8-0x41],0x1
4799f9: cmp BYTE PTR [esp],0x15
4799fd: jne 0x479a04
4799ff: mov BYTE PTR [esi+edx*8-0x41],0x2
479a04: cmp BYTE PTR [esi+edx*8-0x41],0x1
479a09: jne 0x479a12
479a0b: mov WORD PTR [esi+edx*8-0x3a],0x26
479a12: cmp BYTE PTR [esi+edx*8-0x41],0x2
479a17: jne 0x479a20
479a19: mov WORD PTR [esi+edx*8-0x3a],0x28
479a20: mov BYTE PTR [edi],0x1f
479a23: cmp BYTE PTR [esp],0x16
479a27: je 0x479a33
479a29: cmp BYTE PTR [esp],0x17
479a2d: jne 0x479b07
479a33: xor eax,eax
479a35: mov al,bl
479a37: imul eax,eax,0x16
479a3a: mov al,BYTE PTR [esi+eax*8-0x45]
479a3e: cmp al,0x1
479a40: je 0x479a72
479a42: xor edx,edx
479a44: mov dl,bl
479a46: imul edx,edx,0x16
479a49: cmp al,0x2
479a4b: je 0x479a72
479a4d: xor edx,edx
479a4f: mov dl,bl
479a51: imul edx,edx,0x16
479a54: cmp al,0x7
479a56: je 0x479a72
479a58: xor edx,edx
479a5a: mov dl,bl
479a5c: imul edx,edx,0x16
479a5f: cmp al,0x15
479a61: je 0x479a72
479a63: xor edx,edx
479a65: mov dl,bl
479a67: imul edx,edx,0x16
479a6a: cmp al,0x16
479a6c: jne 0x479b07
479a72: xor eax,eax
479a74: mov al,bl
479a76: imul eax,eax,0x16
479a79: mov BYTE PTR [esi+eax*8-0x45],0x1c
479a7e: xor eax,eax
479a80: mov al,bl
479a82: imul eax,eax,0x16
479a85: mov BYTE PTR [esi+eax*8-0x13],0x0
479a8a: xor eax,eax
479a8c: mov al,bl
479a8e: imul eax,eax,0x16
479a91: mov WORD PTR [esi+eax*8-0x3c],0x0
479a98: xor eax,eax
479a9a: mov al,bl
479a9c: imul eax,eax,0x16
479a9f: mov WORD PTR [esi+eax*8-0x3a],0x14
479aa6: xor eax,eax
479aa8: mov al,bl
479aaa: imul eax,eax,0x16
479aad: fld QWORD PTR [esi+eax*8-0x50]
479ab1: fcomp DWORD PTR ds:0x47d1f8
479ab7: fnstsw ax
479ab9: sahf
479aba: jae 0x479ae0
479abc: fld DWORD PTR ds:0x47d204
479ac2: mov eax,ds:0x4b0fe8
479ac7: fmul QWORD PTR [eax]
479ac9: xor eax,eax
479acb: mov al,bl
479acd: imul eax,eax,0x16
479ad0: fadd QWORD PTR [esi+eax*8-0x50]
479ad4: xor eax,eax
479ad6: mov al,bl
479ad8: imul eax,eax,0x16
479adb: fstp QWORD PTR [esi+eax*8-0x50]
479adf: fwait
479ae0: cmp BYTE PTR [esp],0x16
479ae4: jne 0x479af2
479ae6: xor eax,eax
479ae8: mov al,bl
479aea: imul eax,eax,0x16
479aed: mov BYTE PTR [esi+eax*8-0x41],0x1
479af2: cmp BYTE PTR [esp],0x17
479af6: jne 0x479b04
479af8: xor eax,eax
479afa: mov al,bl
479afc: imul eax,eax,0x16
479aff: mov BYTE PTR [esi+eax*8-0x41],0x2
479b04: mov BYTE PTR [edi],0x20
479b07: cmp BYTE PTR [esp],0x18
479b0b: jne 0x479bf7
479b11: xor eax,eax
479b13: mov al,bl
479b15: imul eax,eax,0x16
479b18: mov dl,BYTE PTR [esi+eax*8-0x45]
479b1c: cmp dl,0x1
479b1f: je 0x479b61
479b21: xor eax,eax
479b23: mov al,bl
479b25: imul eax,eax,0x16
479b28: cmp dl,0x2
479b2b: je 0x479b61
479b2d: xor eax,eax
479b2f: mov al,bl
479b31: imul eax,eax,0x16
479b34: cmp dl,0x7
479b37: je 0x479b61
479b39: xor eax,eax
479b3b: mov al,bl
479b3d: imul eax,eax,0x16
479b40: cmp dl,0x15
479b43: je 0x479b61
479b45: xor eax,eax
479b47: mov al,bl
479b49: imul eax,eax,0x16
479b4c: cmp dl,0x16
479b4f: je 0x479b61
479b51: xor eax,eax
479b53: mov al,bl
479b55: imul eax,eax,0x16
479b58: cmp dl,0x1c
479b5b: jne 0x479bf7
479b61: xor eax,eax
479b63: mov al,bl
479b65: imul eax,eax,0x16
479b68: fld QWORD PTR [esi+eax*8-0x70]
479b6c: fcomp DWORD PTR ds:0x47d20c
479b72: fnstsw ax
479b74: sahf
479b75: jbe 0x479b86
479b77: xor eax,eax
479b79: mov al,bl
479b7b: imul eax,eax,0x16
479b7e: cmp WORD PTR [esi+eax*8-0x58],0x0
479b84: jle 0x479bf7
479b86: xor eax,eax
479b88: mov al,bl
479b8a: imul eax,eax,0x16
479b8d: mov BYTE PTR [esi+eax*8-0x45],0x1d
479b92: xor eax,eax
479b94: mov al,bl
479b96: imul eax,eax,0x16
479b99: mov WORD PTR [esi+eax*8-0x3c],0x0
479ba0: xor eax,eax
479ba2: mov al,bl
479ba4: imul eax,eax,0x16
479ba7: mov WORD PTR [esi+eax*8-0x3a],0x1e
479bae: xor eax,eax
479bb0: mov al,bl
479bb2: imul eax,eax,0x16
479bb5: cmp WORD PTR [esi+eax*8-0x58],0x3
479bbb: jne 0x479bce
479bbd: xor eax,eax
479bbf: mov al,bl
479bc1: imul eax,eax,0x16
479bc4: xor edx,edx
479bc6: mov DWORD PTR [esi+eax*8-0x50],edx
479bca: mov DWORD PTR [esi+eax*8-0x4c],edx
479bce: xor eax,eax
479bd0: mov al,bl
479bd2: imul eax,eax,0x16
479bd5: dec WORD PTR [esi+eax*8-0x58]
479bda: xor eax,eax
479bdc: mov al,bl
479bde: imul eax,eax,0x16
479be1: mov dl,BYTE PTR [esp+0x2]
479be5: add dl,0x6
479be8: mov BYTE PTR [esi+eax*8-0x44],dl
479bec: mov eax,ds:0x4b1074
479bf1: mov BYTE PTR [eax],0x16
479bf4: mov BYTE PTR [edi],0x13
479bf7: xor eax,eax
479bf9: mov al,bl
479bfb: imul eax,eax,0x16
479bfe: cmp BYTE PTR [esi+eax*8-0xa0],0x6
479c06: jne 0x47a160
479c0c: cmp BYTE PTR [esp],0xe
479c10: jne 0x479c64
479c12: xor eax,eax
479c14: mov al,bl
479c16: imul eax,eax,0x16
479c19: cmp BYTE PTR [esi+eax*8-0x45],0x1
479c1e: je 0x479c3c
479c20: xor eax,eax
479c22: mov al,bl
479c24: imul eax,eax,0x16
479c27: cmp BYTE PTR [esi+eax*8-0x45],0x2
479c2c: je 0x479c3c
479c2e: xor eax,eax
479c30: mov al,bl
479c32: imul eax,eax,0x16
479c35: cmp BYTE PTR [esi+eax*8-0x45],0x7
479c3a: jne 0x479c64
479c3c: xor eax,eax
479c3e: mov al,bl
479c40: imul eax,eax,0x16
479c43: mov BYTE PTR [esi+eax*8-0x45],0x17
479c48: xor eax,eax
479c4a: mov al,bl
479c4c: imul eax,eax,0x16
479c4f: mov WORD PTR [esi+eax*8-0x3c],0x0
479c56: xor eax,eax
479c58: mov al,bl
479c5a: imul eax,eax,0x16
479c5d: mov WORD PTR [esi+eax*8-0x3a],0xfa
479c64: cmp BYTE PTR [esp],0xf
479c68: jne 0x479cae
479c6a: xor eax,eax
479c6c: mov al,bl
479c6e: imul eax,eax,0x16
479c71: cmp BYTE PTR [esi+eax*8-0x45],0x1
479c76: je 0x479c86
479c78: xor eax,eax
479c7a: mov al,bl
479c7c: imul eax,eax,0x16
479c7f: cmp BYTE PTR [esi+eax*8-0x45],0x2
479c84: jne 0x479cae
479c86: xor eax,eax
479c88: mov al,bl
479c8a: imul eax,eax,0x16
479c8d: mov BYTE PTR [esi+eax*8-0x45],0x18
479c92: xor eax,eax
479c94: mov al,bl
479c96: imul eax,eax,0x16
479c99: mov WORD PTR [esi+eax*8-0x3c],0x0
479ca0: xor eax,eax
479ca2: mov al,bl
479ca4: imul eax,eax,0x16
479ca7: mov WORD PTR [esi+eax*8-0x3a],0x14
479cae: cmp BYTE PTR [esp],0x10
479cb2: je 0x479cbe
479cb4: cmp BYTE PTR [esp],0x11
479cb8: jne 0x479d94
479cbe: xor eax,eax
479cc0: mov al,bl
479cc2: imul eax,eax,0x16
479cc5: cmp BYTE PTR [esi+eax*8-0x45],0x1
479cca: je 0x479cfa
479ccc: xor eax,eax
479cce: mov al,bl
479cd0: imul eax,eax,0x16
479cd3: cmp BYTE PTR [esi+eax*8-0x45],0x2
479cd8: je 0x479cfa
479cda: xor eax,eax
479cdc: mov al,bl
479cde: imul eax,eax,0x16
479ce1: cmp BYTE PTR [esi+eax*8-0x45],0x15
479ce6: je 0x479cfa
479ce8: xor eax,eax
479cea: mov al,bl
479cec: imul eax,eax,0x16
479cef: cmp BYTE PTR [esi+eax*8-0x45],0x16
479cf4: jne 0x479d94
479cfa: mov edx,ebx
479cfc: mov al,0xf
479cfe: call 0x476454
479d03: test al,al
479d05: jne 0x479d94
479d0b: xor eax,eax
479d0d: mov al,bl
479d0f: imul eax,eax,0x16
479d12: mov BYTE PTR [esi+eax*8-0x45],0x19
479d17: xor eax,eax
479d19: mov al,bl
479d1b: imul eax,eax,0x16
479d1e: mov WORD PTR [esi+eax*8-0x3c],0x0
479d25: xor eax,eax
479d27: mov al,bl
479d29: imul eax,eax,0x16
479d2c: mov WORD PTR [esi+eax*8-0x3a],0x1c
479d33: xor eax,eax
479d35: mov al,bl
479d37: imul eax,eax,0x16
479d3a: fld QWORD PTR [esi+eax*8-0x50]
479d3e: fcomp DWORD PTR ds:0x47d1f8
479d44: fnstsw ax
479d46: sahf
479d47: jae 0x479d6d
479d49: fld DWORD PTR ds:0x47d204
479d4f: mov eax,ds:0x4b0fe8
479d54: fmul QWORD PTR [eax]
479d56: xor eax,eax
479d58: mov al,bl
479d5a: imul eax,eax,0x16
479d5d: fadd QWORD PTR [esi+eax*8-0x50]
479d61: xor eax,eax
479d63: mov al,bl
479d65: imul eax,eax,0x16
479d68: fstp QWORD PTR [esi+eax*8-0x50]
479d6c: fwait
479d6d: cmp BYTE PTR [esp],0x10
479d71: jne 0x479d7f
479d73: xor eax,eax
479d75: mov al,bl
479d77: imul eax,eax,0x16
479d7a: mov BYTE PTR [esi+eax*8-0x41],0x1
479d7f: cmp BYTE PTR [esp],0x11
479d83: jne 0x479d91
479d85: xor eax,eax
479d87: mov al,bl
479d89: imul eax,eax,0x16
479d8c: mov BYTE PTR [esi+eax*8-0x41],0x2
479d91: mov BYTE PTR [edi],0x21
479d94: cmp BYTE PTR [esp],0x12
479d98: je 0x479da4
479d9a: cmp BYTE PTR [esp],0x13
479d9e: jne 0x479e7a
479da4: xor eax,eax
479da6: mov al,bl
479da8: imul eax,eax,0x16
479dab: cmp BYTE PTR [esi+eax*8-0x45],0x1
479db0: je 0x479de0
479db2: xor eax,eax
479db4: mov al,bl
479db6: imul eax,eax,0x16
479db9: cmp BYTE PTR [esi+eax*8-0x45],0x2
479dbe: je 0x479de0
479dc0: xor eax,eax
479dc2: mov al,bl
479dc4: imul eax,eax,0x16
479dc7: cmp BYTE PTR [esi+eax*8-0x45],0x15
479dcc: je 0x479de0
479dce: xor eax,eax
479dd0: mov al,bl
479dd2: imul eax,eax,0x16
479dd5: cmp BYTE PTR [esi+eax*8-0x45],0x16
479dda: jne 0x479e7a
479de0: mov edx,ebx
479de2: mov al,0xf
479de4: call 0x476454
479de9: test al,al
479deb: jne 0x479e7a
479df1: xor eax,eax
479df3: mov al,bl
479df5: imul eax,eax,0x16
479df8: mov BYTE PTR [esi+eax*8-0x45],0x1a
479dfd: xor eax,eax
479dff: mov al,bl
479e01: imul eax,eax,0x16
479e04: mov WORD PTR [esi+eax*8-0x3c],0x0
479e0b: xor eax,eax
479e0d: mov al,bl
479e0f: imul eax,eax,0x16
479e12: mov WORD PTR [esi+eax*8-0x3a],0x1c
479e19: xor eax,eax
479e1b: mov al,bl
479e1d: imul eax,eax,0x16
479e20: fld QWORD PTR [esi+eax*8-0x50]
479e24: fcomp DWORD PTR ds:0x47d1f8
479e2a: fnstsw ax
479e2c: sahf
479e2d: jae 0x479e53
479e2f: fld DWORD PTR ds:0x47d204
479e35: mov eax,ds:0x4b0fe8
479e3a: fmul QWORD PTR [eax]
479e3c: xor eax,eax
479e3e: mov al,bl
479e40: imul eax,eax,0x16
479e43: fadd QWORD PTR [esi+eax*8-0x50]
479e47: xor eax,eax
479e49: mov al,bl
479e4b: imul eax,eax,0x16
479e4e: fstp QWORD PTR [esi+eax*8-0x50]
479e52: fwait
479e53: cmp BYTE PTR [esp],0x12
479e57: jne 0x479e65
479e59: xor eax,eax
479e5b: mov al,bl
479e5d: imul eax,eax,0x16
479e60: mov BYTE PTR [esi+eax*8-0x41],0x1
479e65: cmp BYTE PTR [esp],0x13
479e69: jne 0x479e77
479e6b: xor eax,eax
479e6d: mov al,bl
479e6f: imul eax,eax,0x16
479e72: mov BYTE PTR [esi+eax*8-0x41],0x2
479e77: mov BYTE PTR [edi],0x21
479e7a: cmp BYTE PTR [esp],0x14
479e7e: je 0x479e8a
479e80: cmp BYTE PTR [esp],0x15
479e84: jne 0x479f69
479e8a: xor eax,eax
479e8c: mov al,bl
479e8e: imul eax,eax,0x16
479e91: cmp BYTE PTR [esi+eax*8-0x45],0x1
479e96: je 0x479ed4
479e98: xor eax,eax
479e9a: mov al,bl
479e9c: imul eax,eax,0x16
479e9f: cmp BYTE PTR [esi+eax*8-0x45],0x2
479ea4: je 0x479ed4
479ea6: xor eax,eax
479ea8: mov al,bl
479eaa: imul eax,eax,0x16
479ead: cmp BYTE PTR [esi+eax*8-0x45],0x7
479eb2: je 0x479ed4
479eb4: xor eax,eax
479eb6: mov al,bl
479eb8: imul eax,eax,0x16
479ebb: cmp BYTE PTR [esi+eax*8-0x45],0x15
479ec0: je 0x479ed4
479ec2: xor eax,eax
479ec4: mov al,bl
479ec6: imul eax,eax,0x16
479ec9: cmp BYTE PTR [esi+eax*8-0x45],0x16
479ece: jne 0x479f69
479ed4: xor eax,eax
479ed6: mov al,bl
479ed8: imul eax,eax,0x16
479edb: mov BYTE PTR [esi+eax*8-0x45],0x1b
479ee0: xor eax,eax
479ee2: mov al,bl
479ee4: imul eax,eax,0x16
479ee7: mov WORD PTR [esi+eax*8-0x3c],0x0
479eee: xor eax,eax
479ef0: mov al,bl
479ef2: imul eax,eax,0x16
479ef5: mov WORD PTR [esi+eax*8-0x3a],0x19
479efc: xor eax,eax
479efe: mov al,bl
479f00: imul eax,eax,0x16
479f03: mov BYTE PTR [esi+eax*8-0x46],0x0
479f08: xor eax,eax
479f0a: mov al,bl
479f0c: imul eax,eax,0x16
479f0f: fld QWORD PTR [esi+eax*8-0x50]
479f13: fcomp DWORD PTR ds:0x47d1f8
479f19: fnstsw ax
479f1b: sahf
479f1c: jae 0x479f42
479f1e: fld DWORD PTR ds:0x47d204
479f24: mov eax,ds:0x4b0fe8
479f29: fmul QWORD PTR [eax]
479f2b: xor eax,eax
479f2d: mov al,bl
479f2f: imul eax,eax,0x16
479f32: fadd QWORD PTR [esi+eax*8-0x50]
479f36: xor eax,eax
479f38: mov al,bl
479f3a: imul eax,eax,0x16
479f3d: fstp QWORD PTR [esi+eax*8-0x50]
479f41: fwait
479f42: cmp BYTE PTR [esp],0x14
479f46: jne 0x479f54
479f48: xor eax,eax
479f4a: mov al,bl
479f4c: imul eax,eax,0x16
479f4f: mov BYTE PTR [esi+eax*8-0x41],0x1
479f54: cmp BYTE PTR [esp],0x15
479f58: jne 0x479f66
479f5a: xor eax,eax
479f5c: mov al,bl
479f5e: imul eax,eax,0x16
479f61: mov BYTE PTR [esi+eax*8-0x41],0x2
479f66: mov BYTE PTR [edi],0x22
479f69: cmp BYTE PTR [esp],0x16
479f6d: je 0x479f79
479f6f: cmp BYTE PTR [esp],0x17
479f73: jne 0x47a04c
479f79: xor eax,eax
479f7b: mov al,bl
479f7d: imul eax,eax,0x16
479f80: cmp BYTE PTR [esi+eax*8-0x45],0x1
479f85: je 0x479fc3
479f87: xor eax,eax
479f89: mov al,bl
479f8b: imul eax,eax,0x16
479f8e: cmp BYTE PTR [esi+eax*8-0x45],0x2
479f93: je 0x479fc3
479f95: xor eax,eax
479f97: mov al,bl
479f99: imul eax,eax,0x16
479f9c: cmp BYTE PTR [esi+eax*8-0x45],0x7
479fa1: je 0x479fc3
479fa3: xor eax,eax
479fa5: mov al,bl
479fa7: imul eax,eax,0x16
479faa: cmp BYTE PTR [esi+eax*8-0x45],0x15
479faf: je 0x479fc3
479fb1: xor eax,eax
479fb3: mov al,bl
479fb5: imul eax,eax,0x16
479fb8: cmp BYTE PTR [esi+eax*8-0x45],0x16
479fbd: jne 0x47a04c
479fc3: xor eax,eax
479fc5: mov al,bl
479fc7: imul eax,eax,0x16
479fca: mov BYTE PTR [esi+eax*8-0x45],0x1c
479fcf: xor eax,eax
479fd1: mov al,bl
479fd3: imul eax,eax,0x16
479fd6: mov WORD PTR [esi+eax*8-0x3c],0x0
479fdd: xor eax,eax
479fdf: mov al,bl
479fe1: imul eax,eax,0x16
479fe4: mov WORD PTR [esi+eax*8-0x3a],0x1e
479feb: xor eax,eax
479fed: mov al,bl
479fef: imul eax,eax,0x16
479ff2: fld QWORD PTR [esi+eax*8-0x50]
479ff6: fcomp DWORD PTR ds:0x47d1f8
479ffc: fnstsw ax
479ffe: sahf
479fff: jae 0x47a025
47a001: fld DWORD PTR ds:0x47d204
47a007: mov eax,ds:0x4b0fe8
47a00c: fmul QWORD PTR [eax]
47a00e: xor eax,eax
47a010: mov al,bl
47a012: imul eax,eax,0x16
47a015: fadd QWORD PTR [esi+eax*8-0x50]
47a019: xor eax,eax
47a01b: mov al,bl
47a01d: imul eax,eax,0x16
47a020: fstp QWORD PTR [esi+eax*8-0x50]
47a024: fwait
47a025: cmp BYTE PTR [esp],0x16
47a029: jne 0x47a037
47a02b: xor eax,eax
47a02d: mov al,bl
47a02f: imul eax,eax,0x16
47a032: mov BYTE PTR [esi+eax*8-0x41],0x1
47a037: cmp BYTE PTR [esp],0x17
47a03b: jne 0x47a049
47a03d: xor eax,eax
47a03f: mov al,bl
47a041: imul eax,eax,0x16
47a044: mov BYTE PTR [esi+eax*8-0x41],0x2
47a049: mov BYTE PTR [edi],0x23
47a04c: cmp BYTE PTR [esp],0x18
47a050: jne 0x47a160
47a056: xor eax,eax
47a058: mov al,bl
47a05a: imul eax,eax,0x16
47a05d: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a062: je 0x47a0ae
47a064: xor eax,eax
47a066: mov al,bl
47a068: imul eax,eax,0x16
47a06b: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a070: je 0x47a0ae
47a072: xor eax,eax
47a074: mov al,bl
47a076: imul eax,eax,0x16
47a079: cmp BYTE PTR [esi+eax*8-0x45],0x7
47a07e: je 0x47a0ae
47a080: xor eax,eax
47a082: mov al,bl
47a084: imul eax,eax,0x16
47a087: cmp BYTE PTR [esi+eax*8-0x45],0x15
47a08c: je 0x47a0ae
47a08e: xor eax,eax
47a090: mov al,bl
47a092: imul eax,eax,0x16
47a095: cmp BYTE PTR [esi+eax*8-0x45],0x16
47a09a: je 0x47a0ae
47a09c: xor eax,eax
47a09e: mov al,bl
47a0a0: imul eax,eax,0x16
47a0a3: cmp BYTE PTR [esi+eax*8-0x45],0x5
47a0a8: jne 0x47a160
47a0ae: xor eax,eax
47a0b0: mov al,bl
47a0b2: imul eax,eax,0x16
47a0b5: fld QWORD PTR [esi+eax*8-0x70]
47a0b9: fcomp DWORD PTR ds:0x47d20c
47a0bf: fnstsw ax
47a0c1: sahf
47a0c2: jbe 0x47a0d7
47a0c4: xor eax,eax
47a0c6: mov al,bl
47a0c8: imul eax,eax,0x16
47a0cb: cmp WORD PTR [esi+eax*8-0x58],0x0
47a0d1: jle 0x47a160
47a0d7: xor eax,eax
47a0d9: mov al,bl
47a0db: imul eax,eax,0x16
47a0de: mov BYTE PTR [esi+eax*8-0x45],0x1d
47a0e3: xor eax,eax
47a0e5: mov al,bl
47a0e7: imul eax,eax,0x16
47a0ea: mov WORD PTR [esi+eax*8-0x3c],0x0
47a0f1: xor eax,eax
47a0f3: mov al,bl
47a0f5: imul eax,eax,0x16
47a0f8: mov WORD PTR [esi+eax*8-0x3a],0x32
47a0ff: xor eax,eax
47a101: mov al,bl
47a103: imul eax,eax,0x16
47a106: mov BYTE PTR [esi+eax*8-0x38],0xee
47a10b: xor eax,eax
47a10d: mov al,bl
47a10f: imul eax,eax,0x16
47a112: mov BYTE PTR [esi+eax*8-0x46],0x1
47a117: xor eax,eax
47a119: mov al,bl
47a11b: imul eax,eax,0x16
47a11e: cmp WORD PTR [esi+eax*8-0x58],0x3
47a124: jne 0x47a137
47a126: xor eax,eax
47a128: mov al,bl
47a12a: imul eax,eax,0x16
47a12d: xor edx,edx
47a12f: mov DWORD PTR [esi+eax*8-0x50],edx
47a133: mov DWORD PTR [esi+eax*8-0x4c],edx
47a137: xor eax,eax
47a139: mov al,bl
47a13b: imul eax,eax,0x16
47a13e: dec WORD PTR [esi+eax*8-0x58]
47a143: xor eax,eax
47a145: mov al,bl
47a147: imul eax,eax,0x16
47a14a: mov dl,BYTE PTR [esp+0x2]
47a14e: add dl,0x29
47a151: mov BYTE PTR [esi+eax*8-0x44],dl
47a155: mov eax,ds:0x4b1074
47a15a: mov BYTE PTR [eax],0x16
47a15d: mov BYTE PTR [edi],0x13
47a160: xor eax,eax
47a162: mov al,bl
47a164: imul eax,eax,0x16
47a167: cmp BYTE PTR [esi+eax*8-0xa0],0x7
47a16f: jne 0x47a7e3
47a175: cmp BYTE PTR [esp],0xe
47a179: jne 0x47a1cd
47a17b: xor eax,eax
47a17d: mov al,bl
47a17f: imul eax,eax,0x16
47a182: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a187: je 0x47a1a5
47a189: xor eax,eax
47a18b: mov al,bl
47a18d: imul eax,eax,0x16
47a190: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a195: je 0x47a1a5
47a197: xor eax,eax
47a199: mov al,bl
47a19b: imul eax,eax,0x16
47a19e: cmp BYTE PTR [esi+eax*8-0x45],0x7
47a1a3: jne 0x47a1cd
47a1a5: xor eax,eax
47a1a7: mov al,bl
47a1a9: imul eax,eax,0x16
47a1ac: mov BYTE PTR [esi+eax*8-0x45],0x17
47a1b1: xor eax,eax
47a1b3: mov al,bl
47a1b5: imul eax,eax,0x16
47a1b8: mov WORD PTR [esi+eax*8-0x3c],0x0
47a1bf: xor eax,eax
47a1c1: mov al,bl
47a1c3: imul eax,eax,0x16
47a1c6: mov WORD PTR [esi+eax*8-0x3a],0xfa
47a1cd: cmp BYTE PTR [esp],0xf
47a1d1: jne 0x47a217
47a1d3: xor eax,eax
47a1d5: mov al,bl
47a1d7: imul eax,eax,0x16
47a1da: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a1df: je 0x47a1ef
47a1e1: xor eax,eax
47a1e3: mov al,bl
47a1e5: imul eax,eax,0x16
47a1e8: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a1ed: jne 0x47a217
47a1ef: xor eax,eax
47a1f1: mov al,bl
47a1f3: imul eax,eax,0x16
47a1f6: mov BYTE PTR [esi+eax*8-0x45],0x18
47a1fb: xor eax,eax
47a1fd: mov al,bl
47a1ff: imul eax,eax,0x16
47a202: mov WORD PTR [esi+eax*8-0x3c],0x0
47a209: xor eax,eax
47a20b: mov al,bl
47a20d: imul eax,eax,0x16
47a210: mov WORD PTR [esi+eax*8-0x3a],0x14
47a217: cmp BYTE PTR [esp],0x10
47a21b: je 0x47a227
47a21d: cmp BYTE PTR [esp],0x11
47a221: jne 0x47a322
47a227: xor eax,eax
47a229: mov al,bl
47a22b: imul eax,eax,0x16
47a22e: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a233: je 0x47a263
47a235: xor eax,eax
47a237: mov al,bl
47a239: imul eax,eax,0x16
47a23c: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a241: je 0x47a263
47a243: xor eax,eax
47a245: mov al,bl
47a247: imul eax,eax,0x16
47a24a: cmp BYTE PTR [esi+eax*8-0x45],0x15
47a24f: je 0x47a263
47a251: xor eax,eax
47a253: mov al,bl
47a255: imul eax,eax,0x16
47a258: cmp BYTE PTR [esi+eax*8-0x45],0x16
47a25d: jne 0x47a322
47a263: xor eax,eax
47a265: mov al,bl
47a267: imul eax,eax,0x16
47a26a: mov BYTE PTR [esi+eax*8-0x45],0x19
47a26f: xor eax,eax
47a271: mov al,bl
47a273: imul eax,eax,0x16
47a276: mov WORD PTR [esi+eax*8-0x3c],0x0
47a27d: xor eax,eax
47a27f: mov al,bl
47a281: imul eax,eax,0x16
47a284: mov BYTE PTR [esi+eax*8-0x14],0x0
47a289: xor eax,eax
47a28b: mov al,bl
47a28d: imul eax,eax,0x16
47a290: fld QWORD PTR [esi+eax*8-0x50]
47a294: fcomp DWORD PTR ds:0x47d1f8
47a29a: fnstsw ax
47a29c: sahf
47a29d: jae 0x47a2c3
47a29f: fld DWORD PTR ds:0x47d204
47a2a5: mov eax,ds:0x4b0fe8
47a2aa: fmul QWORD PTR [eax]
47a2ac: xor eax,eax
47a2ae: mov al,bl
47a2b0: imul eax,eax,0x16
47a2b3: fadd QWORD PTR [esi+eax*8-0x50]
47a2b7: xor eax,eax
47a2b9: mov al,bl
47a2bb: imul eax,eax,0x16
47a2be: fstp QWORD PTR [esi+eax*8-0x50]
47a2c2: fwait
47a2c3: cmp BYTE PTR [esp],0x10
47a2c7: jne 0x47a2d5
47a2c9: xor eax,eax
47a2cb: mov al,bl
47a2cd: imul eax,eax,0x16
47a2d0: mov BYTE PTR [esi+eax*8-0x41],0x1
47a2d5: cmp BYTE PTR [esp],0x11
47a2d9: jne 0x47a2e7
47a2db: xor eax,eax
47a2dd: mov al,bl
47a2df: imul eax,eax,0x16
47a2e2: mov BYTE PTR [esi+eax*8-0x41],0x2
47a2e7: xor eax,eax
47a2e9: mov al,bl
47a2eb: imul eax,eax,0x16
47a2ee: cmp BYTE PTR [esi+eax*8-0x41],0x1
47a2f3: jne 0x47a303
47a2f5: xor eax,eax
47a2f7: mov al,bl
47a2f9: imul eax,eax,0x16
47a2fc: mov WORD PTR [esi+eax*8-0x3a],0x11
47a303: xor eax,eax
47a305: mov al,bl
47a307: imul eax,eax,0x16
47a30a: cmp BYTE PTR [esi+eax*8-0x41],0x2
47a30f: jne 0x47a31f
47a311: xor eax,eax
47a313: mov al,bl
47a315: imul eax,eax,0x16
47a318: mov WORD PTR [esi+eax*8-0x3a],0x14
47a31f: mov BYTE PTR [edi],0x24
47a322: cmp BYTE PTR [esp],0x12
47a326: je 0x47a332
47a328: cmp BYTE PTR [esp],0x13
47a32c: jne 0x47a411
47a332: xor eax,eax
47a334: mov al,bl
47a336: imul eax,eax,0x16
47a339: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a33e: je 0x47a37c
47a340: xor eax,eax
47a342: mov al,bl
47a344: imul eax,eax,0x16
47a347: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a34c: je 0x47a37c
47a34e: xor eax,eax
47a350: mov al,bl
47a352: imul eax,eax,0x16
47a355: cmp BYTE PTR [esi+eax*8-0x45],0x7
47a35a: je 0x47a37c
47a35c: xor eax,eax
47a35e: mov al,bl
47a360: imul eax,eax,0x16
47a363: cmp BYTE PTR [esi+eax*8-0x45],0x15
47a368: je 0x47a37c
47a36a: xor eax,eax
47a36c: mov al,bl
47a36e: imul eax,eax,0x16
47a371: cmp BYTE PTR [esi+eax*8-0x45],0x16
47a376: jne 0x47a411
47a37c: xor eax,eax
47a37e: mov al,bl
47a380: imul eax,eax,0x16
47a383: mov BYTE PTR [esi+eax*8-0x45],0x1a
47a388: xor eax,eax
47a38a: mov al,bl
47a38c: imul eax,eax,0x16
47a38f: mov WORD PTR [esi+eax*8-0x3c],0x0
47a396: xor eax,eax
47a398: mov al,bl
47a39a: imul eax,eax,0x16
47a39d: mov WORD PTR [esi+eax*8-0x3a],0xf
47a3a4: xor eax,eax
47a3a6: mov al,bl
47a3a8: imul eax,eax,0x16
47a3ab: mov BYTE PTR [esi+eax*8-0x14],0x0
47a3b0: xor eax,eax
47a3b2: mov al,bl
47a3b4: imul eax,eax,0x16
47a3b7: fld QWORD PTR [esi+eax*8-0x50]
47a3bb: fcomp DWORD PTR ds:0x47d1f8
47a3c1: fnstsw ax
47a3c3: sahf
47a3c4: jae 0x47a3ea
47a3c6: fld DWORD PTR ds:0x47d204
47a3cc: mov eax,ds:0x4b0fe8
47a3d1: fmul QWORD PTR [eax]
47a3d3: xor eax,eax
47a3d5: mov al,bl
47a3d7: imul eax,eax,0x16
47a3da: fadd QWORD PTR [esi+eax*8-0x50]
47a3de: xor eax,eax
47a3e0: mov al,bl
47a3e2: imul eax,eax,0x16
47a3e5: fstp QWORD PTR [esi+eax*8-0x50]
47a3e9: fwait
47a3ea: cmp BYTE PTR [esp],0x12
47a3ee: jne 0x47a3fc
47a3f0: xor eax,eax
47a3f2: mov al,bl
47a3f4: imul eax,eax,0x16
47a3f7: mov BYTE PTR [esi+eax*8-0x41],0x1
47a3fc: cmp BYTE PTR [esp],0x13
47a400: jne 0x47a40e
47a402: xor eax,eax
47a404: mov al,bl
47a406: imul eax,eax,0x16
47a409: mov BYTE PTR [esi+eax*8-0x41],0x2
47a40e: mov BYTE PTR [edi],0x25
47a411: cmp BYTE PTR [esp],0x14
47a415: je 0x47a421
47a417: cmp BYTE PTR [esp],0x15
47a41b: jne 0x47a57e
47a421: xor eax,eax
47a423: mov al,bl
47a425: imul eax,eax,0x16
47a428: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a42d: je 0x47a45d
47a42f: xor eax,eax
47a431: mov al,bl
47a433: imul eax,eax,0x16
47a436: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a43b: je 0x47a45d
47a43d: xor eax,eax
47a43f: mov al,bl
47a441: imul eax,eax,0x16
47a444: cmp BYTE PTR [esi+eax*8-0x45],0xc
47a449: je 0x47a45d
47a44b: xor eax,eax
47a44d: mov al,bl
47a44f: imul eax,eax,0x16
47a452: cmp BYTE PTR [esi+eax*8-0x45],0x16
47a457: jne 0x47a57e
47a45d: mov eax,ds:0x4b11f8
47a462: movsx eax,WORD PTR [eax]
47a465: sub eax,0x5a
47a468: mov DWORD PTR [esp+0x4],eax
47a46c: fild DWORD PTR [esp+0x4]
47a470: xor eax,eax
47a472: mov al,bl
47a474: imul eax,eax,0x16
47a477: fcomp QWORD PTR [esi+eax*8-0xa8]
47a47e: fnstsw ax
47a480: sahf
47a481: ja 0x47a57e
47a487: xor eax,eax
47a489: mov al,bl
47a48b: imul eax,eax,0x16
47a48e: mov BYTE PTR [esi+eax*8-0x45],0x1b
47a493: xor eax,eax
47a495: mov al,bl
47a497: imul eax,eax,0x16
47a49a: mov WORD PTR [esi+eax*8-0x3c],0x0
47a4a1: xor eax,eax
47a4a3: mov al,bl
47a4a5: imul eax,eax,0x16
47a4a8: mov WORD PTR [esi+eax*8-0x3a],0xf
47a4af: xor eax,eax
47a4b1: mov al,bl
47a4b3: imul eax,eax,0x16
47a4b6: mov BYTE PTR [esi+eax*8-0x46],0x1
47a4bb: xor eax,eax
47a4bd: mov al,bl
47a4bf: imul eax,eax,0x16
47a4c2: mov BYTE PTR [esi+eax*8-0x42],0x0
47a4c7: xor eax,eax
47a4c9: mov al,bl
47a4cb: imul eax,eax,0x16
47a4ce: mov BYTE PTR [esi+eax*8-0x16],0x0
47a4d3: mov eax,ds:0x4b11f8
47a4d8: fild WORD PTR [eax]
47a4da: xor eax,eax
47a4dc: mov al,bl
47a4de: imul eax,eax,0x16
47a4e1: fstp QWORD PTR [esi+eax*8-0xa8]
47a4e8: fwait
47a4e9: xor eax,eax
47a4eb: mov al,bl
47a4ed: imul eax,eax,0x16
47a4f0: fld QWORD PTR [esi+eax*8-0x50]
47a4f4: fcomp DWORD PTR ds:0x47d1f8
47a4fa: fnstsw ax
47a4fc: sahf
47a4fd: jae 0x47a523
47a4ff: fld DWORD PTR ds:0x47d204
47a505: mov eax,ds:0x4b0fe8
47a50a: fmul QWORD PTR [eax]
47a50c: xor eax,eax
47a50e: mov al,bl
47a510: imul eax,eax,0x16
47a513: fadd QWORD PTR [esi+eax*8-0x50]
47a517: xor eax,eax
47a519: mov al,bl
47a51b: imul eax,eax,0x16
47a51e: fstp QWORD PTR [esi+eax*8-0x50]
47a522: fwait
47a523: cmp BYTE PTR [esp],0x14
47a527: jne 0x47a535
47a529: xor eax,eax
47a52b: mov al,bl
47a52d: imul eax,eax,0x16
47a530: mov BYTE PTR [esi+eax*8-0x41],0x1
47a535: cmp BYTE PTR [esp],0x15
47a539: jne 0x47a547
47a53b: xor eax,eax
47a53d: mov al,bl
47a53f: imul eax,eax,0x16
47a542: mov BYTE PTR [esi+eax*8-0x41],0x2
47a547: xor eax,eax
47a549: mov al,bl
47a54b: imul eax,eax,0x16
47a54e: cmp BYTE PTR [esi+eax*8-0x41],0x1
47a553: jne 0x47a561
47a555: xor eax,eax
47a557: mov al,bl
47a559: imul eax,eax,0x16
47a55c: mov BYTE PTR [esi+eax*8-0x38],0xe5
47a561: xor eax,eax
47a563: mov al,bl
47a565: imul eax,eax,0x16
47a568: cmp BYTE PTR [esi+eax*8-0x41],0x2
47a56d: jne 0x47a57b
47a56f: xor eax,eax
47a571: mov al,bl
47a573: imul eax,eax,0x16
47a576: mov BYTE PTR [esi+eax*8-0x38],0xe0
47a57b: mov BYTE PTR [edi],0x26
47a57e: cmp BYTE PTR [esp],0x16
47a582: je 0x47a58e
47a584: cmp BYTE PTR [esp],0x17
47a588: jne 0x47a6eb
47a58e: xor eax,eax
47a590: mov al,bl
47a592: imul eax,eax,0x16
47a595: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a59a: je 0x47a5ca
47a59c: xor eax,eax
47a59e: mov al,bl
47a5a0: imul eax,eax,0x16
47a5a3: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a5a8: je 0x47a5ca
47a5aa: xor eax,eax
47a5ac: mov al,bl
47a5ae: imul eax,eax,0x16
47a5b1: cmp BYTE PTR [esi+eax*8-0x45],0xc
47a5b6: je 0x47a5ca
47a5b8: xor eax,eax
47a5ba: mov al,bl
47a5bc: imul eax,eax,0x16
47a5bf: cmp BYTE PTR [esi+eax*8-0x45],0x16
47a5c4: jne 0x47a6eb
47a5ca: mov eax,ds:0x4b11f8
47a5cf: movsx eax,WORD PTR [eax]
47a5d2: sub eax,0x5a
47a5d5: mov DWORD PTR [esp+0x4],eax
47a5d9: fild DWORD PTR [esp+0x4]
47a5dd: xor eax,eax
47a5df: mov al,bl
47a5e1: imul eax,eax,0x16
47a5e4: fcomp QWORD PTR [esi+eax*8-0xa8]
47a5eb: fnstsw ax
47a5ed: sahf
47a5ee: ja 0x47a6eb
47a5f4: xor eax,eax
47a5f6: mov al,bl
47a5f8: imul eax,eax,0x16
47a5fb: mov BYTE PTR [esi+eax*8-0x45],0x1c
47a600: xor eax,eax
47a602: mov al,bl
47a604: imul eax,eax,0x16
47a607: mov WORD PTR [esi+eax*8-0x3c],0x0
47a60e: xor eax,eax
47a610: mov al,bl
47a612: imul eax,eax,0x16
47a615: mov WORD PTR [esi+eax*8-0x3a],0xf
47a61c: xor eax,eax
47a61e: mov al,bl
47a620: imul eax,eax,0x16
47a623: mov BYTE PTR [esi+eax*8-0x46],0x1
47a628: xor eax,eax
47a62a: mov al,bl
47a62c: imul eax,eax,0x16
47a62f: mov BYTE PTR [esi+eax*8-0x42],0x0
47a634: xor eax,eax
47a636: mov al,bl
47a638: imul eax,eax,0x16
47a63b: mov BYTE PTR [esi+eax*8-0x16],0x0
47a640: mov eax,ds:0x4b11f8
47a645: fild WORD PTR [eax]
47a647: xor eax,eax
47a649: mov al,bl
47a64b: imul eax,eax,0x16
47a64e: fstp QWORD PTR [esi+eax*8-0xa8]
47a655: fwait
47a656: xor eax,eax
47a658: mov al,bl
47a65a: imul eax,eax,0x16
47a65d: fld QWORD PTR [esi+eax*8-0x50]
47a661: fcomp DWORD PTR ds:0x47d1f8
47a667: fnstsw ax
47a669: sahf
47a66a: jae 0x47a690
47a66c: fld DWORD PTR ds:0x47d204
47a672: mov eax,ds:0x4b0fe8
47a677: fmul QWORD PTR [eax]
47a679: xor eax,eax
47a67b: mov al,bl
47a67d: imul eax,eax,0x16
47a680: fadd QWORD PTR [esi+eax*8-0x50]
47a684: xor eax,eax
47a686: mov al,bl
47a688: imul eax,eax,0x16
47a68b: fstp QWORD PTR [esi+eax*8-0x50]
47a68f: fwait
47a690: cmp BYTE PTR [esp],0x16
47a694: jne 0x47a6a2
47a696: xor eax,eax
47a698: mov al,bl
47a69a: imul eax,eax,0x16
47a69d: mov BYTE PTR [esi+eax*8-0x41],0x1
47a6a2: cmp BYTE PTR [esp],0x17
47a6a6: jne 0x47a6b4
47a6a8: xor eax,eax
47a6aa: mov al,bl
47a6ac: imul eax,eax,0x16
47a6af: mov BYTE PTR [esi+eax*8-0x41],0x2
47a6b4: xor eax,eax
47a6b6: mov al,bl
47a6b8: imul eax,eax,0x16
47a6bb: cmp BYTE PTR [esi+eax*8-0x41],0x1
47a6c0: jne 0x47a6ce
47a6c2: xor eax,eax
47a6c4: mov al,bl
47a6c6: imul eax,eax,0x16
47a6c9: mov BYTE PTR [esi+eax*8-0x38],0xe5
47a6ce: xor eax,eax
47a6d0: mov al,bl
47a6d2: imul eax,eax,0x16
47a6d5: cmp BYTE PTR [esi+eax*8-0x41],0x2
47a6da: jne 0x47a6e8
47a6dc: xor eax,eax
47a6de: mov al,bl
47a6e0: imul eax,eax,0x16
47a6e3: mov BYTE PTR [esi+eax*8-0x38],0xe2
47a6e8: mov BYTE PTR [edi],0x25
47a6eb: cmp BYTE PTR [esp],0x18
47a6ef: jne 0x47a7e3
47a6f5: xor eax,eax
47a6f7: mov al,bl
47a6f9: imul eax,eax,0x16
47a6fc: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a701: je 0x47a74d
47a703: xor eax,eax
47a705: mov al,bl
47a707: imul eax,eax,0x16
47a70a: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a70f: je 0x47a74d
47a711: xor eax,eax
47a713: mov al,bl
47a715: imul eax,eax,0x16
47a718: cmp BYTE PTR [esi+eax*8-0x45],0x5
47a71d: je 0x47a74d
47a71f: xor eax,eax
47a721: mov al,bl
47a723: imul eax,eax,0x16
47a726: cmp BYTE PTR [esi+eax*8-0x45],0x7
47a72b: je 0x47a74d
47a72d: xor eax,eax
47a72f: mov al,bl
47a731: imul eax,eax,0x16
47a734: cmp BYTE PTR [esi+eax*8-0x45],0x15
47a739: je 0x47a74d
47a73b: xor eax,eax
47a73d: mov al,bl
47a73f: imul eax,eax,0x16
47a742: cmp BYTE PTR [esi+eax*8-0x45],0x16
47a747: jne 0x47a7e3
47a74d: xor eax,eax
47a74f: mov al,bl
47a751: imul eax,eax,0x16
47a754: fld QWORD PTR [esi+eax*8-0x70]
47a758: fcomp DWORD PTR ds:0x47d20c
47a75e: fnstsw ax
47a760: sahf
47a761: jbe 0x47a772
47a763: xor eax,eax
47a765: mov al,bl
47a767: imul eax,eax,0x16
47a76a: cmp WORD PTR [esi+eax*8-0x58],0x0
47a770: jle 0x47a7e3
47a772: xor eax,eax
47a774: mov al,bl
47a776: imul eax,eax,0x16
47a779: mov BYTE PTR [esi+eax*8-0x45],0x1d
47a77e: xor eax,eax
47a780: mov al,bl
47a782: imul eax,eax,0x16
47a785: mov WORD PTR [esi+eax*8-0x3c],0x0
47a78c: xor eax,eax
47a78e: mov al,bl
47a790: imul eax,eax,0x16
47a793: mov WORD PTR [esi+eax*8-0x3a],0xc
47a79a: xor eax,eax
47a79c: mov al,bl
47a79e: imul eax,eax,0x16
47a7a1: cmp WORD PTR [esi+eax*8-0x58],0x3
47a7a7: jne 0x47a7ba
47a7a9: xor eax,eax
47a7ab: mov al,bl
47a7ad: imul eax,eax,0x16
47a7b0: xor edx,edx
47a7b2: mov DWORD PTR [esi+eax*8-0x50],edx
47a7b6: mov DWORD PTR [esi+eax*8-0x4c],edx
47a7ba: xor eax,eax
47a7bc: mov al,bl
47a7be: imul eax,eax,0x16
47a7c1: dec WORD PTR [esi+eax*8-0x58]
47a7c6: xor eax,eax
47a7c8: mov al,bl
47a7ca: imul eax,eax,0x16
47a7cd: mov dl,BYTE PTR [esp+0x2]
47a7d1: add dl,0x26
47a7d4: mov BYTE PTR [esi+eax*8-0x44],dl
47a7d8: mov eax,ds:0x4b1074
47a7dd: mov BYTE PTR [eax],0x16
47a7e0: mov BYTE PTR [edi],0x13
47a7e3: xor eax,eax
47a7e5: mov al,bl
47a7e7: imul eax,eax,0x16
47a7ea: cmp BYTE PTR [esi+eax*8-0xa0],0x8
47a7f2: jne 0x47acfa
47a7f8: cmp BYTE PTR [esp],0xe
47a7fc: jne 0x47a850
47a7fe: xor eax,eax
47a800: mov al,bl
47a802: imul eax,eax,0x16
47a805: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a80a: je 0x47a828
47a80c: xor eax,eax
47a80e: mov al,bl
47a810: imul eax,eax,0x16
47a813: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a818: je 0x47a828
47a81a: xor eax,eax
47a81c: mov al,bl
47a81e: imul eax,eax,0x16
47a821: cmp BYTE PTR [esi+eax*8-0x45],0x7
47a826: jne 0x47a850
47a828: xor eax,eax
47a82a: mov al,bl
47a82c: imul eax,eax,0x16
47a82f: mov BYTE PTR [esi+eax*8-0x45],0x17
47a834: xor eax,eax
47a836: mov al,bl
47a838: imul eax,eax,0x16
47a83b: mov WORD PTR [esi+eax*8-0x3c],0x0
47a842: xor eax,eax
47a844: mov al,bl
47a846: imul eax,eax,0x16
47a849: mov WORD PTR [esi+eax*8-0x3a],0xfa
47a850: cmp BYTE PTR [esp],0xf
47a854: jne 0x47a89a
47a856: xor eax,eax
47a858: mov al,bl
47a85a: imul eax,eax,0x16
47a85d: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a862: je 0x47a872
47a864: xor eax,eax
47a866: mov al,bl
47a868: imul eax,eax,0x16
47a86b: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a870: jne 0x47a89a
47a872: xor eax,eax
47a874: mov al,bl
47a876: imul eax,eax,0x16
47a879: mov BYTE PTR [esi+eax*8-0x45],0x18
47a87e: xor eax,eax
47a880: mov al,bl
47a882: imul eax,eax,0x16
47a885: mov WORD PTR [esi+eax*8-0x3c],0x0
47a88c: xor eax,eax
47a88e: mov al,bl
47a890: imul eax,eax,0x16
47a893: mov WORD PTR [esi+eax*8-0x3a],0x14
47a89a: cmp BYTE PTR [esp],0x10
47a89e: je 0x47a8aa
47a8a0: cmp BYTE PTR [esp],0x11
47a8a4: jne 0x47a980
47a8aa: xor eax,eax
47a8ac: mov al,bl
47a8ae: imul eax,eax,0x16
47a8b1: cmp BYTE PTR [esi+eax*8-0x45],0x1
47a8b6: je 0x47a8e6
47a8b8: xor eax,eax
47a8ba: mov al,bl
47a8bc: imul eax,eax,0x16
47a8bf: cmp BYTE PTR [esi+eax*8-0x45],0x2
47a8c4: je 0x47a8e6
47a8c6: xor eax,eax
47a8c8: mov al,bl
47a8ca: imul eax,eax,0x16
47a8cd: cmp BYTE PTR [esi+eax*8-0x45],0x15
47a8d2: je 0x47a8e6
47a8d4: xor eax,eax
47a8d6: mov al,bl
47a8d8: imul eax,eax,0x16
47a8db: cmp BYTE PTR [esi+eax*8-0x45],0x16
47a8e0: jne 0x47a980
47a8e6: mov edx,ebx
47a8e8: mov al,0x12
47a8ea: call 0x476454
47a8ef: test al,al
47a8f1: jne 0x47a980
47a8f7: xor eax,eax
47a8f9: mov al,bl
47a8fb: imul eax,eax,0x16
47a8fe: mov BYTE PTR [esi+eax*8-0x45],0x19
47a903: xor eax,eax
47a905: mov al,bl
47a907: imul eax,eax,0x16
47a90a: mov WORD PTR [esi+eax*8-0x3c],0x0
47a911: xor eax,eax
47a913: mov al,bl
47a915: imul eax,eax,0x16
47a918: mov WORD PTR [esi+eax*8-0x3a],0x1c
47a91f: xor eax,eax
47a921: mov al,bl
47a923: imul eax,eax,0x16
47a926: fld QWORD PTR [esi+eax*8-0x50]
47a92a: fcomp DWORD PTR ds:0x47d1f8
47a930: fnstsw ax
47a932: sahf
47a933: jae 0x47a959
47a935: fld DWORD PTR ds:0x47d204
47a93b: mov eax,ds:0x4b0fe8
47a940: fmul QWORD PTR [eax]
47a942: xor eax,eax
47a944: mov al,bl
47a946: imul eax,eax,0x16
47a949: fadd QWORD PTR [esi+eax*8-0x50]
47a94d: xor eax,eax
47a94f: mov al,bl
47a951: imul eax,eax,0x16
47a954: fstp QWORD PTR [esi+eax*8-0x50]
47a958: fwait
47a959: cmp BYTE PTR [esp],0x10
47a95d: jne 0x47a96b
47a95f: xor eax,eax
47a961: mov al,bl
47a963: imul eax,eax,0x16
47a966: mov BYTE PTR [esi+eax*8-0x41],0x1
47a96b: cmp BYTE PTR [esp],0x11
47a96f: jne 0x47a97d
47a971: xor eax,eax
47a973: mov al,bl
47a975: imul eax,eax,0x16
47a978: mov BYTE PTR [esi+eax*8-0x41],0x2
47a97d: mov BYTE PTR [edi],0x27
47a980: cmp BYTE PTR [esp],0x12
47a984: je 0x47a990
47a986: cmp BYTE PTR [esp],0x13
47a98a: jne 0x47aa3c
47a990: xor eax,eax
47a992: mov al,bl
47a994: imul eax,eax,0x16
47a997: cmp BYTE PTR [esi+eax*8-0x45],0xc
47a99c: jne 0x47aa3c
47a9a2: mov edx,ebx
47a9a4: mov al,0x13
47a9a6: call 0x476454
47a9ab: test al,al
47a9ad: jne 0x47aa3c
47a9b3: xor eax,eax
47a9b5: mov al,bl
47a9b7: imul eax,eax,0x16
47a9ba: mov BYTE PTR [esi+eax*8-0x45],0x1a
47a9bf: xor eax,eax
47a9c1: mov al,bl
47a9c3: imul eax,eax,0x16
47a9c6: mov WORD PTR [esi+eax*8-0x3c],0x0
47a9cd: xor eax,eax
47a9cf: mov al,bl
47a9d1: imul eax,eax,0x16
47a9d4: mov WORD PTR [esi+eax*8-0x3a],0xf
47a9db: xor eax,eax
47a9dd: mov al,bl
47a9df: imul eax,eax,0x16
47a9e2: fld QWORD PTR [esi+eax*8-0x50]
47a9e6: fcomp DWORD PTR ds:0x47d1f8
47a9ec: fnstsw ax
47a9ee: sahf
47a9ef: jae 0x47aa15
47a9f1: fld DWORD PTR ds:0x47d204
47a9f7: mov eax,ds:0x4b0fe8
47a9fc: fmul QWORD PTR [eax]
47a9fe: xor eax,eax
47aa00: mov al,bl
47aa02: imul eax,eax,0x16
47aa05: fadd QWORD PTR [esi+eax*8-0x50]
47aa09: xor eax,eax
47aa0b: mov al,bl
47aa0d: imul eax,eax,0x16
47aa10: fstp QWORD PTR [esi+eax*8-0x50]
47aa14: fwait
47aa15: cmp BYTE PTR [esp],0x12
47aa19: jne 0x47aa27
47aa1b: xor eax,eax
47aa1d: mov al,bl
47aa1f: imul eax,eax,0x16
47aa22: mov BYTE PTR [esi+eax*8-0x41],0x1
47aa27: cmp BYTE PTR [esp],0x13
47aa2b: jne 0x47aa39
47aa2d: xor eax,eax
47aa2f: mov al,bl
47aa31: imul eax,eax,0x16
47aa34: mov BYTE PTR [esi+eax*8-0x41],0x2
47aa39: mov BYTE PTR [edi],0x27
47aa3c: cmp BYTE PTR [esp],0x14
47aa40: je 0x47aa4c
47aa42: cmp BYTE PTR [esp],0x15
47aa46: jne 0x47ab1f
47aa4c: xor eax,eax
47aa4e: mov al,bl
47aa50: imul eax,eax,0x16
47aa53: cmp BYTE PTR [esi+eax*8-0x45],0x1
47aa58: je 0x47aa96
47aa5a: xor eax,eax
47aa5c: mov al,bl
47aa5e: imul eax,eax,0x16
47aa61: cmp BYTE PTR [esi+eax*8-0x45],0x2
47aa66: je 0x47aa96
47aa68: xor eax,eax
47aa6a: mov al,bl
47aa6c: imul eax,eax,0x16
47aa6f: cmp BYTE PTR [esi+eax*8-0x45],0x7
47aa74: je 0x47aa96
47aa76: xor eax,eax
47aa78: mov al,bl
47aa7a: imul eax,eax,0x16
47aa7d: cmp BYTE PTR [esi+eax*8-0x45],0x15
47aa82: je 0x47aa96
47aa84: xor eax,eax
47aa86: mov al,bl
47aa88: imul eax,eax,0x16
47aa8b: cmp BYTE PTR [esi+eax*8-0x45],0x16
47aa90: jne 0x47ab1f
47aa96: xor eax,eax
47aa98: mov al,bl
47aa9a: imul eax,eax,0x16
47aa9d: mov BYTE PTR [esi+eax*8-0x45],0x1b
47aaa2: xor eax,eax
47aaa4: mov al,bl
47aaa6: imul eax,eax,0x16
47aaa9: mov WORD PTR [esi+eax*8-0x3c],0x0
47aab0: xor eax,eax
47aab2: mov al,bl
47aab4: imul eax,eax,0x16
47aab7: mov WORD PTR [esi+eax*8-0x3a],0x14
47aabe: xor eax,eax
47aac0: mov al,bl
47aac2: imul eax,eax,0x16
47aac5: fld QWORD PTR [esi+eax*8-0x50]
47aac9: fcomp DWORD PTR ds:0x47d1f8
47aacf: fnstsw ax
47aad1: sahf
47aad2: jae 0x47aaf8
47aad4: fld DWORD PTR ds:0x47d204
47aada: mov eax,ds:0x4b0fe8
47aadf: fmul QWORD PTR [eax]
47aae1: xor eax,eax
47aae3: mov al,bl
47aae5: imul eax,eax,0x16
47aae8: fadd QWORD PTR [esi+eax*8-0x50]
47aaec: xor eax,eax
47aaee: mov al,bl
47aaf0: imul eax,eax,0x16
47aaf3: fstp QWORD PTR [esi+eax*8-0x50]
47aaf7: fwait
47aaf8: cmp BYTE PTR [esp],0x14
47aafc: jne 0x47ab0a
47aafe: xor eax,eax
47ab00: mov al,bl
47ab02: imul eax,eax,0x16
47ab05: mov BYTE PTR [esi+eax*8-0x41],0x1
47ab0a: cmp BYTE PTR [esp],0x15
47ab0e: jne 0x47ab1c
47ab10: xor eax,eax
47ab12: mov al,bl
47ab14: imul eax,eax,0x16
47ab17: mov BYTE PTR [esi+eax*8-0x41],0x2
47ab1c: mov BYTE PTR [edi],0x28
47ab1f: cmp BYTE PTR [esp],0x16
47ab23: je 0x47ab2f
47ab25: cmp BYTE PTR [esp],0x17
47ab29: jne 0x47ac10
47ab2f: xor eax,eax
47ab31: mov al,bl
47ab33: imul eax,eax,0x16
47ab36: cmp BYTE PTR [esi+eax*8-0x45],0x1
47ab3b: je 0x47ab87
47ab3d: xor eax,eax
47ab3f: mov al,bl
47ab41: imul eax,eax,0x16
47ab44: cmp BYTE PTR [esi+eax*8-0x45],0x2
47ab49: je 0x47ab87
47ab4b: xor eax,eax
47ab4d: mov al,bl
47ab4f: imul eax,eax,0x16
47ab52: cmp BYTE PTR [esi+eax*8-0x45],0x7
47ab57: je 0x47ab87
47ab59: xor eax,eax
47ab5b: mov al,bl
47ab5d: imul eax,eax,0x16
47ab60: cmp BYTE PTR [esi+eax*8-0x45],0xc
47ab65: je 0x47ab87
47ab67: xor eax,eax
47ab69: mov al,bl
47ab6b: imul eax,eax,0x16
47ab6e: cmp BYTE PTR [esi+eax*8-0x45],0x15
47ab73: je 0x47ab87
47ab75: xor eax,eax
47ab77: mov al,bl
47ab79: imul eax,eax,0x16
47ab7c: cmp BYTE PTR [esi+eax*8-0x45],0x16
47ab81: jne 0x47ac10
47ab87: xor eax,eax
47ab89: mov al,bl
47ab8b: imul eax,eax,0x16
47ab8e: mov BYTE PTR [esi+eax*8-0x45],0x1c
47ab93: xor eax,eax
47ab95: mov al,bl
47ab97: imul eax,eax,0x16
47ab9a: mov WORD PTR [esi+eax*8-0x3c],0x0
47aba1: xor eax,eax
47aba3: mov al,bl
47aba5: imul eax,eax,0x16
47aba8: mov WORD PTR [esi+eax*8-0x3a],0x19
47abaf: xor eax,eax
47abb1: mov al,bl
47abb3: imul eax,eax,0x16
47abb6: fld QWORD PTR [esi+eax*8-0x50]
47abba: fcomp DWORD PTR ds:0x47d1f8
47abc0: fnstsw ax
47abc2: sahf
47abc3: jae 0x47abe9
47abc5: fld DWORD PTR ds:0x47d204
47abcb: mov eax,ds:0x4b0fe8
47abd0: fmul QWORD PTR [eax]
47abd2: xor eax,eax
47abd4: mov al,bl
47abd6: imul eax,eax,0x16
47abd9: fadd QWORD PTR [esi+eax*8-0x50]
47abdd: xor eax,eax
47abdf: mov al,bl
47abe1: imul eax,eax,0x16
47abe4: fstp QWORD PTR [esi+eax*8-0x50]
47abe8: fwait
47abe9: cmp BYTE PTR [esp],0x16
47abed: jne 0x47abfb
47abef: xor eax,eax
47abf1: mov al,bl
47abf3: imul eax,eax,0x16
47abf6: mov BYTE PTR [esi+eax*8-0x41],0x1
47abfb: cmp BYTE PTR [esp],0x17
47abff: jne 0x47ac0d
47ac01: xor eax,eax
47ac03: mov al,bl
47ac05: imul eax,eax,0x16
47ac08: mov BYTE PTR [esi+eax*8-0x41],0x2
47ac0d: mov BYTE PTR [edi],0x29
47ac10: cmp BYTE PTR [esp],0x18
47ac14: jne 0x47acfa
47ac1a: xor eax,eax
47ac1c: mov al,bl
47ac1e: imul eax,eax,0x16
47ac21: cmp BYTE PTR [esi+eax*8-0x45],0x1
47ac26: je 0x47ac64
47ac28: xor eax,eax
47ac2a: mov al,bl
47ac2c: imul eax,eax,0x16
47ac2f: cmp BYTE PTR [esi+eax*8-0x45],0x2
47ac34: je 0x47ac64
47ac36: xor eax,eax
47ac38: mov al,bl
47ac3a: imul eax,eax,0x16
47ac3d: cmp BYTE PTR [esi+eax*8-0x45],0x7
47ac42: je 0x47ac64
47ac44: xor eax,eax
47ac46: mov al,bl
47ac48: imul eax,eax,0x16
47ac4b: cmp BYTE PTR [esi+eax*8-0x45],0x15
47ac50: je 0x47ac64
47ac52: xor eax,eax
47ac54: mov al,bl
47ac56: imul eax,eax,0x16
47ac59: cmp BYTE PTR [esi+eax*8-0x45],0x16
47ac5e: jne 0x47acfa
47ac64: xor eax,eax
47ac66: mov al,bl
47ac68: imul eax,eax,0x16
47ac6b: fld QWORD PTR [esi+eax*8-0x70]
47ac6f: fcomp DWORD PTR ds:0x47d20c
47ac75: fnstsw ax
47ac77: sahf
47ac78: jbe 0x47ac89
47ac7a: xor eax,eax
47ac7c: mov al,bl
47ac7e: imul eax,eax,0x16
47ac81: cmp WORD PTR [esi+eax*8-0x58],0x0
47ac87: jle 0x47acfa
47ac89: xor eax,eax
47ac8b: mov al,bl
47ac8d: imul eax,eax,0x16
47ac90: mov BYTE PTR [esi+eax*8-0x45],0x1d
47ac95: xor eax,eax
47ac97: mov al,bl
47ac99: imul eax,eax,0x16
47ac9c: mov WORD PTR [esi+eax*8-0x3c],0x0
47aca3: xor eax,eax
47aca5: mov al,bl
47aca7: imul eax,eax,0x16
47acaa: mov WORD PTR [esi+eax*8-0x3a],0x14
47acb1: xor eax,eax
47acb3: mov al,bl
47acb5: imul eax,eax,0x16
47acb8: cmp WORD PTR [esi+eax*8-0x58],0x3
47acbe: jne 0x47acd1
47acc0: xor eax,eax
47acc2: mov al,bl
47acc4: imul eax,eax,0x16
47acc7: xor edx,edx
47acc9: mov DWORD PTR [esi+eax*8-0x50],edx
47accd: mov DWORD PTR [esi+eax*8-0x4c],edx
47acd1: xor eax,eax
47acd3: mov al,bl
47acd5: imul eax,eax,0x16
47acd8: dec WORD PTR [esi+eax*8-0x58]
47acdd: xor eax,eax
47acdf: mov al,bl
47ace1: imul eax,eax,0x16
47ace4: mov dl,BYTE PTR [esp+0x2]
47ace8: add dl,0x21
47aceb: mov BYTE PTR [esi+eax*8-0x44],dl
47acef: mov eax,ds:0x4b1074
47acf4: mov BYTE PTR [eax],0x16
47acf7: mov BYTE PTR [edi],0x13
47acfa: xor eax,eax
47acfc: mov al,bl
47acfe: imul eax,eax,0x16
47ad01: cmp BYTE PTR [esi+eax*8-0xa0],0x9
47ad09: jne 0x47b275
47ad0f: cmp BYTE PTR [esp],0xe
47ad13: jne 0x47ad67
47ad15: xor eax,eax
47ad17: mov al,bl
47ad19: imul eax,eax,0x16
47ad1c: cmp BYTE PTR [esi+eax*8-0x45],0x1
47ad21: je 0x47ad3f
47ad23: xor eax,eax
47ad25: mov al,bl
47ad27: imul eax,eax,0x16
47ad2a: cmp BYTE PTR [esi+eax*8-0x45],0x2
47ad2f: je 0x47ad3f
47ad31: xor eax,eax
47ad33: mov al,bl
47ad35: imul eax,eax,0x16
47ad38: cmp BYTE PTR [esi+eax*8-0x45],0x7
47ad3d: jne 0x47ad67
47ad3f: xor eax,eax
47ad41: mov al,bl
47ad43: imul eax,eax,0x16
47ad46: mov BYTE PTR [esi+eax*8-0x45],0x17
47ad4b: xor eax,eax
47ad4d: mov al,bl
47ad4f: imul eax,eax,0x16
47ad52: mov WORD PTR [esi+eax*8-0x3c],0x0
47ad59: xor eax,eax
47ad5b: mov al,bl
47ad5d: imul eax,eax,0x16
47ad60: mov WORD PTR [esi+eax*8-0x3a],0xfa
47ad67: cmp BYTE PTR [esp],0xf
47ad6b: jne 0x47adb1
47ad6d: xor eax,eax
47ad6f: mov al,bl
47ad71: imul eax,eax,0x16
47ad74: cmp BYTE PTR [esi+eax*8-0x45],0x1
47ad79: je 0x47ad89
47ad7b: xor eax,eax
47ad7d: mov al,bl
47ad7f: imul eax,eax,0x16
47ad82: cmp BYTE PTR [esi+eax*8-0x45],0x2
47ad87: jne 0x47adb1
47ad89: xor eax,eax
47ad8b: mov al,bl
47ad8d: imul eax,eax,0x16
47ad90: mov BYTE PTR [esi+eax*8-0x45],0x18
47ad95: xor eax,eax
47ad97: mov al,bl
47ad99: imul eax,eax,0x16
47ad9c: mov WORD PTR [esi+eax*8-0x3c],0x0
47ada3: xor eax,eax
47ada5: mov al,bl
47ada7: imul eax,eax,0x16
47adaa: mov WORD PTR [esi+eax*8-0x3a],0x14
47adb1: cmp BYTE PTR [esp],0x10
47adb5: je 0x47adc1
47adb7: cmp BYTE PTR [esp],0x11
47adbb: jne 0x47aeb0
47adc1: xor eax,eax
47adc3: mov al,bl
47adc5: imul eax,eax,0x16
47adc8: cmp BYTE PTR [esi+eax*8-0x45],0x1
47adcd: je 0x47adfd
47adcf: xor eax,eax
47add1: mov al,bl
47add3: imul eax,eax,0x16
47add6: cmp BYTE PTR [esi+eax*8-0x45],0x2
47addb: je 0x47adfd
47addd: xor eax,eax
47addf: mov al,bl
47ade1: imul eax,eax,0x16
47ade4: cmp BYTE PTR [esi+eax*8-0x45],0x15
47ade9: je 0x47adfd
47adeb: xor eax,eax
47aded: mov al,bl
47adef: imul eax,eax,0x16
47adf2: cmp BYTE PTR [esi+eax*8-0x45],0x16
47adf7: jne 0x47aeb0
47adfd: xor eax,eax
47adff: mov al,bl
47ae01: imul eax,eax,0x16
47ae04: mov BYTE PTR [esi+eax*8-0x45],0x19
47ae09: xor eax,eax
47ae0b: mov al,bl
47ae0d: imul eax,eax,0x16
47ae10: mov WORD PTR [esi+eax*8-0x3c],0x0
47ae17: xor eax,eax
47ae19: mov al,bl
47ae1b: imul eax,eax,0x16
47ae1e: fld QWORD PTR [esi+eax*8-0x50]
47ae22: fcomp DWORD PTR ds:0x47d1f8
47ae28: fnstsw ax
47ae2a: sahf
47ae2b: jae 0x47ae51
47ae2d: fld DWORD PTR ds:0x47d204
47ae33: mov eax,ds:0x4b0fe8
47ae38: fmul QWORD PTR [eax]
47ae3a: xor eax,eax
47ae3c: mov al,bl
47ae3e: imul eax,eax,0x16
47ae41: fadd QWORD PTR [esi+eax*8-0x50]
47ae45: xor eax,eax
47ae47: mov al,bl
47ae49: imul eax,eax,0x16
47ae4c: fstp QWORD PTR [esi+eax*8-0x50]
47ae50: fwait
47ae51: cmp BYTE PTR [esp],0x10
47ae55: jne 0x47ae63
47ae57: xor eax,eax
47ae59: mov al,bl
47ae5b: imul eax,eax,0x16
47ae5e: mov BYTE PTR [esi+eax*8-0x41],0x1
47ae63: cmp BYTE PTR [esp],0x11
47ae67: jne 0x47ae75
47ae69: xor eax,eax
47ae6b: mov al,bl
47ae6d: imul eax,eax,0x16
47ae70: mov BYTE PTR [esi+eax*8-0x41],0x2
47ae75: xor eax,eax
47ae77: mov al,bl
47ae79: imul eax,eax,0x16
47ae7c: cmp BYTE PTR [esi+eax*8-0x41],0x1
47ae81: jne 0x47ae91
47ae83: xor eax,eax
47ae85: mov al,bl
47ae87: imul eax,eax,0x16
47ae8a: mov WORD PTR [esi+eax*8-0x3a],0xe
47ae91: xor eax,eax
47ae93: mov al,bl
47ae95: imul eax,eax,0x16
47ae98: cmp BYTE PTR [esi+eax*8-0x41],0x2
47ae9d: jne 0x47aead
47ae9f: xor eax,eax
47aea1: mov al,bl
47aea3: imul eax,eax,0x16
47aea6: mov WORD PTR [esi+eax*8-0x3a],0x17
47aead: mov BYTE PTR [edi],0x2b
47aeb0: cmp BYTE PTR [esp],0x12
47aeb4: je 0x47aec0
47aeb6: cmp BYTE PTR [esp],0x13
47aeba: jne 0x47af85
47aec0: xor eax,eax
47aec2: mov al,bl
47aec4: imul eax,eax,0x16
47aec7: cmp BYTE PTR [esi+eax*8-0x45],0x1
47aecc: je 0x47aefc
47aece: xor eax,eax
47aed0: mov al,bl
47aed2: imul eax,eax,0x16
47aed5: cmp BYTE PTR [esi+eax*8-0x45],0x2
47aeda: je 0x47aefc
47aedc: xor eax,eax
47aede: mov al,bl
47aee0: imul eax,eax,0x16
47aee3: cmp BYTE PTR [esi+eax*8-0x45],0x15
47aee8: je 0x47aefc
47aeea: xor eax,eax
47aeec: mov al,bl
47aeee: imul eax,eax,0x16
47aef1: cmp BYTE PTR [esi+eax*8-0x45],0x16
47aef6: jne 0x47af85
47aefc: xor eax,eax
47aefe: mov al,bl
47af00: imul eax,eax,0x16
47af03: mov BYTE PTR [esi+eax*8-0x45],0x1a
47af08: xor eax,eax
47af0a: mov al,bl
47af0c: imul eax,eax,0x16
47af0f: mov WORD PTR [esi+eax*8-0x3c],0x0
47af16: xor eax,eax
47af18: mov al,bl
47af1a: imul eax,eax,0x16
47af1d: mov WORD PTR [esi+eax*8-0x3a],0x14
47af24: xor eax,eax
47af26: mov al,bl
47af28: imul eax,eax,0x16
47af2b: fld QWORD PTR [esi+eax*8-0x50]
47af2f: fcomp DWORD PTR ds:0x47d1f8
47af35: fnstsw ax
47af37: sahf
47af38: jae 0x47af5e
47af3a: fld DWORD PTR ds:0x47d204
47af40: mov eax,ds:0x4b0fe8
47af45: fmul QWORD PTR [eax]
47af47: xor eax,eax
47af49: mov al,bl
47af4b: imul eax,eax,0x16
47af4e: fadd QWORD PTR [esi+eax*8-0x50]
47af52: xor eax,eax
47af54: mov al,bl
47af56: imul eax,eax,0x16
47af59: fstp QWORD PTR [esi+eax*8-0x50]
47af5d: fwait
47af5e: cmp BYTE PTR [esp],0x12
47af62: jne 0x47af70
47af64: xor eax,eax
47af66: mov al,bl
47af68: imul eax,eax,0x16
47af6b: mov BYTE PTR [esi+eax*8-0x41],0x1
47af70: cmp BYTE PTR [esp],0x13
47af74: jne 0x47af82
47af76: xor eax,eax
47af78: mov al,bl
47af7a: imul eax,eax,0x16
47af7d: mov BYTE PTR [esi+eax*8-0x41],0x2
47af82: mov BYTE PTR [edi],0x2c
47af85: cmp BYTE PTR [esp],0x14
47af89: je 0x47af95
47af8b: cmp BYTE PTR [esp],0x15
47af8f: jne 0x47b0c6
47af95: xor eax,eax
47af97: mov al,bl
47af99: imul eax,eax,0x16
47af9c: cmp BYTE PTR [esi+eax*8-0x45],0x1
47afa1: je 0x47afd1
47afa3: xor eax,eax
47afa5: mov al,bl
47afa7: imul eax,eax,0x16
47afaa: cmp BYTE PTR [esi+eax*8-0x45],0x2
47afaf: je 0x47afd1
47afb1: xor eax,eax
47afb3: mov al,bl
47afb5: imul eax,eax,0x16
47afb8: cmp BYTE PTR [esi+eax*8-0x45],0x15
47afbd: je 0x47afd1
47afbf: xor eax,eax
47afc1: mov al,bl
47afc3: imul eax,eax,0x16
47afc6: cmp BYTE PTR [esi+eax*8-0x45],0x16
47afcb: jne 0x47b0c6
47afd1: xor eax,eax
47afd3: mov al,bl
47afd5: imul eax,eax,0x16
47afd8: mov BYTE PTR [esi+eax*8-0x45],0x1b
47afdd: xor eax,eax
47afdf: mov al,bl
47afe1: imul eax,eax,0x16
47afe4: mov WORD PTR [esi+eax*8-0x3c],0x0
47afeb: xor eax,eax
47afed: mov al,bl
47afef: imul eax,eax,0x16
47aff2: mov WORD PTR [esi+eax*8-0x3a],0xf
47aff9: xor eax,eax
47affb: mov al,bl
47affd: imul eax,eax,0x16
47b000: fld QWORD PTR [esi+eax*8-0x50]
47b004: fcomp DWORD PTR ds:0x47d1f8
47b00a: fnstsw ax
47b00c: sahf
47b00d: jae 0x47b033
47b00f: fld DWORD PTR ds:0x47d204
47b015: mov eax,ds:0x4b0fe8
47b01a: fmul QWORD PTR [eax]
47b01c: xor eax,eax
47b01e: mov al,bl
47b020: imul eax,eax,0x16
47b023: fadd QWORD PTR [esi+eax*8-0x50]
47b027: xor eax,eax
47b029: mov al,bl
47b02b: imul eax,eax,0x16
47b02e: fstp QWORD PTR [esi+eax*8-0x50]
47b032: fwait
47b033: cmp BYTE PTR [esp],0x14
47b037: jne 0x47b045
47b039: xor eax,eax
47b03b: mov al,bl
47b03d: imul eax,eax,0x16
47b040: mov BYTE PTR [esi+eax*8-0x41],0x1
47b045: cmp BYTE PTR [esp],0x15
47b049: jne 0x47b057
47b04b: xor eax,eax
47b04d: mov al,bl
47b04f: imul eax,eax,0x16
47b052: mov BYTE PTR [esi+eax*8-0x41],0x2
47b057: mov BYTE PTR [edi],0x2d
47b05a: mov BYTE PTR [esp+0x1],0x5
47b05f: mov eax,0x28
47b064: call 0x402a1c
47b069: mov DWORD PTR [esp+0x4],eax
47b06d: fild DWORD PTR [esp+0x4]
47b071: xor eax,eax
47b073: mov al,bl
47b075: imul eax,eax,0x16
47b078: fld QWORD PTR [esi+eax*8-0xb0]
47b07f: fsub DWORD PTR ds:0x47d214
47b085: faddp st(1),st
47b087: add esp,0xfffffff8
47b08a: fstp QWORD PTR [esp]
47b08d: fwait
47b08e: mov eax,0xa
47b093: call 0x402a1c
47b098: mov DWORD PTR [esp+0x10],eax
47b09c: fild DWORD PTR [esp+0x10]
47b0a0: xor eax,eax
47b0a2: mov al,bl
47b0a4: imul eax,eax,0x16
47b0a7: fadd QWORD PTR [esi+eax*8-0xa8]
47b0ae: add esp,0xfffffff8
47b0b1: fstp QWORD PTR [esp]
47b0b4: fwait
47b0b5: xor ecx,ecx
47b0b7: xor edx,edx
47b0b9: mov al,0x2
47b0bb: call 0x476a04
47b0c0: dec BYTE PTR [esp+0x1]
47b0c4: jne 0x47b05f
47b0c6: cmp BYTE PTR [esp],0x16
47b0ca: je 0x47b0d6
47b0cc: cmp BYTE PTR [esp],0x17
47b0d0: jne 0x47b17d
47b0d6: xor eax,eax
47b0d8: mov al,bl
47b0da: imul eax,eax,0x16
47b0dd: cmp BYTE PTR [esi+eax*8-0x45],0xc
47b0e2: jne 0x47b17d
47b0e8: xor eax,eax
47b0ea: mov al,bl
47b0ec: imul eax,eax,0x16
47b0ef: mov BYTE PTR [esi+eax*8-0x45],0x1c
47b0f4: xor eax,eax
47b0f6: mov al,bl
47b0f8: imul eax,eax,0x16
47b0fb: mov WORD PTR [esi+eax*8-0x3c],0x0
47b102: xor eax,eax
47b104: mov al,bl
47b106: imul eax,eax,0x16
47b109: mov WORD PTR [esi+eax*8-0x3a],0xf
47b110: xor eax,eax
47b112: mov al,bl
47b114: imul eax,eax,0x16
47b117: mov BYTE PTR [esi+eax*8-0x46],0x0
47b11c: xor eax,eax
47b11e: mov al,bl
47b120: imul eax,eax,0x16
47b123: fld QWORD PTR [esi+eax*8-0x50]
47b127: fcomp DWORD PTR ds:0x47d1f8
47b12d: fnstsw ax
47b12f: sahf
47b130: jae 0x47b156
47b132: fld DWORD PTR ds:0x47d204
47b138: mov eax,ds:0x4b0fe8
47b13d: fmul QWORD PTR [eax]
47b13f: xor eax,eax
47b141: mov al,bl
47b143: imul eax,eax,0x16
47b146: fadd QWORD PTR [esi+eax*8-0x50]
47b14a: xor eax,eax
47b14c: mov al,bl
47b14e: imul eax,eax,0x16
47b151: fstp QWORD PTR [esi+eax*8-0x50]
47b155: fwait
47b156: cmp BYTE PTR [esp],0x16
47b15a: jne 0x47b168
47b15c: xor eax,eax
47b15e: mov al,bl
47b160: imul eax,eax,0x16
47b163: mov BYTE PTR [esi+eax*8-0x41],0x1
47b168: cmp BYTE PTR [esp],0x17
47b16c: jne 0x47b17a
47b16e: xor eax,eax
47b170: mov al,bl
47b172: imul eax,eax,0x16
47b175: mov BYTE PTR [esi+eax*8-0x41],0x2
47b17a: mov BYTE PTR [edi],0x2d
47b17d: cmp BYTE PTR [esp],0x18
47b181: jne 0x47b275
47b187: xor eax,eax
47b189: mov al,bl
47b18b: imul eax,eax,0x16
47b18e: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b193: je 0x47b1df
47b195: xor eax,eax
47b197: mov al,bl
47b199: imul eax,eax,0x16
47b19c: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b1a1: je 0x47b1df
47b1a3: xor eax,eax
47b1a5: mov al,bl
47b1a7: imul eax,eax,0x16
47b1aa: cmp BYTE PTR [esi+eax*8-0x45],0x7
47b1af: je 0x47b1df
47b1b1: xor eax,eax
47b1b3: mov al,bl
47b1b5: imul eax,eax,0x16
47b1b8: cmp BYTE PTR [esi+eax*8-0x45],0x15
47b1bd: je 0x47b1df
47b1bf: xor eax,eax
47b1c1: mov al,bl
47b1c3: imul eax,eax,0x16
47b1c6: cmp BYTE PTR [esi+eax*8-0x45],0x16
47b1cb: je 0x47b1df
47b1cd: xor eax,eax
47b1cf: mov al,bl
47b1d1: imul eax,eax,0x16
47b1d4: cmp BYTE PTR [esi+eax*8-0x45],0x1b
47b1d9: jne 0x47b275
47b1df: xor eax,eax
47b1e1: mov al,bl
47b1e3: imul eax,eax,0x16
47b1e6: fld QWORD PTR [esi+eax*8-0x70]
47b1ea: fcomp DWORD PTR ds:0x47d20c
47b1f0: fnstsw ax
47b1f2: sahf
47b1f3: jbe 0x47b204
47b1f5: xor eax,eax
47b1f7: mov al,bl
47b1f9: imul eax,eax,0x16
47b1fc: cmp WORD PTR [esi+eax*8-0x58],0x0
47b202: jle 0x47b275
47b204: xor eax,eax
47b206: mov al,bl
47b208: imul eax,eax,0x16
47b20b: mov BYTE PTR [esi+eax*8-0x45],0x1d
47b210: xor eax,eax
47b212: mov al,bl
47b214: imul eax,eax,0x16
47b217: mov WORD PTR [esi+eax*8-0x3c],0x0
47b21e: xor eax,eax
47b220: mov al,bl
47b222: imul eax,eax,0x16
47b225: mov WORD PTR [esi+eax*8-0x3a],0x28
47b22c: xor eax,eax
47b22e: mov al,bl
47b230: imul eax,eax,0x16
47b233: cmp WORD PTR [esi+eax*8-0x58],0x3
47b239: jne 0x47b24c
47b23b: xor eax,eax
47b23d: mov al,bl
47b23f: imul eax,eax,0x16
47b242: xor edx,edx
47b244: mov DWORD PTR [esi+eax*8-0x50],edx
47b248: mov DWORD PTR [esi+eax*8-0x4c],edx
47b24c: xor eax,eax
47b24e: mov al,bl
47b250: imul eax,eax,0x16
47b253: dec WORD PTR [esi+eax*8-0x58]
47b258: xor eax,eax
47b25a: mov al,bl
47b25c: imul eax,eax,0x16
47b25f: mov dl,BYTE PTR [esp+0x2]
47b263: add dl,0x13
47b266: mov BYTE PTR [esi+eax*8-0x44],dl
47b26a: mov eax,ds:0x4b1074
47b26f: mov BYTE PTR [eax],0x16
47b272: mov BYTE PTR [edi],0x13
47b275: xor eax,eax
47b277: mov al,bl
47b279: imul eax,eax,0x16
47b27c: cmp BYTE PTR [esi+eax*8-0xa0],0xa
47b284: jne 0x47b848
47b28a: cmp BYTE PTR [esp],0xe
47b28e: jne 0x47b2e2
47b290: xor eax,eax
47b292: mov al,bl
47b294: imul eax,eax,0x16
47b297: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b29c: je 0x47b2ba
47b29e: xor eax,eax
47b2a0: mov al,bl
47b2a2: imul eax,eax,0x16
47b2a5: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b2aa: je 0x47b2ba
47b2ac: xor eax,eax
47b2ae: mov al,bl
47b2b0: imul eax,eax,0x16
47b2b3: cmp BYTE PTR [esi+eax*8-0x45],0x7
47b2b8: jne 0x47b2e2
47b2ba: xor eax,eax
47b2bc: mov al,bl
47b2be: imul eax,eax,0x16
47b2c1: mov BYTE PTR [esi+eax*8-0x45],0x17
47b2c6: xor eax,eax
47b2c8: mov al,bl
47b2ca: imul eax,eax,0x16
47b2cd: mov WORD PTR [esi+eax*8-0x3c],0x0
47b2d4: xor eax,eax
47b2d6: mov al,bl
47b2d8: imul eax,eax,0x16
47b2db: mov WORD PTR [esi+eax*8-0x3a],0xfa
47b2e2: cmp BYTE PTR [esp],0xf
47b2e6: jne 0x47b32c
47b2e8: xor eax,eax
47b2ea: mov al,bl
47b2ec: imul eax,eax,0x16
47b2ef: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b2f4: je 0x47b304
47b2f6: xor eax,eax
47b2f8: mov al,bl
47b2fa: imul eax,eax,0x16
47b2fd: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b302: jne 0x47b32c
47b304: xor eax,eax
47b306: mov al,bl
47b308: imul eax,eax,0x16
47b30b: mov BYTE PTR [esi+eax*8-0x45],0x18
47b310: xor eax,eax
47b312: mov al,bl
47b314: imul eax,eax,0x16
47b317: mov WORD PTR [esi+eax*8-0x3c],0x0
47b31e: xor eax,eax
47b320: mov al,bl
47b322: imul eax,eax,0x16
47b325: mov WORD PTR [esi+eax*8-0x3a],0x14
47b32c: cmp BYTE PTR [esp],0x10
47b330: je 0x47b33c
47b332: cmp BYTE PTR [esp],0x11
47b336: jne 0x47b40d
47b33c: xor eax,eax
47b33e: mov al,bl
47b340: imul eax,eax,0x16
47b343: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b348: je 0x47b378
47b34a: xor eax,eax
47b34c: mov al,bl
47b34e: imul eax,eax,0x16
47b351: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b356: je 0x47b378
47b358: xor eax,eax
47b35a: mov al,bl
47b35c: imul eax,eax,0x16
47b35f: cmp BYTE PTR [esi+eax*8-0x45],0x15
47b364: je 0x47b378
47b366: xor eax,eax
47b368: mov al,bl
47b36a: imul eax,eax,0x16
47b36d: cmp BYTE PTR [esi+eax*8-0x45],0x16
47b372: jne 0x47b40d
47b378: xor eax,eax
47b37a: mov al,bl
47b37c: imul eax,eax,0x16
47b37f: mov BYTE PTR [esi+eax*8-0x45],0x19
47b384: xor eax,eax
47b386: mov al,bl
47b388: imul eax,eax,0x16
47b38b: mov WORD PTR [esi+eax*8-0x3c],0x0
47b392: xor eax,eax
47b394: mov al,bl
47b396: imul eax,eax,0x16
47b399: mov BYTE PTR [esi+eax*8-0x14],0x0
47b39e: xor eax,eax
47b3a0: mov al,bl
47b3a2: imul eax,eax,0x16
47b3a5: fld QWORD PTR [esi+eax*8-0x50]
47b3a9: fcomp DWORD PTR ds:0x47d1f8
47b3af: fnstsw ax
47b3b1: sahf
47b3b2: jae 0x47b3d8
47b3b4: fld DWORD PTR ds:0x47d204
47b3ba: mov eax,ds:0x4b0fe8
47b3bf: fmul QWORD PTR [eax]
47b3c1: xor eax,eax
47b3c3: mov al,bl
47b3c5: imul eax,eax,0x16
47b3c8: fadd QWORD PTR [esi+eax*8-0x50]
47b3cc: xor eax,eax
47b3ce: mov al,bl
47b3d0: imul eax,eax,0x16
47b3d3: fstp QWORD PTR [esi+eax*8-0x50]
47b3d7: fwait
47b3d8: cmp BYTE PTR [esp],0x10
47b3dc: jne 0x47b3ea
47b3de: xor eax,eax
47b3e0: mov al,bl
47b3e2: imul eax,eax,0x16
47b3e5: mov BYTE PTR [esi+eax*8-0x41],0x1
47b3ea: cmp BYTE PTR [esp],0x11
47b3ee: jne 0x47b3fc
47b3f0: xor eax,eax
47b3f2: mov al,bl
47b3f4: imul eax,eax,0x16
47b3f7: mov BYTE PTR [esi+eax*8-0x41],0x2
47b3fc: xor eax,eax
47b3fe: mov al,bl
47b400: imul eax,eax,0x16
47b403: mov WORD PTR [esi+eax*8-0x3a],0x14
47b40a: mov BYTE PTR [edi],0x2f
47b40d: cmp BYTE PTR [esp],0x12
47b411: je 0x47b41d
47b413: cmp BYTE PTR [esp],0x13
47b417: jne 0x47b50c
47b41d: xor eax,eax
47b41f: mov al,bl
47b421: imul eax,eax,0x16
47b424: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b429: je 0x47b459
47b42b: xor eax,eax
47b42d: mov al,bl
47b42f: imul eax,eax,0x16
47b432: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b437: je 0x47b459
47b439: xor eax,eax
47b43b: mov al,bl
47b43d: imul eax,eax,0x16
47b440: cmp BYTE PTR [esi+eax*8-0x45],0x15
47b445: je 0x47b459
47b447: xor eax,eax
47b449: mov al,bl
47b44b: imul eax,eax,0x16
47b44e: cmp BYTE PTR [esi+eax*8-0x45],0x16
47b453: jne 0x47b50c
47b459: xor eax,eax
47b45b: mov al,bl
47b45d: imul eax,eax,0x16
47b460: mov BYTE PTR [esi+eax*8-0x45],0x1a
47b465: xor eax,eax
47b467: mov al,bl
47b469: imul eax,eax,0x16
47b46c: mov WORD PTR [esi+eax*8-0x3c],0x0
47b473: xor eax,eax
47b475: mov al,bl
47b477: imul eax,eax,0x16
47b47a: fld QWORD PTR [esi+eax*8-0x50]
47b47e: fcomp DWORD PTR ds:0x47d1f8
47b484: fnstsw ax
47b486: sahf
47b487: jae 0x47b4ad
47b489: fld DWORD PTR ds:0x47d208
47b48f: mov eax,ds:0x4b0fe8
47b494: fmul QWORD PTR [eax]
47b496: xor eax,eax
47b498: mov al,bl
47b49a: imul eax,eax,0x16
47b49d: fadd QWORD PTR [esi+eax*8-0x50]
47b4a1: xor eax,eax
47b4a3: mov al,bl
47b4a5: imul eax,eax,0x16
47b4a8: fstp QWORD PTR [esi+eax*8-0x50]
47b4ac: fwait
47b4ad: cmp BYTE PTR [esp],0x12
47b4b1: jne 0x47b4bf
47b4b3: xor eax,eax
47b4b5: mov al,bl
47b4b7: imul eax,eax,0x16
47b4ba: mov BYTE PTR [esi+eax*8-0x41],0x1
47b4bf: cmp BYTE PTR [esp],0x13
47b4c3: jne 0x47b4d1
47b4c5: xor eax,eax
47b4c7: mov al,bl
47b4c9: imul eax,eax,0x16
47b4cc: mov BYTE PTR [esi+eax*8-0x41],0x2
47b4d1: xor eax,eax
47b4d3: mov al,bl
47b4d5: imul eax,eax,0x16
47b4d8: cmp BYTE PTR [esi+eax*8-0x41],0x1
47b4dd: jne 0x47b4ed
47b4df: xor eax,eax
47b4e1: mov al,bl
47b4e3: imul eax,eax,0x16
47b4e6: mov WORD PTR [esi+eax*8-0x3a],0xb
47b4ed: xor eax,eax
47b4ef: mov al,bl
47b4f1: imul eax,eax,0x16
47b4f4: cmp BYTE PTR [esi+eax*8-0x41],0x2
47b4f9: jne 0x47b509
47b4fb: xor eax,eax
47b4fd: mov al,bl
47b4ff: imul eax,eax,0x16
47b502: mov WORD PTR [esi+eax*8-0x3a],0x14
47b509: mov BYTE PTR [edi],0x30
47b50c: cmp BYTE PTR [esp],0x14
47b510: je 0x47b51c
47b512: cmp BYTE PTR [esp],0x15
47b516: jne 0x47b66d
47b51c: xor eax,eax
47b51e: mov al,bl
47b520: imul eax,eax,0x16
47b523: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b528: je 0x47b558
47b52a: xor eax,eax
47b52c: mov al,bl
47b52e: imul eax,eax,0x16
47b531: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b536: je 0x47b558
47b538: xor eax,eax
47b53a: mov al,bl
47b53c: imul eax,eax,0x16
47b53f: cmp BYTE PTR [esi+eax*8-0x45],0xc
47b544: je 0x47b558
47b546: xor eax,eax
47b548: mov al,bl
47b54a: imul eax,eax,0x16
47b54d: cmp BYTE PTR [esi+eax*8-0x45],0x16
47b552: jne 0x47b66d
47b558: mov eax,ds:0x4b11f8
47b55d: movsx eax,WORD PTR [eax]
47b560: sub eax,0x5a
47b563: mov DWORD PTR [esp+0x4],eax
47b567: fild DWORD PTR [esp+0x4]
47b56b: xor eax,eax
47b56d: mov al,bl
47b56f: imul eax,eax,0x16
47b572: fcomp QWORD PTR [esi+eax*8-0xa8]
47b579: fnstsw ax
47b57b: sahf
47b57c: ja 0x47b66d
47b582: xor eax,eax
47b584: mov al,bl
47b586: imul eax,eax,0x16
47b589: mov BYTE PTR [esi+eax*8-0x45],0x1b
47b58e: xor eax,eax
47b590: mov al,bl
47b592: imul eax,eax,0x16
47b595: mov WORD PTR [esi+eax*8-0x3c],0x0
47b59c: mov eax,ds:0x4b11f8
47b5a1: movsx eax,WORD PTR [eax]
47b5a4: sub eax,0x32
47b5a7: mov DWORD PTR [esp+0x4],eax
47b5ab: fild DWORD PTR [esp+0x4]
47b5af: xor eax,eax
47b5b1: mov al,bl
47b5b3: imul eax,eax,0x16
47b5b6: fstp QWORD PTR [esi+eax*8-0xa8]
47b5bd: fwait
47b5be: xor eax,eax
47b5c0: mov al,bl
47b5c2: imul eax,eax,0x16
47b5c5: mov BYTE PTR [esi+eax*8-0x46],0x1
47b5ca: xor eax,eax
47b5cc: mov al,bl
47b5ce: imul eax,eax,0x16
47b5d1: mov WORD PTR [esi+eax*8-0x3a],0x14
47b5d8: xor eax,eax
47b5da: mov al,bl
47b5dc: imul eax,eax,0x16
47b5df: fld QWORD PTR [esi+eax*8-0x50]
47b5e3: fcomp DWORD PTR ds:0x47d1f8
47b5e9: fnstsw ax
47b5eb: sahf
47b5ec: jae 0x47b612
47b5ee: fld DWORD PTR ds:0x47d204
47b5f4: mov eax,ds:0x4b0fe8
47b5f9: fmul QWORD PTR [eax]
47b5fb: xor eax,eax
47b5fd: mov al,bl
47b5ff: imul eax,eax,0x16
47b602: fadd QWORD PTR [esi+eax*8-0x50]
47b606: xor eax,eax
47b608: mov al,bl
47b60a: imul eax,eax,0x16
47b60d: fstp QWORD PTR [esi+eax*8-0x50]
47b611: fwait
47b612: cmp BYTE PTR [esp],0x14
47b616: jne 0x47b624
47b618: xor eax,eax
47b61a: mov al,bl
47b61c: imul eax,eax,0x16
47b61f: mov BYTE PTR [esi+eax*8-0x41],0x1
47b624: cmp BYTE PTR [esp],0x15
47b628: jne 0x47b636
47b62a: xor eax,eax
47b62c: mov al,bl
47b62e: imul eax,eax,0x16
47b631: mov BYTE PTR [esi+eax*8-0x41],0x2
47b636: xor eax,eax
47b638: mov al,bl
47b63a: imul eax,eax,0x16
47b63d: cmp BYTE PTR [esi+eax*8-0x41],0x1
47b642: jne 0x47b650
47b644: xor eax,eax
47b646: mov al,bl
47b648: imul eax,eax,0x16
47b64b: mov BYTE PTR [esi+eax*8-0x38],0xe7
47b650: xor eax,eax
47b652: mov al,bl
47b654: imul eax,eax,0x16
47b657: cmp BYTE PTR [esi+eax*8-0x41],0x2
47b65c: jne 0x47b66a
47b65e: xor eax,eax
47b660: mov al,bl
47b662: imul eax,eax,0x16
47b665: mov BYTE PTR [esi+eax*8-0x38],0xe4
47b66a: mov BYTE PTR [edi],0x31
47b66d: cmp BYTE PTR [esp],0x16
47b671: je 0x47b67d
47b673: cmp BYTE PTR [esp],0x17
47b677: jne 0x47b750
47b67d: xor eax,eax
47b67f: mov al,bl
47b681: imul eax,eax,0x16
47b684: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b689: je 0x47b6c7
47b68b: xor eax,eax
47b68d: mov al,bl
47b68f: imul eax,eax,0x16
47b692: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b697: je 0x47b6c7
47b699: xor eax,eax
47b69b: mov al,bl
47b69d: imul eax,eax,0x16
47b6a0: cmp BYTE PTR [esi+eax*8-0x45],0x15
47b6a5: je 0x47b6c7
47b6a7: xor eax,eax
47b6a9: mov al,bl
47b6ab: imul eax,eax,0x16
47b6ae: cmp BYTE PTR [esi+eax*8-0x45],0x16
47b6b3: je 0x47b6c7
47b6b5: xor eax,eax
47b6b7: mov al,bl
47b6b9: imul eax,eax,0x16
47b6bc: cmp BYTE PTR [esi+eax*8-0x45],0x5
47b6c1: jne 0x47b750
47b6c7: xor eax,eax
47b6c9: mov al,bl
47b6cb: imul eax,eax,0x16
47b6ce: mov BYTE PTR [esi+eax*8-0x45],0x1c
47b6d3: xor eax,eax
47b6d5: mov al,bl
47b6d7: imul eax,eax,0x16
47b6da: mov WORD PTR [esi+eax*8-0x3c],0x0
47b6e1: xor eax,eax
47b6e3: mov al,bl
47b6e5: imul eax,eax,0x16
47b6e8: mov WORD PTR [esi+eax*8-0x3a],0xd
47b6ef: xor eax,eax
47b6f1: mov al,bl
47b6f3: imul eax,eax,0x16
47b6f6: fld QWORD PTR [esi+eax*8-0x50]
47b6fa: fcomp DWORD PTR ds:0x47d1f8
47b700: fnstsw ax
47b702: sahf
47b703: jae 0x47b729
47b705: fld DWORD PTR ds:0x47d204
47b70b: mov eax,ds:0x4b0fe8
47b710: fmul QWORD PTR [eax]
47b712: xor eax,eax
47b714: mov al,bl
47b716: imul eax,eax,0x16
47b719: fadd QWORD PTR [esi+eax*8-0x50]
47b71d: xor eax,eax
47b71f: mov al,bl
47b721: imul eax,eax,0x16
47b724: fstp QWORD PTR [esi+eax*8-0x50]
47b728: fwait
47b729: cmp BYTE PTR [esp],0x16
47b72d: jne 0x47b73b
47b72f: xor eax,eax
47b731: mov al,bl
47b733: imul eax,eax,0x16
47b736: mov BYTE PTR [esi+eax*8-0x41],0x1
47b73b: cmp BYTE PTR [esp],0x17
47b73f: jne 0x47b74d
47b741: xor eax,eax
47b743: mov al,bl
47b745: imul eax,eax,0x16
47b748: mov BYTE PTR [esi+eax*8-0x41],0x2
47b74d: mov BYTE PTR [edi],0x31
47b750: cmp BYTE PTR [esp],0x18
47b754: jne 0x47b848
47b75a: xor eax,eax
47b75c: mov al,bl
47b75e: imul eax,eax,0x16
47b761: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b766: je 0x47b7b2
47b768: xor eax,eax
47b76a: mov al,bl
47b76c: imul eax,eax,0x16
47b76f: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b774: je 0x47b7b2
47b776: xor eax,eax
47b778: mov al,bl
47b77a: imul eax,eax,0x16
47b77d: cmp BYTE PTR [esi+eax*8-0x45],0x7
47b782: je 0x47b7b2
47b784: xor eax,eax
47b786: mov al,bl
47b788: imul eax,eax,0x16
47b78b: cmp BYTE PTR [esi+eax*8-0x45],0x15
47b790: je 0x47b7b2
47b792: xor eax,eax
47b794: mov al,bl
47b796: imul eax,eax,0x16
47b799: cmp BYTE PTR [esi+eax*8-0x45],0x16
47b79e: je 0x47b7b2
47b7a0: xor eax,eax
47b7a2: mov al,bl
47b7a4: imul eax,eax,0x16
47b7a7: cmp BYTE PTR [esi+eax*8-0x45],0x19
47b7ac: jne 0x47b848
47b7b2: xor eax,eax
47b7b4: mov al,bl
47b7b6: imul eax,eax,0x16
47b7b9: fld QWORD PTR [esi+eax*8-0x70]
47b7bd: fcomp DWORD PTR ds:0x47d20c
47b7c3: fnstsw ax
47b7c5: sahf
47b7c6: jbe 0x47b7d7
47b7c8: xor eax,eax
47b7ca: mov al,bl
47b7cc: imul eax,eax,0x16
47b7cf: cmp WORD PTR [esi+eax*8-0x58],0x0
47b7d5: jle 0x47b848
47b7d7: xor eax,eax
47b7d9: mov al,bl
47b7db: imul eax,eax,0x16
47b7de: mov BYTE PTR [esi+eax*8-0x45],0x1d
47b7e3: xor eax,eax
47b7e5: mov al,bl
47b7e7: imul eax,eax,0x16
47b7ea: mov WORD PTR [esi+eax*8-0x3c],0x0
47b7f1: xor eax,eax
47b7f3: mov al,bl
47b7f5: imul eax,eax,0x16
47b7f8: mov WORD PTR [esi+eax*8-0x3a],0x28
47b7ff: xor eax,eax
47b801: mov al,bl
47b803: imul eax,eax,0x16
47b806: cmp WORD PTR [esi+eax*8-0x58],0x3
47b80c: jne 0x47b81f
47b80e: xor eax,eax
47b810: mov al,bl
47b812: imul eax,eax,0x16
47b815: xor edx,edx
47b817: mov DWORD PTR [esi+eax*8-0x50],edx
47b81b: mov DWORD PTR [esi+eax*8-0x4c],edx
47b81f: xor eax,eax
47b821: mov al,bl
47b823: imul eax,eax,0x16
47b826: dec WORD PTR [esi+eax*8-0x58]
47b82b: xor eax,eax
47b82d: mov al,bl
47b82f: imul eax,eax,0x16
47b832: mov dl,BYTE PTR [esp+0x2]
47b836: add dl,0x26
47b839: mov BYTE PTR [esi+eax*8-0x44],dl
47b83d: mov eax,ds:0x4b1074
47b842: mov BYTE PTR [eax],0x16
47b845: mov BYTE PTR [edi],0x13
47b848: xor eax,eax
47b84a: mov al,bl
47b84c: imul eax,eax,0x16
47b84f: cmp BYTE PTR [esi+eax*8-0xa0],0xb
47b857: jne 0x47bd9b
47b85d: cmp BYTE PTR [esp],0xe
47b861: jne 0x47b8b5
47b863: xor eax,eax
47b865: mov al,bl
47b867: imul eax,eax,0x16
47b86a: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b86f: je 0x47b88d
47b871: xor eax,eax
47b873: mov al,bl
47b875: imul eax,eax,0x16
47b878: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b87d: je 0x47b88d
47b87f: xor eax,eax
47b881: mov al,bl
47b883: imul eax,eax,0x16
47b886: cmp BYTE PTR [esi+eax*8-0x45],0x7
47b88b: jne 0x47b8b5
47b88d: xor eax,eax
47b88f: mov al,bl
47b891: imul eax,eax,0x16
47b894: mov BYTE PTR [esi+eax*8-0x45],0x17
47b899: xor eax,eax
47b89b: mov al,bl
47b89d: imul eax,eax,0x16
47b8a0: mov WORD PTR [esi+eax*8-0x3c],0x0
47b8a7: xor eax,eax
47b8a9: mov al,bl
47b8ab: imul eax,eax,0x16
47b8ae: mov WORD PTR [esi+eax*8-0x3a],0xfa
47b8b5: cmp BYTE PTR [esp],0xf
47b8b9: jne 0x47b8ff
47b8bb: xor eax,eax
47b8bd: mov al,bl
47b8bf: imul eax,eax,0x16
47b8c2: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b8c7: je 0x47b8d7
47b8c9: xor eax,eax
47b8cb: mov al,bl
47b8cd: imul eax,eax,0x16
47b8d0: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b8d5: jne 0x47b8ff
47b8d7: xor eax,eax
47b8d9: mov al,bl
47b8db: imul eax,eax,0x16
47b8de: mov BYTE PTR [esi+eax*8-0x45],0x18
47b8e3: xor eax,eax
47b8e5: mov al,bl
47b8e7: imul eax,eax,0x16
47b8ea: mov WORD PTR [esi+eax*8-0x3c],0x0
47b8f1: xor eax,eax
47b8f3: mov al,bl
47b8f5: imul eax,eax,0x16
47b8f8: mov WORD PTR [esi+eax*8-0x3a],0x14
47b8ff: cmp BYTE PTR [esp],0x10
47b903: je 0x47b90f
47b905: cmp BYTE PTR [esp],0x11
47b909: jne 0x47b9e2
47b90f: xor eax,eax
47b911: mov al,bl
47b913: imul eax,eax,0x16
47b916: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b91b: je 0x47b94b
47b91d: xor eax,eax
47b91f: mov al,bl
47b921: imul eax,eax,0x16
47b924: cmp BYTE PTR [esi+eax*8-0x45],0x2
47b929: je 0x47b94b
47b92b: xor eax,eax
47b92d: mov al,bl
47b92f: imul eax,eax,0x16
47b932: cmp BYTE PTR [esi+eax*8-0x45],0x15
47b937: je 0x47b94b
47b939: xor eax,eax
47b93b: mov al,bl
47b93d: imul eax,eax,0x16
47b940: cmp BYTE PTR [esi+eax*8-0x45],0x16
47b945: jne 0x47b9e2
47b94b: mov edx,ebx
47b94d: mov al,0x16
47b94f: call 0x476454
47b954: test al,al
47b956: jne 0x47b9e2
47b95c: xor eax,eax
47b95e: mov al,bl
47b960: imul eax,eax,0x16
47b963: mov BYTE PTR [esi+eax*8-0x45],0x19
47b968: xor eax,eax
47b96a: mov al,bl
47b96c: imul eax,eax,0x16
47b96f: mov WORD PTR [esi+eax*8-0x3c],0x0
47b976: xor eax,eax
47b978: mov al,bl
47b97a: imul eax,eax,0x16
47b97d: mov WORD PTR [esi+eax*8-0x3a],0x1c
47b984: xor eax,eax
47b986: mov al,bl
47b988: imul eax,eax,0x16
47b98b: fld QWORD PTR [esi+eax*8-0x50]
47b98f: fcomp DWORD PTR ds:0x47d1f8
47b995: fnstsw ax
47b997: sahf
47b998: jae 0x47b9be
47b99a: fld DWORD PTR ds:0x47d204
47b9a0: mov eax,ds:0x4b0fe8
47b9a5: fmul QWORD PTR [eax]
47b9a7: xor eax,eax
47b9a9: mov al,bl
47b9ab: imul eax,eax,0x16
47b9ae: fadd QWORD PTR [esi+eax*8-0x50]
47b9b2: xor eax,eax
47b9b4: mov al,bl
47b9b6: imul eax,eax,0x16
47b9b9: fstp QWORD PTR [esi+eax*8-0x50]
47b9bd: fwait
47b9be: cmp BYTE PTR [esp],0x10
47b9c2: jne 0x47b9d0
47b9c4: xor eax,eax
47b9c6: mov al,bl
47b9c8: imul eax,eax,0x16
47b9cb: mov BYTE PTR [esi+eax*8-0x41],0x1
47b9d0: cmp BYTE PTR [esp],0x11
47b9d4: jne 0x47b9e2
47b9d6: xor eax,eax
47b9d8: mov al,bl
47b9da: imul eax,eax,0x16
47b9dd: mov BYTE PTR [esi+eax*8-0x41],0x2
47b9e2: cmp BYTE PTR [esp],0x12
47b9e6: je 0x47b9f2
47b9e8: cmp BYTE PTR [esp],0x13
47b9ec: jne 0x47bab4
47b9f2: xor eax,eax
47b9f4: mov al,bl
47b9f6: imul eax,eax,0x16
47b9f9: cmp BYTE PTR [esi+eax*8-0x45],0x1
47b9fe: je 0x47ba2e
47ba00: xor eax,eax
47ba02: mov al,bl
47ba04: imul eax,eax,0x16
47ba07: cmp BYTE PTR [esi+eax*8-0x45],0x2
47ba0c: je 0x47ba2e
47ba0e: xor eax,eax
47ba10: mov al,bl
47ba12: imul eax,eax,0x16
47ba15: cmp BYTE PTR [esi+eax*8-0x45],0x15
47ba1a: je 0x47ba2e
47ba1c: xor eax,eax
47ba1e: mov al,bl
47ba20: imul eax,eax,0x16
47ba23: cmp BYTE PTR [esi+eax*8-0x45],0x16
47ba28: jne 0x47bab4
47ba2e: xor eax,eax
47ba30: mov al,bl
47ba32: imul eax,eax,0x16
47ba35: mov BYTE PTR [esi+eax*8-0x45],0x1a
47ba3a: xor eax,eax
47ba3c: mov al,bl
47ba3e: imul eax,eax,0x16
47ba41: mov WORD PTR [esi+eax*8-0x3c],0x0
47ba48: xor eax,eax
47ba4a: mov al,bl
47ba4c: imul eax,eax,0x16
47ba4f: mov WORD PTR [esi+eax*8-0x3a],0x1e
47ba56: xor eax,eax
47ba58: mov al,bl
47ba5a: imul eax,eax,0x16
47ba5d: fld QWORD PTR [esi+eax*8-0x50]
47ba61: fcomp DWORD PTR ds:0x47d1f8
47ba67: fnstsw ax
47ba69: sahf
47ba6a: jae 0x47ba90
47ba6c: fld DWORD PTR ds:0x47d208
47ba72: mov eax,ds:0x4b0fe8
47ba77: fmul QWORD PTR [eax]
47ba79: xor eax,eax
47ba7b: mov al,bl
47ba7d: imul eax,eax,0x16
47ba80: fadd QWORD PTR [esi+eax*8-0x50]
47ba84: xor eax,eax
47ba86: mov al,bl
47ba88: imul eax,eax,0x16
47ba8b: fstp QWORD PTR [esi+eax*8-0x50]
47ba8f: fwait
47ba90: cmp BYTE PTR [esp],0x12
47ba94: jne 0x47baa2
47ba96: xor eax,eax
47ba98: mov al,bl
47ba9a: imul eax,eax,0x16
47ba9d: mov BYTE PTR [esi+eax*8-0x41],0x1
47baa2: cmp BYTE PTR [esp],0x13
47baa6: jne 0x47bab4
47baa8: xor eax,eax
47baaa: mov al,bl
47baac: imul eax,eax,0x16
47baaf: mov BYTE PTR [esi+eax*8-0x41],0x2
47bab4: cmp BYTE PTR [esp],0x14
47bab8: je 0x47bac4
47baba: cmp BYTE PTR [esp],0x15
47babe: jne 0x47bbb0
47bac4: xor eax,eax
47bac6: mov al,bl
47bac8: imul eax,eax,0x16
47bacb: cmp BYTE PTR [esi+eax*8-0x45],0x1
47bad0: je 0x47bb00
47bad2: xor eax,eax
47bad4: mov al,bl
47bad6: imul eax,eax,0x16
47bad9: cmp BYTE PTR [esi+eax*8-0x45],0x2
47bade: je 0x47bb00
47bae0: xor eax,eax
47bae2: mov al,bl
47bae4: imul eax,eax,0x16
47bae7: cmp BYTE PTR [esi+eax*8-0x45],0x15
47baec: je 0x47bb00
47baee: xor eax,eax
47baf0: mov al,bl
47baf2: imul eax,eax,0x16
47baf5: cmp BYTE PTR [esi+eax*8-0x45],0x16
47bafa: jne 0x47bbb0
47bb00: xor eax,eax
47bb02: mov al,bl
47bb04: imul eax,eax,0x16
47bb07: mov BYTE PTR [esi+eax*8-0x45],0x1b
47bb0c: xor eax,eax
47bb0e: mov al,bl
47bb10: imul eax,eax,0x16
47bb13: mov WORD PTR [esi+eax*8-0x3c],0x0
47bb1a: xor eax,eax
47bb1c: mov al,bl
47bb1e: imul eax,eax,0x16
47bb21: fld QWORD PTR [esi+eax*8-0x50]
47bb25: fcomp DWORD PTR ds:0x47d1f8
47bb2b: fnstsw ax
47bb2d: sahf
47bb2e: jae 0x47bb54
47bb30: fld DWORD PTR ds:0x47d204
47bb36: mov eax,ds:0x4b0fe8
47bb3b: fmul QWORD PTR [eax]
47bb3d: xor eax,eax
47bb3f: mov al,bl
47bb41: imul eax,eax,0x16
47bb44: fadd QWORD PTR [esi+eax*8-0x50]
47bb48: xor eax,eax
47bb4a: mov al,bl
47bb4c: imul eax,eax,0x16
47bb4f: fstp QWORD PTR [esi+eax*8-0x50]
47bb53: fwait
47bb54: cmp BYTE PTR [esp],0x14
47bb58: jne 0x47bb66
47bb5a: xor eax,eax
47bb5c: mov al,bl
47bb5e: imul eax,eax,0x16
47bb61: mov BYTE PTR [esi+eax*8-0x41],0x1
47bb66: cmp BYTE PTR [esp],0x15
47bb6a: jne 0x47bb78
47bb6c: xor eax,eax
47bb6e: mov al,bl
47bb70: imul eax,eax,0x16
47bb73: mov BYTE PTR [esi+eax*8-0x41],0x2
47bb78: xor eax,eax
47bb7a: mov al,bl
47bb7c: imul eax,eax,0x16
47bb7f: cmp BYTE PTR [esi+eax*8-0x41],0x1
47bb84: jne 0x47bb94
47bb86: xor eax,eax
47bb88: mov al,bl
47bb8a: imul eax,eax,0x16
47bb8d: mov WORD PTR [esi+eax*8-0x3a],0x9
47bb94: xor eax,eax
47bb96: mov al,bl
47bb98: imul eax,eax,0x16
47bb9b: cmp BYTE PTR [esi+eax*8-0x41],0x2
47bba0: jne 0x47bbb0
47bba2: xor eax,eax
47bba4: mov al,bl
47bba6: imul eax,eax,0x16
47bba9: mov WORD PTR [esi+eax*8-0x3a],0xf
47bbb0: cmp BYTE PTR [esp],0x16
47bbb4: je 0x47bbc0
47bbb6: cmp BYTE PTR [esp],0x17
47bbba: jne 0x47bca3
47bbc0: xor eax,eax
47bbc2: mov al,bl
47bbc4: imul eax,eax,0x16
47bbc7: cmp BYTE PTR [esi+eax*8-0x45],0x1
47bbcc: je 0x47bc1d
47bbce: xor eax,eax
47bbd0: mov al,bl
47bbd2: imul eax,eax,0x16
47bbd5: cmp BYTE PTR [esi+eax*8-0x45],0x2
47bbda: je 0x47bc1d
47bbdc: xor eax,eax
47bbde: mov al,bl
47bbe0: imul eax,eax,0x16
47bbe3: cmp BYTE PTR [esi+eax*8-0x45],0x15
47bbe8: je 0x47bc1d
47bbea: xor eax,eax
47bbec: mov al,bl
47bbee: imul eax,eax,0x16
47bbf1: cmp BYTE PTR [esi+eax*8-0x45],0x16
47bbf6: je 0x47bc1d
47bbf8: xor eax,eax
47bbfa: mov al,bl
47bbfc: imul eax,eax,0x16
47bbff: cmp BYTE PTR [esi+eax*8-0x45],0x1d
47bc04: jne 0x47bca3
47bc0a: xor eax,eax
47bc0c: mov al,bl
47bc0e: imul eax,eax,0x16
47bc11: cmp WORD PTR [esi+eax*8-0x3c],0x1b
47bc17: jl 0x47bca3
47bc1d: xor eax,eax
47bc1f: mov al,bl
47bc21: imul eax,eax,0x16
47bc24: mov BYTE PTR [esi+eax*8-0x45],0x1c
47bc29: xor eax,eax
47bc2b: mov al,bl
47bc2d: imul eax,eax,0x16
47bc30: mov WORD PTR [esi+eax*8-0x3c],0x0
47bc37: xor eax,eax
47bc39: mov al,bl
47bc3b: imul eax,eax,0x16
47bc3e: mov WORD PTR [esi+eax*8-0x3a],0xc
47bc45: xor eax,eax
47bc47: mov al,bl
47bc49: imul eax,eax,0x16
47bc4c: fld QWORD PTR [esi+eax*8-0x50]
47bc50: fcomp DWORD PTR ds:0x47d1f8
47bc56: fnstsw ax
47bc58: sahf
47bc59: jae 0x47bc7f
47bc5b: fld DWORD PTR ds:0x47d204
47bc61: mov eax,ds:0x4b0fe8
47bc66: fmul QWORD PTR [eax]
47bc68: xor eax,eax
47bc6a: mov al,bl
47bc6c: imul eax,eax,0x16
47bc6f: fadd QWORD PTR [esi+eax*8-0x50]
47bc73: xor eax,eax
47bc75: mov al,bl
47bc77: imul eax,eax,0x16
47bc7a: fstp QWORD PTR [esi+eax*8-0x50]
47bc7e: fwait
47bc7f: cmp BYTE PTR [esp],0x16
47bc83: jne 0x47bc91
47bc85: xor eax,eax
47bc87: mov al,bl
47bc89: imul eax,eax,0x16
47bc8c: mov BYTE PTR [esi+eax*8-0x41],0x1
47bc91: cmp BYTE PTR [esp],0x17
47bc95: jne 0x47bca3
47bc97: xor eax,eax
47bc99: mov al,bl
47bc9b: imul eax,eax,0x16
47bc9e: mov BYTE PTR [esi+eax*8-0x41],0x2
47bca3: cmp BYTE PTR [esp],0x18
47bca7: jne 0x47bd9b
47bcad: xor eax,eax
47bcaf: mov al,bl
47bcb1: imul eax,eax,0x16
47bcb4: cmp BYTE PTR [esi+eax*8-0x45],0x1
47bcb9: je 0x47bd05
47bcbb: xor eax,eax
47bcbd: mov al,bl
47bcbf: imul eax,eax,0x16
47bcc2: cmp BYTE PTR [esi+eax*8-0x45],0x2
47bcc7: je 0x47bd05
47bcc9: xor eax,eax
47bccb: mov al,bl
47bccd: imul eax,eax,0x16
47bcd0: cmp BYTE PTR [esi+eax*8-0x45],0x7
47bcd5: je 0x47bd05
47bcd7: xor eax,eax
47bcd9: mov al,bl
47bcdb: imul eax,eax,0x16
47bcde: cmp BYTE PTR [esi+eax*8-0x45],0x15
47bce3: je 0x47bd05
47bce5: xor eax,eax
47bce7: mov al,bl
47bce9: imul eax,eax,0x16
47bcec: cmp BYTE PTR [esi+eax*8-0x45],0x16
47bcf1: je 0x47bd05
47bcf3: xor eax,eax
47bcf5: mov al,bl
47bcf7: imul eax,eax,0x16
47bcfa: cmp BYTE PTR [esi+eax*8-0x45],0x1b
47bcff: jne 0x47bd9b
47bd05: xor eax,eax
47bd07: mov al,bl
47bd09: imul eax,eax,0x16
47bd0c: fld QWORD PTR [esi+eax*8-0x70]
47bd10: fcomp DWORD PTR ds:0x47d20c
47bd16: fnstsw ax
47bd18: sahf
47bd19: jbe 0x47bd2a
47bd1b: xor eax,eax
47bd1d: mov al,bl
47bd1f: imul eax,eax,0x16
47bd22: cmp WORD PTR [esi+eax*8-0x58],0x0
47bd28: jle 0x47bd9b
47bd2a: xor eax,eax
47bd2c: mov al,bl
47bd2e: imul eax,eax,0x16
47bd31: mov BYTE PTR [esi+eax*8-0x45],0x1d
47bd36: xor eax,eax
47bd38: mov al,bl
47bd3a: imul eax,eax,0x16
47bd3d: mov WORD PTR [esi+eax*8-0x3c],0x0
47bd44: xor eax,eax
47bd46: mov al,bl
47bd48: imul eax,eax,0x16
47bd4b: mov WORD PTR [esi+eax*8-0x3a],0x2d
47bd52: xor eax,eax
47bd54: mov al,bl
47bd56: imul eax,eax,0x16
47bd59: cmp WORD PTR [esi+eax*8-0x58],0x3
47bd5f: jne 0x47bd72
47bd61: xor eax,eax
47bd63: mov al,bl
47bd65: imul eax,eax,0x16
47bd68: xor edx,edx
47bd6a: mov DWORD PTR [esi+eax*8-0x50],edx
47bd6e: mov DWORD PTR [esi+eax*8-0x4c],edx
47bd72: xor eax,eax
47bd74: mov al,bl
47bd76: imul eax,eax,0x16
47bd79: dec WORD PTR [esi+eax*8-0x58]
47bd7e: xor eax,eax
47bd80: mov al,bl
47bd82: imul eax,eax,0x16
47bd85: mov dl,BYTE PTR [esp+0x2]
47bd89: add dl,0x6
47bd8c: mov BYTE PTR [esi+eax*8-0x44],dl
47bd90: mov eax,ds:0x4b1074
47bd95: mov BYTE PTR [eax],0x16
47bd98: mov BYTE PTR [edi],0x13
47bd9b: xor eax,eax
47bd9d: mov al,bl
47bd9f: imul eax,eax,0x16
47bda2: cmp BYTE PTR [esi+eax*8-0xa0],0xc
47bdaa: jne 0x47c291
47bdb0: cmp BYTE PTR [esp],0xe
47bdb4: jne 0x47be68
47bdba: xor eax,eax
47bdbc: mov al,bl
47bdbe: imul eax,eax,0x16
47bdc1: cmp BYTE PTR [esi+eax*8-0x45],0x1
47bdc6: je 0x47bde8
47bdc8: xor eax,eax
47bdca: mov al,bl
47bdcc: imul eax,eax,0x16
47bdcf: cmp BYTE PTR [esi+eax*8-0x45],0x2
47bdd4: je 0x47bde8
47bdd6: xor eax,eax
47bdd8: mov al,bl
47bdda: imul eax,eax,0x16
47bddd: cmp BYTE PTR [esi+eax*8-0x45],0x7
47bde2: jne 0x47be68
47bde8: xor eax,eax
47bdea: mov al,bl
47bdec: imul eax,eax,0x16
47bdef: mov BYTE PTR [esi+eax*8-0x45],0x17
47bdf4: xor eax,eax
47bdf6: mov al,bl
47bdf8: imul eax,eax,0x16
47bdfb: mov WORD PTR [esi+eax*8-0x3c],0x0
47be02: xor eax,eax
47be04: mov al,bl
47be06: imul eax,eax,0x16
47be09: mov WORD PTR [esi+eax*8-0x3a],0xfa
47be10: mov eax,ds:0x4b11b4
47be15: fild DWORD PTR [eax]
47be17: xor eax,eax
47be19: mov al,bl
47be1b: imul eax,eax,0x16
47be1e: fsubr QWORD PTR [esi+eax*8-0xb0]
47be25: fcomp DWORD PTR ds:0x47d218
47be2b: fnstsw ax
47be2d: sahf
47be2e: jae 0x47be3c
47be30: xor eax,eax
47be32: mov al,bl
47be34: imul eax,eax,0x16
47be37: mov BYTE PTR [esi+eax*8-0x43],0x1
47be3c: mov eax,ds:0x4b11b4
47be41: fild DWORD PTR [eax]
47be43: xor eax,eax
47be45: mov al,bl
47be47: imul eax,eax,0x16
47be4a: fsubr QWORD PTR [esi+eax*8-0xb0]
47be51: fcomp DWORD PTR ds:0x47d218
47be57: fnstsw ax
47be59: sahf
47be5a: jb 0x47be68
47be5c: xor eax,eax
47be5e: mov al,bl
47be60: imul eax,eax,0x16
47be63: mov BYTE PTR [esi+eax*8-0x43],0x2
47be68: cmp BYTE PTR [esp],0xf
47be6c: jne 0x47beb2
47be6e: xor eax,eax
47be70: mov al,bl
47be72: imul eax,eax,0x16
47be75: cmp BYTE PTR [esi+eax*8-0x45],0x1
47be7a: je 0x47be8a
47be7c: xor eax,eax
47be7e: mov al,bl
47be80: imul eax,eax,0x16
47be83: cmp BYTE PTR [esi+eax*8-0x45],0x2
47be88: jne 0x47beb2
47be8a: xor eax,eax
47be8c: mov al,bl
47be8e: imul eax,eax,0x16
47be91: mov BYTE PTR [esi+eax*8-0x45],0x18
47be96: xor eax,eax
47be98: mov al,bl
47be9a: imul eax,eax,0x16
47be9d: mov WORD PTR [esi+eax*8-0x3c],0x0
47bea4: xor eax,eax
47bea6: mov al,bl
47bea8: imul eax,eax,0x16
47beab: mov WORD PTR [esi+eax*8-0x3a],0x14
47beb2: cmp BYTE PTR [esp],0x10
47beb6: je 0x47bec2
47beb8: cmp BYTE PTR [esp],0x11
47bebc: jne 0x47bf95
47bec2: xor eax,eax
47bec4: mov al,bl
47bec6: imul eax,eax,0x16
47bec9: cmp BYTE PTR [esi+eax*8-0x45],0x1
47bece: je 0x47befe
47bed0: xor eax,eax
47bed2: mov al,bl
47bed4: imul eax,eax,0x16
47bed7: cmp BYTE PTR [esi+eax*8-0x45],0x2
47bedc: je 0x47befe
47bede: xor eax,eax
47bee0: mov al,bl
47bee2: imul eax,eax,0x16
47bee5: cmp BYTE PTR [esi+eax*8-0x45],0x15
47beea: je 0x47befe
47beec: xor eax,eax
47beee: mov al,bl
47bef0: imul eax,eax,0x16
47bef3: cmp BYTE PTR [esi+eax*8-0x45],0x16
47bef8: jne 0x47bf95
47befe: mov edx,ebx
47bf00: mov al,0x9
47bf02: call 0x476454
47bf07: test al,al
47bf09: jne 0x47bf95
47bf0f: xor eax,eax
47bf11: mov al,bl
47bf13: imul eax,eax,0x16
47bf16: mov BYTE PTR [esi+eax*8-0x45],0x19
47bf1b: xor eax,eax
47bf1d: mov al,bl
47bf1f: imul eax,eax,0x16
47bf22: mov WORD PTR [esi+eax*8-0x3c],0x0
47bf29: xor eax,eax
47bf2b: mov al,bl
47bf2d: imul eax,eax,0x16
47bf30: mov WORD PTR [esi+eax*8-0x3a],0x1c
47bf37: xor eax,eax
47bf39: mov al,bl
47bf3b: imul eax,eax,0x16
47bf3e: fld QWORD PTR [esi+eax*8-0x50]
47bf42: fcomp DWORD PTR ds:0x47d1f8
47bf48: fnstsw ax
47bf4a: sahf
47bf4b: jae 0x47bf71
47bf4d: fld DWORD PTR ds:0x47d204
47bf53: mov eax,ds:0x4b0fe8
47bf58: fmul QWORD PTR [eax]
47bf5a: xor eax,eax
47bf5c: mov al,bl
47bf5e: imul eax,eax,0x16
47bf61: fadd QWORD PTR [esi+eax*8-0x50]
47bf65: xor eax,eax
47bf67: mov al,bl
47bf69: imul eax,eax,0x16
47bf6c: fstp QWORD PTR [esi+eax*8-0x50]
47bf70: fwait
47bf71: cmp BYTE PTR [esp],0x10
47bf75: jne 0x47bf83
47bf77: xor eax,eax
47bf79: mov al,bl
47bf7b: imul eax,eax,0x16
47bf7e: mov BYTE PTR [esi+eax*8-0x41],0x1
47bf83: cmp BYTE PTR [esp],0x11
47bf87: jne 0x47bf95
47bf89: xor eax,eax
47bf8b: mov al,bl
47bf8d: imul eax,eax,0x16
47bf90: mov BYTE PTR [esi+eax*8-0x41],0x2
47bf95: cmp BYTE PTR [esp],0x12
47bf99: je 0x47bfa5
47bf9b: cmp BYTE PTR [esp],0x13
47bf9f: jne 0x47c095
47bfa5: xor eax,eax
47bfa7: mov al,bl
47bfa9: imul eax,eax,0x16
47bfac: cmp BYTE PTR [esi+eax*8-0x45],0x1
47bfb1: je 0x47c00f
47bfb3: xor eax,eax
47bfb5: mov al,bl
47bfb7: imul eax,eax,0x16
47bfba: cmp BYTE PTR [esi+eax*8-0x45],0x2
47bfbf: je 0x47c00f
47bfc1: xor eax,eax
47bfc3: mov al,bl
47bfc5: imul eax,eax,0x16
47bfc8: cmp BYTE PTR [esi+eax*8-0x45],0x7
47bfcd: je 0x47c00f
47bfcf: xor eax,eax
47bfd1: mov al,bl
47bfd3: imul eax,eax,0x16
47bfd6: cmp BYTE PTR [esi+eax*8-0x45],0x15
47bfdb: je 0x47c00f
47bfdd: xor eax,eax
47bfdf: mov al,bl
47bfe1: imul eax,eax,0x16
47bfe4: cmp BYTE PTR [esi+eax*8-0x45],0x16
47bfe9: je 0x47c00f
47bfeb: xor eax,eax
47bfed: mov al,bl
47bfef: imul eax,eax,0x16
47bff2: cmp BYTE PTR [esi+eax*8-0x45],0x1e
47bff7: jne 0x47c095
47bffd: xor eax,eax
47bfff: mov al,bl
47c001: imul eax,eax,0x16
47c004: cmp BYTE PTR [esi+eax*8-0x48],0x0
47c009: jne 0x47c095
47c00f: xor eax,eax
47c011: mov al,bl
47c013: imul eax,eax,0x16
47c016: mov BYTE PTR [esi+eax*8-0x45],0x1a
47c01b: xor eax,eax
47c01d: mov al,bl
47c01f: imul eax,eax,0x16
47c022: mov WORD PTR [esi+eax*8-0x3c],0x0
47c029: xor eax,eax
47c02b: mov al,bl
47c02d: imul eax,eax,0x16
47c030: mov WORD PTR [esi+eax*8-0x3a],0x14
47c037: xor eax,eax
47c039: mov al,bl
47c03b: imul eax,eax,0x16
47c03e: fld QWORD PTR [esi+eax*8-0x50]
47c042: fcomp DWORD PTR ds:0x47d1f8
47c048: fnstsw ax
47c04a: sahf
47c04b: jae 0x47c071
47c04d: fld DWORD PTR ds:0x47d208
47c053: mov eax,ds:0x4b0fe8
47c058: fmul QWORD PTR [eax]
47c05a: xor eax,eax
47c05c: mov al,bl
47c05e: imul eax,eax,0x16
47c061: fadd QWORD PTR [esi+eax*8-0x50]
47c065: xor eax,eax
47c067: mov al,bl
47c069: imul eax,eax,0x16
47c06c: fstp QWORD PTR [esi+eax*8-0x50]
47c070: fwait
47c071: cmp BYTE PTR [esp],0x12
47c075: jne 0x47c083
47c077: xor eax,eax
47c079: mov al,bl
47c07b: imul eax,eax,0x16
47c07e: mov BYTE PTR [esi+eax*8-0x41],0x1
47c083: cmp BYTE PTR [esp],0x13
47c087: jne 0x47c095
47c089: xor eax,eax
47c08b: mov al,bl
47c08d: imul eax,eax,0x16
47c090: mov BYTE PTR [esi+eax*8-0x41],0x2
47c095: cmp BYTE PTR [esp],0x14
47c099: je 0x47c0a5
47c09b: cmp BYTE PTR [esp],0x15
47c09f: jne 0x47c1a7
47c0a5: xor eax,eax
47c0a7: mov al,bl
47c0a9: imul eax,eax,0x16
47c0ac: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c0b1: je 0x47c0fd
47c0b3: xor eax,eax
47c0b5: mov al,bl
47c0b7: imul eax,eax,0x16
47c0ba: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c0bf: je 0x47c0fd
47c0c1: xor eax,eax
47c0c3: mov al,bl
47c0c5: imul eax,eax,0x16
47c0c8: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c0cd: je 0x47c0fd
47c0cf: xor eax,eax
47c0d1: mov al,bl
47c0d3: imul eax,eax,0x16
47c0d6: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c0db: je 0x47c0fd
47c0dd: xor eax,eax
47c0df: mov al,bl
47c0e1: imul eax,eax,0x16
47c0e4: cmp BYTE PTR [esi+eax*8-0x45],0xc
47c0e9: je 0x47c0fd
47c0eb: xor eax,eax
47c0ed: mov al,bl
47c0ef: imul eax,eax,0x16
47c0f2: cmp BYTE PTR [esi+eax*8-0x45],0x5
47c0f7: jne 0x47c1a7
47c0fd: xor eax,eax
47c0ff: mov al,bl
47c101: imul eax,eax,0x16
47c104: mov BYTE PTR [esi+eax*8-0x45],0x1b
47c109: xor eax,eax
47c10b: mov al,bl
47c10d: imul eax,eax,0x16
47c110: mov WORD PTR [esi+eax*8-0x3c],0x0
47c117: xor eax,eax
47c119: mov al,bl
47c11b: imul eax,eax,0x16
47c11e: mov WORD PTR [esi+eax*8-0x3a],0x1c
47c125: xor eax,eax
47c127: mov al,bl
47c129: imul eax,eax,0x16
47c12c: mov BYTE PTR [esi+eax*8-0x38],0x0
47c131: xor eax,eax
47c133: mov al,bl
47c135: imul eax,eax,0x16
47c138: mov BYTE PTR [esi+eax*8-0x46],0x0
47c13d: xor eax,eax
47c13f: mov al,bl
47c141: imul eax,eax,0x16
47c144: mov BYTE PTR [esi+eax*8-0x42],0x0
47c149: xor eax,eax
47c14b: mov al,bl
47c14d: imul eax,eax,0x16
47c150: fld QWORD PTR [esi+eax*8-0x50]
47c154: fcomp DWORD PTR ds:0x47d1f8
47c15a: fnstsw ax
47c15c: sahf
47c15d: jae 0x47c183
47c15f: fld DWORD PTR ds:0x47d204
47c165: mov eax,ds:0x4b0fe8
47c16a: fmul QWORD PTR [eax]
47c16c: xor eax,eax
47c16e: mov al,bl
47c170: imul eax,eax,0x16
47c173: fadd QWORD PTR [esi+eax*8-0x50]
47c177: xor eax,eax
47c179: mov al,bl
47c17b: imul eax,eax,0x16
47c17e: fstp QWORD PTR [esi+eax*8-0x50]
47c182: fwait
47c183: cmp BYTE PTR [esp],0x14
47c187: jne 0x47c195
47c189: xor eax,eax
47c18b: mov al,bl
47c18d: imul eax,eax,0x16
47c190: mov BYTE PTR [esi+eax*8-0x41],0x1
47c195: cmp BYTE PTR [esp],0x15
47c199: jne 0x47c1a7
47c19b: xor eax,eax
47c19d: mov al,bl
47c19f: imul eax,eax,0x16
47c1a2: mov BYTE PTR [esi+eax*8-0x41],0x2
47c1a7: cmp BYTE PTR [esp],0x16
47c1ab: jne 0x47c291
47c1b1: xor eax,eax
47c1b3: mov al,bl
47c1b5: imul eax,eax,0x16
47c1b8: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c1bd: je 0x47c1fb
47c1bf: xor eax,eax
47c1c1: mov al,bl
47c1c3: imul eax,eax,0x16
47c1c6: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c1cb: je 0x47c1fb
47c1cd: xor eax,eax
47c1cf: mov al,bl
47c1d1: imul eax,eax,0x16
47c1d4: cmp BYTE PTR [esi+eax*8-0x45],0x7
47c1d9: je 0x47c1fb
47c1db: xor eax,eax
47c1dd: mov al,bl
47c1df: imul eax,eax,0x16
47c1e2: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c1e7: je 0x47c1fb
47c1e9: xor eax,eax
47c1eb: mov al,bl
47c1ed: imul eax,eax,0x16
47c1f0: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c1f5: jne 0x47c291
47c1fb: xor eax,eax
47c1fd: mov al,bl
47c1ff: imul eax,eax,0x16
47c202: fld QWORD PTR [esi+eax*8-0x70]
47c206: fcomp DWORD PTR ds:0x47d20c
47c20c: fnstsw ax
47c20e: sahf
47c20f: jbe 0x47c220
47c211: xor eax,eax
47c213: mov al,bl
47c215: imul eax,eax,0x16
47c218: cmp WORD PTR [esi+eax*8-0x58],0x0
47c21e: jle 0x47c291
47c220: xor eax,eax
47c222: mov al,bl
47c224: imul eax,eax,0x16
47c227: mov BYTE PTR [esi+eax*8-0x45],0x1c
47c22c: xor eax,eax
47c22e: mov al,bl
47c230: imul eax,eax,0x16
47c233: mov WORD PTR [esi+eax*8-0x3c],0x0
47c23a: xor eax,eax
47c23c: mov al,bl
47c23e: imul eax,eax,0x16
47c241: mov WORD PTR [esi+eax*8-0x3a],0x20
47c248: xor eax,eax
47c24a: mov al,bl
47c24c: imul eax,eax,0x16
47c24f: cmp WORD PTR [esi+eax*8-0x58],0x3
47c255: jne 0x47c268
47c257: xor eax,eax
47c259: mov al,bl
47c25b: imul eax,eax,0x16
47c25e: xor edx,edx
47c260: mov DWORD PTR [esi+eax*8-0x50],edx
47c264: mov DWORD PTR [esi+eax*8-0x4c],edx
47c268: xor eax,eax
47c26a: mov al,bl
47c26c: imul eax,eax,0x16
47c26f: dec WORD PTR [esi+eax*8-0x58]
47c274: xor eax,eax
47c276: mov al,bl
47c278: imul eax,eax,0x16
47c27b: mov dl,BYTE PTR [esp+0x2]
47c27f: add dl,0x26
47c282: mov BYTE PTR [esi+eax*8-0x44],dl
47c286: mov eax,ds:0x4b1074
47c28b: mov BYTE PTR [eax],0x16
47c28e: mov BYTE PTR [edi],0x13
47c291: xor eax,eax
47c293: mov al,bl
47c295: imul eax,eax,0x16
47c298: cmp BYTE PTR [esi+eax*8-0xa0],0xd
47c2a0: jne 0x47c825
47c2a6: cmp BYTE PTR [esp],0xe
47c2aa: jne 0x47c2fe
47c2ac: xor eax,eax
47c2ae: mov al,bl
47c2b0: imul eax,eax,0x16
47c2b3: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c2b8: je 0x47c2d6
47c2ba: xor eax,eax
47c2bc: mov al,bl
47c2be: imul eax,eax,0x16
47c2c1: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c2c6: je 0x47c2d6
47c2c8: xor eax,eax
47c2ca: mov al,bl
47c2cc: imul eax,eax,0x16
47c2cf: cmp BYTE PTR [esi+eax*8-0x45],0x7
47c2d4: jne 0x47c2fe
47c2d6: xor eax,eax
47c2d8: mov al,bl
47c2da: imul eax,eax,0x16
47c2dd: mov BYTE PTR [esi+eax*8-0x45],0x17
47c2e2: xor eax,eax
47c2e4: mov al,bl
47c2e6: imul eax,eax,0x16
47c2e9: mov WORD PTR [esi+eax*8-0x3c],0x0
47c2f0: xor eax,eax
47c2f2: mov al,bl
47c2f4: imul eax,eax,0x16
47c2f7: mov WORD PTR [esi+eax*8-0x3a],0xfa
47c2fe: cmp BYTE PTR [esp],0x10
47c302: je 0x47c30e
47c304: cmp BYTE PTR [esp],0x11
47c308: jne 0x47c3e1
47c30e: xor eax,eax
47c310: mov al,bl
47c312: imul eax,eax,0x16
47c315: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c31a: je 0x47c34a
47c31c: xor eax,eax
47c31e: mov al,bl
47c320: imul eax,eax,0x16
47c323: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c328: je 0x47c34a
47c32a: xor eax,eax
47c32c: mov al,bl
47c32e: imul eax,eax,0x16
47c331: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c336: je 0x47c34a
47c338: xor eax,eax
47c33a: mov al,bl
47c33c: imul eax,eax,0x16
47c33f: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c344: jne 0x47c3e1
47c34a: mov edx,ebx
47c34c: mov al,0x1a
47c34e: call 0x476454
47c353: test al,al
47c355: jne 0x47c3e1
47c35b: xor eax,eax
47c35d: mov al,bl
47c35f: imul eax,eax,0x16
47c362: mov BYTE PTR [esi+eax*8-0x45],0x19
47c367: xor eax,eax
47c369: mov al,bl
47c36b: imul eax,eax,0x16
47c36e: mov WORD PTR [esi+eax*8-0x3c],0x0
47c375: xor eax,eax
47c377: mov al,bl
47c379: imul eax,eax,0x16
47c37c: mov WORD PTR [esi+eax*8-0x3a],0x1c
47c383: xor eax,eax
47c385: mov al,bl
47c387: imul eax,eax,0x16
47c38a: fld QWORD PTR [esi+eax*8-0x50]
47c38e: fcomp DWORD PTR ds:0x47d1f8
47c394: fnstsw ax
47c396: sahf
47c397: jae 0x47c3bd
47c399: fld DWORD PTR ds:0x47d204
47c39f: mov eax,ds:0x4b0fe8
47c3a4: fmul QWORD PTR [eax]
47c3a6: xor eax,eax
47c3a8: mov al,bl
47c3aa: imul eax,eax,0x16
47c3ad: fadd QWORD PTR [esi+eax*8-0x50]
47c3b1: xor eax,eax
47c3b3: mov al,bl
47c3b5: imul eax,eax,0x16
47c3b8: fstp QWORD PTR [esi+eax*8-0x50]
47c3bc: fwait
47c3bd: cmp BYTE PTR [esp],0x10
47c3c1: jne 0x47c3cf
47c3c3: xor eax,eax
47c3c5: mov al,bl
47c3c7: imul eax,eax,0x16
47c3ca: mov BYTE PTR [esi+eax*8-0x41],0x1
47c3cf: cmp BYTE PTR [esp],0x11
47c3d3: jne 0x47c3e1
47c3d5: xor eax,eax
47c3d7: mov al,bl
47c3d9: imul eax,eax,0x16
47c3dc: mov BYTE PTR [esi+eax*8-0x41],0x2
47c3e1: cmp BYTE PTR [esp],0x12
47c3e5: je 0x47c3f1
47c3e7: cmp BYTE PTR [esp],0x13
47c3eb: jne 0x47c504
47c3f1: xor eax,eax
47c3f3: mov al,bl
47c3f5: imul eax,eax,0x16
47c3f8: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c3fd: je 0x47c458
47c3ff: xor eax,eax
47c401: mov al,bl
47c403: imul eax,eax,0x16
47c406: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c40b: je 0x47c458
47c40d: xor eax,eax
47c40f: mov al,bl
47c411: imul eax,eax,0x16
47c414: cmp BYTE PTR [esi+eax*8-0x45],0x5
47c419: jne 0x47c42a
47c41b: xor eax,eax
47c41d: mov al,bl
47c41f: imul eax,eax,0x16
47c422: cmp WORD PTR [esi+eax*8-0x3c],0x3
47c428: jge 0x47c458
47c42a: xor eax,eax
47c42c: mov al,bl
47c42e: imul eax,eax,0x16
47c431: cmp BYTE PTR [esi+eax*8-0x45],0xc
47c436: je 0x47c458
47c438: xor eax,eax
47c43a: mov al,bl
47c43c: imul eax,eax,0x16
47c43f: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c444: je 0x47c458
47c446: xor eax,eax
47c448: mov al,bl
47c44a: imul eax,eax,0x16
47c44d: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c452: jne 0x47c504
47c458: xor eax,eax
47c45a: mov al,bl
47c45c: imul eax,eax,0x16
47c45f: mov BYTE PTR [esi+eax*8-0x45],0x1a
47c464: xor eax,eax
47c466: mov al,bl
47c468: imul eax,eax,0x16
47c46b: mov WORD PTR [esi+eax*8-0x3c],0x0
47c472: xor eax,eax
47c474: mov al,bl
47c476: imul eax,eax,0x16
47c479: mov WORD PTR [esi+eax*8-0x3a],0x10
47c480: xor eax,eax
47c482: mov al,bl
47c484: imul eax,eax,0x16
47c487: cmp BYTE PTR [esi+eax*8-0x38],0x0
47c48c: je 0x47c49a
47c48e: xor eax,eax
47c490: mov al,bl
47c492: imul eax,eax,0x16
47c495: mov BYTE PTR [esi+eax*8-0x38],0xf6
47c49a: xor eax,eax
47c49c: mov al,bl
47c49e: imul eax,eax,0x16
47c4a1: mov BYTE PTR [esi+eax*8-0x42],0x0
47c4a6: xor eax,eax
47c4a8: mov al,bl
47c4aa: imul eax,eax,0x16
47c4ad: fld QWORD PTR [esi+eax*8-0x50]
47c4b1: fcomp DWORD PTR ds:0x47d1f8
47c4b7: fnstsw ax
47c4b9: sahf
47c4ba: jae 0x47c4e0
47c4bc: fld DWORD PTR ds:0x47d204
47c4c2: mov eax,ds:0x4b0fe8
47c4c7: fmul QWORD PTR [eax]
47c4c9: xor eax,eax
47c4cb: mov al,bl
47c4cd: imul eax,eax,0x16
47c4d0: fadd QWORD PTR [esi+eax*8-0x50]
47c4d4: xor eax,eax
47c4d6: mov al,bl
47c4d8: imul eax,eax,0x16
47c4db: fstp QWORD PTR [esi+eax*8-0x50]
47c4df: fwait
47c4e0: cmp BYTE PTR [esp],0x12
47c4e4: jne 0x47c4f2
47c4e6: xor eax,eax
47c4e8: mov al,bl
47c4ea: imul eax,eax,0x16
47c4ed: mov BYTE PTR [esi+eax*8-0x41],0x1
47c4f2: cmp BYTE PTR [esp],0x13
47c4f6: jne 0x47c504
47c4f8: xor eax,eax
47c4fa: mov al,bl
47c4fc: imul eax,eax,0x16
47c4ff: mov BYTE PTR [esi+eax*8-0x41],0x2
47c504: cmp BYTE PTR [esp],0x14
47c508: je 0x47c514
47c50a: cmp BYTE PTR [esp],0x15
47c50e: jne 0x47c5e7
47c514: xor eax,eax
47c516: mov al,bl
47c518: imul eax,eax,0x16
47c51b: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c520: je 0x47c550
47c522: xor eax,eax
47c524: mov al,bl
47c526: imul eax,eax,0x16
47c529: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c52e: je 0x47c550
47c530: xor eax,eax
47c532: mov al,bl
47c534: imul eax,eax,0x16
47c537: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c53c: je 0x47c550
47c53e: xor eax,eax
47c540: mov al,bl
47c542: imul eax,eax,0x16
47c545: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c54a: jne 0x47c5e7
47c550: mov edx,ebx
47c552: mov al,0x1c
47c554: call 0x476454
47c559: test al,al
47c55b: jne 0x47c5e7
47c561: xor eax,eax
47c563: mov al,bl
47c565: imul eax,eax,0x16
47c568: mov BYTE PTR [esi+eax*8-0x45],0x1b
47c56d: xor eax,eax
47c56f: mov al,bl
47c571: imul eax,eax,0x16
47c574: mov WORD PTR [esi+eax*8-0x3c],0x0
47c57b: xor eax,eax
47c57d: mov al,bl
47c57f: imul eax,eax,0x16
47c582: mov WORD PTR [esi+eax*8-0x3a],0x1e
47c589: xor eax,eax
47c58b: mov al,bl
47c58d: imul eax,eax,0x16
47c590: fld QWORD PTR [esi+eax*8-0x50]
47c594: fcomp DWORD PTR ds:0x47d1f8
47c59a: fnstsw ax
47c59c: sahf
47c59d: jae 0x47c5c3
47c59f: fld DWORD PTR ds:0x47d204
47c5a5: mov eax,ds:0x4b0fe8
47c5aa: fmul QWORD PTR [eax]
47c5ac: xor eax,eax
47c5ae: mov al,bl
47c5b0: imul eax,eax,0x16
47c5b3: fadd QWORD PTR [esi+eax*8-0x50]
47c5b7: xor eax,eax
47c5b9: mov al,bl
47c5bb: imul eax,eax,0x16
47c5be: fstp QWORD PTR [esi+eax*8-0x50]
47c5c2: fwait
47c5c3: cmp BYTE PTR [esp],0x14
47c5c7: jne 0x47c5d5
47c5c9: xor eax,eax
47c5cb: mov al,bl
47c5cd: imul eax,eax,0x16
47c5d0: mov BYTE PTR [esi+eax*8-0x41],0x1
47c5d5: cmp BYTE PTR [esp],0x15
47c5d9: jne 0x47c5e7
47c5db: xor eax,eax
47c5dd: mov al,bl
47c5df: imul eax,eax,0x16
47c5e2: mov BYTE PTR [esi+eax*8-0x41],0x2
47c5e7: cmp BYTE PTR [esp],0x16
47c5eb: je 0x47c603
47c5ed: cmp BYTE PTR [esp],0x17
47c5f1: je 0x47c603
47c5f3: cmp BYTE PTR [esp],0x18
47c5f7: je 0x47c603
47c5f9: cmp BYTE PTR [esp],0x19
47c5fd: jne 0x47c6f7
47c603: xor eax,eax
47c605: mov al,bl
47c607: imul eax,eax,0x16
47c60a: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c60f: je 0x47c64d
47c611: xor eax,eax
47c613: mov al,bl
47c615: imul eax,eax,0x16
47c618: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c61d: je 0x47c64d
47c61f: xor eax,eax
47c621: mov al,bl
47c623: imul eax,eax,0x16
47c626: cmp BYTE PTR [esi+eax*8-0x45],0xc
47c62b: je 0x47c64d
47c62d: xor eax,eax
47c62f: mov al,bl
47c631: imul eax,eax,0x16
47c634: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c639: je 0x47c64d
47c63b: xor eax,eax
47c63d: mov al,bl
47c63f: imul eax,eax,0x16
47c642: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c647: jne 0x47c6f7
47c64d: xor eax,eax
47c64f: mov al,bl
47c651: imul eax,eax,0x16
47c654: mov BYTE PTR [esi+eax*8-0x45],0x1c
47c659: xor eax,eax
47c65b: mov al,bl
47c65d: imul eax,eax,0x16
47c660: mov WORD PTR [esi+eax*8-0x3c],0x0
47c667: xor eax,eax
47c669: mov al,bl
47c66b: imul eax,eax,0x16
47c66e: mov WORD PTR [esi+eax*8-0x3a],0x1e
47c675: xor eax,eax
47c677: mov al,bl
47c679: imul eax,eax,0x16
47c67c: fld QWORD PTR [esi+eax*8-0x50]
47c680: fcomp DWORD PTR ds:0x47d1f8
47c686: fnstsw ax
47c688: sahf
47c689: jae 0x47c6af
47c68b: fld DWORD PTR ds:0x47d204
47c691: mov eax,ds:0x4b0fe8
47c696: fmul QWORD PTR [eax]
47c698: xor eax,eax
47c69a: mov al,bl
47c69c: imul eax,eax,0x16
47c69f: fadd QWORD PTR [esi+eax*8-0x50]
47c6a3: xor eax,eax
47c6a5: mov al,bl
47c6a7: imul eax,eax,0x16
47c6aa: fstp QWORD PTR [esi+eax*8-0x50]
47c6ae: fwait
47c6af: cmp BYTE PTR [esp],0x16
47c6b3: jne 0x47c6c1
47c6b5: xor eax,eax
47c6b7: mov al,bl
47c6b9: imul eax,eax,0x16
47c6bc: mov BYTE PTR [esi+eax*8-0x41],0x1
47c6c1: cmp BYTE PTR [esp],0x17
47c6c5: jne 0x47c6d3
47c6c7: xor eax,eax
47c6c9: mov al,bl
47c6cb: imul eax,eax,0x16
47c6ce: mov BYTE PTR [esi+eax*8-0x41],0x2
47c6d3: cmp BYTE PTR [esp],0x18
47c6d7: jne 0x47c6e5
47c6d9: xor eax,eax
47c6db: mov al,bl
47c6dd: imul eax,eax,0x16
47c6e0: mov BYTE PTR [esi+eax*8-0x41],0x3
47c6e5: cmp BYTE PTR [esp],0x19
47c6e9: jne 0x47c6f7
47c6eb: xor eax,eax
47c6ed: mov al,bl
47c6ef: imul eax,eax,0x16
47c6f2: mov BYTE PTR [esi+eax*8-0x41],0x4
47c6f7: cmp BYTE PTR [esp],0x1a
47c6fb: jne 0x47c825
47c701: xor eax,eax
47c703: mov al,bl
47c705: imul eax,eax,0x16
47c708: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c70d: je 0x47c767
47c70f: xor eax,eax
47c711: mov al,bl
47c713: imul eax,eax,0x16
47c716: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c71b: je 0x47c767
47c71d: xor eax,eax
47c71f: mov al,bl
47c721: imul eax,eax,0x16
47c724: cmp BYTE PTR [esi+eax*8-0x45],0x7
47c729: je 0x47c767
47c72b: xor eax,eax
47c72d: mov al,bl
47c72f: imul eax,eax,0x16
47c732: cmp BYTE PTR [esi+eax*8-0x45],0xc
47c737: je 0x47c767
47c739: xor eax,eax
47c73b: mov al,bl
47c73d: imul eax,eax,0x16
47c740: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c745: je 0x47c767
47c747: xor eax,eax
47c749: mov al,bl
47c74b: imul eax,eax,0x16
47c74e: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c753: je 0x47c767
47c755: xor eax,eax
47c757: mov al,bl
47c759: imul eax,eax,0x16
47c75c: cmp BYTE PTR [esi+eax*8-0x45],0x1b
47c761: jne 0x47c825
47c767: xor eax,eax
47c769: mov al,bl
47c76b: imul eax,eax,0x16
47c76e: fld QWORD PTR [esi+eax*8-0x70]
47c772: fcomp DWORD PTR ds:0x47d20c
47c778: fnstsw ax
47c77a: sahf
47c77b: jbe 0x47c790
47c77d: xor eax,eax
47c77f: mov al,bl
47c781: imul eax,eax,0x16
47c784: cmp WORD PTR [esi+eax*8-0x58],0x0
47c78a: jle 0x47c825
47c790: xor eax,eax
47c792: mov al,bl
47c794: imul eax,eax,0x16
47c797: mov BYTE PTR [esi+eax*8-0x45],0x1d
47c79c: xor eax,eax
47c79e: mov al,bl
47c7a0: imul eax,eax,0x16
47c7a3: mov WORD PTR [esi+eax*8-0x3c],0x0
47c7aa: xor eax,eax
47c7ac: mov al,bl
47c7ae: imul eax,eax,0x16
47c7b1: mov WORD PTR [esi+eax*8-0x3a],0x1e
47c7b8: xor eax,eax
47c7ba: mov al,bl
47c7bc: imul eax,eax,0x16
47c7bf: mov BYTE PTR [esi+eax*8-0x46],0x0
47c7c4: xor eax,eax
47c7c6: mov al,bl
47c7c8: imul eax,eax,0x16
47c7cb: mov BYTE PTR [esi+eax*8-0x42],0x0
47c7d0: xor eax,eax
47c7d2: mov al,bl
47c7d4: imul eax,eax,0x16
47c7d7: mov BYTE PTR [esi+eax*8-0x38],0x0
47c7dc: xor eax,eax
47c7de: mov al,bl
47c7e0: imul eax,eax,0x16
47c7e3: cmp WORD PTR [esi+eax*8-0x58],0x3
47c7e9: jne 0x47c7fc
47c7eb: xor eax,eax
47c7ed: mov al,bl
47c7ef: imul eax,eax,0x16
47c7f2: xor edx,edx
47c7f4: mov DWORD PTR [esi+eax*8-0x50],edx
47c7f8: mov DWORD PTR [esi+eax*8-0x4c],edx
47c7fc: xor eax,eax
47c7fe: mov al,bl
47c800: imul eax,eax,0x16
47c803: dec WORD PTR [esi+eax*8-0x58]
47c808: xor eax,eax
47c80a: mov al,bl
47c80c: imul eax,eax,0x16
47c80f: mov dl,BYTE PTR [esp+0x2]
47c813: add dl,0x25
47c816: mov BYTE PTR [esi+eax*8-0x44],dl
47c81a: mov eax,ds:0x4b1074
47c81f: mov BYTE PTR [eax],0x16
47c822: mov BYTE PTR [edi],0x13
47c825: xor eax,eax
47c827: mov al,bl
47c829: imul eax,eax,0x16
47c82c: cmp BYTE PTR [esi+eax*8-0xa0],0xe
47c834: jne 0x47ccc1
47c83a: cmp BYTE PTR [esp],0xe
47c83e: jne 0x47c892
47c840: xor eax,eax
47c842: mov al,bl
47c844: imul eax,eax,0x16
47c847: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c84c: je 0x47c86a
47c84e: xor eax,eax
47c850: mov al,bl
47c852: imul eax,eax,0x16
47c855: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c85a: je 0x47c86a
47c85c: xor eax,eax
47c85e: mov al,bl
47c860: imul eax,eax,0x16
47c863: cmp BYTE PTR [esi+eax*8-0x45],0x7
47c868: jne 0x47c892
47c86a: xor eax,eax
47c86c: mov al,bl
47c86e: imul eax,eax,0x16
47c871: mov BYTE PTR [esi+eax*8-0x45],0x17
47c876: xor eax,eax
47c878: mov al,bl
47c87a: imul eax,eax,0x16
47c87d: mov WORD PTR [esi+eax*8-0x3c],0x0
47c884: xor eax,eax
47c886: mov al,bl
47c888: imul eax,eax,0x16
47c88b: mov WORD PTR [esi+eax*8-0x3a],0xfa
47c892: cmp BYTE PTR [esp],0x10
47c896: je 0x47c8a2
47c898: cmp BYTE PTR [esp],0x11
47c89c: jne 0x47c975
47c8a2: xor eax,eax
47c8a4: mov al,bl
47c8a6: imul eax,eax,0x16
47c8a9: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c8ae: je 0x47c8de
47c8b0: xor eax,eax
47c8b2: mov al,bl
47c8b4: imul eax,eax,0x16
47c8b7: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c8bc: je 0x47c8de
47c8be: xor eax,eax
47c8c0: mov al,bl
47c8c2: imul eax,eax,0x16
47c8c5: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c8ca: je 0x47c8de
47c8cc: xor eax,eax
47c8ce: mov al,bl
47c8d0: imul eax,eax,0x16
47c8d3: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c8d8: jne 0x47c975
47c8de: mov edx,ebx
47c8e0: mov al,0x1d
47c8e2: call 0x476454
47c8e7: test al,al
47c8e9: jne 0x47c975
47c8ef: xor eax,eax
47c8f1: mov al,bl
47c8f3: imul eax,eax,0x16
47c8f6: mov BYTE PTR [esi+eax*8-0x45],0x19
47c8fb: xor eax,eax
47c8fd: mov al,bl
47c8ff: imul eax,eax,0x16
47c902: mov WORD PTR [esi+eax*8-0x3c],0x0
47c909: xor eax,eax
47c90b: mov al,bl
47c90d: imul eax,eax,0x16
47c910: mov WORD PTR [esi+eax*8-0x3a],0x1c
47c917: xor eax,eax
47c919: mov al,bl
47c91b: imul eax,eax,0x16
47c91e: fld QWORD PTR [esi+eax*8-0x50]
47c922: fcomp DWORD PTR ds:0x47d1f8
47c928: fnstsw ax
47c92a: sahf
47c92b: jae 0x47c951
47c92d: fld DWORD PTR ds:0x47d204
47c933: mov eax,ds:0x4b0fe8
47c938: fmul QWORD PTR [eax]
47c93a: xor eax,eax
47c93c: mov al,bl
47c93e: imul eax,eax,0x16
47c941: fadd QWORD PTR [esi+eax*8-0x50]
47c945: xor eax,eax
47c947: mov al,bl
47c949: imul eax,eax,0x16
47c94c: fstp QWORD PTR [esi+eax*8-0x50]
47c950: fwait
47c951: cmp BYTE PTR [esp],0x10
47c955: jne 0x47c963
47c957: xor eax,eax
47c959: mov al,bl
47c95b: imul eax,eax,0x16
47c95e: mov BYTE PTR [esi+eax*8-0x41],0x1
47c963: cmp BYTE PTR [esp],0x11
47c967: jne 0x47c975
47c969: xor eax,eax
47c96b: mov al,bl
47c96d: imul eax,eax,0x16
47c970: mov BYTE PTR [esi+eax*8-0x41],0x2
47c975: cmp BYTE PTR [esp],0x12
47c979: je 0x47c985
47c97b: cmp BYTE PTR [esp],0x13
47c97f: jne 0x47ca1f
47c985: xor eax,eax
47c987: mov al,bl
47c989: imul eax,eax,0x16
47c98c: cmp BYTE PTR [esi+eax*8-0x45],0x1
47c991: je 0x47c9bd
47c993: xor eax,eax
47c995: mov al,bl
47c997: imul eax,eax,0x16
47c99a: cmp BYTE PTR [esi+eax*8-0x45],0x2
47c99f: je 0x47c9bd
47c9a1: xor eax,eax
47c9a3: mov al,bl
47c9a5: imul eax,eax,0x16
47c9a8: cmp BYTE PTR [esi+eax*8-0x45],0x15
47c9ad: je 0x47c9bd
47c9af: xor eax,eax
47c9b1: mov al,bl
47c9b3: imul eax,eax,0x16
47c9b6: cmp BYTE PTR [esi+eax*8-0x45],0x16
47c9bb: jne 0x47ca1f
47c9bd: xor eax,eax
47c9bf: mov al,bl
47c9c1: imul eax,eax,0x16
47c9c4: mov BYTE PTR [esi+eax*8-0x45],0x1a
47c9c9: xor eax,eax
47c9cb: mov al,bl
47c9cd: imul eax,eax,0x16
47c9d0: mov WORD PTR [esi+eax*8-0x3c],0x0
47c9d7: xor eax,eax
47c9d9: mov al,bl
47c9db: imul eax,eax,0x16
47c9de: mov WORD PTR [esi+eax*8-0x3a],0x23
47c9e5: xor eax,eax
47c9e7: mov al,bl
47c9e9: imul eax,eax,0x16
47c9ec: fld QWORD PTR [esi+eax*8-0x50]
47c9f0: fcomp DWORD PTR ds:0x47d1f8
47c9f6: fnstsw ax
47c9f8: sahf
47c9f9: jae 0x47ca1f
47c9fb: fld DWORD PTR ds:0x47d204
47ca01: mov eax,ds:0x4b0fe8
47ca06: fmul QWORD PTR [eax]
47ca08: xor eax,eax
47ca0a: mov al,bl
47ca0c: imul eax,eax,0x16
47ca0f: fadd QWORD PTR [esi+eax*8-0x50]
47ca13: xor eax,eax
47ca15: mov al,bl
47ca17: imul eax,eax,0x16
47ca1a: fstp QWORD PTR [esi+eax*8-0x50]
47ca1e: fwait
47ca1f: cmp BYTE PTR [esp],0x14
47ca23: je 0x47ca2f
47ca25: cmp BYTE PTR [esp],0x15
47ca29: jne 0x47cadf
47ca2f: xor eax,eax
47ca31: mov al,bl
47ca33: imul eax,eax,0x16
47ca36: cmp BYTE PTR [esi+eax*8-0x45],0xc
47ca3b: jne 0x47cadf
47ca41: xor eax,eax
47ca43: mov al,bl
47ca45: imul eax,eax,0x16
47ca48: mov BYTE PTR [esi+eax*8-0x45],0x1b
47ca4d: xor eax,eax
47ca4f: mov al,bl
47ca51: imul eax,eax,0x16
47ca54: mov WORD PTR [esi+eax*8-0x3c],0x0
47ca5b: xor eax,eax
47ca5d: mov al,bl
47ca5f: imul eax,eax,0x16
47ca62: mov WORD PTR [esi+eax*8-0x3a],0x23
47ca69: xor eax,eax
47ca6b: mov al,bl
47ca6d: imul eax,eax,0x16
47ca70: mov BYTE PTR [esi+eax*8-0x46],0x0
47ca75: xor eax,eax
47ca77: mov al,bl
47ca79: imul eax,eax,0x16
47ca7c: mov BYTE PTR [esi+eax*8-0x38],0x0
47ca81: xor eax,eax
47ca83: mov al,bl
47ca85: imul eax,eax,0x16
47ca88: fld QWORD PTR [esi+eax*8-0x50]
47ca8c: fcomp DWORD PTR ds:0x47d1f8
47ca92: fnstsw ax
47ca94: sahf
47ca95: jae 0x47cabb
47ca97: fld DWORD PTR ds:0x47d204
47ca9d: mov eax,ds:0x4b0fe8
47caa2: fmul QWORD PTR [eax]
47caa4: xor eax,eax
47caa6: mov al,bl
47caa8: imul eax,eax,0x16
47caab: fadd QWORD PTR [esi+eax*8-0x50]
47caaf: xor eax,eax
47cab1: mov al,bl
47cab3: imul eax,eax,0x16
47cab6: fstp QWORD PTR [esi+eax*8-0x50]
47caba: fwait
47cabb: cmp BYTE PTR [esp],0x14
47cabf: jne 0x47cacd
47cac1: xor eax,eax
47cac3: mov al,bl
47cac5: imul eax,eax,0x16
47cac8: mov BYTE PTR [esi+eax*8-0x41],0x1
47cacd: cmp BYTE PTR [esp],0x15
47cad1: jne 0x47cadf
47cad3: xor eax,eax
47cad5: mov al,bl
47cad7: imul eax,eax,0x16
47cada: mov BYTE PTR [esi+eax*8-0x41],0x2
47cadf: cmp BYTE PTR [esp],0x16
47cae3: je 0x47caef
47cae5: cmp BYTE PTR [esp],0x17
47cae9: jne 0x47cbd7
47caef: xor eax,eax
47caf1: mov al,bl
47caf3: imul eax,eax,0x16
47caf6: cmp BYTE PTR [esi+eax*8-0x45],0x1
47cafb: je 0x47cb39
47cafd: xor eax,eax
47caff: mov al,bl
47cb01: imul eax,eax,0x16
47cb04: cmp BYTE PTR [esi+eax*8-0x45],0x2
47cb09: je 0x47cb39
47cb0b: xor eax,eax
47cb0d: mov al,bl
47cb0f: imul eax,eax,0x16
47cb12: cmp BYTE PTR [esi+eax*8-0x45],0xc
47cb17: je 0x47cb39
47cb19: xor eax,eax
47cb1b: mov al,bl
47cb1d: imul eax,eax,0x16
47cb20: cmp BYTE PTR [esi+eax*8-0x45],0x15
47cb25: je 0x47cb39
47cb27: xor eax,eax
47cb29: mov al,bl
47cb2b: imul eax,eax,0x16
47cb2e: cmp BYTE PTR [esi+eax*8-0x45],0x16
47cb33: jne 0x47cbd7
47cb39: xor eax,eax
47cb3b: mov al,bl
47cb3d: imul eax,eax,0x16
47cb40: mov BYTE PTR [esi+eax*8-0x45],0x1c
47cb45: xor eax,eax
47cb47: mov al,bl
47cb49: imul eax,eax,0x16
47cb4c: mov WORD PTR [esi+eax*8-0x3c],0x0
47cb53: xor eax,eax
47cb55: mov al,bl
47cb57: imul eax,eax,0x16
47cb5a: mov WORD PTR [esi+eax*8-0x3a],0x23
47cb61: xor eax,eax
47cb63: mov al,bl
47cb65: imul eax,eax,0x16
47cb68: mov BYTE PTR [esi+eax*8-0x46],0x0
47cb6d: xor eax,eax
47cb6f: mov al,bl
47cb71: imul eax,eax,0x16
47cb74: mov BYTE PTR [esi+eax*8-0x38],0x0
47cb79: xor eax,eax
47cb7b: mov al,bl
47cb7d: imul eax,eax,0x16
47cb80: fld QWORD PTR [esi+eax*8-0x50]
47cb84: fcomp DWORD PTR ds:0x47d1f8
47cb8a: fnstsw ax
47cb8c: sahf
47cb8d: jae 0x47cbb3
47cb8f: fld DWORD PTR ds:0x47d204
47cb95: mov eax,ds:0x4b0fe8
47cb9a: fmul QWORD PTR [eax]
47cb9c: xor eax,eax
47cb9e: mov al,bl
47cba0: imul eax,eax,0x16
47cba3: fadd QWORD PTR [esi+eax*8-0x50]
47cba7: xor eax,eax
47cba9: mov al,bl
47cbab: imul eax,eax,0x16
47cbae: fstp QWORD PTR [esi+eax*8-0x50]
47cbb2: fwait
47cbb3: cmp BYTE PTR [esp],0x16
47cbb7: jne 0x47cbc5
47cbb9: xor eax,eax
47cbbb: mov al,bl
47cbbd: imul eax,eax,0x16
47cbc0: mov BYTE PTR [esi+eax*8-0x41],0x1
47cbc5: cmp BYTE PTR [esp],0x17
47cbc9: jne 0x47cbd7
47cbcb: xor eax,eax
47cbcd: mov al,bl
47cbcf: imul eax,eax,0x16
47cbd2: mov BYTE PTR [esi+eax*8-0x41],0x2
47cbd7: cmp BYTE PTR [esp],0x18
47cbdb: jne 0x47ccc1
47cbe1: xor eax,eax
47cbe3: mov al,bl
47cbe5: imul eax,eax,0x16
47cbe8: cmp BYTE PTR [esi+eax*8-0x45],0x1
47cbed: je 0x47cc2b
47cbef: xor eax,eax
47cbf1: mov al,bl
47cbf3: imul eax,eax,0x16
47cbf6: cmp BYTE PTR [esi+eax*8-0x45],0x2
47cbfb: je 0x47cc2b
47cbfd: xor eax,eax
47cbff: mov al,bl
47cc01: imul eax,eax,0x16
47cc04: cmp BYTE PTR [esi+eax*8-0x45],0x7
47cc09: je 0x47cc2b
47cc0b: xor eax,eax
47cc0d: mov al,bl
47cc0f: imul eax,eax,0x16
47cc12: cmp BYTE PTR [esi+eax*8-0x45],0x15
47cc17: je 0x47cc2b
47cc19: xor eax,eax
47cc1b: mov al,bl
47cc1d: imul eax,eax,0x16
47cc20: cmp BYTE PTR [esi+eax*8-0x45],0x16
47cc25: jne 0x47ccc1
47cc2b: xor eax,eax
47cc2d: mov al,bl
47cc2f: imul eax,eax,0x16
47cc32: fld QWORD PTR [esi+eax*8-0x70]
47cc36: fcomp DWORD PTR ds:0x47d20c
47cc3c: fnstsw ax
47cc3e: sahf
47cc3f: jbe 0x47cc50
47cc41: xor eax,eax
47cc43: mov al,bl
47cc45: imul eax,eax,0x16
47cc48: cmp WORD PTR [esi+eax*8-0x58],0x0
47cc4e: jle 0x47ccc1
47cc50: xor eax,eax
47cc52: mov al,bl
47cc54: imul eax,eax,0x16
47cc57: mov BYTE PTR [esi+eax*8-0x45],0x1d
47cc5c: xor eax,eax
47cc5e: mov al,bl
47cc60: imul eax,eax,0x16
47cc63: mov WORD PTR [esi+eax*8-0x3c],0x0
47cc6a: xor eax,eax
47cc6c: mov al,bl
47cc6e: imul eax,eax,0x16
47cc71: mov WORD PTR [esi+eax*8-0x3a],0x46
47cc78: xor eax,eax
47cc7a: mov al,bl
47cc7c: imul eax,eax,0x16
47cc7f: cmp WORD PTR [esi+eax*8-0x58],0x3
47cc85: jne 0x47cc98
47cc87: xor eax,eax
47cc89: mov al,bl
47cc8b: imul eax,eax,0x16
47cc8e: xor edx,edx
47cc90: mov DWORD PTR [esi+eax*8-0x50],edx
47cc94: mov DWORD PTR [esi+eax*8-0x4c],edx
47cc98: xor eax,eax
47cc9a: mov al,bl
47cc9c: imul eax,eax,0x16
47cc9f: dec WORD PTR [esi+eax*8-0x58]
47cca4: xor eax,eax
47cca6: mov al,bl
47cca8: imul eax,eax,0x16
47ccab: mov dl,BYTE PTR [esp+0x2]
47ccaf: add dl,0x25
47ccb2: mov BYTE PTR [esi+eax*8-0x44],dl
47ccb6: mov eax,ds:0x4b1074
47ccbb: mov BYTE PTR [eax],0x16
47ccbe: mov BYTE PTR [edi],0x13
47ccc1: xor eax,eax
47ccc3: mov al,bl
47ccc5: imul eax,eax,0x16
47ccc8: cmp BYTE PTR [esi+eax*8-0xa0],0xf
47ccd0: jne 0x47d1b7
47ccd6: cmp BYTE PTR [esp],0xe
47ccda: jne 0x47cd2e
47ccdc: xor eax,eax
47ccde: mov al,bl
47cce0: imul eax,eax,0x16
47cce3: cmp BYTE PTR [esi+eax*8-0x45],0x1
47cce8: je 0x47cd06
47ccea: xor eax,eax
47ccec: mov al,bl
47ccee: imul eax,eax,0x16
47ccf1: cmp BYTE PTR [esi+eax*8-0x45],0x2
47ccf6: je 0x47cd06
47ccf8: xor eax,eax
47ccfa: mov al,bl
47ccfc: imul eax,eax,0x16
47ccff: cmp BYTE PTR [esi+eax*8-0x45],0x7
47cd04: jne 0x47cd2e
47cd06: xor eax,eax
47cd08: mov al,bl
47cd0a: imul eax,eax,0x16
47cd0d: mov BYTE PTR [esi+eax*8-0x45],0x17
47cd12: xor eax,eax
47cd14: mov al,bl
47cd16: imul eax,eax,0x16
47cd19: mov WORD PTR [esi+eax*8-0x3c],0x0
47cd20: xor eax,eax
47cd22: mov al,bl
47cd24: imul eax,eax,0x16
47cd27: mov WORD PTR [esi+eax*8-0x3a],0xfa
47cd2e: cmp BYTE PTR [esp],0x10
47cd32: je 0x47cd3e
47cd34: cmp BYTE PTR [esp],0x11
47cd38: jne 0x47ce11
47cd3e: xor eax,eax
47cd40: mov al,bl
47cd42: imul eax,eax,0x16
47cd45: cmp BYTE PTR [esi+eax*8-0x45],0x1
47cd4a: je 0x47cd7a
47cd4c: xor eax,eax
47cd4e: mov al,bl
47cd50: imul eax,eax,0x16
47cd53: cmp BYTE PTR [esi+eax*8-0x45],0x2
47cd58: je 0x47cd7a
47cd5a: xor eax,eax
47cd5c: mov al,bl
47cd5e: imul eax,eax,0x16
47cd61: cmp BYTE PTR [esi+eax*8-0x45],0x15
47cd66: je 0x47cd7a
47cd68: xor eax,eax
47cd6a: mov al,bl
47cd6c: imul eax,eax,0x16
47cd6f: cmp BYTE PTR [esi+eax*8-0x45],0x16
47cd74: jne 0x47ce11
47cd7a: mov edx,ebx
47cd7c: mov al,0x21
47cd7e: call 0x476454
47cd83: test al,al
47cd85: jne 0x47ce11
47cd8b: xor eax,eax
47cd8d: mov al,bl
47cd8f: imul eax,eax,0x16
47cd92: mov BYTE PTR [esi+eax*8-0x45],0x19
47cd97: xor eax,eax
47cd99: mov al,bl
47cd9b: imul eax,eax,0x16
47cd9e: mov WORD PTR [esi+eax*8-0x3c],0x0
47cda5: xor eax,eax
47cda7: mov al,bl
47cda9: imul eax,eax,0x16
47cdac: mov WORD PTR [esi+eax*8-0x3a],0x1c
47cdb3: xor eax,eax
47cdb5: mov al,bl
47cdb7: imul eax,eax,0x16
47cdba: fld QWORD PTR [esi+eax*8-0x50]
47cdbe: fcomp DWORD PTR ds:0x47d1f8
47cdc4: fnstsw ax
47cdc6: sahf
47cdc7: jae 0x47cded
47cdc9: fld DWORD PTR ds:0x47d204
47cdcf: mov eax,ds:0x4b0fe8
47cdd4: fmul QWORD PTR [eax]
47cdd6: xor eax,eax
47cdd8: mov al,bl
47cdda: imul eax,eax,0x16
47cddd: fadd QWORD PTR [esi+eax*8-0x50]
47cde1: xor eax,eax
47cde3: mov al,bl
47cde5: imul eax,eax,0x16
47cde8: fstp QWORD PTR [esi+eax*8-0x50]
47cdec: fwait
47cded: cmp BYTE PTR [esp],0x10
47cdf1: jne 0x47cdff
47cdf3: xor eax,eax
47cdf5: mov al,bl
47cdf7: imul eax,eax,0x16
47cdfa: mov BYTE PTR [esi+eax*8-0x41],0x1
47cdff: cmp BYTE PTR [esp],0x11
47ce03: jne 0x47ce11
47ce05: xor eax,eax
47ce07: mov al,bl
47ce09: imul eax,eax,0x16
47ce0c: mov BYTE PTR [esi+eax*8-0x41],0x2
47ce11: cmp BYTE PTR [esp],0x12
47ce15: je 0x47ce21
47ce17: cmp BYTE PTR [esp],0x13
47ce1b: jne 0x47cee3
47ce21: xor eax,eax
47ce23: mov al,bl
47ce25: imul eax,eax,0x16
47ce28: cmp BYTE PTR [esi+eax*8-0x45],0x1
47ce2d: je 0x47ce5d
47ce2f: xor eax,eax
47ce31: mov al,bl
47ce33: imul eax,eax,0x16
47ce36: cmp BYTE PTR [esi+eax*8-0x45],0x2
47ce3b: je 0x47ce5d
47ce3d: xor eax,eax
47ce3f: mov al,bl
47ce41: imul eax,eax,0x16
47ce44: cmp BYTE PTR [esi+eax*8-0x45],0x15
47ce49: je 0x47ce5d
47ce4b: xor eax,eax
47ce4d: mov al,bl
47ce4f: imul eax,eax,0x16
47ce52: cmp BYTE PTR [esi+eax*8-0x45],0x16
47ce57: jne 0x47cee3
47ce5d: xor eax,eax
47ce5f: mov al,bl
47ce61: imul eax,eax,0x16
47ce64: mov BYTE PTR [esi+eax*8-0x45],0x1a
47ce69: xor eax,eax
47ce6b: mov al,bl
47ce6d: imul eax,eax,0x16
47ce70: mov WORD PTR [esi+eax*8-0x3c],0x0
47ce77: xor eax,eax
47ce79: mov al,bl
47ce7b: imul eax,eax,0x16
47ce7e: mov WORD PTR [esi+eax*8-0x3a],0x16
47ce85: xor eax,eax
47ce87: mov al,bl
47ce89: imul eax,eax,0x16
47ce8c: fld QWORD PTR [esi+eax*8-0x50]
47ce90: fcomp DWORD PTR ds:0x47d1f8
47ce96: fnstsw ax
47ce98: sahf
47ce99: jae 0x47cebf
47ce9b: fld DWORD PTR ds:0x47d204
47cea1: mov eax,ds:0x4b0fe8
47cea6: fmul QWORD PTR [eax]
47cea8: xor eax,eax
47ceaa: mov al,bl
47ceac: imul eax,eax,0x16
47ceaf: fadd QWORD PTR [esi+eax*8-0x50]
47ceb3: xor eax,eax
47ceb5: mov al,bl
47ceb7: imul eax,eax,0x16
47ceba: fstp QWORD PTR [esi+eax*8-0x50]
47cebe: fwait
47cebf: cmp BYTE PTR [esp],0x12
47cec3: jne 0x47ced1
47cec5: xor eax,eax
47cec7: mov al,bl
47cec9: imul eax,eax,0x16
47cecc: mov BYTE PTR [esi+eax*8-0x41],0x1
47ced1: cmp BYTE PTR [esp],0x13
47ced5: jne 0x47cee3
47ced7: xor eax,eax
47ced9: mov al,bl
47cedb: imul eax,eax,0x16
47cede: mov BYTE PTR [esi+eax*8-0x41],0x2
47cee3: cmp BYTE PTR [esp],0x14
47cee7: je 0x47cef3
47cee9: cmp BYTE PTR [esp],0x15
47ceed: jne 0x47cfde
47cef3: xor eax,eax
47cef5: mov al,bl
47cef7: imul eax,eax,0x16
47cefa: cmp BYTE PTR [esi+eax*8-0x45],0x1
47ceff: je 0x47cf4c
47cf01: xor eax,eax
47cf03: mov al,bl
47cf05: imul eax,eax,0x16
47cf08: cmp BYTE PTR [esi+eax*8-0x45],0x2
47cf0d: je 0x47cf4c
47cf0f: xor eax,eax
47cf11: mov al,bl
47cf13: imul eax,eax,0x16
47cf16: cmp BYTE PTR [esi+eax*8-0x45],0x6
47cf1b: jne 0x47cf2c
47cf1d: xor eax,eax
47cf1f: mov al,bl
47cf21: imul eax,eax,0x16
47cf24: cmp WORD PTR [esi+eax*8-0x3c],0x6
47cf2a: jge 0x47cf4c
47cf2c: xor eax,eax
47cf2e: mov al,bl
47cf30: imul eax,eax,0x16
47cf33: cmp BYTE PTR [esi+eax*8-0x45],0x15
47cf38: je 0x47cf4c
47cf3a: xor eax,eax
47cf3c: mov al,bl
47cf3e: imul eax,eax,0x16
47cf41: cmp BYTE PTR [esi+eax*8-0x45],0x16
47cf46: jne 0x47cfde
47cf4c: xor eax,eax
47cf4e: mov al,bl
47cf50: imul eax,eax,0x16
47cf53: mov BYTE PTR [esi+eax*8-0x45],0x1b
47cf58: xor eax,eax
47cf5a: mov al,bl
47cf5c: imul eax,eax,0x16
47cf5f: mov WORD PTR [esi+eax*8-0x3c],0x0
47cf66: xor eax,eax
47cf68: mov al,bl
47cf6a: imul eax,eax,0x16
47cf6d: mov WORD PTR [esi+eax*8-0x3a],0x19
47cf74: xor eax,eax
47cf76: mov al,bl
47cf78: imul eax,eax,0x16
47cf7b: mov BYTE PTR [esi+eax*8-0x46],0x0
47cf80: xor eax,eax
47cf82: mov al,bl
47cf84: imul eax,eax,0x16
47cf87: fld QWORD PTR [esi+eax*8-0x50]
47cf8b: fcomp DWORD PTR ds:0x47d1f8
47cf91: fnstsw ax
47cf93: sahf
47cf94: jae 0x47cfba
47cf96: fld DWORD PTR ds:0x47d204
47cf9c: mov eax,ds:0x4b0fe8
47cfa1: fmul QWORD PTR [eax]
47cfa3: xor eax,eax
47cfa5: mov al,bl
47cfa7: imul eax,eax,0x16
47cfaa: fadd QWORD PTR [esi+eax*8-0x50]
47cfae: xor eax,eax
47cfb0: mov al,bl
47cfb2: imul eax,eax,0x16
47cfb5: fstp QWORD PTR [esi+eax*8-0x50]
47cfb9: fwait
47cfba: cmp BYTE PTR [esp],0x14
47cfbe: jne 0x47cfcc
47cfc0: xor eax,eax
47cfc2: mov al,bl
47cfc4: imul eax,eax,0x16
47cfc7: mov BYTE PTR [esi+eax*8-0x41],0x1
47cfcc: cmp BYTE PTR [esp],0x15
47cfd0: jne 0x47cfde
47cfd2: xor eax,eax
47cfd4: mov al,bl
47cfd6: imul eax,eax,0x16
47cfd9: mov BYTE PTR [esi+eax*8-0x41],0x2
47cfde: cmp BYTE PTR [esp],0x16
47cfe2: je 0x47cfee
47cfe4: cmp BYTE PTR [esp],0x17
47cfe8: jne 0x47d0b0
47cfee: xor eax,eax
47cff0: mov al,bl
47cff2: imul eax,eax,0x16
47cff5: cmp BYTE PTR [esi+eax*8-0x45],0x1
47cffa: je 0x47d02a
47cffc: xor eax,eax
47cffe: mov al,bl
47d000: imul eax,eax,0x16
47d003: cmp BYTE PTR [esi+eax*8-0x45],0x2
47d008: je 0x47d02a
47d00a: xor eax,eax
47d00c: mov al,bl
47d00e: imul eax,eax,0x16
47d011: cmp BYTE PTR [esi+eax*8-0x45],0x15
47d016: je 0x47d02a
47d018: xor eax,eax
47d01a: mov al,bl
47d01c: imul eax,eax,0x16
47d01f: cmp BYTE PTR [esi+eax*8-0x45],0x16
47d024: jne 0x47d0b0
47d02a: xor eax,eax
47d02c: mov al,bl
47d02e: imul eax,eax,0x16
47d031: mov BYTE PTR [esi+eax*8-0x45],0x1c
47d036: xor eax,eax
47d038: mov al,bl
47d03a: imul eax,eax,0x16
47d03d: mov WORD PTR [esi+eax*8-0x3c],0x0
47d044: xor eax,eax
47d046: mov al,bl
47d048: imul eax,eax,0x16
47d04b: mov WORD PTR [esi+eax*8-0x3a],0x12
47d052: xor eax,eax
47d054: mov al,bl
47d056: imul eax,eax,0x16
47d059: fld QWORD PTR [esi+eax*8-0x50]
47d05d: fcomp DWORD PTR ds:0x47d1f8
47d063: fnstsw ax
47d065: sahf
47d066: jae 0x47d08c
47d068: fld DWORD PTR ds:0x47d204
47d06e: mov eax,ds:0x4b0fe8
47d073: fmul QWORD PTR [eax]
47d075: xor eax,eax
47d077: mov al,bl
47d079: imul eax,eax,0x16
47d07c: fadd QWORD PTR [esi+eax*8-0x50]
47d080: xor eax,eax
47d082: mov al,bl
47d084: imul eax,eax,0x16
47d087: fstp QWORD PTR [esi+eax*8-0x50]
47d08b: fwait
47d08c: cmp BYTE PTR [esp],0x16
47d090: jne 0x47d09e
47d092: xor eax,eax
47d094: mov al,bl
47d096: imul eax,eax,0x16
47d099: mov BYTE PTR [esi+eax*8-0x41],0x1
47d09e: cmp BYTE PTR [esp],0x17
47d0a2: jne 0x47d0b0
47d0a4: xor eax,eax
47d0a6: mov al,bl
47d0a8: imul eax,eax,0x16
47d0ab: mov BYTE PTR [esi+eax*8-0x41],0x2
47d0b0: cmp BYTE PTR [esp],0x18
47d0b4: jne 0x47d1b7
47d0ba: xor eax,eax
47d0bc: mov al,bl
47d0be: imul eax,eax,0x16
47d0c1: cmp BYTE PTR [esi+eax*8-0x45],0x1
47d0c6: je 0x47d121
47d0c8: xor eax,eax
47d0ca: mov al,bl
47d0cc: imul eax,eax,0x16
47d0cf: cmp BYTE PTR [esi+eax*8-0x45],0x2
47d0d4: je 0x47d121
47d0d6: xor eax,eax
47d0d8: mov al,bl
47d0da: imul eax,eax,0x16
47d0dd: cmp BYTE PTR [esi+eax*8-0x45],0x7
47d0e2: je 0x47d121
47d0e4: xor eax,eax
47d0e6: mov al,bl
47d0e8: imul eax,eax,0x16
47d0eb: cmp BYTE PTR [esi+eax*8-0x45],0x19
47d0f0: jne 0x47d101
47d0f2: xor eax,eax
47d0f4: mov al,bl
47d0f6: imul eax,eax,0x16
47d0f9: cmp WORD PTR [esi+eax*8-0x3c],0x18
47d0ff: jge 0x47d121
47d101: xor eax,eax
47d103: mov al,bl
47d105: imul eax,eax,0x16
47d108: cmp BYTE PTR [esi+eax*8-0x45],0x15
47d10d: je 0x47d121
47d10f: xor eax,eax
47d111: mov al,bl
47d113: imul eax,eax,0x16
47d116: cmp BYTE PTR [esi+eax*8-0x45],0x16
47d11b: jne 0x47d1b7
47d121: xor eax,eax
47d123: mov al,bl
47d125: imul eax,eax,0x16
47d128: fld QWORD PTR [esi+eax*8-0x70]
47d12c: fcomp DWORD PTR ds:0x47d20c
47d132: fnstsw ax
47d134: sahf
47d135: jbe 0x47d146
47d137: xor eax,eax
47d139: mov al,bl
47d13b: imul eax,eax,0x16
47d13e: cmp WORD PTR [esi+eax*8-0x58],0x0
47d144: jle 0x47d1b7
47d146: xor eax,eax
47d148: mov al,bl
47d14a: imul eax,eax,0x16
47d14d: mov BYTE PTR [esi+eax*8-0x45],0x1d
47d152: xor eax,eax
47d154: mov al,bl
47d156: imul eax,eax,0x16
47d159: mov WORD PTR [esi+eax*8-0x3c],0x0
47d160: xor eax,eax
47d162: mov al,bl
47d164: imul eax,eax,0x16
47d167: mov WORD PTR [esi+eax*8-0x3a],0x1e
47d16e: xor eax,eax
47d170: mov al,bl
47d172: imul eax,eax,0x16
47d175: cmp WORD PTR [esi+eax*8-0x58],0x3
47d17b: jne 0x47d18e
47d17d: xor eax,eax
47d17f: mov al,bl
47d181: imul eax,eax,0x16
47d184: xor edx,edx
47d186: mov DWORD PTR [esi+eax*8-0x50],edx
47d18a: mov DWORD PTR [esi+eax*8-0x4c],edx
47d18e: xor eax,eax
47d190: mov al,bl
47d192: imul eax,eax,0x16
47d195: dec WORD PTR [esi+eax*8-0x58]
47d19a: xor eax,eax
47d19c: mov al,bl
47d19e: imul eax,eax,0x16
47d1a1: mov dl,BYTE PTR [esp+0x2]
47d1a5: add dl,0xc
47d1a8: mov BYTE PTR [esi+eax*8-0x44],dl
47d1ac: mov eax,ds:0x4b1074
47d1b1: mov BYTE PTR [eax],0x16
47d1b4: mov BYTE PTR [edi],0x13
47d1b7: xor eax,eax
47d1b9: mov al,bl
47d1bb: imul eax,eax,0x16
47d1be: cmp BYTE PTR [esi+eax*8-0x45],0x2
47d1c3: jne 0x47d1ee
47d1c5: xor eax,eax
47d1c7: mov al,bl
47d1c9: imul eax,eax,0x16
47d1cc: inc WORD PTR [esi+eax*8-0x3c]
47d1d1: xor eax,eax
47d1d3: mov al,bl
47d1d5: imul eax,eax,0x16
47d1d8: cmp WORD PTR [esi+eax*8-0x3c],0x10
47d1de: jle 0x47d1ee
47d1e0: xor eax,eax
47d1e2: mov al,bl
47d1e4: imul eax,eax,0x16
47d1e7: mov WORD PTR [esi+eax*8-0x3c],0x0
47d1ee: add esp,0xc
47d1f1: pop ebp
47d1f2: pop edi
47d1f3: pop esi
47d1f4: pop ebx
47d1f5: ret
.data 4b0ef0 e8444b000c204b0030b8
.data 4b1098 09584b0078b640005472
.data 47d1f8 0000cc420000803f0000
.data 47d1fc 0000803f000000400000
.data 4b0fe8 90584b00d0264b00e061
.data 47d200 000000400000a0400000
.data 47d204 0000a0400000c0400000
.data 4b11f8 98444b00db444b004027
.data 47d208 0000c040000070410000
.data 47d20c 000070410000e0400000
.data 4b1074 f8574b00c8274b00d470
.data 47d210 0000e0400000a0410000
.data 47d214 0000a041000048435356
.data 4b11b4 c8444b00a0b640003470
.data 47d218 000048435356575583c4
