; entry 49a3f4
49a3f4: push ebx
49a3f5: push esi
49a3f6: push edi
49a3f7: push ebp
49a3f8: add esp,0xfffffff4
49a3fb: mov ebx,eax
49a3fd: mov esi,DWORD PTR ds:0x4b0ef0
49a403: mov edi,DWORD PTR ds:0x4b1094
49a409: mov ebp,DWORD PTR ds:0x4b11b4
49a40f: mov eax,ds:0x4b1124
49a414: cmp BYTE PTR [eax],0x1
49a417: je 0x49a431
49a419: mov eax,ds:0x4b1124
49a41e: cmp BYTE PTR [eax],0x5
49a421: je 0x49a431
49a423: mov eax,ds:0x4b1124
49a428: cmp BYTE PTR [eax],0x6
49a42b: jne 0x49a587
49a431: cmp BYTE PTR [esi+0x10],0x1
49a435: je 0x49a587
49a43b: cmp BYTE PTR [esi+0xc0],0x1
49a442: je 0x49a587
49a448: mov eax,ds:0x4b1144
49a44d: mov edx,0x101
49a452: sub edx,DWORD PTR [eax]
49a454: push edx
49a455: push 0x0
49a457: mov eax,DWORD PTR [ebx+0x308]
49a45d: mov eax,DWORD PTR [eax+0x28]
49a460: xor edx,edx
49a462: call 0x461dcc
49a467: mov ecx,0xe6
49a46c: sub ecx,DWORD PTR [ebp+0x0]
49a46f: mov edx,DWORD PTR [ebx+0x2d0]
49a475: mov edx,DWORD PTR [edx+0x270]
49a47b: call 0x46161c
49a480: cmp BYTE PTR [edi],0x8
49a483: jae 0x49a4bd
49a485: mov eax,ds:0x4b1144
49a48a: mov edx,0x82
49a48f: sub edx,DWORD PTR [eax]
49a491: push edx
49a492: push 0x0
49a494: mov eax,DWORD PTR [ebx+0x338]
49a49a: mov eax,DWORD PTR [eax+0x28]
49a49d: xor edx,edx
49a49f: call 0x461dcc
49a4a4: mov ecx,0xf0
49a4a9: sub ecx,DWORD PTR [ebp+0x0]
49a4ac: mov edx,DWORD PTR [ebx+0x2d0]
49a4b2: mov edx,DWORD PTR [edx+0x270]
49a4b8: call 0x46161c
49a4bd: cmp BYTE PTR [edi],0x8
49a4c0: jb 0x49a502
49a4c2: cmp BYTE PTR [edi],0x10
49a4c5: jae 0x49a502
49a4c7: mov eax,ds:0x4b1144
49a4cc: mov edx,0x82
49a4d1: sub edx,DWORD PTR [eax]
49a4d3: push edx
49a4d4: push 0x0
49a4d6: mov eax,DWORD PTR [ebx+0x338]
49a4dc: mov eax,DWORD PTR [eax+0x28]
49a4df: mov edx,0x1
49a4e4: call 0x461dcc
49a4e9: mov ecx,0xdc
49a4ee: sub ecx,DWORD PTR [ebp+0x0]
49a4f1: mov edx,DWORD PTR [ebx+0x2d0]
49a4f7: mov edx,DWORD PTR [edx+0x270]
49a4fd: call 0x46161c
49a502: cmp BYTE PTR [edi],0x10
49a505: jb 0x49a547
49a507: cmp BYTE PTR [edi],0x18
49a50a: jae 0x49a547
49a50c: mov eax,ds:0x4b1144
49a511: mov edx,0x82
49a516: sub edx,DWORD PTR [eax]
49a518: push edx
49a519: push 0x0
49a51b: mov eax,DWORD PTR [ebx+0x338]
49a521: mov eax,DWORD PTR [eax+0x28]
49a524: mov edx,0x2
49a529: call 0x461dcc
49a52e: mov ecx,0xf0
49a533: sub ecx,DWORD PTR [ebp+0x0]
49a536: mov edx,DWORD PTR [ebx+0x2d0]
49a53c: mov edx,DWORD PTR [edx+0x270]
49a542: call 0x46161c
49a547: cmp BYTE PTR [edi],0x18
49a54a: jb 0x49a587
49a54c: mov eax,ds:0x4b1144
49a551: mov edx,0x82
49a556: sub edx,DWORD PTR [eax]
49a558: push edx
49a559: push 0x0
49a55b: mov eax,DWORD PTR [ebx+0x338]
49a561: mov eax,DWORD PTR [eax+0x28]
49a564: mov edx,0x3
49a569: call 0x461dcc
49a56e: mov ecx,0xf0
49a573: sub ecx,DWORD PTR [ebp+0x0]
49a576: mov edx,DWORD PTR [ebx+0x2d0]
49a57c: mov edx,DWORD PTR [edx+0x270]
49a582: call 0x46161c
49a587: mov eax,ds:0x4b1124
49a58c: cmp BYTE PTR [eax],0x1
49a58f: je 0x49a5a9
49a591: mov eax,ds:0x4b1124
49a596: cmp BYTE PTR [eax],0x2
49a599: je 0x49a5a9
49a59b: mov eax,ds:0x4b1124
49a5a0: cmp BYTE PTR [eax],0x6
49a5a3: jne 0x49a678
49a5a9: cmp BYTE PTR [esi+0x10],0x3
49a5ad: je 0x49a678
49a5b3: cmp BYTE PTR [esi+0xc0],0x3
49a5ba: je 0x49a678
49a5c0: mov eax,ds:0x4b1144
49a5c5: mov edx,0x104
49a5ca: sub edx,DWORD PTR [eax]
49a5cc: push edx
49a5cd: push 0x0
49a5cf: mov eax,DWORD PTR [ebx+0x308]
49a5d5: mov eax,DWORD PTR [eax+0x28]
49a5d8: xor edx,edx
49a5da: call 0x461dcc
49a5df: mov ecx,0x181
49a5e4: sub ecx,DWORD PTR [ebp+0x0]
49a5e7: mov edx,DWORD PTR [ebx+0x2d0]
49a5ed: mov edx,DWORD PTR [edx+0x270]
49a5f3: call 0x46161c
49a5f8: cmp BYTE PTR [edi],0xa
49a5fb: jae 0x49a638
49a5fd: mov eax,ds:0x4b1144
49a602: mov edx,0xa0
49a607: sub edx,DWORD PTR [eax]
49a609: push edx
49a60a: push 0x0
49a60c: mov eax,DWORD PTR [ebx+0x338]
49a612: mov eax,DWORD PTR [eax+0x28]
49a615: mov edx,0x4
49a61a: call 0x461dcc
49a61f: mov ecx,0x190
49a624: sub ecx,DWORD PTR [ebp+0x0]
49a627: mov edx,DWORD PTR [ebx+0x2d0]
49a62d: mov edx,DWORD PTR [edx+0x270]
49a633: call 0x46161c
49a638: cmp BYTE PTR [edi],0xa
49a63b: jb 0x49a678
49a63d: mov eax,ds:0x4b1144
49a642: mov edx,0x9f
49a647: sub edx,DWORD PTR [eax]
49a649: push edx
49a64a: push 0x0
49a64c: mov eax,DWORD PTR [ebx+0x338]
49a652: mov eax,DWORD PTR [eax+0x28]
49a655: mov edx,0x5
49a65a: call 0x461dcc
49a65f: mov ecx,0x191
49a664: sub ecx,DWORD PTR [ebp+0x0]
49a667: mov edx,DWORD PTR [ebx+0x2d0]
49a66d: mov edx,DWORD PTR [edx+0x270]
49a673: call 0x46161c
49a678: mov eax,ds:0x4b1124
49a67d: cmp BYTE PTR [eax],0x1
49a680: jne 0x49a6cc
49a682: cmp BYTE PTR [esi+0x10],0x9
49a686: je 0x49a6cc
49a688: cmp BYTE PTR [esi+0xc0],0x9
49a68f: je 0x49a6cc
49a691: mov eax,ds:0x4b1144
49a696: mov edx,0x15
49a69b: sub edx,DWORD PTR [eax]
49a69d: push edx
49a69e: push 0x0
49a6a0: mov eax,DWORD PTR [ebx+0x338]
49a6a6: mov eax,DWORD PTR [eax+0x28]
49a6a9: mov edx,0xb
49a6ae: call 0x461dcc
49a6b3: mov ecx,0xfa
49a6b8: sub ecx,DWORD PTR [ebp+0x0]
49a6bb: mov edx,DWORD PTR [ebx+0x2d0]
49a6c1: mov edx,DWORD PTR [edx+0x270]
49a6c7: call 0x46161c
49a6cc: mov eax,ds:0x4b1124
49a6d1: cmp BYTE PTR [eax],0x1
49a6d4: jne 0x49a75c
49a6da: cmp BYTE PTR [esi+0x10],0x4
49a6de: je 0x49a75c
49a6e0: cmp BYTE PTR [esi+0xc0],0x4
49a6e7: je 0x49a75c
49a6e9: mov eax,ds:0x4b1144
49a6ee: mov edx,0xfa
49a6f3: sub edx,DWORD PTR [eax]
49a6f5: push edx
49a6f6: push 0x0
49a6f8: mov eax,DWORD PTR [ebx+0x308]
49a6fe: mov eax,DWORD PTR [eax+0x28]
49a701: xor edx,edx
49a703: call 0x461dcc
49a708: mov ecx,0x54
49a70d: sub ecx,DWORD PTR [ebp+0x0]
49a710: mov edx,DWORD PTR [ebx+0x2d0]
49a716: mov edx,DWORD PTR [edx+0x270]
49a71c: call 0x46161c
49a721: mov eax,ds:0x4b1144
49a726: mov edx,0x84
49a72b: sub edx,DWORD PTR [eax]
49a72d: push edx
49a72e: push 0x0
49a730: mov eax,DWORD PTR [ebx+0x338]
49a736: mov eax,DWORD PTR [eax+0x28]
49a739: mov edx,0xf
49a73e: call 0x461dcc
49a743: mov ecx,0x4e
49a748: sub ecx,DWORD PTR [ebp+0x0]
49a74b: mov edx,DWORD PTR [ebx+0x2d0]
49a751: mov edx,DWORD PTR [edx+0x270]
49a757: call 0x46161c
49a75c: mov eax,ds:0x4b1124
49a761: cmp BYTE PTR [eax],0x1
49a764: jne 0x49a8c3
49a76a: cmp BYTE PTR [esi+0x10],0x2
49a76e: je 0x49a8c3
49a774: cmp BYTE PTR [esi+0xc0],0x2
49a77b: je 0x49a8c3
49a781: mov eax,ds:0x4b1144
49a786: mov edx,0xff
49a78b: sub edx,DWORD PTR [eax]
49a78d: push edx
49a78e: push 0x0
49a790: mov eax,DWORD PTR [ebx+0x308]
49a796: mov eax,DWORD PTR [eax+0x28]
49a799: xor edx,edx
49a79b: call 0x461dcc
49a7a0: mov ecx,0x1d6
49a7a5: sub ecx,DWORD PTR [ebp+0x0]
49a7a8: mov edx,DWORD PTR [ebx+0x2d0]
49a7ae: mov edx,DWORD PTR [edx+0x270]
49a7b4: call 0x46161c
49a7b9: cmp BYTE PTR [edi],0x8
49a7bc: jae 0x49a7f9
49a7be: mov eax,ds:0x4b1144
49a7c3: mov edx,0x8a
49a7c8: sub edx,DWORD PTR [eax]
49a7ca: push edx
49a7cb: push 0x0
49a7cd: mov eax,DWORD PTR [ebx+0x338]
49a7d3: mov eax,DWORD PTR [eax+0x28]
49a7d6: mov edx,0x1b
49a7db: call 0x461dcc
49a7e0: mov ecx,0x1e3
49a7e5: sub ecx,DWORD PTR [ebp+0x0]
49a7e8: mov edx,DWORD PTR [ebx+0x2d0]
49a7ee: mov edx,DWORD PTR [edx+0x270]
49a7f4: call 0x46161c
49a7f9: cmp BYTE PTR [edi],0x8
49a7fc: jb 0x49a83e
49a7fe: cmp BYTE PTR [edi],0x10
49a801: jae 0x49a83e
49a803: mov eax,ds:0x4b1144
49a808: mov edx,0x8b
49a80d: sub edx,DWORD PTR [eax]
49a80f: push edx
49a810: push 0x0
49a812: mov eax,DWORD PTR [ebx+0x338]
49a818: mov eax,DWORD PTR [eax+0x28]
49a81b: mov edx,0x1c
49a820: call 0x461dcc
49a825: mov ecx,0x1e7
49a82a: sub ecx,DWORD PTR [ebp+0x0]
49a82d: mov edx,DWORD PTR [ebx+0x2d0]
49a833: mov edx,DWORD PTR [edx+0x270]
49a839: call 0x46161c
49a83e: cmp BYTE PTR [edi],0x10
49a841: jb 0x49a883
49a843: cmp BYTE PTR [edi],0x18
49a846: jae 0x49a883
49a848: mov eax,ds:0x4b1144
49a84d: mov edx,0x8a
49a852: sub edx,DWORD PTR [eax]
49a854: push edx
49a855: push 0x0
49a857: mov eax,DWORD PTR [ebx+0x338]
49a85d: mov eax,DWORD PTR [eax+0x28]
49a860: mov edx,0x1b
49a865: call 0x461dcc
49a86a: mov ecx,0x1e3
49a86f: sub ecx,DWORD PTR [ebp+0x0]
49a872: mov edx,DWORD PTR [ebx+0x2d0]
49a878: mov edx,DWORD PTR [edx+0x270]
49a87e: call 0x46161c
49a883: cmp BYTE PTR [edi],0x18
49a886: jb 0x49a8c3
49a888: mov eax,ds:0x4b1144
49a88d: mov edx,0x8b
49a892: sub edx,DWORD PTR [eax]
49a894: push edx
49a895: push 0x0
49a897: mov eax,DWORD PTR [ebx+0x338]
49a89d: mov eax,DWORD PTR [eax+0x28]
49a8a0: mov edx,0x1c
49a8a5: call 0x461dcc
49a8aa: mov ecx,0x1e7
49a8af: sub ecx,DWORD PTR [ebp+0x0]
49a8b2: mov edx,DWORD PTR [ebx+0x2d0]
49a8b8: mov edx,DWORD PTR [edx+0x270]
49a8be: call 0x46161c
49a8c3: mov eax,ds:0x4b1124
49a8c8: cmp BYTE PTR [eax],0x1
49a8cb: jne 0x49aa13
49a8d1: mov eax,ds:0x4b1144
49a8d6: mov edx,0xff
49a8db: sub edx,DWORD PTR [eax]
49a8dd: push edx
49a8de: push 0x0
49a8e0: mov eax,DWORD PTR [ebx+0x308]
49a8e6: mov eax,DWORD PTR [eax+0x28]
49a8e9: xor edx,edx
49a8eb: call 0x461dcc
49a8f0: mov ecx,0xa0
49a8f5: sub ecx,DWORD PTR [ebp+0x0]
49a8f8: mov edx,DWORD PTR [ebx+0x2d0]
49a8fe: mov edx,DWORD PTR [edx+0x270]
49a904: call 0x46161c
49a909: cmp BYTE PTR [edi],0x8
49a90c: jae 0x49a949
49a90e: mov eax,ds:0x4b1144
49a913: mov edx,0x8a
49a918: sub edx,DWORD PTR [eax]
49a91a: push edx
49a91b: push 0x0
49a91d: mov eax,DWORD PTR [ebx+0x338]
49a923: mov eax,DWORD PTR [eax+0x28]
49a926: mov edx,0x38
49a92b: call 0x461dcc
49a930: mov ecx,0xb4
49a935: sub ecx,DWORD PTR [ebp+0x0]
49a938: mov edx,DWORD PTR [ebx+0x2d0]
49a93e: mov edx,DWORD PTR [edx+0x270]
49a944: call 0x46161c
49a949: cmp BYTE PTR [edi],0x8
49a94c: jb 0x49a98e
49a94e: cmp BYTE PTR [edi],0x10
49a951: jae 0x49a98e
49a953: mov eax,ds:0x4b1144
49a958: mov edx,0x8a
49a95d: sub edx,DWORD PTR [eax]
49a95f: push edx
49a960: push 0x0
49a962: mov eax,DWORD PTR [ebx+0x338]
49a968: mov eax,DWORD PTR [eax+0x28]
49a96b: mov edx,0x39
49a970: call 0x461dcc
49a975: mov ecx,0xb4
49a97a: sub ecx,DWORD PTR [ebp+0x0]
49a97d: mov edx,DWORD PTR [ebx+0x2d0]
49a983: mov edx,DWORD PTR [edx+0x270]
49a989: call 0x46161c
49a98e: cmp BYTE PTR [edi],0x10
49a991: jb 0x49a9d3
49a993: cmp BYTE PTR [edi],0x18
49a996: jae 0x49a9d3
49a998: mov eax,ds:0x4b1144
49a99d: mov edx,0x8a
49a9a2: sub edx,DWORD PTR [eax]
49a9a4: push edx
49a9a5: push 0x0
49a9a7: mov eax,DWORD PTR [ebx+0x338]
49a9ad: mov eax,DWORD PTR [eax+0x28]
49a9b0: mov edx,0x3a
49a9b5: call 0x461dcc
49a9ba: mov ecx,0xb4
49a9bf: sub ecx,DWORD PTR [ebp+0x0]
49a9c2: mov edx,DWORD PTR [ebx+0x2d0]
49a9c8: mov edx,DWORD PTR [edx+0x270]
49a9ce: call 0x46161c
49a9d3: cmp BYTE PTR [edi],0x18
49a9d6: jb 0x49aa13
49a9d8: mov eax,ds:0x4b1144
49a9dd: mov edx,0x8a
49a9e2: sub edx,DWORD PTR [eax]
49a9e4: push edx
49a9e5: push 0x0
49a9e7: mov eax,DWORD PTR [ebx+0x338]
49a9ed: mov eax,DWORD PTR [eax+0x28]
49a9f0: mov edx,0x39
49a9f5: call 0x461dcc
49a9fa: mov ecx,0xb4
49a9ff: sub ecx,DWORD PTR [ebp+0x0]
49aa02: mov edx,DWORD PTR [ebx+0x2d0]
49aa08: mov edx,DWORD PTR [edx+0x270]
49aa0e: call 0x46161c
49aa13: mov eax,ds:0x4b1124
49aa18: cmp BYTE PTR [eax],0x2
49aa1b: jne 0x49aab8
49aa21: cmp BYTE PTR [esi+0x10],0x2
49aa25: je 0x49aab8
49aa2b: cmp BYTE PTR [esi+0xc0],0x2
49aa32: je 0x49aab8
49aa38: cmp BYTE PTR [edi],0x8
49aa3b: jae 0x49aa78
49aa3d: mov eax,ds:0x4b1144
49aa42: mov edx,0x9b
49aa47: sub edx,DWORD PTR [eax]
49aa49: push edx
49aa4a: push 0x0
49aa4c: mov eax,DWORD PTR [ebx+0x338]
49aa52: mov eax,DWORD PTR [eax+0x28]
49aa55: mov edx,0x9
49aa5a: call 0x461dcc
49aa5f: mov ecx,0xaa
49aa64: sub ecx,DWORD PTR [ebp+0x0]
49aa67: mov edx,DWORD PTR [ebx+0x2d0]
49aa6d: mov edx,DWORD PTR [edx+0x270]
49aa73: call 0x46161c
49aa78: cmp BYTE PTR [edi],0x8
49aa7b: jb 0x49aab8
49aa7d: mov eax,ds:0x4b1144
49aa82: mov edx,0x9b
49aa87: sub edx,DWORD PTR [eax]
49aa89: push edx
49aa8a: push 0x0
49aa8c: mov eax,DWORD PTR [ebx+0x338]
49aa92: mov eax,DWORD PTR [eax+0x28]
49aa95: mov edx,0xa
49aa9a: call 0x461dcc
49aa9f: mov ecx,0xaa
49aaa4: sub ecx,DWORD PTR [ebp+0x0]
49aaa7: mov edx,DWORD PTR [ebx+0x2d0]
49aaad: mov edx,DWORD PTR [edx+0x270]
49aab3: call 0x46161c
49aab8: mov eax,ds:0x4b1124
49aabd: cmp BYTE PTR [eax],0x2
49aac0: jne 0x49ab95
49aac6: cmp BYTE PTR [esi+0x10],0xe
49aaca: je 0x49ab95
49aad0: cmp BYTE PTR [esi+0xc0],0xe
49aad7: je 0x49ab95
49aadd: mov eax,ds:0x4b1144
49aae2: mov edx,0x102
49aae7: sub edx,DWORD PTR [eax]
49aae9: push edx
49aaea: push 0x0
49aaec: mov eax,DWORD PTR [ebx+0x308]
49aaf2: mov eax,DWORD PTR [eax+0x28]
49aaf5: xor edx,edx
49aaf7: call 0x461dcc
49aafc: mov ecx,0x136
49ab01: sub ecx,DWORD PTR [ebp+0x0]
49ab04: mov edx,DWORD PTR [ebx+0x2d0]
49ab0a: mov edx,DWORD PTR [edx+0x270]
49ab10: call 0x46161c
49ab15: cmp BYTE PTR [edi],0xf
49ab18: ja 0x49ab55
49ab1a: mov eax,ds:0x4b1144
49ab1f: mov edx,0x9b
49ab24: sub edx,DWORD PTR [eax]
49ab26: push edx
49ab27: push 0x0
49ab29: mov eax,DWORD PTR [ebx+0x338]
49ab2f: mov eax,DWORD PTR [eax+0x28]
49ab32: mov edx,0x3b
49ab37: call 0x461dcc
49ab3c: mov ecx,0x140
49ab41: sub ecx,DWORD PTR [ebp+0x0]
49ab44: mov edx,DWORD PTR [ebx+0x2d0]
49ab4a: mov edx,DWORD PTR [edx+0x270]
49ab50: call 0x46161c
49ab55: cmp BYTE PTR [edi],0xf
49ab58: jbe 0x49ab95
49ab5a: mov eax,ds:0x4b1144
49ab5f: mov edx,0x9b
49ab64: sub edx,DWORD PTR [eax]
49ab66: push edx
49ab67: push 0x0
49ab69: mov eax,DWORD PTR [ebx+0x338]
49ab6f: mov eax,DWORD PTR [eax+0x28]
49ab72: mov edx,0x3c
49ab77: call 0x461dcc
49ab7c: mov ecx,0x140
49ab81: sub ecx,DWORD PTR [ebp+0x0]
49ab84: mov edx,DWORD PTR [ebx+0x2d0]
49ab8a: mov edx,DWORD PTR [edx+0x270]
49ab90: call 0x46161c
49ab95: mov eax,ds:0x4b1124
49ab9a: cmp BYTE PTR [eax],0x3
49ab9d: jne 0x49acfc
49aba3: cmp BYTE PTR [esi+0x10],0x5
49aba7: je 0x49acfc
49abad: cmp BYTE PTR [esi+0xc0],0x5
49abb4: je 0x49acfc
49abba: mov eax,ds:0x4b1144
49abbf: mov edx,0x104
49abc4: sub edx,DWORD PTR [eax]
49abc6: push edx
49abc7: push 0x0
49abc9: mov eax,DWORD PTR [ebx+0x308]
49abcf: mov eax,DWORD PTR [eax+0x28]
49abd2: xor edx,edx
49abd4: call 0x461dcc
49abd9: mov ecx,0xd7
49abde: sub ecx,DWORD PTR [ebp+0x0]
49abe1: mov edx,DWORD PTR [ebx+0x2d0]
49abe7: mov edx,DWORD PTR [edx+0x270]
49abed: call 0x46161c
49abf2: cmp BYTE PTR [edi],0x8
49abf5: jae 0x49ac32
49abf7: mov eax,ds:0x4b1144
49abfc: mov edx,0x8c
49ac01: sub edx,DWORD PTR [eax]
49ac03: push edx
49ac04: push 0x0
49ac06: mov eax,DWORD PTR [ebx+0x338]
49ac0c: mov eax,DWORD PTR [eax+0x28]
49ac0f: mov edx,0x6
49ac14: call 0x461dcc
49ac19: mov ecx,0xe6
49ac1e: sub ecx,DWORD PTR [ebp+0x0]
49ac21: mov edx,DWORD PTR [ebx+0x2d0]
49ac27: mov edx,DWORD PTR [edx+0x270]
49ac2d: call 0x46161c
49ac32: cmp BYTE PTR [edi],0x8
49ac35: jb 0x49ac77
49ac37: cmp BYTE PTR [edi],0x10
49ac3a: jae 0x49ac77
49ac3c: mov eax,ds:0x4b1144
49ac41: mov edx,0x8c
49ac46: sub edx,DWORD PTR [eax]
49ac48: push edx
49ac49: push 0x0
49ac4b: mov eax,DWORD PTR [ebx+0x338]
49ac51: mov eax,DWORD PTR [eax+0x28]
49ac54: mov edx,0x7
49ac59: call 0x461dcc
49ac5e: mov ecx,0xe6
49ac63: sub ecx,DWORD PTR [ebp+0x0]
49ac66: mov edx,DWORD PTR [ebx+0x2d0]
49ac6c: mov edx,DWORD PTR [edx+0x270]
49ac72: call 0x46161c
49ac77: cmp BYTE PTR [edi],0x10
49ac7a: jb 0x49acbc
49ac7c: cmp BYTE PTR [edi],0x18
49ac7f: jae 0x49acbc
49ac81: mov eax,ds:0x4b1144
49ac86: mov edx,0x8c
49ac8b: sub edx,DWORD PTR [eax]
49ac8d: push edx
49ac8e: push 0x0
49ac90: mov eax,DWORD PTR [ebx+0x338]
49ac96: mov eax,DWORD PTR [eax+0x28]
49ac99: mov edx,0x6
49ac9e: call 0x461dcc
49aca3: mov ecx,0xe6
49aca8: sub ecx,DWORD PTR [ebp+0x0]
49acab: mov edx,DWORD PTR [ebx+0x2d0]
49acb1: mov edx,DWORD PTR [edx+0x270]
49acb7: call 0x46161c
49acbc: cmp BYTE PTR [edi],0x18
49acbf: jb 0x49acfc
49acc1: mov eax,ds:0x4b1144
49acc6: mov edx,0x8c
49accb: sub edx,DWORD PTR [eax]
49accd: push edx
49acce: push 0x0
49acd0: mov eax,DWORD PTR [ebx+0x338]
49acd6: mov eax,DWORD PTR [eax+0x28]
49acd9: mov edx,0x7
49acde: call 0x461dcc
49ace3: mov ecx,0xe6
49ace8: sub ecx,DWORD PTR [ebp+0x0]
49aceb: mov edx,DWORD PTR [ebx+0x2d0]
49acf1: mov edx,DWORD PTR [edx+0x270]
49acf7: call 0x46161c
49acfc: mov eax,ds:0x4b1124
49ad01: cmp BYTE PTR [eax],0x3
49ad04: jne 0x49add9
49ad0a: cmp BYTE PTR [esi+0x10],0x4
49ad0e: je 0x49add9
49ad14: cmp BYTE PTR [esi+0xc0],0x4
49ad1b: je 0x49add9
49ad21: mov eax,ds:0x4b1144
49ad26: mov edx,0xf0
49ad2b: sub edx,DWORD PTR [eax]
49ad2d: push edx
49ad2e: push 0x0
49ad30: mov eax,DWORD PTR [ebx+0x308]
49ad36: mov eax,DWORD PTR [eax+0x28]
49ad39: xor edx,edx
49ad3b: call 0x461dcc
49ad40: mov ecx,0x3e
49ad45: sub ecx,DWORD PTR [ebp+0x0]
49ad48: mov edx,DWORD PTR [ebx+0x2d0]
49ad4e: mov edx,DWORD PTR [edx+0x270]
49ad54: call 0x46161c
49ad59: cmp BYTE PTR [edi],0xf
49ad5c: jae 0x49ad99
49ad5e: mov eax,ds:0x4b1144
49ad63: mov edx,0xbe
49ad68: sub edx,DWORD PTR [eax]
49ad6a: push edx
49ad6b: push 0x0
49ad6d: mov eax,DWORD PTR [ebx+0x338]
49ad73: mov eax,DWORD PTR [eax+0x28]
49ad76: mov edx,0x3d
49ad7b: call 0x461dcc
49ad80: mov ecx,0x3c
49ad85: sub ecx,DWORD PTR [ebp+0x0]
49ad88: mov edx,DWORD PTR [ebx+0x2d0]
49ad8e: mov edx,DWORD PTR [edx+0x270]
49ad94: call 0x46161c
49ad99: cmp BYTE PTR [edi],0xf
49ad9c: jb 0x49add9
49ad9e: mov eax,ds:0x4b1144
49ada3: mov edx,0xbd
49ada8: sub edx,DWORD PTR [eax]
49adaa: push edx
49adab: push 0x0
49adad: mov eax,DWORD PTR [ebx+0x338]
49adb3: mov eax,DWORD PTR [eax+0x28]
49adb6: mov edx,0x3e
49adbb: call 0x461dcc
49adc0: mov ecx,0x37
49adc5: sub ecx,DWORD PTR [ebp+0x0]
49adc8: mov edx,DWORD PTR [ebx+0x2d0]
49adce: mov edx,DWORD PTR [edx+0x270]
49add4: call 0x46161c
49add9: mov eax,ds:0x4b1124
49adde: cmp BYTE PTR [eax],0x4
49ade1: jne 0x49af40
49ade7: cmp BYTE PTR [esi+0x10],0x2
49adeb: je 0x49af40
49adf1: cmp BYTE PTR [esi+0xc0],0x2
49adf8: je 0x49af40
49adfe: mov eax,ds:0x4b1144
49ae03: mov edx,0xeb
49ae08: sub edx,DWORD PTR [eax]
49ae0a: push edx
49ae0b: push 0x0
49ae0d: mov eax,DWORD PTR [ebx+0x308]
49ae13: mov eax,DWORD PTR [eax+0x28]
49ae16: xor edx,edx
49ae18: call 0x461dcc
49ae1d: mov ecx,0x13b
49ae22: sub ecx,DWORD PTR [ebp+0x0]
49ae25: mov edx,DWORD PTR [ebx+0x2d0]
49ae2b: mov edx,DWORD PTR [edx+0x270]
49ae31: call 0x46161c
49ae36: cmp BYTE PTR [edi],0x8
49ae39: jae 0x49ae76
49ae3b: mov eax,ds:0x4b1144
49ae40: mov edx,0x55
49ae45: sub edx,DWORD PTR [eax]
49ae47: push edx
49ae48: push 0x0
49ae4a: mov eax,DWORD PTR [ebx+0x338]
49ae50: mov eax,DWORD PTR [eax+0x28]
49ae53: mov edx,0x24
49ae58: call 0x461dcc
49ae5d: mov ecx,0x14a
49ae62: sub ecx,DWORD PTR [ebp+0x0]
49ae65: mov edx,DWORD PTR [ebx+0x2d0]
49ae6b: mov edx,DWORD PTR [edx+0x270]
49ae71: call 0x46161c
49ae76: cmp BYTE PTR [edi],0x8
49ae79: jb 0x49aebb
49ae7b: cmp BYTE PTR [edi],0x10
49ae7e: jae 0x49aebb
49ae80: mov eax,ds:0x4b1144
49ae85: mov edx,0x55
49ae8a: sub edx,DWORD PTR [eax]
49ae8c: push edx
49ae8d: push 0x0
49ae8f: mov eax,DWORD PTR [ebx+0x338]
49ae95: mov eax,DWORD PTR [eax+0x28]
49ae98: mov edx,0x25
49ae9d: call 0x461dcc
49aea2: mov ecx,0x146
49aea7: sub ecx,DWORD PTR [ebp+0x0]
49aeaa: mov edx,DWORD PTR [ebx+0x2d0]
49aeb0: mov edx,DWORD PTR [edx+0x270]
49aeb6: call 0x46161c
49aebb: cmp BYTE PTR [edi],0x10
49aebe: jb 0x49af00
49aec0: cmp BYTE PTR [edi],0x18
49aec3: jae 0x49af00
49aec5: mov eax,ds:0x4b1144
49aeca: mov edx,0x55
49aecf: sub edx,DWORD PTR [eax]
49aed1: push edx
49aed2: push 0x0
49aed4: mov eax,DWORD PTR [ebx+0x338]
49aeda: mov eax,DWORD PTR [eax+0x28]
49aedd: mov edx,0x24
49aee2: call 0x461dcc
49aee7: mov ecx,0x14a
49aeec: sub ecx,DWORD PTR [ebp+0x0]
49aeef: mov edx,DWORD PTR [ebx+0x2d0]
49aef5: mov edx,DWORD PTR [edx+0x270]
49aefb: call 0x46161c
49af00: cmp BYTE PTR [edi],0x18
49af03: jb 0x49af40
49af05: mov eax,ds:0x4b1144
49af0a: mov edx,0x55
49af0f: sub edx,DWORD PTR [eax]
49af11: push edx
49af12: push 0x0
49af14: mov eax,DWORD PTR [ebx+0x338]
49af1a: mov eax,DWORD PTR [eax+0x28]
49af1d: mov edx,0x25
49af22: call 0x461dcc
49af27: mov ecx,0x146
49af2c: sub ecx,DWORD PTR [ebp+0x0]
49af2f: mov edx,DWORD PTR [ebx+0x2d0]
49af35: mov edx,DWORD PTR [edx+0x270]
49af3b: call 0x46161c
49af40: mov eax,ds:0x4b1124
49af45: cmp BYTE PTR [eax],0x4
49af48: jne 0x49afe7
49af4e: cmp BYTE PTR [esi+0x10],0x5
49af52: je 0x49afe7
49af58: cmp BYTE PTR [esi+0xc0],0x5
49af5f: je 0x49afe7
49af65: cmp BYTE PTR [esi+0x10],0x6
49af69: je 0x49afe7
49af6b: cmp BYTE PTR [esi+0xc0],0x6
49af72: je 0x49afe7
49af74: mov eax,ds:0x4b1144
49af79: mov edx,0x103
49af7e: sub edx,DWORD PTR [eax]
49af80: push edx
49af81: push 0x0
49af83: mov eax,DWORD PTR [ebx+0x308]
49af89: mov eax,DWORD PTR [eax+0x28]
49af8c: xor edx,edx
49af8e: call 0x461dcc
49af93: mov ecx,0xec
49af98: sub ecx,DWORD PTR [ebp+0x0]
49af9b: mov edx,DWORD PTR [ebx+0x2d0]
49afa1: mov edx,DWORD PTR [edx+0x270]
49afa7: call 0x46161c
49afac: mov eax,ds:0x4b1144
49afb1: mov edx,0x6e
49afb6: sub edx,DWORD PTR [eax]
49afb8: push edx
49afb9: push 0x0
49afbb: mov eax,DWORD PTR [ebx+0x338]
49afc1: mov eax,DWORD PTR [eax+0x28]
49afc4: mov edx,0x3f
49afc9: call 0x461dcc
49afce: mov ecx,0xe6
49afd3: sub ecx,DWORD PTR [ebp+0x0]
49afd6: mov edx,DWORD PTR [ebx+0x2d0]
49afdc: mov edx,DWORD PTR [edx+0x270]
49afe2: call 0x46161c
49afe7: mov eax,ds:0x4b1124
49afec: cmp BYTE PTR [eax],0x5
49afef: jne 0x49b14e
49aff5: cmp BYTE PTR [esi+0x10],0x4
49aff9: je 0x49b14e
49afff: cmp BYTE PTR [esi+0xc0],0x4
49b006: je 0x49b14e
49b00c: mov eax,ds:0x4b1144
49b011: mov edx,0xff
49b016: sub edx,DWORD PTR [eax]
49b018: push edx
49b019: push 0x0
49b01b: mov eax,DWORD PTR [ebx+0x308]
49b021: mov eax,DWORD PTR [eax+0x28]
49b024: xor edx,edx
49b026: call 0x461dcc
49b02b: mov ecx,0x199
49b030: sub ecx,DWORD PTR [ebp+0x0]
49b033: mov edx,DWORD PTR [ebx+0x2d0]
49b039: mov edx,DWORD PTR [edx+0x270]
49b03f: call 0x46161c
49b044: cmp BYTE PTR [edi],0x8
49b047: jae 0x49b084
49b049: mov eax,ds:0x4b1144
49b04e: mov edx,0x9a
49b053: sub edx,DWORD PTR [eax]
49b055: push edx
49b056: push 0x0
49b058: mov eax,DWORD PTR [ebx+0x338]
49b05e: mov eax,DWORD PTR [eax+0x28]
49b061: mov edx,0xc
49b066: call 0x461dcc
49b06b: mov ecx,0x1a4
49b070: sub ecx,DWORD PTR [ebp+0x0]
49b073: mov edx,DWORD PTR [ebx+0x2d0]
49b079: mov edx,DWORD PTR [edx+0x270]
49b07f: call 0x46161c
49b084: cmp BYTE PTR [edi],0x8
49b087: jb 0x49b0c9
49b089: cmp BYTE PTR [edi],0x10
49b08c: jae 0x49b0c9
49b08e: mov eax,ds:0x4b1144
49b093: mov edx,0x9f
49b098: sub edx,DWORD PTR [eax]
49b09a: push edx
49b09b: push 0x0
49b09d: mov eax,DWORD PTR [ebx+0x338]
49b0a3: mov eax,DWORD PTR [eax+0x28]
49b0a6: mov edx,0xd
49b0ab: call 0x461dcc
49b0b0: mov ecx,0x1a4
49b0b5: sub ecx,DWORD PTR [ebp+0x0]
49b0b8: mov edx,DWORD PTR [ebx+0x2d0]
49b0be: mov edx,DWORD PTR [edx+0x270]
49b0c4: call 0x46161c
49b0c9: cmp BYTE PTR [edi],0x10
49b0cc: jb 0x49b10e
49b0ce: cmp BYTE PTR [edi],0x18
49b0d1: jae 0x49b10e
49b0d3: mov eax,ds:0x4b1144
49b0d8: mov edx,0x93
49b0dd: sub edx,DWORD PTR [eax]
49b0df: push edx
49b0e0: push 0x0
49b0e2: mov eax,DWORD PTR [ebx+0x338]
49b0e8: mov eax,DWORD PTR [eax+0x28]
49b0eb: mov edx,0xe
49b0f0: call 0x461dcc
49b0f5: mov ecx,0x1a4
49b0fa: sub ecx,DWORD PTR [ebp+0x0]
49b0fd: mov edx,DWORD PTR [ebx+0x2d0]
49b103: mov edx,DWORD PTR [edx+0x270]
49b109: call 0x46161c
49b10e: cmp BYTE PTR [edi],0x18
49b111: jb 0x49b14e
49b113: mov eax,ds:0x4b1144
49b118: mov edx,0x9f
49b11d: sub edx,DWORD PTR [eax]
49b11f: push edx
49b120: push 0x0
49b122: mov eax,DWORD PTR [ebx+0x338]
49b128: mov eax,DWORD PTR [eax+0x28]
49b12b: mov edx,0xd
49b130: call 0x461dcc
49b135: mov ecx,0x1a4
49b13a: sub ecx,DWORD PTR [ebp+0x0]
49b13d: mov edx,DWORD PTR [ebx+0x2d0]
49b143: mov edx,DWORD PTR [edx+0x270]
49b149: call 0x46161c
49b14e: mov eax,ds:0x4b1124
49b153: cmp BYTE PTR [eax],0x5
49b156: jne 0x49b20a
49b15c: cmp BYTE PTR [esi+0x10],0x2
49b160: je 0x49b20a
49b166: cmp BYTE PTR [esi+0xc0],0x2
49b16d: je 0x49b20a
49b173: cmp BYTE PTR [esi+0x10],0x7
49b177: je 0x49b20a
49b17d: cmp BYTE PTR [esi+0xc0],0x7
49b184: je 0x49b20a
49b18a: cmp BYTE PTR [edi],0xf
49b18d: jae 0x49b1ca
49b18f: mov eax,ds:0x4b1144
49b194: mov edx,0x6e
49b199: sub edx,DWORD PTR [eax]
49b19b: push edx
49b19c: push 0x0
49b19e: mov eax,DWORD PTR [ebx+0x338]
49b1a4: mov eax,DWORD PTR [eax+0x28]
49b1a7: mov edx,0x20
49b1ac: call 0x461dcc
49b1b1: mov ecx,0x172
49b1b6: sub ecx,DWORD PTR [ebp+0x0]
49b1b9: mov edx,DWORD PTR [ebx+0x2d0]
49b1bf: mov edx,DWORD PTR [edx+0x270]
49b1c5: call 0x46161c
49b1ca: cmp BYTE PTR [edi],0xf
49b1cd: jb 0x49b20a
49b1cf: mov eax,ds:0x4b1144
49b1d4: mov edx,0x6e
49b1d9: sub edx,DWORD PTR [eax]
49b1db: push edx
49b1dc: push 0x0
49b1de: mov eax,DWORD PTR [ebx+0x338]
49b1e4: mov eax,DWORD PTR [eax+0x28]
49b1e7: mov edx,0x21
49b1ec: call 0x461dcc
49b1f1: mov ecx,0x172
49b1f6: sub ecx,DWORD PTR [ebp+0x0]
49b1f9: mov edx,DWORD PTR [ebx+0x2d0]
49b1ff: mov edx,DWORD PTR [edx+0x270]
49b205: call 0x46161c
49b20a: mov eax,ds:0x4b1124
49b20f: cmp BYTE PTR [eax],0x6
49b212: jne 0x49b29a
49b218: cmp BYTE PTR [esi+0x10],0xa
49b21c: je 0x49b29a
49b21e: cmp BYTE PTR [esi+0xc0],0xa
49b225: je 0x49b29a
49b227: mov eax,ds:0x4b1144
49b22c: mov edx,0xe3
49b231: sub edx,DWORD PTR [eax]
49b233: push edx
49b234: push 0x0
49b236: mov eax,DWORD PTR [ebx+0x308]
49b23c: mov eax,DWORD PTR [eax+0x28]
49b23f: xor edx,edx
49b241: call 0x461dcc
49b246: mov ecx,0xd
49b24b: sub ecx,DWORD PTR [ebp+0x0]
49b24e: mov edx,DWORD PTR [ebx+0x2d0]
49b254: mov edx,DWORD PTR [edx+0x270]
49b25a: call 0x46161c
49b25f: mov eax,ds:0x4b1144
49b264: mov edx,0x93
49b269: sub edx,DWORD PTR [eax]
49b26b: push edx
49b26c: push 0x0
49b26e: mov eax,DWORD PTR [ebx+0x338]
49b274: mov eax,DWORD PTR [eax+0x28]
49b277: mov edx,0x45
49b27c: call 0x461dcc
49b281: mov ecx,0x14
49b286: sub ecx,DWORD PTR [ebp+0x0]
49b289: mov edx,DWORD PTR [ebx+0x2d0]
49b28f: mov edx,DWORD PTR [edx+0x270]
49b295: call 0x46161c
49b29a: mov eax,ds:0x4b1124
49b29f: cmp BYTE PTR [eax],0x6
49b2a2: jne 0x49b401
49b2a8: cmp BYTE PTR [esi+0x10],0x2
49b2ac: je 0x49b401
49b2b2: cmp BYTE PTR [esi+0xc0],0x2
49b2b9: je 0x49b401
49b2bf: mov eax,ds:0x4b1144
49b2c4: mov edx,0xeb
49b2c9: sub edx,DWORD PTR [eax]
49b2cb: push edx
49b2cc: push 0x0
49b2ce: mov eax,DWORD PTR [ebx+0x308]
49b2d4: mov eax,DWORD PTR [eax+0x28]
49b2d7: xor edx,edx
49b2d9: call 0x461dcc
49b2de: mov ecx,0x4f
49b2e3: sub ecx,DWORD PTR [ebp+0x0]
49b2e6: mov edx,DWORD PTR [ebx+0x2d0]
49b2ec: mov edx,DWORD PTR [edx+0x270]
49b2f2: call 0x46161c
49b2f7: cmp BYTE PTR [edi],0xf
49b2fa: jae 0x49b337
49b2fc: mov eax,ds:0x4b1144
49b301: mov edx,0xb4
49b306: sub edx,DWORD PTR [eax]
49b308: push edx
49b309: push 0x0
49b30b: mov eax,DWORD PTR [ebx+0x338]
49b311: mov eax,DWORD PTR [eax+0x28]
49b314: mov edx,0x22
49b319: call 0x461dcc
49b31e: mov ecx,0x55
49b323: sub ecx,DWORD PTR [ebp+0x0]
49b326: mov edx,DWORD PTR [ebx+0x2d0]
49b32c: mov edx,DWORD PTR [edx+0x270]
49b332: call 0x46161c
49b337: cmp BYTE PTR [edi],0xf
49b33a: jb 0x49b37c
49b33c: cmp BYTE PTR [edi],0x14
49b33f: jae 0x49b37c
49b341: mov eax,ds:0x4b1144
49b346: mov edx,0xaf
49b34b: sub edx,DWORD PTR [eax]
49b34d: push edx
49b34e: push 0x0
49b350: mov eax,DWORD PTR [ebx+0x338]
49b356: mov eax,DWORD PTR [eax+0x28]
49b359: mov edx,0x23
49b35e: call 0x461dcc
49b363: mov ecx,0x55
49b368: sub ecx,DWORD PTR [ebp+0x0]
49b36b: mov edx,DWORD PTR [ebx+0x2d0]
49b371: mov edx,DWORD PTR [edx+0x270]
49b377: call 0x46161c
49b37c: cmp BYTE PTR [edi],0x14
49b37f: jb 0x49b3c1
49b381: cmp BYTE PTR [edi],0x1c
49b384: jae 0x49b3c1
49b386: mov eax,ds:0x4b1144
49b38b: mov edx,0xb4
49b390: sub edx,DWORD PTR [eax]
49b392: push edx
49b393: push 0x0
49b395: mov eax,DWORD PTR [ebx+0x338]
49b39b: mov eax,DWORD PTR [eax+0x28]
49b39e: mov edx,0x22
49b3a3: call 0x461dcc
49b3a8: mov ecx,0x55
49b3ad: sub ecx,DWORD PTR [ebp+0x0]
49b3b0: mov edx,DWORD PTR [ebx+0x2d0]
49b3b6: mov edx,DWORD PTR [edx+0x270]
49b3bc: call 0x46161c
49b3c1: cmp BYTE PTR [edi],0x1c
49b3c4: jb 0x49b401
49b3c6: mov eax,ds:0x4b1144
49b3cb: mov edx,0xaf
49b3d0: sub edx,DWORD PTR [eax]
49b3d2: push edx
49b3d3: push 0x0
49b3d5: mov eax,DWORD PTR [ebx+0x338]
49b3db: mov eax,DWORD PTR [eax+0x28]
49b3de: mov edx,0x23
49b3e3: call 0x461dcc
49b3e8: mov ecx,0x55
49b3ed: sub ecx,DWORD PTR [ebp+0x0]
49b3f0: mov edx,DWORD PTR [ebx+0x2d0]
49b3f6: mov edx,DWORD PTR [edx+0x270]
49b3fc: call 0x46161c
49b401: mov eax,ds:0x4b1124
49b406: cmp BYTE PTR [eax],0x6
49b409: jne 0x49b455
49b40b: cmp BYTE PTR [esi+0x10],0xb
49b40f: je 0x49b455
49b411: cmp BYTE PTR [esi+0xc0],0xb
49b418: je 0x49b455
49b41a: mov eax,ds:0x4b1144
49b41f: mov edx,0x91
49b424: sub edx,DWORD PTR [eax]
49b426: push edx
49b427: push 0x0
49b429: mov eax,DWORD PTR [ebx+0x338]
49b42f: mov eax,DWORD PTR [eax+0x28]
49b432: mov edx,0x8
49b437: call 0x461dcc
49b43c: mov ecx,0x1cc
49b441: sub ecx,DWORD PTR [ebp+0x0]
49b444: mov edx,DWORD PTR [ebx+0x2d0]
49b44a: mov edx,DWORD PTR [edx+0x270]
49b450: call 0x46161c
49b455: mov eax,ds:0x4b1124
49b45a: cmp BYTE PTR [eax],0x6
49b45d: jne 0x49b6d0
49b463: cmp BYTE PTR [esi+0x10],0x6
49b467: je 0x49b6d0
49b46d: cmp BYTE PTR [esi+0xc0],0x6
49b474: je 0x49b6d0
49b47a: mov eax,ds:0x4b1144
49b47f: mov edx,0xe6
49b484: sub edx,DWORD PTR [eax]
49b486: push edx
49b487: push 0x0
49b489: mov eax,DWORD PTR [ebx+0x308]
49b48f: mov eax,DWORD PTR [eax+0x28]
49b492: xor edx,edx
49b494: call 0x461dcc
49b499: mov ecx,0x130
49b49e: sub ecx,DWORD PTR [ebp+0x0]
49b4a1: mov edx,DWORD PTR [ebx+0x2d0]
49b4a7: mov edx,DWORD PTR [edx+0x270]
49b4ad: call 0x46161c
49b4b2: cmp BYTE PTR [edi],0x9
49b4b5: jae 0x49b4f2
49b4b7: mov eax,ds:0x4b1144
49b4bc: mov edx,0x5a
49b4c1: sub edx,DWORD PTR [eax]
49b4c3: push edx
49b4c4: push 0x0
49b4c6: mov eax,DWORD PTR [ebx+0x338]
49b4cc: mov eax,DWORD PTR [eax+0x28]
49b4cf: mov edx,0x40
49b4d4: call 0x461dcc
49b4d9: mov ecx,0x146
49b4de: sub ecx,DWORD PTR [ebp+0x0]
49b4e1: mov edx,DWORD PTR [ebx+0x2d0]
49b4e7: mov edx,DWORD PTR [edx+0x270]
49b4ed: call 0x46161c
49b4f2: cmp BYTE PTR [edi],0x9
49b4f5: jb 0x49b537
49b4f7: cmp BYTE PTR [edi],0xc
49b4fa: jae 0x49b537
49b4fc: mov eax,ds:0x4b1144
49b501: mov edx,0x7c
49b506: sub edx,DWORD PTR [eax]
49b508: push edx
49b509: push 0x0
49b50b: mov eax,DWORD PTR [ebx+0x338]
49b511: mov eax,DWORD PTR [eax+0x28]
49b514: mov edx,0x41
49b519: call 0x461dcc
49b51e: mov ecx,0x13c
49b523: sub ecx,DWORD PTR [ebp+0x0]
49b526: mov edx,DWORD PTR [ebx+0x2d0]
49b52c: mov edx,DWORD PTR [edx+0x270]
49b532: call 0x46161c
49b537: cmp BYTE PTR [edi],0xc
49b53a: jb 0x49b57c
49b53c: cmp BYTE PTR [edi],0xf
49b53f: jae 0x49b57c
49b541: mov eax,ds:0x4b1144
49b546: mov edx,0x97
49b54b: sub edx,DWORD PTR [eax]
49b54d: push edx
49b54e: push 0x0
49b550: mov eax,DWORD PTR [ebx+0x338]
49b556: mov eax,DWORD PTR [eax+0x28]
49b559: mov edx,0x42
49b55e: call 0x461dcc
49b563: mov ecx,0x13b
49b568: sub ecx,DWORD PTR [ebp+0x0]
49b56b: mov edx,DWORD PTR [ebx+0x2d0]
49b571: mov edx,DWORD PTR [edx+0x270]
49b577: call 0x46161c
49b57c: cmp BYTE PTR [edi],0xf
49b57f: jb 0x49b5c1
49b581: cmp BYTE PTR [edi],0x12
49b584: jae 0x49b5c1
49b586: mov eax,ds:0x4b1144
49b58b: mov edx,0x7c
49b590: sub edx,DWORD PTR [eax]
49b592: push edx
49b593: push 0x0
49b595: mov eax,DWORD PTR [ebx+0x338]
49b59b: mov eax,DWORD PTR [eax+0x28]
49b59e: mov edx,0x41
49b5a3: call 0x461dcc
49b5a8: mov ecx,0x13c
49b5ad: sub ecx,DWORD PTR [ebp+0x0]
49b5b0: mov edx,DWORD PTR [ebx+0x2d0]
49b5b6: mov edx,DWORD PTR [edx+0x270]
49b5bc: call 0x46161c
49b5c1: cmp BYTE PTR [edi],0x12
49b5c4: jb 0x49b606
49b5c6: cmp BYTE PTR [edi],0x15
49b5c9: jae 0x49b606
49b5cb: mov eax,ds:0x4b1144
49b5d0: mov edx,0x5a
49b5d5: sub edx,DWORD PTR [eax]
49b5d7: push edx
49b5d8: push 0x0
49b5da: mov eax,DWORD PTR [ebx+0x338]
49b5e0: mov eax,DWORD PTR [eax+0x28]
49b5e3: mov edx,0x40
49b5e8: call 0x461dcc
49b5ed: mov ecx,0x146
49b5f2: sub ecx,DWORD PTR [ebp+0x0]
49b5f5: mov edx,DWORD PTR [ebx+0x2d0]
49b5fb: mov edx,DWORD PTR [edx+0x270]
49b601: call 0x46161c
49b606: cmp BYTE PTR [edi],0x15
49b609: jb 0x49b64b
49b60b: cmp BYTE PTR [edi],0x18
49b60e: jae 0x49b64b
49b610: mov eax,ds:0x4b1144
49b615: mov edx,0x5a
49b61a: sub edx,DWORD PTR [eax]
49b61c: push edx
49b61d: push 0x0
49b61f: mov eax,DWORD PTR [ebx+0x338]
49b625: mov eax,DWORD PTR [eax+0x28]
49b628: mov edx,0x43
49b62d: call 0x461dcc
49b632: mov ecx,0x146
49b637: sub ecx,DWORD PTR [ebp+0x0]
49b63a: mov edx,DWORD PTR [ebx+0x2d0]
49b640: mov edx,DWORD PTR [edx+0x270]
49b646: call 0x46161c
49b64b: cmp BYTE PTR [edi],0x18
49b64e: jb 0x49b690
49b650: cmp BYTE PTR [edi],0x1b
49b653: jae 0x49b690
49b655: mov eax,ds:0x4b1144
49b65a: mov edx,0x5a
49b65f: sub edx,DWORD PTR [eax]
49b661: push edx
49b662: push 0x0
49b664: mov eax,DWORD PTR [ebx+0x338]
49b66a: mov eax,DWORD PTR [eax+0x28]
49b66d: mov edx,0x44
49b672: call 0x461dcc
49b677: mov ecx,0x144
49b67c: sub ecx,DWORD PTR [ebp+0x0]
49b67f: mov edx,DWORD PTR [ebx+0x2d0]
49b685: mov edx,DWORD PTR [edx+0x270]
49b68b: call 0x46161c
49b690: cmp BYTE PTR [edi],0x1b
49b693: jb 0x49b6d0
49b695: mov eax,ds:0x4b1144
49b69a: mov edx,0x5a
49b69f: sub edx,DWORD PTR [eax]
49b6a1: push edx
49b6a2: push 0x0
49b6a4: mov eax,DWORD PTR [ebx+0x338]
49b6aa: mov eax,DWORD PTR [eax+0x28]
49b6ad: mov edx,0x43
49b6b2: call 0x461dcc
49b6b7: mov ecx,0x146
49b6bc: sub ecx,DWORD PTR [ebp+0x0]
49b6bf: mov edx,DWORD PTR [ebx+0x2d0]
49b6c5: mov edx,DWORD PTR [edx+0x270]
49b6cb: call 0x46161c
49b6d0: mov eax,ds:0x4b1124
49b6d5: cmp BYTE PTR [eax],0x7
49b6d8: jne 0x49b775
49b6de: cmp BYTE PTR [esi+0x10],0x2
49b6e2: je 0x49b775
49b6e8: cmp BYTE PTR [esi+0xc0],0x2
49b6ef: je 0x49b775
49b6f5: cmp BYTE PTR [edi],0xf
49b6f8: jae 0x49b735
49b6fa: mov eax,ds:0x4b1144
49b6ff: mov edx,0xaa
49b704: sub edx,DWORD PTR [eax]
49b706: push edx
49b707: push 0x0
49b709: mov eax,DWORD PTR [ebx+0x338]
49b70f: mov eax,DWORD PTR [eax+0x28]
49b712: mov edx,0x32
49b717: call 0x461dcc
49b71c: mov ecx,0x17c
49b721: sub ecx,DWORD PTR [ebp+0x0]
49b724: mov edx,DWORD PTR [ebx+0x2d0]
49b72a: mov edx,DWORD PTR [edx+0x270]
49b730: call 0x46161c
49b735: cmp BYTE PTR [edi],0xf
49b738: jb 0x49b775
49b73a: mov eax,ds:0x4b1144
49b73f: mov edx,0xaa
49b744: sub edx,DWORD PTR [eax]
49b746: push edx
49b747: push 0x0
49b749: mov eax,DWORD PTR [ebx+0x338]
49b74f: mov eax,DWORD PTR [eax+0x28]
49b752: mov edx,0x33
49b757: call 0x461dcc
49b75c: mov ecx,0x17c
49b761: sub ecx,DWORD PTR [ebp+0x0]
49b764: mov edx,DWORD PTR [ebx+0x2d0]
49b76a: mov edx,DWORD PTR [edx+0x270]
49b770: call 0x46161c
49b775: mov eax,ds:0x4b1124
49b77a: cmp BYTE PTR [eax],0x7
49b77d: jne 0x49b81c
49b783: cmp BYTE PTR [esi+0x10],0x2
49b787: je 0x49b81c
49b78d: cmp BYTE PTR [esi+0xc0],0x2
49b794: je 0x49b81c
49b79a: cmp BYTE PTR [esi+0x10],0x5
49b79e: je 0x49b81c
49b7a0: cmp BYTE PTR [esi+0xc0],0x5
49b7a7: je 0x49b81c
49b7a9: mov eax,ds:0x4b1144
49b7ae: mov edx,0xff
49b7b3: sub edx,DWORD PTR [eax]
49b7b5: push edx
49b7b6: push 0x0
49b7b8: mov eax,DWORD PTR [ebx+0x308]
49b7be: mov eax,DWORD PTR [eax+0x28]
49b7c1: xor edx,edx
49b7c3: call 0x461dcc
49b7c8: mov ecx,0x1d2
49b7cd: sub ecx,DWORD PTR [ebp+0x0]
49b7d0: mov edx,DWORD PTR [ebx+0x2d0]
49b7d6: mov edx,DWORD PTR [edx+0x270]
49b7dc: call 0x46161c
49b7e1: mov eax,ds:0x4b1144
49b7e6: mov edx,0x82
49b7eb: sub edx,DWORD PTR [eax]
49b7ed: push edx
49b7ee: push 0x0
49b7f0: mov eax,DWORD PTR [ebx+0x338]
49b7f6: mov eax,DWORD PTR [eax+0x28]
49b7f9: mov edx,0x34
49b7fe: call 0x461dcc
49b803: mov ecx,0x1e0
49b808: sub ecx,DWORD PTR [ebp+0x0]
49b80b: mov edx,DWORD PTR [ebx+0x2d0]
49b811: mov edx,DWORD PTR [edx+0x270]
49b817: call 0x46161c
49b81c: mov eax,ds:0x4b1124
49b821: cmp BYTE PTR [eax],0x7
49b824: jne 0x49b983
49b82a: cmp BYTE PTR [esi+0x10],0x3
49b82e: je 0x49b983
49b834: cmp BYTE PTR [esi+0xc0],0x3
49b83b: je 0x49b983
49b841: mov eax,ds:0x4b1144
49b846: mov edx,0xfd
49b84b: sub edx,DWORD PTR [eax]
49b84d: push edx
49b84e: push 0x0
49b850: mov eax,DWORD PTR [ebx+0x308]
49b856: mov eax,DWORD PTR [eax+0x28]
49b859: xor edx,edx
49b85b: call 0x461dcc
49b860: mov ecx,0x49
49b865: sub ecx,DWORD PTR [ebp+0x0]
49b868: mov edx,DWORD PTR [ebx+0x2d0]
49b86e: mov edx,DWORD PTR [edx+0x270]
49b874: call 0x46161c
49b879: cmp BYTE PTR [edi],0xa
49b87c: ja 0x49b8b9
49b87e: mov eax,ds:0x4b1144
49b883: mov edx,0x8c
49b888: sub edx,DWORD PTR [eax]
49b88a: push edx
49b88b: push 0x0
49b88d: mov eax,DWORD PTR [ebx+0x338]
49b893: mov eax,DWORD PTR [eax+0x28]
49b896: mov edx,0x35
49b89b: call 0x461dcc
49b8a0: mov ecx,0x50
49b8a5: sub ecx,DWORD PTR [ebp+0x0]
49b8a8: mov edx,DWORD PTR [ebx+0x2d0]
49b8ae: mov edx,DWORD PTR [edx+0x270]
49b8b4: call 0x46161c
49b8b9: cmp BYTE PTR [edi],0xa
49b8bc: jbe 0x49b8fe
49b8be: cmp BYTE PTR [edi],0xe
49b8c1: ja 0x49b8fe
49b8c3: mov eax,ds:0x4b1144
49b8c8: mov edx,0x92
49b8cd: sub edx,DWORD PTR [eax]
49b8cf: push edx
49b8d0: push 0x0
49b8d2: mov eax,DWORD PTR [ebx+0x338]
49b8d8: mov eax,DWORD PTR [eax+0x28]
49b8db: mov edx,0x36
49b8e0: call 0x461dcc
49b8e5: mov ecx,0x58
49b8ea: sub ecx,DWORD PTR [ebp+0x0]
49b8ed: mov edx,DWORD PTR [ebx+0x2d0]
49b8f3: mov edx,DWORD PTR [edx+0x270]
49b8f9: call 0x46161c
49b8fe: cmp BYTE PTR [edi],0xe
49b901: jbe 0x49b943
49b903: cmp BYTE PTR [edi],0x19
49b906: ja 0x49b943
49b908: mov eax,ds:0x4b1144
49b90d: mov edx,0x94
49b912: sub edx,DWORD PTR [eax]
49b914: push edx
49b915: push 0x0
49b917: mov eax,DWORD PTR [ebx+0x338]
49b91d: mov eax,DWORD PTR [eax+0x28]
49b920: mov edx,0x37
49b925: call 0x461dcc
49b92a: mov ecx,0x59
49b92f: sub ecx,DWORD PTR [ebp+0x0]
49b932: mov edx,DWORD PTR [ebx+0x2d0]
49b938: mov edx,DWORD PTR [edx+0x270]
49b93e: call 0x46161c
49b943: cmp BYTE PTR [edi],0x19
49b946: jbe 0x49b983
49b948: mov eax,ds:0x4b1144
49b94d: mov edx,0x92
49b952: sub edx,DWORD PTR [eax]
49b954: push edx
49b955: push 0x0
49b957: mov eax,DWORD PTR [ebx+0x338]
49b95d: mov eax,DWORD PTR [eax+0x28]
49b960: mov edx,0x36
49b965: call 0x461dcc
49b96a: mov ecx,0x58
49b96f: sub ecx,DWORD PTR [ebp+0x0]
49b972: mov edx,DWORD PTR [ebx+0x2d0]
49b978: mov edx,DWORD PTR [edx+0x270]
49b97e: call 0x46161c
49b983: mov eax,ds:0x4b1124
49b988: cmp BYTE PTR [eax],0x8
49b98b: jne 0x49bf92
49b991: cmp BYTE PTR [edi],0xf
49b994: jae 0x49b9db
49b996: mov eax,ds:0x4b1144
49b99b: mov edx,0xff
49b9a0: sub edx,DWORD PTR [eax]
49b9a2: push edx
49b9a3: push 0x0
49b9a5: mov eax,DWORD PTR [ebx+0x338]
49b9ab: mov eax,DWORD PTR [eax+0x28]
49b9ae: mov edx,0x10
49b9b3: call 0x461dcc
49b9b8: xor edx,edx
49b9ba: mov dl,BYTE PTR [edi]
49b9bc: mov ecx,edx
49b9be: shl ecx,0x2
49b9c1: add ecx,0xc8
49b9c7: sub ecx,DWORD PTR [ebp+0x0]
49b9ca: mov edx,DWORD PTR [ebx+0x2d0]
49b9d0: mov edx,DWORD PTR [edx+0x270]
49b9d6: call 0x46161c
49b9db: cmp BYTE PTR [edi],0xf
49b9de: jb 0x49ba2a
49b9e0: mov eax,ds:0x4b1144
49b9e5: mov edx,0xff
49b9ea: sub edx,DWORD PTR [eax]
49b9ec: push edx
49b9ed: push 0x0
49b9ef: mov eax,DWORD PTR [ebx+0x338]
49b9f5: mov eax,DWORD PTR [eax+0x28]
49b9f8: mov edx,0x11
49b9fd: call 0x461dcc
49ba02: xor edx,edx
49ba04: mov dl,BYTE PTR [edi]
49ba06: mov ecx,0x1e
49ba0b: sub ecx,edx
49ba0d: shl ecx,0x2
49ba10: add ecx,0xc8
49ba16: sub ecx,DWORD PTR [ebp+0x0]
49ba19: mov edx,DWORD PTR [ebx+0x2d0]
49ba1f: mov edx,DWORD PTR [edx+0x270]
49ba25: call 0x46161c
49ba2a: mov eax,0x3
49ba2f: call 0x402a1c
49ba34: lea eax,[eax+eax*2]
49ba37: mov edx,0xff
49ba3c: sub edx,eax
49ba3e: mov eax,ds:0x4b1144
49ba43: sub edx,DWORD PTR [eax]
49ba45: push edx
49ba46: push 0x0
49ba48: mov eax,DWORD PTR [ebx+0x338]
49ba4e: mov eax,DWORD PTR [eax+0x28]
49ba51: mov edx,0x12
49ba56: call 0x461dcc
49ba5b: mov ecx,0x12c
49ba60: sub ecx,DWORD PTR [ebp+0x0]
49ba63: mov edx,DWORD PTR [ebx+0x2d0]
49ba69: mov edx,DWORD PTR [edx+0x270]
49ba6f: call 0x46161c
49ba74: mov eax,0x3
49ba79: call 0x402a1c
49ba7e: lea eax,[eax+eax*2]
49ba81: mov edx,0x102
49ba86: sub edx,eax
49ba88: mov eax,ds:0x4b1144
49ba8d: sub edx,DWORD PTR [eax]
49ba8f: push edx
49ba90: push 0x0
49ba92: mov eax,DWORD PTR [ebx+0x338]
49ba98: mov eax,DWORD PTR [eax+0x28]
49ba9b: mov edx,0x12
49baa0: call 0x461dcc
49baa5: mov ecx,0x154
49baaa: sub ecx,DWORD PTR [ebp+0x0]
49baad: mov edx,DWORD PTR [ebx+0x2d0]
49bab3: mov edx,DWORD PTR [edx+0x270]
49bab9: call 0x46161c
49babe: mov eax,0x3
49bac3: call 0x402a1c
49bac8: lea eax,[eax+eax*2]
49bacb: mov edx,0xfc
49bad0: sub edx,eax
49bad2: mov eax,ds:0x4b1144
49bad7: sub edx,DWORD PTR [eax]
49bad9: push edx
49bada: push 0x0
49badc: mov eax,DWORD PTR [ebx+0x338]
49bae2: mov eax,DWORD PTR [eax+0x28]
49bae5: mov edx,0x12
49baea: call 0x461dcc
49baef: mov ecx,0x17c
49baf4: sub ecx,DWORD PTR [ebp+0x0]
49baf7: mov edx,DWORD PTR [ebx+0x2d0]
49bafd: mov edx,DWORD PTR [edx+0x270]
49bb03: call 0x46161c
49bb08: mov eax,0x3
49bb0d: call 0x402a1c
49bb12: lea eax,[eax+eax*2]
49bb15: mov edx,0xff
49bb1a: sub edx,eax
49bb1c: mov eax,ds:0x4b1144
49bb21: sub edx,DWORD PTR [eax]
49bb23: push edx
49bb24: push 0x0
49bb26: mov eax,DWORD PTR [ebx+0x338]
49bb2c: mov eax,DWORD PTR [eax+0x28]
49bb2f: mov edx,0x12
49bb34: call 0x461dcc
49bb39: mov ecx,0x190
49bb3e: sub ecx,DWORD PTR [ebp+0x0]
49bb41: mov edx,DWORD PTR [ebx+0x2d0]
49bb47: mov edx,DWORD PTR [edx+0x270]
49bb4d: call 0x46161c
49bb52: mov eax,0x3
49bb57: call 0x402a1c
49bb5c: lea eax,[eax+eax*2]
49bb5f: mov edx,0xff
49bb64: sub edx,eax
49bb66: mov eax,ds:0x4b1144
49bb6b: sub edx,DWORD PTR [eax]
49bb6d: push edx
49bb6e: push 0x0
49bb70: mov eax,DWORD PTR [ebx+0x338]
49bb76: mov eax,DWORD PTR [eax+0x28]
49bb79: mov edx,0x12
49bb7e: call 0x461dcc
49bb83: mov ecx,0x64
49bb88: sub ecx,DWORD PTR [ebp+0x0]
49bb8b: mov edx,DWORD PTR [ebx+0x2d0]
49bb91: mov edx,DWORD PTR [edx+0x270]
49bb97: call 0x46161c
49bb9c: mov eax,0x3
49bba1: call 0x402a1c
49bba6: shl eax,0x2
49bba9: mov edx,0xa0
49bbae: sub edx,eax
49bbb0: mov eax,ds:0x4b1144
49bbb5: sub edx,DWORD PTR [eax]
49bbb7: push edx
49bbb8: push 0x0
49bbba: mov eax,DWORD PTR [ebx+0x338]
49bbc0: mov eax,DWORD PTR [eax+0x28]
49bbc3: mov edx,0x12
49bbc8: call 0x461dcc
49bbcd: mov ecx,0x82
49bbd2: sub ecx,DWORD PTR [ebp+0x0]
49bbd5: mov edx,DWORD PTR [ebx+0x2d0]
49bbdb: mov edx,DWORD PTR [edx+0x270]
49bbe1: call 0x46161c
49bbe6: mov eax,0x3
49bbeb: call 0x402a1c
49bbf0: shl eax,0x2
49bbf3: mov edx,0xa4
49bbf8: sub edx,eax
49bbfa: mov eax,ds:0x4b1144
49bbff: sub edx,DWORD PTR [eax]
49bc01: push edx
49bc02: push 0x0
49bc04: mov eax,DWORD PTR [ebx+0x338]
49bc0a: mov eax,DWORD PTR [eax+0x28]
49bc0d: mov edx,0x12
49bc12: call 0x461dcc
49bc17: mov ecx,0x91
49bc1c: sub ecx,DWORD PTR [ebp+0x0]
49bc1f: mov edx,DWORD PTR [ebx+0x2d0]
49bc25: mov edx,DWORD PTR [edx+0x270]
49bc2b: call 0x46161c
49bc30: mov eax,0x3
49bc35: call 0x402a1c
49bc3a: shl eax,0x2
49bc3d: mov edx,0xa2
49bc42: sub edx,eax
49bc44: mov eax,ds:0x4b1144
49bc49: sub edx,DWORD PTR [eax]
49bc4b: push edx
49bc4c: push 0x0
49bc4e: mov eax,DWORD PTR [ebx+0x338]
49bc54: mov eax,DWORD PTR [eax+0x28]
49bc57: mov edx,0x12
49bc5c: call 0x461dcc
49bc61: mov ecx,0xa5
49bc66: sub ecx,DWORD PTR [ebp+0x0]
49bc69: mov edx,DWORD PTR [ebx+0x2d0]
49bc6f: mov edx,DWORD PTR [edx+0x270]
49bc75: call 0x46161c
49bc7a: cmp BYTE PTR [edi],0xf
49bc7d: ja 0x49bcba
49bc7f: mov eax,ds:0x4b1144
49bc84: mov edx,0xc3
49bc89: sub edx,DWORD PTR [eax]
49bc8b: push edx
49bc8c: push 0x0
49bc8e: mov eax,DWORD PTR [ebx+0x338]
49bc94: mov eax,DWORD PTR [eax+0x28]
49bc97: mov edx,0x13
49bc9c: call 0x461dcc
49bca1: mov ecx,0x208
49bca6: sub ecx,DWORD PTR [ebp+0x0]
49bca9: mov edx,DWORD PTR [ebx+0x2d0]
49bcaf: mov edx,DWORD PTR [edx+0x270]
49bcb5: call 0x46161c
49bcba: cmp BYTE PTR [edi],0xf
49bcbd: jbe 0x49bcfa
49bcbf: mov eax,ds:0x4b1144
49bcc4: mov edx,0xc3
49bcc9: sub edx,DWORD PTR [eax]
49bccb: push edx
49bccc: push 0x0
49bcce: mov eax,DWORD PTR [ebx+0x338]
49bcd4: mov eax,DWORD PTR [eax+0x28]
49bcd7: mov edx,0x14
49bcdc: call 0x461dcc
49bce1: mov ecx,0x208
49bce6: sub ecx,DWORD PTR [ebp+0x0]
49bce9: mov edx,DWORD PTR [ebx+0x2d0]
49bcef: mov edx,DWORD PTR [edx+0x270]
49bcf5: call 0x46161c
49bcfa: cmp BYTE PTR [edi],0x8
49bcfd: ja 0x49bd3a
49bcff: mov eax,ds:0x4b1144
49bd04: mov edx,0xaf
49bd09: sub edx,DWORD PTR [eax]
49bd0b: push edx
49bd0c: push 0x0
49bd0e: mov eax,DWORD PTR [ebx+0x338]
49bd14: mov eax,DWORD PTR [eax+0x28]
49bd17: mov edx,0x15
49bd1c: call 0x461dcc
49bd21: mov ecx,0x6e
49bd26: sub ecx,DWORD PTR [ebp+0x0]
49bd29: mov edx,DWORD PTR [ebx+0x2d0]
49bd2f: mov edx,DWORD PTR [edx+0x270]
49bd35: call 0x46161c
49bd3a: cmp BYTE PTR [edi],0x8
49bd3d: jbe 0x49bd7f
49bd3f: cmp BYTE PTR [edi],0x10
49bd42: ja 0x49bd7f
49bd44: mov eax,ds:0x4b1144
49bd49: mov edx,0xb6
49bd4e: sub edx,DWORD PTR [eax]
49bd50: push edx
49bd51: push 0x0
49bd53: mov eax,DWORD PTR [ebx+0x338]
49bd59: mov eax,DWORD PTR [eax+0x28]
49bd5c: mov edx,0x16
49bd61: call 0x461dcc
49bd66: mov ecx,0x72
49bd6b: sub ecx,DWORD PTR [ebp+0x0]
49bd6e: mov edx,DWORD PTR [ebx+0x2d0]
49bd74: mov edx,DWORD PTR [edx+0x270]
49bd7a: call 0x46161c
49bd7f: cmp BYTE PTR [edi],0x10
49bd82: jbe 0x49bdc4
49bd84: cmp BYTE PTR [edi],0x18
49bd87: ja 0x49bdc4
49bd89: mov eax,ds:0x4b1144
49bd8e: mov edx,0xaf
49bd93: sub edx,DWORD PTR [eax]
49bd95: push edx
49bd96: push 0x0
49bd98: mov eax,DWORD PTR [ebx+0x338]
49bd9e: mov eax,DWORD PTR [eax+0x28]
49bda1: mov edx,0x15
49bda6: call 0x461dcc
49bdab: mov ecx,0x6e
49bdb0: sub ecx,DWORD PTR [ebp+0x0]
49bdb3: mov edx,DWORD PTR [ebx+0x2d0]
49bdb9: mov edx,DWORD PTR [edx+0x270]
49bdbf: call 0x46161c
49bdc4: cmp BYTE PTR [edi],0x18
49bdc7: jbe 0x49be04
49bdc9: mov eax,ds:0x4b1144
49bdce: mov edx,0xb6
49bdd3: sub edx,DWORD PTR [eax]
49bdd5: push edx
49bdd6: push 0x0
49bdd8: mov eax,DWORD PTR [ebx+0x338]
49bdde: mov eax,DWORD PTR [eax+0x28]
49bde1: mov edx,0x16
49bde6: call 0x461dcc
49bdeb: mov ecx,0x72
49bdf0: sub ecx,DWORD PTR [ebp+0x0]
49bdf3: mov edx,DWORD PTR [ebx+0x2d0]
49bdf9: mov edx,DWORD PTR [edx+0x270]
49bdff: call 0x46161c
49be04: cmp BYTE PTR [edi],0xf
49be07: ja 0x49be44
49be09: mov eax,ds:0x4b1144
49be0e: mov edx,0xff
49be13: sub edx,DWORD PTR [eax]
49be15: push edx
49be16: push 0x0
49be18: mov eax,DWORD PTR [ebx+0x338]
49be1e: mov eax,DWORD PTR [eax+0x28]
49be21: mov edx,0x17
49be26: call 0x461dcc
49be2b: mov ecx,0x1e0
49be30: sub ecx,DWORD PTR [ebp+0x0]
49be33: mov edx,DWORD PTR [ebx+0x2d0]
49be39: mov edx,DWORD PTR [edx+0x270]
49be3f: call 0x46161c
49be44: cmp BYTE PTR [edi],0xf
49be47: jbe 0x49be84
49be49: mov eax,ds:0x4b1144
49be4e: mov edx,0xff
49be53: sub edx,DWORD PTR [eax]
49be55: push edx
49be56: push 0x0
49be58: mov eax,DWORD PTR [ebx+0x338]
49be5e: mov eax,DWORD PTR [eax+0x28]
49be61: mov edx,0x18
49be66: call 0x461dcc
49be6b: mov ecx,0x1e0
49be70: sub ecx,DWORD PTR [ebp+0x0]
49be73: mov edx,DWORD PTR [ebx+0x2d0]
49be79: mov edx,DWORD PTR [edx+0x270]
49be7f: call 0x46161c
49be84: cmp BYTE PTR [edi],0xf
49be87: ja 0x49bec4
49be89: mov eax,ds:0x4b1144
49be8e: mov edx,0xfa
49be93: sub edx,DWORD PTR [eax]
49be95: push edx
49be96: push 0x0
49be98: mov eax,DWORD PTR [ebx+0x338]
49be9e: mov eax,DWORD PTR [eax+0x28]
49bea1: mov edx,0x19
49bea6: call 0x461dcc
49beab: mov ecx,0xaa
49beb0: sub ecx,DWORD PTR [ebp+0x0]
49beb3: mov edx,DWORD PTR [ebx+0x2d0]
49beb9: mov edx,DWORD PTR [edx+0x270]
49bebf: call 0x46161c
49bec4: cmp BYTE PTR [edi],0xf
49bec7: jbe 0x49bf04
49bec9: mov eax,ds:0x4b1144
49bece: mov edx,0xfa
49bed3: sub edx,DWORD PTR [eax]
49bed5: push edx
49bed6: push 0x0
49bed8: mov eax,DWORD PTR [ebx+0x338]
49bede: mov eax,DWORD PTR [eax+0x28]
49bee1: mov edx,0x1a
49bee6: call 0x461dcc
49beeb: mov ecx,0xaa
49bef0: sub ecx,DWORD PTR [ebp+0x0]
49bef3: mov edx,DWORD PTR [ebx+0x2d0]
49bef9: mov edx,DWORD PTR [edx+0x270]
49beff: call 0x46161c
49bf04: fld QWORD PTR [esi]
49bf06: fadd QWORD PTR [esi+0xb0]
49bf0c: fdiv DWORD PTR ds:0x49cd28
49bf12: call 0x402894
49bf17: sub eax,0x3c
49bf1a: mov DWORD PTR [esp],eax
49bf1d: mov DWORD PTR [esp+0x4],0x1
49bf25: mov eax,0x3
49bf2a: call 0x402a1c
49bf2f: shl eax,0x2
49bf32: mov edx,0x10d
49bf37: sub edx,eax
49bf39: mov eax,ds:0x4b1144
49bf3e: sub edx,DWORD PTR [eax]
49bf40: push edx
49bf41: push 0x0
49bf43: mov eax,0x2
49bf48: call 0x402a1c
49bf4d: mov edx,DWORD PTR [esp+0xc]
49bf51: mov ecx,edx
49bf53: shl edx,0x4
49bf56: sub edx,ecx
49bf58: add edx,DWORD PTR [esp+0x8]
49bf5c: add eax,edx
49bf5e: sub eax,DWORD PTR [ebp+0x0]
49bf61: push eax
49bf62: mov eax,DWORD PTR [ebx+0x338]
49bf68: mov eax,DWORD PTR [eax+0x28]
49bf6b: mov edx,0x12
49bf70: call 0x461dcc
49bf75: mov edx,DWORD PTR [ebx+0x2d0]
49bf7b: mov edx,DWORD PTR [edx+0x270]
49bf81: pop ecx
49bf82: call 0x46161c
49bf87: inc DWORD PTR [esp+0x4]
49bf8b: cmp DWORD PTR [esp+0x4],0x6
49bf90: jne 0x49bf25
49bf92: mov eax,ds:0x4b1124
49bf97: cmp BYTE PTR [eax],0x9
49bf9a: jne 0x49c0d8
49bfa0: cmp BYTE PTR [esi+0x10],0x2
49bfa4: je 0x49c0d8
49bfaa: cmp BYTE PTR [esi+0xc0],0x2
49bfb1: je 0x49c0d8
49bfb7: cmp BYTE PTR [esi+0x10],0x4
49bfbb: je 0x49c0d8
49bfc1: cmp BYTE PTR [esi+0xc0],0x4
49bfc8: je 0x49c0d8
49bfce: cmp BYTE PTR [edi],0x8
49bfd1: jae 0x49c00e
49bfd3: mov eax,ds:0x4b1144
49bfd8: mov edx,0x55
49bfdd: sub edx,DWORD PTR [eax]
49bfdf: push edx
49bfe0: push 0x0
49bfe2: mov eax,DWORD PTR [ebx+0x338]
49bfe8: mov eax,DWORD PTR [eax+0x28]
49bfeb: mov edx,0x1d
49bff0: call 0x461dcc
49bff5: mov ecx,0xe6
49bffa: sub ecx,DWORD PTR [ebp+0x0]
49bffd: mov edx,DWORD PTR [ebx+0x2d0]
49c003: mov edx,DWORD PTR [edx+0x270]
49c009: call 0x46161c
49c00e: cmp BYTE PTR [edi],0x8
49c011: jb 0x49c053
49c013: cmp BYTE PTR [edi],0x10
49c016: ja 0x49c053
49c018: mov eax,ds:0x4b1144
49c01d: mov edx,0x58
49c022: sub edx,DWORD PTR [eax]
49c024: push edx
49c025: push 0x0
49c027: mov eax,DWORD PTR [ebx+0x338]
49c02d: mov eax,DWORD PTR [eax+0x28]
49c030: mov edx,0x1f
49c035: call 0x461dcc
49c03a: mov ecx,0xe7
49c03f: sub ecx,DWORD PTR [ebp+0x0]
49c042: mov edx,DWORD PTR [ebx+0x2d0]
49c048: mov edx,DWORD PTR [edx+0x270]
49c04e: call 0x46161c
49c053: cmp BYTE PTR [edi],0x10
49c056: jb 0x49c098
49c058: cmp BYTE PTR [edi],0x1b
49c05b: jae 0x49c098
49c05d: mov eax,ds:0x4b1144
49c062: mov edx,0x5e
49c067: sub edx,DWORD PTR [eax]
49c069: push edx
49c06a: push 0x0
49c06c: mov eax,DWORD PTR [ebx+0x338]
49c072: mov eax,DWORD PTR [eax+0x28]
49c075: mov edx,0x1e
49c07a: call 0x461dcc
49c07f: mov ecx,0xe7
49c084: sub ecx,DWORD PTR [ebp+0x0]
49c087: mov edx,DWORD PTR [ebx+0x2d0]
49c08d: mov edx,DWORD PTR [edx+0x270]
49c093: call 0x46161c
49c098: cmp BYTE PTR [edi],0x1b
49c09b: jb 0x49c0d8
49c09d: mov eax,ds:0x4b1144
49c0a2: mov edx,0x58
49c0a7: sub edx,DWORD PTR [eax]
49c0a9: push edx
49c0aa: push 0x0
49c0ac: mov eax,DWORD PTR [ebx+0x338]
49c0b2: mov eax,DWORD PTR [eax+0x28]
49c0b5: mov edx,0x1f
49c0ba: call 0x461dcc
49c0bf: mov ecx,0xe7
49c0c4: sub ecx,DWORD PTR [ebp+0x0]
49c0c7: mov edx,DWORD PTR [ebx+0x2d0]
49c0cd: mov edx,DWORD PTR [edx+0x270]
49c0d3: call 0x46161c
49c0d8: mov eax,ds:0x4b1124
49c0dd: cmp BYTE PTR [eax],0x9
49c0e0: jne 0x49c2c9
49c0e6: cmp BYTE PTR [esi+0x10],0x1
49c0ea: je 0x49c2c9
49c0f0: cmp BYTE PTR [esi+0xc0],0x1
49c0f7: je 0x49c2c9
49c0fd: mov eax,ds:0x4b1144
49c102: mov edx,0xd7
49c107: sub edx,DWORD PTR [eax]
49c109: push edx
49c10a: push 0x0
49c10c: mov eax,DWORD PTR [ebx+0x308]
49c112: mov eax,DWORD PTR [eax+0x28]
49c115: xor edx,edx
49c117: call 0x461dcc
49c11c: mov ecx,0x190
49c121: sub ecx,DWORD PTR [ebp+0x0]
49c124: mov edx,DWORD PTR [ebx+0x2d0]
49c12a: mov edx,DWORD PTR [edx+0x270]
49c130: call 0x46161c
49c135: cmp BYTE PTR [edi],0x5
49c138: jae 0x49c175
49c13a: mov eax,ds:0x4b1144
49c13f: mov edx,0xa5
49c144: sub edx,DWORD PTR [eax]
49c146: push edx
49c147: push 0x0
49c149: mov eax,DWORD PTR [ebx+0x338]
49c14f: mov eax,DWORD PTR [eax+0x28]
49c152: mov edx,0x46
49c157: call 0x461dcc
49c15c: mov ecx,0x190
49c161: sub ecx,DWORD PTR [ebp+0x0]
49c164: mov edx,DWORD PTR [ebx+0x2d0]
49c16a: mov edx,DWORD PTR [edx+0x270]
49c170: call 0x46161c
49c175: cmp BYTE PTR [edi],0x5
49c178: jb 0x49c1ba
49c17a: cmp BYTE PTR [edi],0xa
49c17d: jae 0x49c1ba
49c17f: mov eax,ds:0x4b1144
49c184: mov edx,0xa5
49c189: sub edx,DWORD PTR [eax]
49c18b: push edx
49c18c: push 0x0
49c18e: mov eax,DWORD PTR [ebx+0x338]
49c194: mov eax,DWORD PTR [eax+0x28]
49c197: mov edx,0x47
49c19c: call 0x461dcc
49c1a1: mov ecx,0x190
49c1a6: sub ecx,DWORD PTR [ebp+0x0]
49c1a9: mov edx,DWORD PTR [ebx+0x2d0]
49c1af: mov edx,DWORD PTR [edx+0x270]
49c1b5: call 0x46161c
49c1ba: cmp BYTE PTR [edi],0xa
49c1bd: jb 0x49c1ff
49c1bf: cmp BYTE PTR [edi],0xf
49c1c2: jae 0x49c1ff
49c1c4: mov eax,ds:0x4b1144
49c1c9: mov edx,0xa5
49c1ce: sub edx,DWORD PTR [eax]
49c1d0: push edx
49c1d1: push 0x0
49c1d3: mov eax,DWORD PTR [ebx+0x338]
49c1d9: mov eax,DWORD PTR [eax+0x28]
49c1dc: mov edx,0x48
49c1e1: call 0x461dcc
49c1e6: mov ecx,0x190
49c1eb: sub ecx,DWORD PTR [ebp+0x0]
49c1ee: mov edx,DWORD PTR [ebx+0x2d0]
49c1f4: mov edx,DWORD PTR [edx+0x270]
49c1fa: call 0x46161c
49c1ff: cmp BYTE PTR [edi],0xf
49c202: jb 0x49c244
49c204: cmp BYTE PTR [edi],0x14
49c207: jae 0x49c244
49c209: mov eax,ds:0x4b1144
49c20e: mov edx,0xa5
49c213: sub edx,DWORD PTR [eax]
49c215: push edx
49c216: push 0x0
49c218: mov eax,DWORD PTR [ebx+0x338]
49c21e: mov eax,DWORD PTR [eax+0x28]
49c221: mov edx,0x46
49c226: call 0x461dcc
49c22b: mov ecx,0x190
49c230: sub ecx,DWORD PTR [ebp+0x0]
49c233: mov edx,DWORD PTR [ebx+0x2d0]
49c239: mov edx,DWORD PTR [edx+0x270]
49c23f: call 0x46161c
49c244: cmp BYTE PTR [edi],0x14
49c247: jb 0x49c289
49c249: cmp BYTE PTR [edi],0x19
49c24c: jae 0x49c289
49c24e: mov eax,ds:0x4b1144
49c253: mov edx,0xa5
49c258: sub edx,DWORD PTR [eax]
49c25a: push edx
49c25b: push 0x0
49c25d: mov eax,DWORD PTR [ebx+0x338]
49c263: mov eax,DWORD PTR [eax+0x28]
49c266: mov edx,0x47
49c26b: call 0x461dcc
49c270: mov ecx,0x190
49c275: sub ecx,DWORD PTR [ebp+0x0]
49c278: mov edx,DWORD PTR [ebx+0x2d0]
49c27e: mov edx,DWORD PTR [edx+0x270]
49c284: call 0x46161c
49c289: cmp BYTE PTR [edi],0x19
49c28c: jb 0x49c2c9
49c28e: mov eax,ds:0x4b1144
49c293: mov edx,0xa5
49c298: sub edx,DWORD PTR [eax]
49c29a: push edx
49c29b: push 0x0
49c29d: mov eax,DWORD PTR [ebx+0x338]
49c2a3: mov eax,DWORD PTR [eax+0x28]
49c2a6: mov edx,0x48
49c2ab: call 0x461dcc
49c2b0: mov ecx,0x190
49c2b5: sub ecx,DWORD PTR [ebp+0x0]
49c2b8: mov edx,DWORD PTR [ebx+0x2d0]
49c2be: mov edx,DWORD PTR [edx+0x270]
49c2c4: call 0x46161c
49c2c9: mov eax,ds:0x4b1124
49c2ce: cmp BYTE PTR [eax],0x9
49c2d1: jne 0x49c3f8
49c2d7: cmp BYTE PTR [esi+0x10],0x3
49c2db: je 0x49c3f8
49c2e1: cmp BYTE PTR [esi+0xc0],0x3
49c2e8: je 0x49c3f8
49c2ee: cmp BYTE PTR [edi],0xb
49c2f1: jae 0x49c32e
49c2f3: mov eax,ds:0x4b1144
49c2f8: mov edx,0x9d
49c2fd: sub edx,DWORD PTR [eax]
49c2ff: push edx
49c300: push 0x0
49c302: mov eax,DWORD PTR [ebx+0x338]
49c308: mov eax,DWORD PTR [eax+0x28]
49c30b: mov edx,0x49
49c310: call 0x461dcc
49c315: mov ecx,0xb9
49c31a: sub ecx,DWORD PTR [ebp+0x0]
49c31d: mov edx,DWORD PTR [ebx+0x2d0]
49c323: mov edx,DWORD PTR [edx+0x270]
49c329: call 0x46161c
49c32e: cmp BYTE PTR [edi],0xb
49c331: jb 0x49c373
49c333: cmp BYTE PTR [edi],0x16
49c336: jae 0x49c373
49c338: mov eax,ds:0x4b1144
49c33d: mov edx,0x9d
49c342: sub edx,DWORD PTR [eax]
49c344: push edx
49c345: push 0x0
49c347: mov eax,DWORD PTR [ebx+0x338]
49c34d: mov eax,DWORD PTR [eax+0x28]
49c350: mov edx,0x4a
49c355: call 0x461dcc
49c35a: mov ecx,0xb9
49c35f: sub ecx,DWORD PTR [ebp+0x0]
49c362: mov edx,DWORD PTR [ebx+0x2d0]
49c368: mov edx,DWORD PTR [edx+0x270]
49c36e: call 0x46161c
49c373: cmp BYTE PTR [edi],0x16
49c376: jb 0x49c3b8
49c378: cmp BYTE PTR [edi],0x1a
49c37b: jae 0x49c3b8
49c37d: mov eax,ds:0x4b1144
49c382: mov edx,0x9d
49c387: sub edx,DWORD PTR [eax]
49c389: push edx
49c38a: push 0x0
49c38c: mov eax,DWORD PTR [ebx+0x338]
49c392: mov eax,DWORD PTR [eax+0x28]
49c395: mov edx,0x49
49c39a: call 0x461dcc
49c39f: mov ecx,0xb9
49c3a4: sub ecx,DWORD PTR [ebp+0x0]
49c3a7: mov edx,DWORD PTR [ebx+0x2d0]
49c3ad: mov edx,DWORD PTR [edx+0x270]
49c3b3: call 0x46161c
49c3b8: cmp BYTE PTR [edi],0x1a
49c3bb: jb 0x49c3f8
49c3bd: mov eax,ds:0x4b1144
49c3c2: mov edx,0x9d
49c3c7: sub edx,DWORD PTR [eax]
49c3c9: push edx
49c3ca: push 0x0
49c3cc: mov eax,DWORD PTR [ebx+0x338]
49c3d2: mov eax,DWORD PTR [eax+0x28]
49c3d5: mov edx,0x4a
49c3da: call 0x461dcc
49c3df: mov ecx,0xb9
49c3e4: sub ecx,DWORD PTR [ebp+0x0]
49c3e7: mov edx,DWORD PTR [ebx+0x2d0]
49c3ed: mov edx,DWORD PTR [edx+0x270]
49c3f3: call 0x46161c
49c3f8: mov eax,ds:0x4b1124
49c3fd: cmp BYTE PTR [eax],0xa
49c400: jne 0x49c44c
49c402: cmp BYTE PTR [esi+0x10],0x2
49c406: je 0x49c44c
49c408: cmp BYTE PTR [esi+0xc0],0x2
49c40f: je 0x49c44c
49c411: mov eax,ds:0x4b1144
49c416: mov edx,0x8a
49c41b: sub edx,DWORD PTR [eax]
49c41d: push edx
49c41e: push 0x0
49c420: mov eax,DWORD PTR [ebx+0x338]
49c426: mov eax,DWORD PTR [eax+0x28]
49c429: mov edx,0x26
49c42e: call 0x461dcc
49c433: mov ecx,0x17c
49c438: sub ecx,DWORD PTR [ebp+0x0]
49c43b: mov edx,DWORD PTR [ebx+0x2d0]
49c441: mov edx,DWORD PTR [edx+0x270]
49c447: call 0x46161c
49c44c: mov eax,ds:0x4b1124
49c451: cmp BYTE PTR [eax],0xa
49c454: jne 0x49c4bd
49c456: cmp BYTE PTR [esi+0x10],0xb
49c45a: je 0x49c4bd
49c45c: cmp BYTE PTR [esi+0xc0],0xb
49c463: je 0x49c4bd
49c465: cmp BYTE PTR [esi+0x10],0x2
49c469: je 0x49c4bd
49c46b: cmp BYTE PTR [esi+0xc0],0x2
49c472: je 0x49c4bd
49c474: mov eax,ds:0x4b1144
49c479: mov edx,0x8a
49c47e: sub edx,DWORD PTR [eax]
49c480: push edx
49c481: push 0x0
49c483: mov eax,0x2
49c488: call 0x402a1c
49c48d: mov edx,0x96
49c492: sub edx,DWORD PTR [ebp+0x0]
49c495: add eax,edx
49c497: push eax
49c498: mov eax,DWORD PTR [ebx+0x338]
49c49e: mov eax,DWORD PTR [eax+0x28]
49c4a1: mov edx,0x27
49c4a6: call 0x461dcc
49c4ab: mov edx,DWORD PTR [ebx+0x2d0]
49c4b1: mov edx,DWORD PTR [edx+0x270]
49c4b7: pop ecx
49c4b8: call 0x46161c
49c4bd: mov eax,ds:0x4b1124
49c4c2: cmp BYTE PTR [eax],0xb
49c4c5: jne 0x49c520
49c4c7: cmp BYTE PTR [esi+0x10],0x5
49c4cb: je 0x49c520
49c4cd: cmp BYTE PTR [esi+0xc0],0x5
49c4d4: je 0x49c520
49c4d6: cmp BYTE PTR [esi+0x10],0x6
49c4da: je 0x49c520
49c4dc: cmp BYTE PTR [esi+0xc0],0x6
49c4e3: je 0x49c520
49c4e5: mov eax,ds:0x4b1144
49c4ea: mov edx,0x98
49c4ef: sub edx,DWORD PTR [eax]
49c4f1: push edx
49c4f2: push 0x0
49c4f4: mov eax,DWORD PTR [ebx+0x338]
49c4fa: mov eax,DWORD PTR [eax+0x28]
49c4fd: mov edx,0x4b
49c502: call 0x461dcc
49c507: mov ecx,0x183
49c50c: sub ecx,DWORD PTR [ebp+0x0]
49c50f: mov edx,DWORD PTR [ebx+0x2d0]
49c515: mov edx,DWORD PTR [edx+0x270]
49c51b: call 0x46161c
49c520: mov eax,ds:0x4b1124
49c525: cmp BYTE PTR [eax],0xb
49c528: jne 0x49c582
49c52a: cmp BYTE PTR [esi+0x10],0xe
49c52e: je 0x49c582
49c530: cmp BYTE PTR [esi+0xc0],0xe
49c537: je 0x49c582
49c539: mov eax,ds:0x4b1144
49c53e: mov edx,0x52
49c543: sub edx,DWORD PTR [eax]
49c545: push edx
49c546: push 0x0
49c548: mov eax,0x2
49c54d: call 0x402a1c
49c552: mov edx,0x78
49c557: sub edx,DWORD PTR [ebp+0x0]
49c55a: add eax,edx
49c55c: push eax
49c55d: mov eax,DWORD PTR [ebx+0x338]
49c563: mov eax,DWORD PTR [eax+0x28]
49c566: mov edx,0x4c
49c56b: call 0x461dcc
49c570: mov edx,DWORD PTR [ebx+0x2d0]
49c576: mov edx,DWORD PTR [edx+0x270]
49c57c: pop ecx
49c57d: call 0x46161c
49c582: mov eax,ds:0x4b1124
49c587: cmp BYTE PTR [eax],0xb
49c58a: jne 0x49c5d6
49c58c: cmp BYTE PTR [esi+0x10],0x8
49c590: je 0x49c5d6
49c592: cmp BYTE PTR [esi+0xc0],0x8
49c599: je 0x49c5d6
49c59b: mov eax,ds:0x4b1144
49c5a0: mov edx,0x6e
49c5a5: sub edx,DWORD PTR [eax]
49c5a7: push edx
49c5a8: push 0x0
49c5aa: mov eax,DWORD PTR [ebx+0x338]
49c5b0: mov eax,DWORD PTR [eax+0x28]
49c5b3: mov edx,0x4d
49c5b8: call 0x461dcc
49c5bd: mov ecx,0x136
49c5c2: sub ecx,DWORD PTR [ebp+0x0]
49c5c5: mov edx,DWORD PTR [ebx+0x2d0]
49c5cb: mov edx,DWORD PTR [edx+0x270]
49c5d1: call 0x46161c
49c5d6: mov eax,ds:0x4b1124
49c5db: cmp BYTE PTR [eax],0xc
49c5de: jne 0x49c862
49c5e4: mov eax,ds:0x4b1144
49c5e9: mov edx,0xe4
49c5ee: sub edx,DWORD PTR [eax]
49c5f0: push edx
49c5f1: push 0x0
49c5f3: mov eax,DWORD PTR [ebx+0x308]
49c5f9: mov eax,DWORD PTR [eax+0x28]
49c5fc: xor edx,edx
49c5fe: call 0x461dcc
49c603: mov ecx,0x104
49c608: sub ecx,DWORD PTR [ebp+0x0]
49c60b: mov edx,DWORD PTR [ebx+0x2d0]
49c611: mov edx,DWORD PTR [edx+0x270]
49c617: call 0x46161c
49c61c: cmp BYTE PTR [edi],0x5
49c61f: ja 0x49c65c
49c621: mov eax,ds:0x4b1144
49c626: mov edx,0x50
49c62b: sub edx,DWORD PTR [eax]
49c62d: push edx
49c62e: push 0x0
49c630: mov eax,DWORD PTR [ebx+0x338]
49c636: mov eax,DWORD PTR [eax+0x28]
49c639: mov edx,0x28
49c63e: call 0x461dcc
49c643: mov ecx,0x104
49c648: sub ecx,DWORD PTR [ebp+0x0]
49c64b: mov edx,DWORD PTR [ebx+0x2d0]
49c651: mov edx,DWORD PTR [edx+0x270]
49c657: call 0x46161c
49c65c: cmp BYTE PTR [edi],0x5
49c65f: jbe 0x49c6a1
49c661: cmp BYTE PTR [edi],0x8
49c664: ja 0x49c6a1
49c666: mov eax,ds:0x4b1144
49c66b: mov edx,0x80
49c670: sub edx,DWORD PTR [eax]
49c672: push edx
49c673: push 0x0
49c675: mov eax,DWORD PTR [ebx+0x338]
49c67b: mov eax,DWORD PTR [eax+0x28]
49c67e: mov edx,0x29
49c683: call 0x461dcc
49c688: mov ecx,0xde
49c68d: sub ecx,DWORD PTR [ebp+0x0]
49c690: mov edx,DWORD PTR [ebx+0x2d0]
49c696: mov edx,DWORD PTR [edx+0x270]
49c69c: call 0x46161c
49c6a1: cmp BYTE PTR [edi],0x8
49c6a4: jbe 0x49c6e6
49c6a6: cmp BYTE PTR [edi],0xb
49c6a9: ja 0x49c6e6
49c6ab: mov eax,ds:0x4b1144
49c6b0: mov edx,0x96
49c6b5: sub edx,DWORD PTR [eax]
49c6b7: push edx
49c6b8: push 0x0
49c6ba: mov eax,DWORD PTR [ebx+0x338]
49c6c0: mov eax,DWORD PTR [eax+0x28]
49c6c3: mov edx,0x2a
49c6c8: call 0x461dcc
49c6cd: mov ecx,0xc8
49c6d2: sub ecx,DWORD PTR [ebp+0x0]
49c6d5: mov edx,DWORD PTR [ebx+0x2d0]
49c6db: mov edx,DWORD PTR [edx+0x270]
49c6e1: call 0x46161c
49c6e6: cmp BYTE PTR [edi],0xb
49c6e9: jbe 0x49c72b
49c6eb: cmp BYTE PTR [edi],0xe
49c6ee: ja 0x49c72b
49c6f0: mov eax,ds:0x4b1144
49c6f5: mov edx,0x96
49c6fa: sub edx,DWORD PTR [eax]
49c6fc: push edx
49c6fd: push 0x0
49c6ff: mov eax,DWORD PTR [ebx+0x338]
49c705: mov eax,DWORD PTR [eax+0x28]
49c708: mov edx,0x2b
49c70d: call 0x461dcc
49c712: mov ecx,0xdc
49c717: sub ecx,DWORD PTR [ebp+0x0]
49c71a: mov edx,DWORD PTR [ebx+0x2d0]
49c720: mov edx,DWORD PTR [edx+0x270]
49c726: call 0x46161c
49c72b: cmp BYTE PTR [edi],0xe
49c72e: jbe 0x49c770
49c730: cmp BYTE PTR [edi],0x13
49c733: ja 0x49c770
49c735: mov eax,ds:0x4b1144
49c73a: mov edx,0x96
49c73f: sub edx,DWORD PTR [eax]
49c741: push edx
49c742: push 0x0
49c744: mov eax,DWORD PTR [ebx+0x338]
49c74a: mov eax,DWORD PTR [eax+0x28]
49c74d: mov edx,0x2a
49c752: call 0x461dcc
49c757: mov ecx,0xc8
49c75c: sub ecx,DWORD PTR [ebp+0x0]
49c75f: mov edx,DWORD PTR [ebx+0x2d0]
49c765: mov edx,DWORD PTR [edx+0x270]
49c76b: call 0x46161c
49c770: cmp BYTE PTR [edi],0x13
49c773: jbe 0x49c7b5
49c775: cmp BYTE PTR [edi],0x16
49c778: ja 0x49c7b5
49c77a: mov eax,ds:0x4b1144
49c77f: mov edx,0x80
49c784: sub edx,DWORD PTR [eax]
49c786: push edx
49c787: push 0x0
49c789: mov eax,DWORD PTR [ebx+0x338]
49c78f: mov eax,DWORD PTR [eax+0x28]
49c792: mov edx,0x29
49c797: call 0x461dcc
49c79c: mov ecx,0xde
49c7a1: sub ecx,DWORD PTR [ebp+0x0]
49c7a4: mov edx,DWORD PTR [ebx+0x2d0]
49c7aa: mov edx,DWORD PTR [edx+0x270]
49c7b0: call 0x46161c
49c7b5: cmp BYTE PTR [edi],0x16
49c7b8: jbe 0x49c7fa
49c7ba: cmp BYTE PTR [edi],0x1e
49c7bd: ja 0x49c7fa
49c7bf: mov eax,ds:0x4b1144
49c7c4: mov edx,0x50
49c7c9: sub edx,DWORD PTR [eax]
49c7cb: push edx
49c7cc: push 0x0
49c7ce: mov eax,DWORD PTR [ebx+0x338]
49c7d4: mov eax,DWORD PTR [eax+0x28]
49c7d7: mov edx,0x28
49c7dc: call 0x461dcc
49c7e1: mov ecx,0x104
49c7e6: sub ecx,DWORD PTR [ebp+0x0]
49c7e9: mov edx,DWORD PTR [ebx+0x2d0]
49c7ef: mov edx,DWORD PTR [edx+0x270]
49c7f5: call 0x46161c
49c7fa: xor eax,eax
49c7fc: mov al,BYTE PTR [edi]
49c7fe: sub eax,0xb
49c801: mov DWORD PTR [esp+0x8],eax
49c805: fild DWORD PTR [esp+0x8]
49c809: fdiv DWORD PTR ds:0x49cd2c
49c80f: call 0x40286c
49c814: fchs
49c816: fmul DWORD PTR ds:0x49cd30
49c81c: call 0x402894
49c821: mov DWORD PTR [esp],eax
49c824: mov eax,ds:0x4b1144
49c829: mov edx,0x86
49c82e: sub edx,DWORD PTR [eax]
49c830: sub edx,DWORD PTR [esp]
49c833: push edx
49c834: push 0x0
49c836: mov eax,DWORD PTR [ebx+0x314]
49c83c: mov eax,DWORD PTR [eax+0x28]
49c83f: mov edx,0xd
49c844: call 0x461dcc
49c849: mov ecx,0xe1
49c84e: sub ecx,DWORD PTR [ebp+0x0]
49c851: mov edx,DWORD PTR [ebx+0x2d0]
49c857: mov edx,DWORD PTR [edx+0x270]
49c85d: call 0x46161c
49c862: mov eax,ds:0x4b1124
49c867: cmp BYTE PTR [eax],0xc
49c86a: jne 0x49c8f2
49c870: cmp BYTE PTR [esi+0x10],0xb
49c874: je 0x49c8f2
49c876: cmp BYTE PTR [esi+0xc0],0xb
49c87d: je 0x49c8f2
49c87f: mov eax,ds:0x4b1144
49c884: mov edx,0xff
49c889: sub edx,DWORD PTR [eax]
49c88b: push edx
49c88c: push 0x0
49c88e: mov eax,DWORD PTR [ebx+0x308]
49c894: mov eax,DWORD PTR [eax+0x28]
49c897: xor edx,edx
49c899: call 0x461dcc
49c89e: mov ecx,0x87
49c8a3: sub ecx,DWORD PTR [ebp+0x0]
49c8a6: mov edx,DWORD PTR [ebx+0x2d0]
49c8ac: mov edx,DWORD PTR [edx+0x270]
49c8b2: call 0x46161c
49c8b7: mov eax,ds:0x4b1144
49c8bc: mov edx,0xa0
49c8c1: sub edx,DWORD PTR [eax]
49c8c3: push edx
49c8c4: push 0x0
49c8c6: mov eax,DWORD PTR [ebx+0x338]
49c8cc: mov eax,DWORD PTR [eax+0x28]
49c8cf: mov edx,0x2c
49c8d4: call 0x461dcc
49c8d9: mov ecx,0x8c
49c8de: sub ecx,DWORD PTR [ebp+0x0]
49c8e1: mov edx,DWORD PTR [ebx+0x2d0]
49c8e7: mov edx,DWORD PTR [edx+0x270]
49c8ed: call 0x46161c
49c8f2: mov eax,ds:0x4b1124
49c8f7: cmp BYTE PTR [eax],0xc
49c8fa: jne 0x49ca4f
49c900: cmp BYTE PTR [esi+0x10],0x2
49c904: je 0x49ca4f
49c90a: cmp BYTE PTR [esi+0xc0],0x2
49c911: je 0x49ca4f
49c917: mov eax,ds:0x4b1144
49c91c: mov edx,0x107
49c921: sub edx,DWORD PTR [eax]
49c923: push edx
49c924: push 0x0
49c926: mov eax,DWORD PTR [ebx+0x308]
49c92c: mov eax,DWORD PTR [eax+0x28]
49c92f: xor edx,edx
49c931: call 0x461dcc
49c936: mov ecx,0x127
49c93b: sub ecx,DWORD PTR [ebp+0x0]
49c93e: mov edx,DWORD PTR [ebx+0x2d0]
49c944: mov edx,DWORD PTR [edx+0x270]
49c94a: call 0x46161c
49c94f: cmp BYTE PTR [edi],0xf
49c952: jae 0x49c98f
49c954: mov eax,ds:0x4b1144
49c959: mov edx,0x78
49c95e: sub edx,DWORD PTR [eax]
49c960: push edx
49c961: push 0x0
49c963: mov eax,DWORD PTR [ebx+0x338]
49c969: mov eax,DWORD PTR [eax+0x28]
49c96c: mov edx,0x2d
49c971: call 0x461dcc
49c976: mov ecx,0x122
49c97b: sub ecx,DWORD PTR [ebp+0x0]
49c97e: mov edx,DWORD PTR [ebx+0x2d0]
49c984: mov edx,DWORD PTR [edx+0x270]
49c98a: call 0x46161c
49c98f: cmp BYTE PTR [edi],0xf
49c992: jb 0x49c9cf
49c994: mov eax,ds:0x4b1144
49c999: mov edx,0x76
49c99e: sub edx,DWORD PTR [eax]
49c9a0: push edx
49c9a1: push 0x0
49c9a3: mov eax,DWORD PTR [ebx+0x338]
49c9a9: mov eax,DWORD PTR [eax+0x28]
49c9ac: mov edx,0x2e
49c9b1: call 0x461dcc
49c9b6: mov ecx,0x124
49c9bb: sub ecx,DWORD PTR [ebp+0x0]
49c9be: mov edx,DWORD PTR [ebx+0x2d0]
49c9c4: mov edx,DWORD PTR [edx+0x270]
49c9ca: call 0x46161c
49c9cf: cmp BYTE PTR [edi],0xf
49c9d2: jae 0x49ca0f
49c9d4: mov eax,ds:0x4b1144
49c9d9: mov edx,0x37
49c9de: sub edx,DWORD PTR [eax]
49c9e0: push edx
49c9e1: push 0x0
49c9e3: mov eax,DWORD PTR [ebx+0x338]
49c9e9: mov eax,DWORD PTR [eax+0x28]
49c9ec: mov edx,0x2f
49c9f1: call 0x461dcc
49c9f6: mov ecx,0x101
49c9fb: sub ecx,DWORD PTR [ebp+0x0]
49c9fe: mov edx,DWORD PTR [ebx+0x2d0]
49ca04: mov edx,DWORD PTR [edx+0x270]
49ca0a: call 0x46161c
49ca0f: cmp BYTE PTR [edi],0xf
49ca12: jb 0x49ca4f
49ca14: mov eax,ds:0x4b1144
49ca19: mov edx,0x35
49ca1e: sub edx,DWORD PTR [eax]
49ca20: push edx
49ca21: push 0x0
49ca23: mov eax,DWORD PTR [ebx+0x338]
49ca29: mov eax,DWORD PTR [eax+0x28]
49ca2c: mov edx,0x2f
49ca31: call 0x461dcc
49ca36: mov ecx,0x103
49ca3b: sub ecx,DWORD PTR [ebp+0x0]
49ca3e: mov edx,DWORD PTR [ebx+0x2d0]
49ca44: mov edx,DWORD PTR [edx+0x270]
49ca4a: call 0x46161c
49ca4f: mov eax,ds:0x4b1124
49ca54: cmp BYTE PTR [eax],0xc
49ca57: jne 0x49cbb6
49ca5d: cmp BYTE PTR [esi+0x10],0x4
49ca61: je 0x49cbb6
49ca67: cmp BYTE PTR [esi+0xc0],0x4
49ca6e: je 0x49cbb6
49ca74: mov eax,ds:0x4b1144
49ca79: mov edx,0xff
49ca7e: sub edx,DWORD PTR [eax]
49ca80: push edx
49ca81: push 0x0
49ca83: mov eax,DWORD PTR [ebx+0x308]
49ca89: mov eax,DWORD PTR [eax+0x28]
49ca8c: xor edx,edx
49ca8e: call 0x461dcc
49ca93: mov ecx,0x9
49ca98: sub ecx,DWORD PTR [ebp+0x0]
49ca9b: mov edx,DWORD PTR [ebx+0x2d0]
49caa1: mov edx,DWORD PTR [edx+0x270]
49caa7: call 0x46161c
49caac: cmp BYTE PTR [edi],0x8
49caaf: jae 0x49caec
49cab1: mov eax,ds:0x4b1144
49cab6: mov edx,0x9a
49cabb: sub edx,DWORD PTR [eax]
49cabd: push edx
49cabe: push 0x0
49cac0: mov eax,DWORD PTR [ebx+0x338]
49cac6: mov eax,DWORD PTR [eax+0x28]
49cac9: mov edx,0xc
49cace: call 0x461dcc
49cad3: mov ecx,0x14
49cad8: sub ecx,DWORD PTR [ebp+0x0]
49cadb: mov edx,DWORD PTR [ebx+0x2d0]
49cae1: mov edx,DWORD PTR [edx+0x270]
49cae7: call 0x46161c
49caec: cmp BYTE PTR [edi],0x8
49caef: jb 0x49cb31
49caf1: cmp BYTE PTR [edi],0x10
49caf4: jae 0x49cb31
49caf6: mov eax,ds:0x4b1144
49cafb: mov edx,0x9f
49cb00: sub edx,DWORD PTR [eax]
49cb02: push edx
49cb03: push 0x0
49cb05: mov eax,DWORD PTR [ebx+0x338]
49cb0b: mov eax,DWORD PTR [eax+0x28]
49cb0e: mov edx,0xd
49cb13: call 0x461dcc
49cb18: mov ecx,0x14
49cb1d: sub ecx,DWORD PTR [ebp+0x0]
49cb20: mov edx,DWORD PTR [ebx+0x2d0]
49cb26: mov edx,DWORD PTR [edx+0x270]
49cb2c: call 0x46161c
49cb31: cmp BYTE PTR [edi],0x10
49cb34: jb 0x49cb76
49cb36: cmp BYTE PTR [edi],0x18
49cb39: jae 0x49cb76
49cb3b: mov eax,ds:0x4b1144
49cb40: mov edx,0x93
49cb45: sub edx,DWORD PTR [eax]
49cb47: push edx
49cb48: push 0x0
49cb4a: mov eax,DWORD PTR [ebx+0x338]
49cb50: mov eax,DWORD PTR [eax+0x28]
49cb53: mov edx,0xe
49cb58: call 0x461dcc
49cb5d: mov ecx,0x14
49cb62: sub ecx,DWORD PTR [ebp+0x0]
49cb65: mov edx,DWORD PTR [ebx+0x2d0]
49cb6b: mov edx,DWORD PTR [edx+0x270]
49cb71: call 0x46161c
49cb76: cmp BYTE PTR [edi],0x18
49cb79: jb 0x49cbb6
49cb7b: mov eax,ds:0x4b1144
49cb80: mov edx,0x9f
49cb85: sub edx,DWORD PTR [eax]
49cb87: push edx
49cb88: push 0x0
49cb8a: mov eax,DWORD PTR [ebx+0x338]
49cb90: mov eax,DWORD PTR [eax+0x28]
49cb93: mov edx,0xd
49cb98: call 0x461dcc
49cb9d: mov ecx,0x14
49cba2: sub ecx,DWORD PTR [ebp+0x0]
49cba5: mov edx,DWORD PTR [ebx+0x2d0]
49cbab: mov edx,DWORD PTR [edx+0x270]
49cbb1: call 0x46161c
49cbb6: mov eax,ds:0x4b1124
49cbbb: cmp BYTE PTR [eax],0xc
49cbbe: jne 0x49cd1d
49cbc4: cmp BYTE PTR [esi+0x10],0xe
49cbc8: je 0x49cd1d
49cbce: cmp BYTE PTR [esi+0xc0],0xe
49cbd5: je 0x49cd1d
49cbdb: mov eax,ds:0x4b1144
49cbe0: mov edx,0x10c
49cbe5: sub edx,DWORD PTR [eax]
49cbe7: push edx
49cbe8: push 0x0
49cbea: mov eax,DWORD PTR [ebx+0x308]
49cbf0: mov eax,DWORD PTR [eax+0x28]
49cbf3: xor edx,edx
49cbf5: call 0x461dcc
49cbfa: mov ecx,0x21b
49cbff: sub ecx,DWORD PTR [ebp+0x0]
49cc02: mov edx,DWORD PTR [ebx+0x2d0]
49cc08: mov edx,DWORD PTR [edx+0x270]
49cc0e: call 0x46161c
49cc13: cmp BYTE PTR [edi],0x8
49cc16: jae 0x49cc53
49cc18: mov eax,ds:0x4b1144
49cc1d: mov edx,0xa0
49cc22: sub edx,DWORD PTR [eax]
49cc24: push edx
49cc25: push 0x0
49cc27: mov eax,DWORD PTR [ebx+0x338]
49cc2d: mov eax,DWORD PTR [eax+0x28]
49cc30: mov edx,0x30
49cc35: call 0x461dcc
49cc3a: mov ecx,0x226
49cc3f: sub ecx,DWORD PTR [ebp+0x0]
49cc42: mov edx,DWORD PTR [ebx+0x2d0]
49cc48: mov edx,DWORD PTR [edx+0x270]
49cc4e: call 0x46161c
49cc53: cmp BYTE PTR [edi],0x8
49cc56: jb 0x49cc98
49cc58: cmp BYTE PTR [edi],0x10
49cc5b: jae 0x49cc98
49cc5d: mov eax,ds:0x4b1144
49cc62: mov edx,0xa1
49cc67: sub edx,DWORD PTR [eax]
49cc69: push edx
49cc6a: push 0x0
49cc6c: mov eax,DWORD PTR [ebx+0x338]
49cc72: mov eax,DWORD PTR [eax+0x28]
49cc75: mov edx,0x31
49cc7a: call 0x461dcc
49cc7f: mov ecx,0x228
49cc84: sub ecx,DWORD PTR [ebp+0x0]
49cc87: mov edx,DWORD PTR [ebx+0x2d0]
49cc8d: mov edx,DWORD PTR [edx+0x270]
49cc93: call 0x46161c
49cc98: cmp BYTE PTR [edi],0x10
49cc9b: jb 0x49ccdd
49cc9d: cmp BYTE PTR [edi],0x18
49cca0: jae 0x49ccdd
49cca2: mov eax,ds:0x4b1144
49cca7: mov edx,0xa0
49ccac: sub edx,DWORD PTR [eax]
49ccae: push edx
49ccaf: push 0x0
49ccb1: mov eax,DWORD PTR [ebx+0x338]
49ccb7: mov eax,DWORD PTR [eax+0x28]
49ccba: mov edx,0x30
49ccbf: call 0x461dcc
49ccc4: mov ecx,0x226
49ccc9: sub ecx,DWORD PTR [ebp+0x0]
49cccc: mov edx,DWORD PTR [ebx+0x2d0]
49ccd2: mov edx,DWORD PTR [edx+0x270]
49ccd8: call 0x46161c
49ccdd: cmp BYTE PTR [edi],0x18
49cce0: jb 0x49cd1d
49cce2: mov eax,ds:0x4b1144
49cce7: mov edx,0xa1
49ccec: sub edx,DWORD PTR [eax]
49ccee: push edx
49ccef: push 0x0
49ccf1: mov eax,DWORD PTR [ebx+0x338]
49ccf7: mov eax,DWORD PTR [eax+0x28]
49ccfa: mov edx,0x31
49ccff: call 0x461dcc
49cd04: mov ecx,0x228
49cd09: sub ecx,DWORD PTR [ebp+0x0]
49cd0c: mov edx,DWORD PTR [ebx+0x2d0]
49cd12: mov edx,DWORD PTR [edx+0x270]
49cd18: call 0x46161c
49cd1d: add esp,0xc
49cd20: pop ebp
49cd21: pop edi
49cd22: pop esi
49cd23: pop ebx
49cd24: ret
.data 4b0ef0 e8444b000c204b0030b8
.data 4b1094 c0444b0009584b0078b6
.data 4b11b4 c8444b00a0b640003470
.data 4b1124 d8444b0024714000580a
.data 4b1144 cc444b0004004b0098b8
.data 49cd28 000000400000a0400000
.data 49cd2c 0000a04000008c42558b
.data 49cd30 00008c42558becb92800
