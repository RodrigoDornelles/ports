; entry 490bb8
490bb8: push ebp
490bb9: mov ebp,esp
490bbb: add esp,0xffffffec
490bbe: push ebx
490bbf: push esi
490bc0: push edi
490bc1: mov WORD PTR [ebp-0x2],cx
490bc5: mov ebx,edx
490bc7: mov edi,eax
490bc9: mov esi,DWORD PTR ds:0x4b0ef0
490bcf: mov BYTE PTR [ebp-0x3],0x0
490bd3: xor eax,eax
490bd5: mov al,bl
490bd7: imul eax,eax,0x16
490bda: mov dl,BYTE PTR [ebp+0xc]
490bdd: mov BYTE PTR [esi+eax*8-0x45],dl
490be1: xor edx,edx
490be3: mov dl,BYTE PTR [ebp+0x8]
490be6: mov WORD PTR [esi+eax*8-0x3c],dx
490beb: mov eax,DWORD PTR [edi+0x2d0]
490bf1: mov eax,DWORD PTR [eax+0x270]
490bf7: call 0x45cd9c
490bfc: call 0x45bb18
490c01: mov dx,WORD PTR [ebp-0x2]
490c05: sub dx,0x23
490c09: mov eax,ds:0x4b11b4
490c0e: mov ax,WORD PTR [eax]
490c11: sub dx,ax
490c14: mov WORD PTR [ebp-0xa],dx
490c18: mov eax,ds:0x4b11f8
490c1d: movsx eax,WORD PTR [eax]
490c20: movsx edx,WORD PTR [ebp+0x10]
490c24: sub eax,edx
490c26: mov DWORD PTR [ebp-0x14],eax
490c29: fild DWORD PTR [ebp-0x14]
490c2c: fdiv DWORD PTR ds:0x4914b4
490c32: call 0x402894
490c37: mov edx,DWORD PTR ds:0x4b11f8
490c3d: mov dx,WORD PTR [edx]
490c40: sub dx,0xc
490c44: sub dx,ax
490c47: mov eax,ds:0x4b1144
490c4c: sub dx,WORD PTR [eax]
490c4f: mov WORD PTR [ebp-0xc],dx
490c53: mov eax,ds:0x4b11f8
490c58: mov eax,ds:0x4b11f8
490c5d: movsx eax,WORD PTR [eax]
490c60: movsx edx,WORD PTR [ebp+0x10]
490c64: sub eax,edx
490c66: mov DWORD PTR [ebp-0x14],eax
490c69: fild DWORD PTR [ebp-0x14]
490c6c: fdiv DWORD PTR ds:0x4914b4
490c72: call 0x402894
490c77: mov eax,ds:0x4b1144
490c7c: movsx eax,WORD PTR [ebp-0xc]
490c80: push eax
490c81: push 0x0
490c83: mov eax,DWORD PTR [edi+0x308]
490c89: mov eax,DWORD PTR [eax+0x28]
490c8c: xor edx,edx
490c8e: call 0x461dcc
490c93: movsx ecx,WORD PTR [ebp-0xa]
490c97: mov edx,DWORD PTR [edi+0x2d0]
490c9d: mov edx,DWORD PTR [edx+0x270]
490ca3: call 0x46161c
490ca8: xor eax,eax
490caa: mov al,bl
490cac: imul eax,eax,0x16
490caf: mov al,BYTE PTR [esi+eax*8-0x45]
490cb3: cmp al,0x1
490cb5: je 0x490ccd
490cb7: xor edx,edx
490cb9: mov dl,bl
490cbb: imul edx,edx,0x16
490cbe: cmp al,0x2
490cc0: je 0x490ccd
490cc2: xor edx,edx
490cc4: mov dl,bl
490cc6: imul edx,edx,0x16
490cc9: cmp al,0x7
490ccb: jne 0x490d43
490ccd: xor eax,eax
490ccf: mov al,bl
490cd1: imul eax,eax,0x16
490cd4: cmp BYTE PTR [esi+eax*8-0x38],0x0
490cd9: jne 0x490d43
490cdb: xor eax,eax
490cdd: mov al,bl
490cdf: imul eax,eax,0x16
490ce2: fld QWORD PTR [esi+eax*8-0xb0]
490ce9: xor eax,eax
490ceb: mov al,bl
490ced: mov edx,0x3
490cf2: sub edx,eax
490cf4: imul eax,edx,0x16
490cf7: fcomp QWORD PTR [esi+eax*8-0xb0]
490cfe: fnstsw ax
490d00: sahf
490d01: jae 0x490d0f
490d03: xor eax,eax
490d05: mov al,bl
490d07: imul eax,eax,0x16
490d0a: mov BYTE PTR [esi+eax*8-0x43],0x1
490d0f: xor eax,eax
490d11: mov al,bl
490d13: imul eax,eax,0x16
490d16: fld QWORD PTR [esi+eax*8-0xb0]
490d1d: xor eax,eax
490d1f: mov al,bl
490d21: mov edx,0x3
490d26: sub edx,eax
490d28: imul eax,edx,0x16
490d2b: fcomp QWORD PTR [esi+eax*8-0xb0]
490d32: fnstsw ax
490d34: sahf
490d35: jb 0x490d43
490d37: xor eax,eax
490d39: mov al,bl
490d3b: imul eax,eax,0x16
490d3e: mov BYTE PTR [esi+eax*8-0x43],0x2
490d43: mov eax,ds:0x4b0fcc
490d48: cmp BYTE PTR [eax],0x1
490d4b: jne 0x490f30
490d51: xor eax,eax
490d53: mov al,bl
490d55: imul eax,eax,0x16
490d58: mov eax,DWORD PTR [esi+eax*8-0x88]
490d5f: movsx edx,WORD PTR [ebp-0x2]
490d63: add eax,edx
490d65: mov edx,DWORD PTR ds:0x4b11b4
490d6b: sub eax,DWORD PTR [edx]
490d6d: push eax
490d6e: xor eax,eax
490d70: mov al,bl
490d72: imul eax,eax,0x16
490d75: movsx eax,WORD PTR [esi+eax*8-0x36]
490d7a: movsx edx,WORD PTR [ebp+0x10]
490d7e: sub edx,eax
490d80: xor eax,eax
490d82: mov al,bl
490d84: imul eax,eax,0x16
490d87: add edx,DWORD PTR [esi+eax*8-0x84]
490d8e: mov eax,ds:0x4b1144
490d93: sub edx,DWORD PTR [eax]
490d95: push edx
490d96: mov cl,0xff
490d98: mov dl,0x32
490d9a: mov al,0x32
490d9c: call 0x406de4
490da1: push eax
490da2: xor eax,eax
490da4: mov al,bl
490da6: imul eax,eax,0x16
490da9: movsx eax,WORD PTR [esi+eax*8-0x36]
490dae: movsx ecx,WORD PTR [ebp+0x10]
490db2: sub ecx,eax
490db4: mov eax,ds:0x4b1144
490db9: sub ecx,DWORD PTR [eax]
490dbb: xor eax,eax
490dbd: mov al,bl
490dbf: imul eax,eax,0x16
490dc2: add ecx,DWORD PTR [esi+eax*8-0x8c]
490dc9: xor eax,eax
490dcb: mov al,bl
490dcd: imul eax,eax,0x16
490dd0: mov edx,DWORD PTR [esi+eax*8-0x90]
490dd7: movsx eax,WORD PTR [ebp-0x2]
490ddb: add edx,eax
490ddd: mov eax,ds:0x4b11b4
490de2: sub edx,DWORD PTR [eax]
490de4: mov eax,edi
490de6: call 0x48e444
490deb: xor eax,eax
490ded: mov al,bl
490def: imul eax,eax,0x16
490df2: cmp BYTE PTR [esi+eax*8-0x48],0x1
490df7: jne 0x490e8b
490dfd: xor eax,eax
490dff: mov al,bl
490e01: imul eax,eax,0x16
490e04: mov eax,DWORD PTR [esi+eax*8-0x78]
490e08: movsx edx,WORD PTR [ebp-0x2]
490e0c: add eax,edx
490e0e: mov edx,DWORD PTR ds:0x4b11b4
490e14: sub eax,DWORD PTR [edx]
490e16: push eax
490e17: xor eax,eax
490e19: mov al,bl
490e1b: imul eax,eax,0x16
490e1e: movsx eax,WORD PTR [esi+eax*8-0x36]
490e23: movsx edx,WORD PTR [ebp+0x10]
490e27: sub edx,eax
490e29: xor eax,eax
490e2b: mov al,bl
490e2d: imul eax,eax,0x16
490e30: add edx,DWORD PTR [esi+eax*8-0x74]
490e34: mov eax,ds:0x4b1144
490e39: sub edx,DWORD PTR [eax]
490e3b: push edx
490e3c: mov cl,0x32
490e3e: mov dl,0x32
490e40: mov al,0xff
490e42: call 0x406de4
490e47: push eax
490e48: xor eax,eax
490e4a: mov al,bl
490e4c: imul eax,eax,0x16
490e4f: movsx eax,WORD PTR [esi+eax*8-0x36]
490e54: movsx ecx,WORD PTR [ebp+0x10]
490e58: sub ecx,eax
490e5a: mov eax,ds:0x4b1144
490e5f: sub ecx,DWORD PTR [eax]
490e61: xor eax,eax
490e63: mov al,bl
490e65: imul eax,eax,0x16
490e68: add ecx,DWORD PTR [esi+eax*8-0x7c]
490e6c: xor eax,eax
490e6e: mov al,bl
490e70: imul eax,eax,0x16
490e73: mov edx,DWORD PTR [esi+eax*8-0x80]
490e77: movsx eax,WORD PTR [ebp-0x2]
490e7b: add edx,eax
490e7d: mov eax,ds:0x4b11b4
490e82: sub edx,DWORD PTR [eax]
490e84: mov eax,edi
490e86: call 0x48e444
490e8b: xor eax,eax
490e8d: mov al,bl
490e8f: imul eax,eax,0x16
490e92: fld QWORD PTR [esi+eax*8-0xb0]
490e99: call 0x402894
490e9e: mov edx,DWORD PTR ds:0x4b11b4
490ea4: sub eax,DWORD PTR [edx]
490ea6: push eax
490ea7: push 0x12c
490eac: mov cl,0xff
490eae: mov dl,0xff
490eb0: mov al,0xff
490eb2: call 0x406de4
490eb7: push eax
490eb8: xor eax,eax
490eba: mov al,bl
490ebc: imul eax,eax,0x16
490ebf: fld QWORD PTR [esi+eax*8-0xb0]
490ec6: call 0x402894
490ecb: mov edx,eax
490ecd: mov eax,ds:0x4b11b4
490ed2: sub edx,DWORD PTR [eax]
490ed4: xor ecx,ecx
490ed6: mov eax,edi
490ed8: call 0x48e4c0
490edd: push 0x190
490ee2: xor eax,eax
490ee4: mov al,bl
490ee6: imul eax,eax,0x16
490ee9: fld QWORD PTR [esi+eax*8-0xa8]
490ef0: call 0x402894
490ef5: mov edx,DWORD PTR ds:0x4b1144
490efb: sub eax,DWORD PTR [edx]
490efd: inc eax
490efe: push eax
490eff: mov cl,0xff
490f01: mov dl,0xff
490f03: mov al,0xff
490f05: call 0x406de4
490f0a: push eax
490f0b: xor eax,eax
490f0d: mov al,bl
490f0f: imul eax,eax,0x16
490f12: fld QWORD PTR [esi+eax*8-0xa8]
490f19: call 0x402894
490f1e: mov ecx,eax
490f20: mov eax,ds:0x4b1144
490f25: sub ecx,DWORD PTR [eax]
490f27: xor edx,edx
490f29: mov eax,edi
490f2b: call 0x48e4c0
490f30: mov eax,ds:0x4b1074
490f35: cmp BYTE PTR [eax],0x0
490f38: jne 0x490f4b
490f3a: mov eax,ds:0x4b0e84
490f3f: cmp BYTE PTR [eax],0x0
490f42: jne 0x490f4b
490f44: mov eax,ebx
490f46: call 0x47d21c
490f4b: cmp bl,0x1
490f4e: jne 0x490f54
490f50: mov BYTE PTR [ebp-0x3],0x0
490f54: cmp bl,0x2
490f57: jne 0x490f5d
490f59: mov BYTE PTR [ebp-0x3],0x32
490f5d: xor eax,eax
490f5f: mov al,bl
490f61: imul eax,eax,0x16
490f64: cmp BYTE PTR [esi+eax*8-0x44],0x0
490f69: jne 0x490f73
490f6b: mov dl,BYTE PTR [ebp-0x3]
490f6e: inc edx
490f6f: mov BYTE PTR [esi+eax*8-0x44],dl
490f73: mov BYTE PTR [ebp-0x4],0x0
490f77: xor eax,eax
490f79: mov al,bl
490f7b: imul eax,eax,0x16
490f7e: mov al,BYTE PTR [esi+eax*8-0x45]
490f82: cmp al,0x11
490f84: je 0x490f91
490f86: xor edx,edx
490f88: mov dl,bl
490f8a: imul edx,edx,0x16
490f8d: cmp al,0x12
490f8f: jne 0x490fa0
490f91: mov eax,0xa
490f96: call 0x402a1c
490f9b: add al,0xfb
490f9d: mov BYTE PTR [ebp-0x4],al
490fa0: xor eax,eax
490fa2: mov al,bl
490fa4: imul eax,eax,0x16
490fa7: cmp BYTE PTR [esi+eax*8-0x45],0x13
490fac: jne 0x490fc7
490fae: mov eax,ds:0x4b0e84
490fb3: cmp BYTE PTR [eax],0x0
490fb6: jbe 0x490fc7
490fb8: mov eax,0xe
490fbd: call 0x402a1c
490fc2: add al,0xf9
490fc4: mov BYTE PTR [ebp-0x4],al
490fc7: xor eax,eax
490fc9: mov al,bl
490fcb: imul eax,eax,0x16
490fce: mov al,BYTE PTR [esi+eax*8-0x45]
490fd2: cmp al,0x11
490fd4: je 0x490fec
490fd6: xor edx,edx
490fd8: mov dl,bl
490fda: imul edx,edx,0x16
490fdd: cmp al,0x12
490fdf: je 0x490fec
490fe1: xor edx,edx
490fe3: mov dl,bl
490fe5: imul edx,edx,0x16
490fe8: cmp al,0x13
490fea: jne 0x491005
490fec: mov eax,ds:0x4b0e84
490ff1: cmp BYTE PTR [eax],0xf
490ff4: jbe 0x491005
490ff6: mov eax,0x14
490ffb: call 0x402a1c
491000: add al,0xf6
491002: mov BYTE PTR [ebp-0x4],al
491005: mov eax,ds:0x4b0e84
49100a: cmp BYTE PTR [eax],0x0
49100d: jne 0x491037
49100f: mov eax,ds:0x4b1074
491014: cmp BYTE PTR [eax],0x0
491017: jne 0x491037
491019: xor eax,eax
49101b: mov al,bl
49101d: imul eax,eax,0x16
491020: mov ax,WORD PTR [esi+eax*8-0x98]
491028: xor edx,edx
49102a: mov dl,bl
49102c: imul edx,edx,0x16
49102f: add WORD PTR [esi+edx*8-0x9a],ax
491037: xor eax,eax
491039: mov al,bl
49103b: imul eax,eax,0x16
49103e: mov al,BYTE PTR [esi+eax*8-0x45]
491042: cmp al,0xc
491044: je 0x491073
491046: xor edx,edx
491048: mov dl,bl
49104a: imul edx,edx,0x16
49104d: cmp al,0x13
49104f: je 0x491073
491051: xor eax,eax
491053: mov al,bl
491055: imul eax,eax,0x16
491058: mov WORD PTR [esi+eax*8-0x9a],0x0
491062: xor eax,eax
491064: mov al,bl
491066: imul eax,eax,0x16
491069: mov WORD PTR [esi+eax*8-0x98],0x0
491073: xor eax,eax
491075: mov al,bl
491077: imul eax,eax,0x16
49107a: cmp BYTE PTR [esi+eax*8-0x43],0x1
49107f: jne 0x49127e
491085: mov eax,DWORD PTR [edi+0x320]
49108b: mov eax,DWORD PTR [eax+0x28]
49108e: call 0x40efcc
491093: xor edx,edx
491095: mov dl,bl
491097: imul edx,edx,0x16
49109a: movzx edx,BYTE PTR [esi+edx*8-0x44]
49109f: cmp eax,edx
4910a1: jle 0x49127e
4910a7: mov eax,ebx
4910a9: call 0x473728
4910ae: mov dx,WORD PTR [ebp-0x2]
4910b2: sub dx,ax
4910b5: movsx eax,BYTE PTR [ebp-0x4]
4910b9: add dx,ax
4910bc: mov eax,ds:0x4b11b4
4910c1: sub dx,WORD PTR [eax]
4910c4: mov WORD PTR [ebp-0x6],dx
4910c8: xor eax,eax
4910ca: mov al,bl
4910cc: imul eax,eax,0x16
4910cf: mov dx,WORD PTR [ebp+0x10]
4910d3: sub dx,WORD PTR [esi+eax*8-0x36]
4910d8: mov eax,ds:0x4b1144
4910dd: sub dx,WORD PTR [eax]
4910e0: mov WORD PTR [ebp-0x8],dx
4910e4: mov eax,ebx
4910e6: call 0x473728
4910eb: mov dx,WORD PTR [ebp-0x2]
4910ef: sub dx,ax
4910f2: movsx eax,BYTE PTR [ebp-0x4]
4910f6: add dx,ax
4910f9: mov eax,ds:0x4b11b4
4910fe: sub dx,WORD PTR [eax]
491101: push edx
491102: xor eax,eax
491104: mov al,bl
491106: imul eax,eax,0x16
491109: xor edx,edx
49110b: mov dl,BYTE PTR [esi+eax*8-0x44]
49110f: mov eax,DWORD PTR [edi+0x320]
491115: mov eax,DWORD PTR [eax+0x28]
491118: call 0x461dcc
49111d: call 0x461608
491122: mov DWORD PTR [ebp-0x14],eax
491125: fild DWORD PTR [ebp-0x14]
491128: fdiv DWORD PTR ds:0x4914b8
49112e: call 0x402894
491133: pop edx
491134: add dx,ax
491137: mov WORD PTR [ebp-0xa],dx
49113b: xor eax,eax
49113d: mov al,bl
49113f: imul eax,eax,0x16
491142: xor edx,edx
491144: mov dl,BYTE PTR [esi+eax*8-0x44]
491148: mov eax,DWORD PTR [edi+0x320]
49114e: mov eax,DWORD PTR [eax+0x28]
491151: call 0x461dcc
491156: call 0x4615e0
49115b: mov DWORD PTR [ebp-0x14],eax
49115e: fild DWORD PTR [ebp-0x14]
491161: fdiv DWORD PTR ds:0x4914b8
491167: call 0x402894
49116c: xor edx,edx
49116e: mov dl,bl
491170: imul edx,edx,0x16
491173: mov cx,WORD PTR [ebp+0x10]
491177: sub cx,WORD PTR [esi+edx*8-0x36]
49117c: mov edx,DWORD PTR ds:0x4b1144
491182: sub cx,WORD PTR [edx]
491185: add ax,cx
491188: mov WORD PTR [ebp-0xc],ax
49118c: xor eax,eax
49118e: mov al,bl
491190: imul eax,eax,0x16
491193: xor edx,edx
491195: mov dl,BYTE PTR [esi+eax*8-0x44]
491199: mov eax,DWORD PTR [edi+0x320]
49119f: mov eax,DWORD PTR [eax+0x28]
4911a2: call 0x461dcc
4911a7: call 0x461608
4911ac: mov WORD PTR [ebp-0xe],ax
4911b0: xor eax,eax
4911b2: mov al,bl
4911b4: imul eax,eax,0x16
4911b7: mov ax,WORD PTR [esi+eax*8-0x36]
4911bc: mov WORD PTR [ebp-0x10],ax
4911c0: xor eax,eax
4911c2: mov al,bl
4911c4: imul eax,eax,0x16
4911c7: cmp WORD PTR [esi+eax*8-0x98],0x0
4911d0: jne 0x491209
4911d2: movsx eax,WORD PTR [ebp-0x8]
4911d6: push eax
4911d7: push 0x0
4911d9: xor eax,eax
4911db: mov al,bl
4911dd: imul eax,eax,0x16
4911e0: xor edx,edx
4911e2: mov dl,BYTE PTR [esi+eax*8-0x44]
4911e6: mov eax,DWORD PTR [edi+0x320]
4911ec: mov eax,DWORD PTR [eax+0x28]
4911ef: call 0x461dcc
4911f4: movsx ecx,WORD PTR [ebp-0x6]
4911f8: mov edx,DWORD PTR [edi+0x2d0]
4911fe: mov edx,DWORD PTR [edx+0x270]
491204: call 0x46161c
491209: xor eax,eax
49120b: mov al,bl
49120d: imul eax,eax,0x16
491210: cmp WORD PTR [esi+eax*8-0x98],0x0
491219: je 0x49127e
49121b: movsx eax,WORD PTR [ebp-0xc]
49121f: push eax
491220: movsx eax,WORD PTR [ebp-0xe]
491224: push eax
491225: movsx eax,WORD PTR [ebp-0x10]
491229: push eax
49122a: push 0x0
49122c: push 0x3fe00000
491231: push 0x0
491233: push 0x3fe00000
491238: push 0x0
49123a: xor eax,eax
49123c: mov al,bl
49123e: imul eax,eax,0x16
491241: fild WORD PTR [esi+eax*8-0x9a]
491248: call 0x402894
49124d: push eax
49124e: xor eax,eax
491250: mov al,bl
491252: imul eax,eax,0x16
491255: xor edx,edx
491257: mov dl,BYTE PTR [esi+eax*8-0x44]
49125b: mov eax,DWORD PTR [edi+0x320]
491261: mov eax,DWORD PTR [eax+0x28]
491264: call 0x461dcc
491269: movsx ecx,WORD PTR [ebp-0xa]
49126d: mov edx,DWORD PTR [edi+0x2d0]
491273: mov edx,DWORD PTR [edx+0x270]
491279: call 0x461714
49127e: xor eax,eax
491280: mov al,bl
491282: imul eax,eax,0x16
491285: cmp BYTE PTR [esi+eax*8-0x43],0x2
49128a: jne 0x4914aa
491290: mov eax,DWORD PTR [edi+0x324]
491296: mov eax,DWORD PTR [eax+0x28]
491299: call 0x40efcc
49129e: xor edx,edx
4912a0: mov dl,bl
4912a2: imul edx,edx,0x16
4912a5: movzx edx,BYTE PTR [esi+edx*8-0x44]
4912aa: cmp eax,edx
4912ac: jle 0x4914aa
4912b2: mov eax,ebx
4912b4: call 0x473728
4912b9: add ax,WORD PTR [ebp-0x2]
4912bd: movsx edx,BYTE PTR [ebp-0x4]
4912c1: add ax,dx
4912c4: mov edx,DWORD PTR ds:0x4b11b4
4912ca: sub ax,WORD PTR [edx]
4912cd: push eax
4912ce: xor eax,eax
4912d0: mov al,bl
4912d2: imul eax,eax,0x16
4912d5: xor edx,edx
4912d7: mov dl,BYTE PTR [esi+eax*8-0x44]
4912db: mov eax,DWORD PTR [edi+0x320]
4912e1: mov eax,DWORD PTR [eax+0x28]
4912e4: call 0x461dcc
4912e9: call 0x461608
4912ee: pop edx
4912ef: sub dx,ax
4912f2: mov WORD PTR [ebp-0x6],dx
4912f6: xor eax,eax
4912f8: mov al,bl
4912fa: imul eax,eax,0x16
4912fd: mov dx,WORD PTR [ebp+0x10]
491301: sub dx,WORD PTR [esi+eax*8-0x36]
491306: mov eax,ds:0x4b1144
49130b: sub dx,WORD PTR [eax]
49130e: mov WORD PTR [ebp-0x8],dx
491312: mov eax,ebx
491314: call 0x473728
491319: add ax,WORD PTR [ebp-0x2]
49131d: movsx edx,BYTE PTR [ebp-0x4]
491321: add ax,dx
491324: mov edx,DWORD PTR ds:0x4b11b4
49132a: sub ax,WORD PTR [edx]
49132d: push eax
49132e: xor eax,eax
491330: mov al,bl
491332: imul eax,eax,0x16
491335: xor edx,edx
491337: mov dl,BYTE PTR [esi+eax*8-0x44]
49133b: mov eax,DWORD PTR [edi+0x320]
491341: mov eax,DWORD PTR [eax+0x28]
491344: call 0x461dcc
491349: call 0x461608
49134e: mov DWORD PTR [ebp-0x14],eax
491351: fild DWORD PTR [ebp-0x14]
491354: fdiv DWORD PTR ds:0x4914b8
49135a: call 0x402894
49135f: pop edx
491360: sub dx,ax
491363: mov WORD PTR [ebp-0xa],dx
491367: xor eax,eax
491369: mov al,bl
49136b: imul eax,eax,0x16
49136e: xor edx,edx
491370: mov dl,BYTE PTR [esi+eax*8-0x44]
491374: mov eax,DWORD PTR [edi+0x320]
49137a: mov eax,DWORD PTR [eax+0x28]
49137d: call 0x461dcc
491382: call 0x4615e0
491387: mov DWORD PTR [ebp-0x14],eax
49138a: fild DWORD PTR [ebp-0x14]
49138d: fdiv DWORD PTR ds:0x4914b8
491393: call 0x402894
491398: xor edx,edx
49139a: mov dl,bl
49139c: imul edx,edx,0x16
49139f: mov cx,WORD PTR [ebp+0x10]
4913a3: sub cx,WORD PTR [esi+edx*8-0x36]
4913a8: mov edx,DWORD PTR ds:0x4b1144
4913ae: sub cx,WORD PTR [edx]
4913b1: add ax,cx
4913b4: mov WORD PTR [ebp-0xc],ax
4913b8: xor eax,eax
4913ba: mov al,bl
4913bc: imul eax,eax,0x16
4913bf: xor edx,edx
4913c1: mov dl,BYTE PTR [esi+eax*8-0x44]
4913c5: mov eax,DWORD PTR [edi+0x320]
4913cb: mov eax,DWORD PTR [eax+0x28]
4913ce: call 0x461dcc
4913d3: call 0x461608
4913d8: mov WORD PTR [ebp-0xe],ax
4913dc: xor eax,eax
4913de: mov al,bl
4913e0: imul eax,eax,0x16
4913e3: mov ax,WORD PTR [esi+eax*8-0x36]
4913e8: mov WORD PTR [ebp-0x10],ax
4913ec: xor eax,eax
4913ee: mov al,bl
4913f0: imul eax,eax,0x16
4913f3: cmp WORD PTR [esi+eax*8-0x98],0x0
4913fc: jne 0x491435
4913fe: movsx eax,WORD PTR [ebp-0x8]
491402: push eax
491403: push 0x0
491405: xor eax,eax
491407: mov al,bl
491409: imul eax,eax,0x16
49140c: xor edx,edx
49140e: mov dl,BYTE PTR [esi+eax*8-0x44]
491412: mov eax,DWORD PTR [edi+0x324]
491418: mov eax,DWORD PTR [eax+0x28]
49141b: call 0x461dcc
491420: movsx ecx,WORD PTR [ebp-0x6]
491424: mov edx,DWORD PTR [edi+0x2d0]
49142a: mov edx,DWORD PTR [edx+0x270]
491430: call 0x46161c
491435: xor eax,eax
491437: mov al,bl
491439: imul eax,eax,0x16
49143c: cmp WORD PTR [esi+eax*8-0x98],0x0
491445: je 0x4914aa
491447: movsx eax,WORD PTR [ebp-0xc]
49144b: push eax
49144c: movsx eax,WORD PTR [ebp-0xe]
491450: push eax
491451: movsx eax,WORD PTR [ebp-0x10]
491455: push eax
491456: push 0x0
491458: push 0x3fe00000
49145d: push 0x0
49145f: push 0x3fe00000
491464: push 0x0
491466: xor eax,eax
491468: mov al,bl
49146a: imul eax,eax,0x16
49146d: fild WORD PTR [esi+eax*8-0x9a]
491474: call 0x402894
491479: push eax
49147a: xor eax,eax
49147c: mov al,bl
49147e: imul eax,eax,0x16
491481: xor edx,edx
491483: mov dl,BYTE PTR [esi+eax*8-0x44]
491487: mov eax,DWORD PTR [edi+0x324]
49148d: mov eax,DWORD PTR [eax+0x28]
491490: call 0x461dcc
491495: movsx ecx,WORD PTR [ebp-0xa]
491499: mov edx,DWORD PTR [edi+0x2d0]
49149f: mov edx,DWORD PTR [edx+0x270]
4914a5: call 0x461714
4914aa: pop edi
4914ab: pop esi
4914ac: pop ebx
4914ad: mov esp,ebp
4914af: pop ebp
4914b0: ret 0xc
.data 4b0ef0 e8444b000c204b0030b8
.data 4b11b4 c8444b00a0b640003470
.data 4b11f8 98444b00db444b004027
.data 4914b4 0000404100000040558b
.data 4b1144 cc444b0004004b0098b8
.data 4b0fcc a5584b00a1584b00df44
.data 4b1074 f8574b00c8274b00d470
.data 4b0e84 f9574b00c8b64000f0b6
.data 4914b8 00000040558bec81c4fc
