; entry 494bd8
494bd8: push ebx
494bd9: push esi
494bda: push edi
494bdb: push ebp
494bdc: add esp,0xffffffdc
494bdf: mov BYTE PTR [esp],dl
494be2: mov edi,eax
494be4: xor eax,eax
494be6: mov al,BYTE PTR [esp]
494be9: imul eax,eax,0x16
494bec: mov edx,DWORD PTR ds:0x4b0ef0
494bf2: cmp BYTE PTR [edx+eax*8-0x12],0x1
494bf7: jne 0x494d1c
494bfd: mov ecx,0x495158
494c02: mov dl,BYTE PTR [esp]
494c05: mov eax,edi
494c07: call 0x4905a8
494c0c: cmp al,0x1
494c0e: jne 0x494c49
494c10: mov ecx,0x495168
494c15: mov dl,BYTE PTR [esp]
494c18: mov eax,edi
494c1a: call 0x4905a8
494c1f: test al,al
494c21: jne 0x494c49
494c23: xor eax,eax
494c25: mov al,BYTE PTR [esp]
494c28: mov edx,0x3
494c2d: sub edx,eax
494c2f: imul eax,edx,0x16
494c32: mov edx,DWORD PTR ds:0x4b0ef0
494c38: cmp BYTE PTR [edx+eax*8-0x48],0x1
494c3d: jne 0x494c49
494c3f: mov dl,0xc
494c41: mov al,BYTE PTR [esp]
494c44: call 0x4775fc
494c49: mov ecx,0x495158
494c4e: mov dl,BYTE PTR [esp]
494c51: mov eax,edi
494c53: call 0x4905a8
494c58: cmp al,0x1
494c5a: jne 0x494c95
494c5c: mov ecx,0x495168
494c61: mov dl,BYTE PTR [esp]
494c64: mov eax,edi
494c66: call 0x4905a8
494c6b: cmp al,0x1
494c6d: jne 0x494c95
494c6f: xor eax,eax
494c71: mov al,BYTE PTR [esp]
494c74: mov edx,0x3
494c79: sub edx,eax
494c7b: imul eax,edx,0x16
494c7e: mov edx,DWORD PTR ds:0x4b0ef0
494c84: cmp BYTE PTR [edx+eax*8-0x48],0x1
494c89: jne 0x494c95
494c8b: mov dl,0xd
494c8d: mov al,BYTE PTR [esp]
494c90: call 0x4775fc
494c95: mov esi,0x50
494c9a: mov ebx,DWORD PTR ds:0x4b1118
494ca0: add ebx,0x2b
494ca3: cmp BYTE PTR [ebx],0x0
494ca6: je 0x494d16
494ca8: cmp BYTE PTR [ebx+0x6],0x1
494cac: jne 0x494d16
494cae: mov al,BYTE PTR [ebx-0x7]
494cb1: cmp al,BYTE PTR [esp]
494cb4: je 0x494d16
494cb6: mov ecx,0x495158
494cbb: mov dl,BYTE PTR [esp]
494cbe: mov eax,edi
494cc0: call 0x4905a8
494cc5: cmp al,0x1
494cc7: jne 0x494ce6
494cc9: mov ecx,0x495168
494cce: mov dl,BYTE PTR [esp]
494cd1: mov eax,edi
494cd3: call 0x4905a8
494cd8: test al,al
494cda: jne 0x494ce6
494cdc: mov dl,0xc
494cde: mov al,BYTE PTR [esp]
494ce1: call 0x4775fc
494ce6: mov ecx,0x495158
494ceb: mov dl,BYTE PTR [esp]
494cee: mov eax,edi
494cf0: call 0x4905a8
494cf5: cmp al,0x1
494cf7: jne 0x494d16
494cf9: mov ecx,0x495168
494cfe: mov dl,BYTE PTR [esp]
494d01: mov eax,edi
494d03: call 0x4905a8
494d08: cmp al,0x1
494d0a: jne 0x494d16
494d0c: mov dl,0xd
494d0e: mov al,BYTE PTR [esp]
494d11: call 0x4775fc
494d16: add ebx,0x38
494d19: dec esi
494d1a: jne 0x494ca3
494d1c: xor eax,eax
494d1e: mov al,BYTE PTR [esp]
494d21: imul eax,eax,0x16
494d24: mov edx,DWORD PTR ds:0x4b0ef0
494d2a: cmp BYTE PTR [edx+eax*8-0x12],0x0
494d2f: jne 0x495148
494d35: mov eax,ds:0x4b0ef0
494d3a: fld QWORD PTR [eax]
494d3c: call 0x402894
494d41: push edx
494d42: push eax
494d43: mov eax,ds:0x4b0ef0
494d48: fld QWORD PTR [eax+0xb0]
494d4e: call 0x402894
494d53: sub DWORD PTR [esp],eax
494d56: sbb DWORD PTR [esp+0x4],edx
494d5a: pop eax
494d5b: pop edx
494d5c: test edx,edx
494d5e: jge 0x494d67
494d60: neg eax
494d62: adc edx,0x0
494d65: neg edx
494d67: mov DWORD PTR [esp+0x4],eax
494d6b: xor ebx,ebx
494d6d: xor ebp,ebp
494d6f: mov BYTE PTR [esp+0x8],0x0
494d74: mov esi,0x50
494d79: mov edi,DWORD PTR ds:0x4b1118
494d7f: add edi,0x31
494d82: cmp BYTE PTR [edi],0x1
494d85: jne 0x494dea
494d87: mov al,BYTE PTR [edi-0xd]
494d8a: cmp al,BYTE PTR [esp]
494d8d: je 0x494dea
494d8f: cmp BYTE PTR [edi-0x6],0x0
494d93: je 0x494dea
494d95: mov bl,0x1
494d97: xor eax,eax
494d99: mov al,BYTE PTR [esp]
494d9c: imul eax,eax,0x16
494d9f: mov edx,DWORD PTR ds:0x4b0ef0
494da5: fld QWORD PTR [edx+eax*8-0xb0]
494dac: call 0x402894
494db1: push edx
494db2: push eax
494db3: fld QWORD PTR [edi-0x31]
494db6: call 0x402894
494dbb: sub DWORD PTR [esp],eax
494dbe: sbb DWORD PTR [esp+0x4],edx
494dc2: pop eax
494dc3: pop edx
494dc4: test edx,edx
494dc6: jge 0x494dcf
494dc8: neg eax
494dca: adc edx,0x0
494dcd: neg edx
494dcf: mov ebp,eax
494dd1: cmp BYTE PTR [edi-0x7],0x1
494dd5: jne 0x494ddc
494dd7: mov BYTE PTR [esp+0x8],0x1
494ddc: mov eax,DWORD PTR [edi-0x29]
494ddf: mov DWORD PTR [esp+0x10],eax
494de3: mov eax,DWORD PTR [edi-0x25]
494de6: mov DWORD PTR [esp+0x14],eax
494dea: add edi,0x38
494ded: dec esi
494dee: jne 0x494d82
494df0: mov eax,ds:0x4b0d50
494df5: movzx eax,BYTE PTR [eax]
494df8: mov edx,0x8
494dfd: sub edx,eax
494dff: mov DWORD PTR [esp+0x20],edx
494e03: fild DWORD PTR [esp+0x20]
494e07: fld TBYTE PTR ds:0x495170
494e0d: fmulp st(1),st
494e0f: fld TBYTE PTR ds:0x49517c
494e15: faddp st(1),st
494e17: fstp QWORD PTR [esp+0x18]
494e1b: fwait
494e1c: mov eax,ds:0x4b116c
494e21: movzx eax,BYTE PTR [eax]
494e24: mov DWORD PTR [esp+0x20],eax
494e28: fild DWORD PTR [esp+0x20]
494e2c: fld TBYTE PTR ds:0x495188
494e32: fmulp st(1),st
494e34: fsubr QWORD PTR [esp+0x18]
494e38: fstp QWORD PTR [esp+0x18]
494e3c: fld QWORD PTR [esp+0x18]
494e41: fcomp DWORD PTR ds:0x495194
494e47: fnstsw ax
494e49: sahf
494e4a: jae 0x494e56
494e4c: xor eax,eax
494e4e: mov DWORD PTR [esp+0x18],eax
494e52: mov DWORD PTR [esp+0x1c],eax
494e56: xor eax,eax
494e58: mov al,BYTE PTR [esp]
494e5b: mov edx,0x3
494e60: sub edx,eax
494e62: imul eax,edx,0x16
494e65: mov edx,DWORD PTR ds:0x4b0ef0
494e6b: cmp BYTE PTR [edx+eax*8-0x48],0x1
494e70: jne 0x494f5e
494e76: cmp DWORD PTR [esp+0x4],0xa0
494e7e: jg 0x494f5e
494e84: mov eax,ds:0x4b11f8
494e89: movsx eax,WORD PTR [eax]
494e8c: sub eax,0x1e
494e8f: mov DWORD PTR [esp+0x20],eax
494e93: fild DWORD PTR [esp+0x20]
494e97: xor eax,eax
494e99: mov al,BYTE PTR [esp]
494e9c: mov edx,0x3
494ea1: sub edx,eax
494ea3: imul eax,edx,0x16
494ea6: mov edx,DWORD PTR ds:0x4b0ef0
494eac: fcomp QWORD PTR [edx+eax*8-0xa8]
494eb3: fnstsw ax
494eb5: sahf
494eb6: jb 0x494eda
494eb8: fld DWORD PTR ds:0x495198
494ebe: fmul QWORD PTR [esp+0x18]
494ec2: call 0x402894
494ec7: call 0x402a1c
494ecc: test eax,eax
494ece: jne 0x494eda
494ed0: mov dl,0xc
494ed2: mov al,BYTE PTR [esp]
494ed5: call 0x4775fc
494eda: mov eax,ds:0x4b11f8
494edf: movsx eax,WORD PTR [eax]
494ee2: sub eax,0x1e
494ee5: mov DWORD PTR [esp+0x20],eax
494ee9: fild DWORD PTR [esp+0x20]
494eed: movzx esi,BYTE PTR [esp]
494ef1: mov eax,0x3
494ef6: sub eax,esi
494ef8: imul eax,eax,0x16
494efb: mov edx,DWORD PTR ds:0x4b0ef0
494f01: fcomp QWORD PTR [edx+eax*8-0xa8]
494f08: fnstsw ax
494f0a: sahf
494f0b: ja 0x494f2f
494f0d: fld DWORD PTR ds:0x495198
494f13: fmul QWORD PTR [esp+0x18]
494f17: call 0x402894
494f1c: call 0x402a1c
494f21: test eax,eax
494f23: jne 0x494f2f
494f25: mov dl,0xd
494f27: mov al,BYTE PTR [esp]
494f2a: call 0x4775fc
494f2f: imul edi,esi,0x16
494f32: mov eax,ds:0x4b0ef0
494f37: cmp BYTE PTR [eax+edi*8-0x45],0x15
494f3c: jne 0x494f48
494f3e: mov dl,0xc
494f40: mov al,BYTE PTR [esp]
494f43: call 0x4775fc
494f48: mov eax,ds:0x4b0ef0
494f4d: cmp BYTE PTR [eax+edi*8-0x45],0x16
494f52: jne 0x494f5e
494f54: mov dl,0xd
494f56: mov al,BYTE PTR [esp]
494f59: call 0x4775fc
494f5e: xor eax,eax
494f60: mov al,BYTE PTR [esp]
494f63: imul eax,eax,0x16
494f66: mov edx,DWORD PTR ds:0x4b0ef0
494f6c: mov al,BYTE PTR [edx+eax*8-0x45]
494f70: cmp al,0x1
494f72: je 0x494f8a
494f74: xor edx,edx
494f76: mov dl,BYTE PTR [esp]
494f79: imul edx,edx,0x16
494f7c: mov ecx,DWORD PTR ds:0x4b0ef0
494f82: cmp al,0x2
494f84: jne 0x4950a8
494f8a: cmp bl,0x1
494f8d: jne 0x494fd4
494f8f: cmp ebp,0x82
494f95: jg 0x494fd4
494f97: xor eax,eax
494f99: mov al,BYTE PTR [esp]
494f9c: imul eax,eax,0x16
494f9f: mov edx,DWORD PTR ds:0x4b0ef0
494fa5: fld QWORD PTR [edx+eax*8-0xa8]
494fac: fsub DWORD PTR ds:0x49519c
494fb2: fcomp QWORD PTR [esp+0x10]
494fb6: fnstsw ax
494fb8: sahf
494fb9: jae 0x494fd4
494fbb: fld DWORD PTR ds:0x4951a0
494fc1: fmul QWORD PTR [esp+0x18]
494fc5: call 0x402894
494fca: call 0x402a1c
494fcf: cmp eax,0x3
494fd2: jle 0x49501c
494fd4: test bl,bl
494fd6: jne 0x4950a8
494fdc: fld DWORD PTR ds:0x4951a4
494fe2: fmul QWORD PTR [esp+0x18]
494fe6: call 0x402894
494feb: call 0x402a1c
494ff0: test eax,eax
494ff2: jne 0x4950a8
494ff8: xor eax,eax
494ffa: mov al,BYTE PTR [esp]
494ffd: imul eax,eax,0x16
495000: mov edx,DWORD PTR ds:0x4b0ef0
495006: cmp BYTE PTR [edx+eax*8-0x46],0x0
49500b: jne 0x4950a8
495011: cmp BYTE PTR [esp+0x8],0x0
495016: jne 0x4950a8
49501c: xor eax,eax
49501e: mov al,BYTE PTR [esp]
495021: imul esi,eax,0x16
495024: mov eax,ds:0x4b0ef0
495029: mov BYTE PTR [eax+esi*8-0x38],0xe0
49502e: mov eax,ds:0x4b0ef0
495033: mov BYTE PTR [eax+esi*8-0x46],0x1
495038: mov eax,ds:0x4b0ef0
49503d: mov BYTE PTR [eax+esi*8-0x45],0xc
495042: mov eax,ds:0x4b0ef0
495047: mov WORD PTR [eax+esi*8-0x3c],0x0
49504e: mov eax,ds:0x4b0ef0
495053: mov WORD PTR [eax+esi*8-0x3a],0x63
49505a: mov eax,ds:0x4b0ef0
49505f: mov BYTE PTR [eax+esi*8-0x1d],0x0
495064: mov eax,ds:0x4b0ef0
495069: cmp BYTE PTR [eax+esi*8-0x43],0x1
49506e: jne 0x49507a
495070: mov eax,ds:0x4b0ef0
495075: mov BYTE PTR [eax+esi*8-0x42],0x3
49507a: mov eax,ds:0x4b0ef0
49507f: cmp BYTE PTR [eax+esi*8-0x43],0x2
495084: jne 0x495090
495086: mov eax,ds:0x4b0ef0
49508b: mov BYTE PTR [eax+esi*8-0x42],0x2
495090: mov eax,0x8
495095: call 0x402a1c
49509a: test eax,eax
49509c: jne 0x4950a8
49509e: mov eax,ds:0x4b0ef0
4950a3: mov BYTE PTR [eax+esi*8-0x42],0x1
4950a8: cmp bl,0x1
4950ab: jne 0x4950f8
4950ad: cmp ebp,0x78
4950b0: jg 0x4950f8
4950b2: xor eax,eax
4950b4: mov al,BYTE PTR [esp]
4950b7: imul eax,eax,0x16
4950ba: mov edx,DWORD PTR ds:0x4b0ef0
4950c0: fld QWORD PTR [edx+eax*8-0xa8]
4950c7: fsub DWORD PTR ds:0x49519c
4950cd: fcomp QWORD PTR [esp+0x10]
4950d1: fnstsw ax
4950d3: sahf
4950d4: jae 0x4950f8
4950d6: fld TBYTE PTR ds:0x4951a8
4950dc: fmul QWORD PTR [esp+0x18]
4950e0: call 0x402894
4950e5: call 0x402a1c
4950ea: test eax,eax
4950ec: jne 0x4950f8
4950ee: mov dl,0xc
4950f0: mov al,BYTE PTR [esp]
4950f3: call 0x4775fc
4950f8: cmp bl,0x1
4950fb: jne 0x495148
4950fd: cmp ebp,0x64
495100: jg 0x495148
495102: xor eax,eax
495104: mov al,BYTE PTR [esp]
495107: imul eax,eax,0x16
49510a: mov edx,DWORD PTR ds:0x4b0ef0
495110: fld QWORD PTR [edx+eax*8-0xa8]
495117: fsub DWORD PTR ds:0x49519c
49511d: fcomp QWORD PTR [esp+0x10]
495121: fnstsw ax
495123: sahf
495124: jb 0x495148
495126: fld DWORD PTR ds:0x4951b4
49512c: fmul QWORD PTR [esp+0x18]
495130: call 0x402894
495135: call 0x402a1c
49513a: test eax,eax
49513c: jne 0x495148
49513e: mov dl,0xd
495140: mov al,BYTE PTR [esp]
495143: call 0x4775fc
495148: add esp,0x24
49514b: pop ebp
49514c: pop edi
49514d: pop esi
49514e: pop ebx
49514f: ret
.data 4b0ef0 e8444b000c204b0030b8
.data 4b1118 48464b00d6444b0040b6
.data 4b0d50 d9444b0004704000c857
.data 495170 66666666666666e6fe3f
.data 49517c 9a99999999999999ff3f
.data 4b116c dd444b00c8b740000862
.data 495188 cdccccccccccccccfb3f
.data 495194 000000000000003f0000
.data 4b11f8 98444b00db444b004027
.data 495198 0000003f0000f0420000
.data 49519c 0000f0420000a0400000
.data 4951a0 0000a04000003442cdcc
.data 4951a4 00003442cdcccccccccc
.data 4951a8 cdccccccccccccccfd3f
.data 4951b4 00002040558bec536bc2
.string 495158 54524153
.string 495168 424149584f
