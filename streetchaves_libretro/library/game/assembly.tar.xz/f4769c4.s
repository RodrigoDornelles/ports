; entry 4769c4
4769c4: push ebp
4769c5: mov ebp,esp
4769c7: push ebx
4769c8: push esi
4769c9: mov ebx,eax
4769cb: shl ebx,0x3
4769ce: sub ebx,eax
4769d0: mov esi,DWORD PTR ds:0x4b1118
4769d6: mov DWORD PTR [esi+ebx*8-0x28],edx
4769da: mov edx,DWORD PTR ds:0x4b1118
4769e0: mov DWORD PTR [edx+ebx*8-0x24],ecx
4769e4: mov edx,DWORD PTR ds:0x4b1118
4769ea: mov ecx,DWORD PTR [ebp+0xc]
4769ed: mov DWORD PTR [edx+ebx*8-0x20],ecx
4769f1: mov eax,ds:0x4b1118
4769f6: mov edx,DWORD PTR [ebp+0x8]
4769f9: mov DWORD PTR [eax+ebx*8-0x1c],edx
4769fd: pop esi
4769fe: pop ebx
4769ff: pop ebp
476a00: ret 0x8
.data 4b1118 48464b00d6444b0040b6
